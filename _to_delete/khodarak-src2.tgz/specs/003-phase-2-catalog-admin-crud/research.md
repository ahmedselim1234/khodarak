# Phase 0 Research: Phase 2 — Catalog + Admin Product CRUD

No `NEEDS CLARIFICATION` markers remain in the Technical Context — the feature spec's own
2026-08-10 Clarifications session already resolved the two decisions that would otherwise have
landed here (cart persistence model, photo-required-at-creation). This document instead records
the design-level decisions made while turning that spec into an implementable plan, in the same
decision/rationale/alternatives format Phase 1's research.md used.

## 1. Where does the cart live?

**Decision**: A new `cart_items` table (`user_id`, `product_id`, `quantity`), owner-scoped by RLS,
for signed-in customers; a Redux slice hydrated from `localStorage` for guests. No separate `carts`
parent table.

**Rationale**: The spec's Clarifications session already settled *that* the cart must be
server-synced per account and device-local for guests. The remaining question was table shape. A
`cart_items` row per `(user, product)` is the direct customer-facing analog of `subscription_items`
(`plan.md` §2) and needs no parent `carts` row, because "the cart" is simply "this user's
`cart_items` rows" — there's never more than one cart per account to disambiguate, unlike
`subscriptions` (which can have many per user over time) or `orders`.

**Alternatives considered**:
- A `carts` + `cart_items` pair (mirroring `orders`/`order_items`) — rejected as an unused extra
  join; `orders` needs its own id because multiple orders exist per subscription over time, but
  there is exactly one cart per user, so `user_id` alone is a sufficient key.
- `redux-persist` for guest cart hydration — rejected; the project has no persistence middleware
  dependency yet, and a single `useEffect` that reads/writes one `localStorage` key on the existing
  `StoreProvider` (Phase 1, `components/providers/StoreProvider.tsx`) covers the same need without
  a new dependency.

## 2. How does `/browse` fetch and filter products?

**Decision**: `/browse` and `/browse/[id]` are Server Components. Category, price range,
availability, sort, and page are all encoded in the URL (`searchParams`); `FilterSidebar`,
`CategoryTabs`, and `SortBar` are small Client Components whose only job is pushing a new URL via
`useRouter`. The Server Component reads `searchParams` and queries `products` directly through the
server Supabase client (`lib/products/queryProducts.ts`).

**Rationale**: Constitution Principle I asks every route to make a deliberate rendering choice and
keep data fetching colocated in Server Components rather than defaulting to client-side fetching.
The product grid is a textbook case: it's a read, it doesn't need per-keystroke reactivity (filters
apply on selection, not on every render frame), and URL-encoded filter state is shareable/bookmarkable
for free. This also keeps the interactive JS surface on `/browse` to three small leaf components
instead of a client-side data-fetching library, which matters for Principle III's Core Web Vitals
budget on an image-heavy page.

**Alternatives considered**:
- An RTK Query `productsApi` (mirroring `addressesApi.ts`) driving a client-rendered grid —
  rejected as the default for the grid itself; it's the right tool for *mutations* (cart, admin
  product writes) where a Route Handler and optimistic UI make sense, but it would make the grid a
  Client Component wrapper for no benefit, working against Principle I.
- Query-string-free client state (e.g., a Zustand/Redux "current filters" slice) — rejected;
  `searchParams` state is what the framework already round-trips through server rendering, and
  duplicating it in client state would just be a second source of truth to keep in sync.

## 3. How do product photo uploads work?

**Decision**: The admin's browser uploads the image file directly to a new Supabase Storage bucket
(`product-images`) using the browser Supabase client, guarded by a storage bucket policy that only
allows writes from `admin`-role users. The `ProductForm`'s submit then sends the resulting public
URL (plus the rest of the product fields) to `/api/admin/products`, which validates it's a URL
from that bucket before persisting.

**Rationale**: Mirrors the reasoning Phase 1 used for Auth calls going browser-to-Supabase directly
instead of proxying through our server: Storage's own RLS-backed bucket policy is what actually
enforces "only admins can write here," so routing the file bytes through our Route Handler first
would add latency (and a multipart-body-handling surface) without adding any real safety. Format
and size are validated client-side before the upload starts (fast feedback) and the resulting URL
is re-validated server-side before it's trusted into `products.image_url` (never trust a client
value at the point it's persisted, even a URL).

**Alternatives considered**:
- Uploading through a `/api/admin/products/upload` Route Handler that proxies the file to Storage —
  rejected; it's strictly more latency and code for the same authorization outcome the bucket
  policy already gives for free, and the constitution's Principle V precedent (client-to-Moyasar
  tokenization bypassing our server) supports letting the browser talk directly to a
  purpose-built, policy-protected storage target.
- A signed-upload-URL flow (Route Handler issues a short-lived signed URL, browser uploads to it) —
  considered as a slightly more locked-down alternative to a standing bucket policy, but rejected
  for this phase as unnecessary complexity: the bucket policy already scopes writes to
  authenticated admins, and a signed-URL indirection only pays for itself once uploads need to be
  unauthenticated or time-boxed for non-admin actors, neither of which applies here.

## 4. Is the cart-bar total "server-side pricing authority" under Constitution Principle II?

**Decision**: No — not yet. The cart bar in this phase renders a live but *non-binding* preview
(current product price × quantity, summed), computed the same way whether the cart is
server-synced or device-local. It does not get snapshotted, charged, or persisted as an order/
subscription value.

**Rationale**: Principle II's gate is specifically about values that get *charged or persisted* as
money owed — it explicitly allows "the browser may render a preview using the same pure function"
as long as the value that's actually charged/persisted always comes from a server recompute at the
moment of the mutation. No such mutation (subscribe, charge, snapshot) exists yet; those begin in
Phase 3 (pricing engine) and Phase 4/5 (subscription creation, snapshot-on-order). Applying
Principle II's full server-authority machinery to a cart preview two phases early would be
speculative complexity the spec's own Assumptions section explicitly rules out ("neither creates an
order, subscription, or server-side price lock in this phase").

**Alternatives considered**:
- Building the real pricing engine's discount/VAT/delivery math early so the cart bar total is
  already "real" — rejected as scope creep; `plan.md` §5 deliberately orders Phase 3 (settings +
  pricing engine) before Phase 4 (subscription builder) specifically so pricing logic isn't
  scattered across earlier phases' UI. The cart bar showing a plain items-subtotal-style number
  (no discount/VAT/delivery yet) is consistent with that ordering, not a shortcut around it.
