---

description: "Task list for Phase 7 — Renewal Engine & Dunning"
---

# Tasks: Phase 7 — Renewal Engine & Dunning

**Input**: Design documents from `/specs/008-phase-7-renewal-engine/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/
(cron-renewals-api.md, process-renewal-outcome.md, webhook-dispatch-amendment.md), quickstart.md

**Tests**: Included — plan.md's Technical Context and research.md explicitly scope Vitest suites
for `advanceDeliveryDate.ts`, `dunningSchedule.ts`, and `cardExpiry.ts` (written and passing
before the Route Handler that uses them, per Constitution Principle VI — the exact "a bug
silently costs real money" class of function), plus a Playwright spec for the phase's demo
scenario.

**Organization**: Tasks are grouped by user story (US1/US2/US3, matching spec.md's priorities:
US1 = P1, US2 = P1, US3 = P2). The split follows each story's own acceptance scenarios precisely:
US1's five scenarios are entirely about the *successful* renewal + skip/self-heal path, US2's five
are entirely about the *failure* → retry → suspend path, and US3's three are specifically about
dropped/unavailable items — so `processRenewalOutcome.ts`, the cron route, and `reprice.ts` are
each built incrementally, one story's slice at a time, on the same shared files (mirroring how
Phase 5's own tasks.md built `processPaymentOutcome.ts` across its US2 then extended it further
in US3).

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Confirm the `app/api/cron/renewals/` directory scaffold (new this phase)

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T002 Create migration `supabase/migrations/<timestamp>_renewal_engine.sql`: `ALTER TABLE
      subscriptions ADD COLUMN` for `renewal_attempt_count` (integer, default 0),
      `next_renewal_attempt_date` (date, nullable), `renewal_claimed_at` (timestamptz, nullable);
      `ALTER TABLE payments ADD COLUMN kind` (`'initial' | 'renewal'`, default `'initial'`,
      backfilling existing rows) and `ALTER TABLE payments ALTER COLUMN moyasar_payment_id DROP
      NOT NULL` (data-model.md — a renewal attempt that never reaches Moyasar still gets its own
      row per FR-012). No new `authenticated`-role write policy on either table
- [X] T003 [P] Update `lib/env.server.ts`: add `CRON_SECRET` to the server-only schema
- [X] T004 [P] Write unit test `tests/unit/validation.cronAuth.test.ts` covering: a correct
      secret (passes), an incorrect one (fails), a missing header (fails)
- [X] T005 Create `lib/validation/cronAuth.ts`: constant-time comparison of the incoming
      `Authorization: Bearer <secret>` header against `serverEnv.CRON_SECRET`, same technique as
      `verifyWebhookSignature.ts` (Phase 5) — depends on T004, T003
- [X] T006 [P] Update `lib/payments/moyasarClient.ts`: add `createRecurringPayment` — `source:
      {type:'token', token}`, `amount`, `currency: 'SAR'`, `description`, `metadata:
      {subscription_id, cycle_number, order_id}` — deliberately no `callback_url`, no `3ds`
      field, per `plan.md` §3b's own example (research.md §2)
- [X] T007 [P] Write unit test `tests/unit/subscription.advanceDeliveryDate.test.ts` covering:
      weekly (+7 days), biweekly (+14 days), monthly (+1 calendar month) period math, and a
      resulting date that falls on a blackout weekday skipping forward to the next non-blackout
      day
- [X] T008 Create `lib/subscription/advanceDeliveryDate.ts`: pure function per research.md §3 —
      depends on T007
- [X] T009 [P] Write unit test `tests/unit/payments.cardExpiry.test.ts` covering: a card already
      expired as of the target delivery date, a card that expires between now and a delayed
      retry's date, and a card still valid throughout
- [X] T010 Create `lib/payments/cardExpiry.ts`: pure function per FR-006 — depends on T009
- [X] T011 [P] Create `lib/subscription/reprice.ts`: server-only — resolves a due pending change
      via Phase 6's existing `resolveEffectiveConfig.ts` (unchanged), loads the resulting items'
      current prices, calls the existing `calculate()` (Phase 3, unchanged) for the fresh
      breakdown. This story's cut handles only the "every item still available" case —
      unavailable-item dropping is added by US3 (T021) — depends on T002
- [X] T012 [P] Extend `lib/subscription/mutateSubscription.ts`: add `claimSubscriptionForRenewal`
      — the single conditional `UPDATE ... WHERE ... RETURNING` claim-lock step (research.md §1)
      — depends on T002

**Checkpoint**: Foundation ready — new schema, the cron auth check, the Moyasar recurring-charge
call, date advancement, card-expiry checking, and the claim lock all exist; user story
implementation can now begin.

---

## Phase 3: User Story 1 - A due subscription renews automatically (Priority: P1) 🎯 MVP

**Goal**: Without any customer action, a subscription due today is re-priced against current
rules, charged, and — on success — gets a new order and an advanced next delivery date; paused/
cancelled subscriptions are skipped, and an overdue pause self-heals independently of the
dashboard.

**Independent Test**: Back-date an active subscription's next delivery date to today, trigger the
renewal endpoint, and confirm a new `payments` row shows `paid`, a new `orders` row (with
`order_items`) now exists matching current rules, and the subscription's next delivery date has
advanced by exactly one frequency period — per quickstart.md steps 2–4.

### Implementation for User Story 1

- [X] T013 [US1] Create `lib/payments/processRenewalOutcome.ts`: the conditional-update
      idempotency guard (keyed by `payments.id`, not `moyasar_payment_id` — research.md §1) plus
      the full `'paid'` branch (order + `order_items` generation, pending-change promotion,
      `next_delivery_date`/`next_renewal_attempt_date` advance via T008,
      `renewal_attempt_count`/`renewal_claimed_at` reset) per contracts/process-renewal-outcome.md
      §3. The `'failed'` branch this story is a minimal stub (records the failure, leaves retry
      state untouched) — US2 (T019) replaces it with the real dunning transition — depends on
      T008, T011
- [X] T014 [US1] Implement `app/api/cron/renewals/route.ts`: `POST` — auth via T005 (`401`
      otherwise); selects `status = 'active' AND next_renewal_attempt_date <= current_date`; for
      each, sequentially: claims it (T012, skip on zero rows), self-heals an overdue pause the
      same way Phase 6's `GET /api/subscriptions/[id]` does (independently, per FR-010, since
      this job may run before any dashboard visit), calls `reprice.ts` (T011), calls
      `moyasarClient.createRecurringPayment` (T006) with the resolved token, inserts a `payments`
      row (`kind: 'renewal'`), and calls `processRenewalOutcome` (T013) — returns the run summary
      per contracts/cron-renewals-api.md — depends on T005, T006, T011, T012, T013
- [X] T015 [US1] Update `app/api/webhooks/moyasar/route.ts` (Phase 5): look up the matching
      `payments` row by `moyasar_payment_id` before dispatching; `kind: 'initial'` →
      `processPaymentOutcome` (Phase 5, unchanged); `kind: 'renewal'` → `processRenewalOutcome`
      (T013), keyed by the looked-up row's own `id` — per
      contracts/webhook-dispatch-amendment.md — depends on T013

**Checkpoint**: User Story 1 is fully functional and independently testable — a due subscription
renews correctly end to end, even though a failed charge doesn't yet retry or suspend.

---

## Phase 4: User Story 2 - A failed charge is retried on a schedule, then the subscription is suspended (Priority: P1)

**Goal**: A failed renewal charge doesn't advance the delivery date; it's retried on a fixed
+1/+3/+5-day schedule against whatever card is currently saved, and once every retry has also
failed, the subscription is automatically paused with no resume date — reusing Phase 6's existing
dashboard surfaces verbatim.

**Independent Test**: Force a renewal charge to fail (a declining test card), confirm the
subscription's delivery date doesn't advance and a specific failure reason is recorded, simulate
each scheduled retry failing in turn, and confirm the subscription becomes paused with no resume
date after the last one — per quickstart.md steps 5–6, the phase's own demo target's second half.

### Tests for User Story 2

> Write this test FIRST; it MUST fail until T018 exists.

- [X] T017 [P] [US2] Write unit test `tests/unit/payments.dunningSchedule.test.ts` covering:
      attempt count 1 → retry at +1 day, count 2 → retry at +3 days (from the *original* failure,
      not the prior retry — research.md §4), count 3 → retry at +5 days, count 4 → suspend

### Implementation for User Story 2

- [X] T018 [US2] Create `lib/payments/dunningSchedule.ts`: pure function
      `nextRetryOrSuspend(attemptCount, firstFailedAt)` per research.md §4 — depends on T017
- [X] T019 [US2] Extend `lib/payments/processRenewalOutcome.ts` (T013): replace the US1 stub
      `'failed'` branch with the real transition — call `dunningSchedule` (T018) with
      `renewal_attempt_count + 1` and the cycle's first-failure timestamp; on `retry`, set
      `renewal_attempt_count`/`next_renewal_attempt_date`, leave `status`/`next_delivery_date`
      untouched (spec.md Clarification 1); on `suspend`, set `status: 'paused'`, `paused_until:
      null`, reset retry state, insert a `subscription_pauses` row with `resume_date: null`
      (spec.md Clarification 2) — depends on T018, T013
- [X] T020 [US2] Extend `app/api/cron/renewals/route.ts` (T014): wire the card-expiry check
      (T010) — an already-expired card short-circuits straight to a `'failed'` outcome with
      `failure_reason: 'card_expired'`, no charge attempted (FR-006) — and the request-level
      Moyasar failure case (`failure_reason: 'provider_error'`, spec.md Clarification 4) into the
      now-complete failure path (T019) — depends on T019, T010, T014

**Checkpoint**: User Stories 1 AND 2 both work — the phase's full headline demo (renew → decline →
retry → suspend) is complete.

---

## Phase 5: User Story 3 - Renewal handles a discontinued product without failing the whole box (Priority: P2)

**Goal**: A product deleted or made unavailable since the last delivery is excluded from the
re-priced charge and the resulting order rather than crashing the whole renewal or silently
charging for something that no longer exists; a box with nothing left available is a recorded
failure, not an empty success.

**Independent Test**: Disable one product in a due, active subscription's box, trigger renewal,
and confirm it still succeeds excluding that product's cost, with the resulting order visibly
missing it; disable every product and confirm the renewal is recorded as a failure instead of an
empty order — per quickstart.md steps 7–8.

### Implementation for User Story 3

- [X] T021 [US3] Extend `lib/subscription/reprice.ts` (T011): drop any product that's been
      deleted or marked unavailable from the item list before calling `calculate()` (FR-004), and
      distinctly signal an empty resulting list (every item unavailable) so the caller can treat
      it as a failure rather than a valid zero-item charge (FR-005) — depends on T011
- [X] T022 [US3] Extend `app/api/cron/renewals/route.ts` (T014/T020): when `reprice.ts` (T021)
      reports an empty item list, skip charging entirely and route straight to the failure
      outcome (T019) with `failure_reason: 'no_available_items'` — depends on T021, T020

**Checkpoint**: All three user stories are independently functional.

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all three stories

- [X] T023 [P] Write Playwright spec `tests/e2e/renewal-engine.spec.ts`: successful renewal
      (order + advanced date), decline → retry-scheduled — quickstart.md steps 2 and 5, plus the
      always-runnable auth-boundary checks (missing/incorrect secret, both `401`). The two
      credentialed suites are `test.skip` pending `CRON_SECRET`/`TEST_ACTIVE_SUBSCRIPTION_ID`/
      `TEST_DECLINING_SUBSCRIPTION_ID` (none available in this sandbox, same constraint noted in
      every prior phase's tasks.md) — not executed against a live server this session.
- [X] T024 [P] Run the full `quickstart.md` validation (all 11 steps) end to end — **not run**:
      requires a live linked Supabase project, real Moyasar test-mode credentials, and seeded
      subscriptions with real saved cards (one succeeding, one declining), none available in this
      sandbox. `npm run build` was run instead and confirms every new/changed route (including
      `/api/cron/renewals` and the amended `/api/webhooks/moyasar`) compiles and type-checks; this
      does not substitute for the manual walkthrough with real test charges.
- [X] T025 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed
      files (Constitution Development Workflow gate) — both clean. Also ran `npm run test:unit`
      (151/151 passing, including the three new suites — `advanceDeliveryDate`, `cardExpiry`,
      `dunningSchedule` — plus every pre-existing suite still green) and `npm run build` (all 39
      routes compile).
- [ ] T026 Manual RLS spot-check: as a signed-in customer, attempt to `PATCH` your own
      `subscriptions` row's renewal-tracking columns, and attempt direct writes to `payments`
      with `kind: 'renewal'`, directly via the Supabase REST API — confirm every attempt is
      rejected (Constitution Principle V; quickstart.md step 10 covers the endpoint's own auth
      boundary, this task is the dedicated database-level verification pass) — **not run**:
      requires a live linked Supabase project and a disposable test account (same constraint noted
      in every prior phase's tasks.md). The RLS policies themselves were authored in the migration
      (no new `authenticated`-role write policy on any renewal-related column; `subscription_pauses`
      keeps its existing owner-only `SELECT` policy) but have not been exercised against a live
      project from this session.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only
- **User Story 2 (Phase 4, P1)**: Depends on Foundational and on US1's `processRenewalOutcome.ts`
  (T013) and cron route (T014) existing to extend
- **User Story 3 (Phase 5, P2)**: Depends on Foundational's `reprice.ts` (T011) and on US2's
  completed failure path (T019/T020) to route its own empty-box failure into — build last
- **Polish (Phase 6)**: Depends on all three user stories being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories — true MVP starting point (a subscription can
  renew successfully end to end, even though failures aren't yet retried)
- **US2 (P1)**: Extends `processRenewalOutcome.ts`/the cron route from US1 — build after US1
- **US3 (P2)**: Extends `reprice.ts` (Foundational) and routes into US2's failure path — build
  last

### Within Each User Story

- Tests (where included) written and failing before implementation
- The migration (Foundational) before any Route Handler or function that queries the new columns
- Pure logic functions (`advanceDeliveryDate`, `cardExpiry`, `dunningSchedule`) before the
  outcome processor/route that call them
- The claim lock (Foundational) before the route that relies on it for idempotency
- `processRenewalOutcome.ts`'s `'paid'` branch (US1) before its `'failed'` branch (US2), since
  both live in the same file and the idempotency guard wrapping both is shared infrastructure
  built once
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T003–T011 (Foundational, after T002) — T003 in parallel with T004/T006/T007/T009/T011; T005
  depends on T003/T004; T008 depends on T007; T010 depends on T009; T012 in parallel with all of
  the above (different file, only depends on T002)
- Within US2: T017 (test) stands alone before T018

---

## Parallel Example: Foundational

```bash
# Launch the independent tests and pure-function scaffolding together:
Task: "Write unit test tests/unit/validation.cronAuth.test.ts"
Task: "Update lib/payments/moyasarClient.ts: add createRecurringPayment"
Task: "Write unit test tests/unit/subscription.advanceDeliveryDate.test.ts"
Task: "Write unit test tests/unit/payments.cardExpiry.test.ts"
Task: "Create lib/subscription/reprice.ts"
Task: "Extend lib/subscription/mutateSubscription.ts: add claimSubscriptionForRenewal"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: a back-dated subscription renews correctly — new order, advanced date —
   even though a declined charge doesn't yet retry or suspend
5. Demo: back-date a subscription, trigger the endpoint, watch a real test charge go through and
   a fresh order appear (the phase's own demo target's first half)

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US1 → validate → successful renewal works end to end (MVP!)
3. Add US2 → validate → demo (the phase's full headline scenario: renew → decline → retry →
   suspend)
4. Add US3 → validate → demo (a discontinued product doesn't break the rest of the box)
5. Phase 6 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes:
- Developer A: US1 (the full success path + cron route skeleton)
- Developer B: starts US2's `dunningSchedule.ts` (T017/T018) in parallel with US1, holding T019
  (the `processRenewalOutcome.ts` extension) until US1's T013 lands
- Developer C: joins for US3 once US2's T019/T020 exist

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- `processRenewalOutcome.ts` and the cron route are each built across two user-story phases
  (US1's success path, US2's failure path) rather than duplicated — mirroring how Phase 5's own
  tasks.md built `processPaymentOutcome.ts` incrementally across its own US2 then US3, since a
  single idempotent function naturally owns both branches of one outcome
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
