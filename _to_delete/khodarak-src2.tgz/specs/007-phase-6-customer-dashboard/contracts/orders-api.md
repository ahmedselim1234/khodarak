# Contract: Order history & detail reads (User Story 4)

Read-only, no client-side mutation ever touches this data, so — per Constitution Principle I
("data fetching happens in Server Components... colocated with the data it renders") and the
precedent already set by `app/subscription/confirmed/[id]/page.tsx` (fetches straight from
Supabase, no self-owned API route) — `app/dashboard/orders/page.tsx` and
`app/dashboard/orders/[id]/page.tsx` are Server Components querying Supabase directly with the
per-request RLS-scoped client, not Route Handlers. The shapes below document exactly what each
page fetches and renders; there is no `/api/orders*` endpoint in this phase. Both queries rely on
the existing owner-scoped `orders_select_own`/`order_items_select_own` RLS policies from Phase 5
(no service-role client needed anywhere in this contract — this phase never writes to `orders`).

## `/dashboard/orders` list query

**Query**: `select id, scheduled_date, status, price_breakdown from orders where user_id =
auth.uid() order by created_at desc` (RLS already enforces the `user_id` filter; the explicit
`.eq` is defense in depth, matching every other owner-scoped read in this codebase).

**Renders**: each row's date, status, and `price_breakdown.totalPerDelivery` — read from that
order's own snapshot, never recomputed (FR-017). An empty result renders `OrderList`'s empty state,
not an error (US4 Acceptance Scenario 3).

**No session**: `notFound()`/redirect to sign-in, per the existing `/dashboard/:path*` middleware
protection — never reached without one.

---

## `/dashboard/orders/[id]` detail query

**Query**: loads the order (`.eq("id", id).eq("user_id", user.id)`) and its `order_items`. Calls
Next.js `notFound()` if the row doesn't exist or isn't the caller's (RLS makes "doesn't exist" and
"not mine" indistinguishable at the query level, which is the correct behavior for FR-017/US4
Acceptance Scenario 4 — never reveal that a different customer's order id is valid).

**Renders**: `scheduled_date`, `delivered_at`, `status`, `address_snapshot`, every `order_items`
row (`product_name_snapshot`, `unit_price_snapshot`, `quantity`), and `price_breakdown` — all
exactly as snapshotted at generation time, same shape as `lib/pricing/calculate.ts`'s
`PriceBreakdown`.
