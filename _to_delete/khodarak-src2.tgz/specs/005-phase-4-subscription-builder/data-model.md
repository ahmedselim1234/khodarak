# Phase 1 Design: Data Model — Phase 4 — Subscription Builder (no payment yet)

Two new tables, matching the spec's Key Entities. Shapes follow `plan.md` §2's original sketch
(`subscriptions`, `subscription_items`) with the additions the spec's Clarifications/Assumptions
establish as necessary this phase: `pending_payment` as a status value, and a `delivery_time_slot`
column. No changes to `products`, `cities`, `addresses`, `cart_items`, `settings`, or `profiles`.

## `subscriptions`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `user_id` | `uuid`, not null, FK → `profiles(id)` on delete cascade | Owner |
| `address_id` | `uuid`, not null, FK → `addresses(id)` | The delivery address chosen at checkout (FR-007) |
| `frequency` | `text`, not null, check in `('weekly', 'biweekly', 'monthly')` | Must be enabled in `settings.frequencies` at confirmation time (FR-004, validated in the Route Handler, not a DB constraint — enabled/disabled is data, not schema) |
| `status` | `text`, not null, default `'pending_payment'`, check in `('pending_payment', 'active', 'paused', 'cancelled')` | This phase only ever writes `'pending_payment'`; the other three values are reserved for Phase 5 (activation) and Phase 6 (pause/cancel) |
| `next_delivery_date` | `date`, not null | The first delivery date chosen in the build step (FR-006); doubles as "next" until Phase 7's renewal engine advances it |
| `delivery_time_slot` | `text`, not null, check in `('morning', 'afternoon', 'evening')` | Chosen at checkout (FR-008); values shared with `lib/subscription/timeSlots.ts` (research.md §2) |
| `paused_until` | `date`, null | Unused this phase — reserved for Phase 6 |
| `started_at` | `timestamptz`, null | Unused this phase — set when Phase 5 activates the subscription on successful payment |
| `cancelled_at` | `timestamptz`, null | Unused this phase — reserved for Phase 6 |
| `price_breakdown` | `jsonb`, not null | The full breakdown snapshot from `calculate.ts` at confirmation time (FR-010, SC-003) — shape matches Phase 3's `PriceBreakdown` type |
| `created_at` | `timestamptz`, not null, default `now()` | |
| `updated_at` | `timestamptz`, not null, default `now()` | Bumped whenever a later phase edits the subscription |

**Validation rules** (enforced in `lib/validation/subscription.ts` with zod, re-checked
server-side even though the client-side pickers already restrict input — FR-005/FR-006's "never a
client-computed or stale" guarantee applies to validation, not just pricing):
- `frequency` must currently be `enabled: true` in the live `settings.frequencies` row (checked
  against the database at request time, not just the enum)
- `next_delivery_date` must satisfy `settings.firstDeliveryLeadDays` and not fall on a
  `settings.blackoutWeekdays` entry, per `lib/subscription/selectableDeliveryDates.ts`
  (data-model.md's Route Handler flow reuses the exact same function the picker uses)
- `address_id` must belong to the requesting user (owner check, not just existence)
- `delivery_time_slot` must be one of the three fixed values

**RLS**: owner-only (`select`/`insert` scoped to `user_id = auth.uid()`). No `update`/`delete`
policy yet — this phase never edits or removes a subscription after creation; Phase 6 adds those
policies alongside the dashboard actions that need them.

**Lifecycle**: created once, in `pending_payment`, by `POST /api/subscriptions`. Nothing in this
phase transitions its status — that begins in Phase 5 (payment success → `active`) and Phase 6
(pause/cancel).

## `subscription_items`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `subscription_id` | `uuid`, not null, FK → `subscriptions(id)` on delete cascade | |
| `product_id` | `uuid`, not null, FK → `products(id)` | Deliberately **not** snapshotted (no `product_name_snapshot`/`unit_price_snapshot` columns, unlike the future `order_items`) — `plan.md` §2 reserves snapshot-on-write for `orders`/`order_items` specifically, since subscriptions are meant to stay live/editable (Phase 6's "edit items → triggers live re-price"); `price_breakdown` on the parent row is what captures history at each save point, not this table |
| `quantity` | `integer`, not null, check `>= 1` | Copied from the corresponding `cart_items` row at confirmation time |
| `created_at` | `timestamptz`, not null, default `now()` | |

**RLS**: owner-only, via the parent subscription — `select`/`insert` scoped to
`exists (select 1 from subscriptions where subscriptions.id = subscription_items.subscription_id and subscriptions.user_id = auth.uid())`,
since this table has no `user_id` column of its own (same join-based ownership pattern as
`order_items` will need later, and mirrors how `cities`' `cities_select_all` policy already reads
"public" rather than owner-scoped when a table has no direct owner column).

**Lifecycle**: created once per subscription, copied from `cart_items` at confirmation time
(research.md §3). Never edited or deleted independently of the subscription this phase.

## Creation flow (not a new entity — documents how the two tables + `cart_items` interact)

```
POST /api/subscriptions
  1. Resolve & validate: frequency enabled?, date selectable?, address owned?, time slot valid?
  2. Read current cart_items (joined with products) for the user — this IS the box (research.md §1)
  3. Drop unavailable/deleted products (same behavior as the cart and pricing preview)
  4. Recompute the full price via calculate.ts (Constitution Principle II) — reject if
     meetsMinimumOrderValue or withinMaxItemsPerBox is false (FR-009)
  5. Insert subscriptions (status: 'pending_payment', price_breakdown: <fresh breakdown>)
  6. Insert subscription_items (one row per surviving cart_items row)
     — on failure, delete the subscriptions row from step 5 (research.md §3 compensating action)
  7. Delete the user's cart_items rows (FR-012) — only after steps 5-6 both succeed
  8. Return the created subscription's id
```

## Entity relationships

```
profiles ──< subscriptions >── addresses
              │
              ├─< subscription_items >── products
              │
              └── price_breakdown (jsonb snapshot, not a separate entity)

cart_items (Phase 2) ──consumed-into──▶ subscription_items, then deleted
```
