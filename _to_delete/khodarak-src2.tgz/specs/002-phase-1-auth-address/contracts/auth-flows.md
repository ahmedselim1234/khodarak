# Contract: Auth flows (Supabase Auth, called directly from the browser)

Unlike `/api/addresses`, these are not custom Route Handlers — they are direct calls from the four
leaf Client Components (`components/auth/*`) to Supabase Auth via `lib/supabase/client.ts` (see
research.md's rationale). This document is the contract for *how* each screen calls Supabase Auth
and what the app does with the result, so it can be implemented and tested without re-deriving the
flow from the spec each time.

## Sign up (`/signup` → `SignupForm.tsx`)

```ts
supabase.auth.signUp({
  email,
  password,
  options: { data: { full_name: fullName, phone } },
});
```

- `full_name`/`phone` land in `raw_user_meta_data`, read by the `profiles`-creation trigger
  (data-model.md).
- Client-side zod validation (`lib/validation/auth.ts`) runs before this call: valid email shape,
  minimum password strength (Supabase Auth default policy), non-empty `full_name`, KSA-format
  `phone` (FR-009).
- **On success**: session is set (email confirmation not required this phase, per spec.md
  Assumptions); redirect to `/dashboard`.
- **On error** (`email already registered`, weak password, etc.): surface Supabase's returned
  error message inline on the form (FR-002).

## Log in (`/login` → `LoginForm.tsx`)

```ts
supabase.auth.signInWithPassword({ email, password });
```

- **On success**: redirect to the page the visitor originally requested if middleware sent them
  to `/login` with a return path (FR-010's "returned to the page they requested"), else
  `/dashboard`.
- **On error** (wrong password, throttled): surface a generic "incorrect email or password"
  message — never reveal whether the email exists (mirrors FR-006's non-enumeration principle,
  applied consistently to login as well as reset). When Supabase's rate limiter rejects the
  attempt (FR-003a), surface a distinct "too many attempts, try again in a few minutes" message
  rather than the generic credentials error.

## Log out (any authenticated page → a shared sign-out action)

```ts
supabase.auth.signOut();
```

- **On completion**: redirect to `/`. Middleware's next request sees no session and treats
  subsequent protected-route access as signed-out (FR-003).

## Forgot password (`/forgot-password` → `ForgotPasswordForm.tsx`)

```ts
supabase.auth.resetPasswordForEmail(email, {
  redirectTo: `${origin}/reset-password`,
});
```

- **Always** shows the same confirmation message ("if that email is registered, a reset link has
  been sent") regardless of whether the call succeeds or the email is unregistered — this is
  Supabase Auth's default non-enumerating behavior for this call, satisfying FR-006.

## Reset password (`/reset-password` → `ResetPasswordForm.tsx`)

Landed on via the emailed link, which Supabase exchanges for a temporary recovery session
automatically on page load (handled by `@supabase/ssr`'s auth-state listener).

```ts
supabase.auth.updateUser({ password: newPassword });
```

- **On success**: the old password no longer works (Supabase invalidates it); redirect to
  `/login` with a "password updated, please sign in" message.
- **On error** (link expired/already used — the recovery session is missing/invalid by the time
  this runs): show "this link is no longer valid" with a link back to `/forgot-password` to
  request a new one (spec.md Edge Cases).

## Notes

- None of these flows go through `/api/*` — see research.md for why. `middleware.ts` is what
  keeps the session cookie fresh on every navigation regardless of which of these flows produced
  it.
- Rate limiting (FR-003a) and reset-link expiry are both Supabase Auth platform defaults, not
  application code — verified in [quickstart.md](../quickstart.md), not re-implemented here.
