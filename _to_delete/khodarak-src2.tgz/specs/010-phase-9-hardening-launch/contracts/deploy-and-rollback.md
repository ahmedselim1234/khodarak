# Contract: `scripts/deploy.sh` / `scripts/rollback.sh`

Not HTTP endpoints — the two shell scripts that make FR-008 (deploy) and FR-009 (rollback,
exercised-not-just-documented per the clarification session) concrete, repeatable actions on the
single production Docker host (research.md §2/§3), rather than a set of manual steps someone has
to remember correctly under pressure.

## `scripts/deploy.sh <image-tag>`

**Preconditions**: run on the production host, in the directory containing
`docker-compose.prod.yml`; the host is already logged in to the container registry.

**Behavior**:
1. Write `<image-tag>` to a local `.env`-style file as `IMAGE_TAG=<image-tag>` (the variable
   `docker-compose.prod.yml` interpolates into its `image:` reference — research.md §3).
2. `docker compose -f docker-compose.prod.yml pull`
3. `docker compose -f docker-compose.prod.yml up -d`
4. Poll `/api/health` (the same endpoint Phase 0 already built — contracts don't duplicate it)
   until it returns `200`, or a short timeout elapses; print the result either way so the caller
   (a human, or CI's own SSH step) knows whether the deploy actually came up healthy.

**Exit code**: non-zero if the health check never passes within the timeout — this is the signal
CI's `deploy` job (contracts/ci-workflow.md) and a human running it manually both rely on to know
whether the deploy needs immediate attention.

---

## `scripts/rollback.sh <previous-image-tag>`

**Behavior**: identical to `deploy.sh`, called with the previous known-good tag instead of a new
one — rollback and deploy are the same underlying mechanism (research.md §3's own point: tag-based
rollback needs no separate code path, only a different argument).

**Preconditions**: the caller already knows which tag was previously running — this project's own
CI run history (contracts/ci-workflow.md) and the registry's own tag list are both authoritative
sources for that, so this script doesn't try to auto-detect "the previous one" itself (a
heuristic that could silently pick the wrong tag is worse than requiring the caller to be
explicit).

## Notes

- Neither script builds an image — both only ever pull an already-built, already-registry-hosted
  tag, exactly the property that makes rollback fast enough to actually exercise (the clarification
  session's own requirement) rather than a multi-minute rebuild-and-hope.
- `quickstart.md`'s own validation steps are what actually exercise `rollback.sh` once, per
  spec.md's FR-009/SC-003a — this contract documents the mechanism, not the one-time act of
  proving it.
