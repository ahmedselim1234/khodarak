# Contract: `lib/payments/processRenewalOutcome.ts`

Not a network endpoint — the shared, idempotent function that turns a confirmed renewal-charge
outcome into database state (spec User Story 1/2). Documented as its own contract for the same
reason Phase 5's `processPaymentOutcome.ts` is: two different entry points (this phase's own cron
route, synchronously, and the shared webhook route, asynchronously) depend on it behaving
identically, and Constitution Principle V requires its idempotency guarantee to be explicit.

## Signature

```ts
async function processRenewalOutcome(
  paymentId: string, // payments.id (the row's own primary key) — NOT moyasar_payment_id
  verifiedStatus: "paid" | "failed",
  rawResponse: unknown,
  failureReason?: string
): Promise<void>;
```

Keyed by `payments.id` rather than `moyasar_payment_id` (unlike Phase 5's
`processPaymentOutcome.ts`) because three of `cron-renewals-api.md`'s four outcome paths
(`no_available_items`, `card_expired`, `provider_error`) never produce a Moyasar payment id at
all — every renewal attempt still gets its own `payments` row and its own resolution, whether or
not Moyasar was ever actually reached. The webhook route (which only ever hears about attempts
that *did* reach Moyasar) looks up the matching `payments.id` by `moyasar_payment_id` before
calling this function.

## Behavior (exact order)

1. **Conditional update, always first**: `UPDATE payments SET status = $verifiedStatus,
   failure_reason = $failureReason, raw_response = $rawResponse WHERE id = $paymentId AND status
   NOT IN ('paid', 'failed') RETURNING id, subscription_id, amount_halalas`.
   - Zero rows returned → this attempt was already terminally resolved by an earlier call
     (the cron route's own synchronous handling and a subsequent webhook delivery racing each
     other, or a redelivered webhook). Return immediately — this is the entire idempotency
     guarantee, identical in shape to Phase 5's own (research.md §1).
2. Load the subscription (`subscriptions`, service-role) — `renewal_attempt_count`,
   `next_delivery_date`, `frequency`, `pending_*` fields, `address_id`.
3. **If `verifiedStatus === 'paid'`**:
   1. Generate the order: `orders` row (`subscription_id`, `user_id`, `address_snapshot` from
      the subscription's current address, `status: 'pending'`, `scheduled_date:
      subscription.next_delivery_date`, `price_breakdown` from this cycle's fresh breakdown —
      the exact same shape Phase 5's activation flow already writes) plus `order_items` for every
      surviving (non-dropped) item, product name/price snapshotted at this exact moment.
   2. Link the payment to its order: `payments.order_id = <the new order's id>`.
   3. If this cycle resolved a due pending change (Phase 6), promote it: the subscription's
      current `frequency`/`address_id`/items become the pending values, and the pending columns
      (`pending_frequency`, `pending_address_id`, `pending_price_breakdown`,
      `pending_effective_from`) are cleared — this is the concrete promotion Phase 6's own
      research.md §1 deferred to this phase.
   4. Advance the subscription: `next_delivery_date = advanceDeliveryDate(...)` (research.md §3),
      `next_renewal_attempt_date = <the new next_delivery_date>`, `renewal_attempt_count = 0`,
      `renewal_claimed_at = null`.
4. **If `verifiedStatus === 'failed'`**:
   1. Call `dunningSchedule.nextRetryOrSuspend(subscription.renewal_attempt_count + 1,
      firstFailedAt)` — `firstFailedAt` is this cycle's *first* failed attempt's `created_at`
      (looked up from `payments` if this isn't attempt #1), not this attempt's own time
      (research.md §4).
   2. **If `{ action: 'retry', retryAt }`**: `renewal_attempt_count += 1`,
      `next_renewal_attempt_date = retryAt`, `renewal_claimed_at = null`. `next_delivery_date`
      and `subscriptions.status` are both left untouched (spec.md Clarification 1 — the cycle
      holds, nothing advances).
   3. **If `{ action: 'suspend' }`**: `status = 'paused'`, `paused_until = null`,
      `renewal_attempt_count = 0`, `next_renewal_attempt_date = null`, `renewal_claimed_at =
      null`; insert a `subscription_pauses` row (`subscription_id`, `started_at: now()`,
      `resume_date: null`) — the same table Phase 6's customer-initiated pause already writes to,
      distinguishable only by having no `resume_date` (spec.md Clarification 2).

Every write in steps 3–4 runs through the service-role client (`lib/supabase/serviceRole.ts`) —
never a request-scoped client, since neither the cron route nor the webhook route ever has a
customer session (research.md, extending Phase 5/6's established rule).

## Required test cases (unit-testable pieces; full end-to-end flow covered by
`tests/e2e/renewal-engine.spec.ts`)

Mirroring how Phase 5 extracted `processPaymentOutcome.ts`'s pure decision logic for direct
Vitest coverage, this function's own conditional-update and dunning-transition decisions are
covered via `dunningSchedule.ts`'s own test suite (contracts/`cron-renewals-api.md`'s Notes) plus:

| Case | What it proves |
|---|---|
| A payment currently `'initiated'`, outcome `'paid'` | Proceeds to order generation + date advancement |
| A payment already `'paid'`, called again with `'paid'` (webhook race) | No-ops (idempotency) |
| A payment already `'failed'`, called again with `'failed'` (redelivered webhook) | No-ops — a terminal state is never overwritten in either direction |
| Outcome `'failed'` on attempt 1 of a cycle | `renewal_attempt_count` becomes 1, `next_renewal_attempt_date` set to +1 day, `next_delivery_date` unchanged |
| Outcome `'failed'` on attempt 4 of a cycle (every retry exhausted) | Subscription becomes `paused` with no `resume_date`, retry state cleared |
| A cycle whose pending change's effective date has arrived, outcome `'paid'` | Pending fields promoted to current, then cleared |
