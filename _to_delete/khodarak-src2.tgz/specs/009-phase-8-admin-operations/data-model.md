# Phase 1 Data Model: Phase 8 — Admin Operations

Five existing tables are altered (`profiles`, `orders`, `subscriptions`, `subscription_pauses`,
`cities`); no new tables (research.md §2).

## `profiles` (altered)

| Column | Type | Notes |
|---|---|---|
| `email` | text, nullable | Denormalized from `auth.users.email` (research.md §4) — populated going forward by the updated `handle_new_user()` trigger, backfilled once for existing rows by the migration itself |

`handle_new_user()` (Phase 1) is updated to also set `email = new.email` on insert. No RLS policy
change — `profiles_select_own` already covers reading a customer's own email (Phase 6's profile
settings could show it later if ever needed, out of this phase's scope); admin list reads use a
new `profiles_select_admin` policy (below) to read *other* customers' emails for search/display.

**New RLS policy**: `profiles_select_admin` — `select` where
`exists (select 1 from profiles p2 where p2.id = auth.uid() and p2.role = 'admin')`. Needed
because every admin list (orders/subscriptions/payments) displays and searches by the owning
customer's name/email/phone, which requires reading `profiles` rows that aren't the caller's own —
`profiles_select_own` alone would make every such join return nothing for a customer's row that
isn't the admin's own.

## `orders` (altered)

| Column | Type | Notes |
|---|---|---|
| `status_updated_by` | uuid, references `profiles(id)`, nullable | Which admin performed the most recent status change (FR-004a). Null for an order that has never had its status changed by this phase's own action (i.e., still in its Phase 5/7-generated `pending` state) |
| `status_updated_at` | timestamptz, nullable | When the most recent status change happened |

**New RLS policies**:
- `orders_select_admin` — `select` where the caller is an admin (same inline check as
  `profiles_select_admin`). Existing `orders_select_own` (Phase 5) is unchanged for customers.
- `orders_update_admin` — `update` where the caller is an admin. This is the **first**
  authenticated-role write policy `orders` has ever had — Phase 5's own migration deliberately
  granted none (all writes were service-role-only, since no customer or admin action existed yet);
  this phase's admin status-transition write is exactly the kind of trusted, role-gated write
  Phase 2's pattern (research.md §1) is for.

## `subscriptions` (altered)

| Column | Type | Notes |
|---|---|---|
| `cancelled_by_admin_id` | uuid, references `profiles(id)`, nullable | Set only when the cancellation was admin-initiated (FR-008); stays `null` for a customer's own cancellation (Phase 6) |
| `cancel_reason` | text, nullable | The required reason text for an admin-initiated cancellation; `null` for a customer's own |

**New RLS policy**: `subscriptions_select_admin` — `select` where the caller is an admin (Phase
4's `subscriptions_select_own` is unchanged for customers). **No new `update` policy is added
directly on `subscriptions`** — admin pause/cancel writes go through the exact same
`lib/subscription/mutateSubscription.ts` service-role functions Phase 6/7 already use
(`pauseSubscription`, `cancelSubscription`), extended with two new optional parameters
(`adminId`, `reason`) rather than duplicated. This is the one deliberate exception to this phase's
"no new service-role usage" framing (plan.md's Technical Context) — reusing the *existing*,
already-idempotent, already-correct pause/cancel logic (cutoff-override behavior, terminal
cancellation, `subscription_pauses` history insertion) is safer than re-implementing equivalent
logic behind a new RLS policy just to keep every write on the RLS-scoped client uniformly. The
`requireAdmin()` check happens in the Route Handler *before* calling into
`mutateSubscription.ts`, exactly mirroring how the pattern already works for the customer-facing
routes (ownership/rule checks happen in the Route Handler, the mutation module just executes).

## `subscription_pauses` (altered)

| Column | Type | Notes |
|---|---|---|
| `initiated_by_admin_id` | uuid, references `profiles(id)`, nullable | Set only for an admin-initiated pause; `null` for a customer's own pause or a Phase 7 auto-suspension |
| `reason` | text, nullable | The required reason text for an admin-initiated pause; `null` otherwise |

No RLS policy change — this table already has no authenticated-role write policy (Phase 6/7
service-role-only), unaffected by this phase's admin-pause path reusing that same service-role
insert.

## `cities` (altered — no new columns)

**New RLS policies** (Phase 1's migration deliberately left these unwritten, "city management
ships in Phase 8's admin panel"):
- `cities_insert_admin` — `insert` where the caller is an admin.
- `cities_update_admin` — `update` where the caller is an admin.

No `delete` policy — per FR-013/014 and spec.md's own established rule (a deactivated city, not a
deleted one, is how a city stops being served; existing addresses referencing it must stay valid,
which a hard delete would break via the `addresses.city_id` foreign key).

## Existing entities this phase reads, unchanged in shape

- **`payments`** (Phase 5/7) — read-only this phase (spec.md Assumptions). Needs a new
  `payments_select_admin` RLS policy (same inline admin check) alongside the existing
  `payments_select_own` (Phase 5), since this phase's payments list spans every customer.
- **`order_items`, `subscription_items`, `addresses`** — read for detail views exactly as their
  existing owner-scoped `SELECT` policies already permit for the *owner*; an admin detail view
  additionally needs `order_items`/`subscription_items` reads for *any* order/subscription, so
  each gains its own `_select_admin` policy (same inline check), mirroring the pattern above.
- **`settings`** (Phase 3) — unchanged; this phase adds no new settings fields (the dunning
  schedule stayed a fixed constant per Phase 7's own clarification, and nothing in this phase's
  scope needs a new admin-configurable rule).

## State transitions

### `orders.status` (new this phase — Phase 5/7 only ever created orders as `pending`)

```
pending ──admin advances──▶ out_for_delivery ──admin advances──▶ delivered  (terminal)
pending ──admin cancels───▶ cancelled  (terminal)
out_for_delivery ──admin cancels───▶ cancelled  (terminal)
```

No other edge exists — `orderStatusTransition.ts` (research.md's Constitution Check, FR-003) is
the single source of truth for this table, called by the Route Handler before any conditional
`UPDATE` is attempted (research.md §3).

### `subscriptions.status` (extends Phase 6/7's diagram — admin actions use the identical states)

```
active ──admin pauses (reason required)──▶ paused  (resume_date optional; indefinite if none chosen)
paused ──admin cancels (reason required)──▶ cancelled  (terminal)
active ──admin cancels (reason required)──▶ cancelled  (terminal)
```

Functionally identical to the customer-initiated and Phase 7 auto-suspend transitions already
documented in `specs/007-phase-6-customer-dashboard/data-model.md` and
`specs/008-phase-7-renewal-engine/data-model.md` — this phase adds no new status value, only a
third *cause* (admin, alongside customer-initiated and dunning-auto-suspend) distinguishable via
the new attribution columns above.
