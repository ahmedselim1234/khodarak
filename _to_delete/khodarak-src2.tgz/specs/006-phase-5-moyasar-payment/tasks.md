---

description: "Task list for Phase 5 — Moyasar Integration & First Payment"
---

# Tasks: Phase 5 — Moyasar Integration & First Payment

**Input**: Design documents from `/specs/006-phase-5-moyasar-payment/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/ (pay-initiate-api.md, payment-callback-and-webhook.md, payment-outcome-processing.md), quickstart.md

**Tests**: Included — plan.md's Technical Context, research.md, and
contracts/payment-outcome-processing.md all explicitly scope Vitest suites for `halalas.ts`,
`retryThrottle.ts`, `verifyWebhookSignature.ts`, and `processPaymentOutcome.ts`'s pure decision
logic (written and passing before the Route Handlers that use them, per Constitution Principle
VI), plus a Playwright spec for the phase's full demo scenario.

**Organization**: Tasks are grouped by user story (US1/US2/US3, matching spec.md's priorities:
US1 = P1, US2 = P1, US3 = P2). US1 (submitting a payment attempt) is built before US2 (processing
its outcome) since an attempt has to exist before anything can process it; US3 (decline/retry UX)
is a thin final layer over both, since the underlying failure recording already happens as part of
US2's `processPaymentOutcome`.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Create the `components/payment/` directory scaffold
- [X] T002 [P] Create the `lib/payments/` directory scaffold

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T003 Create migration `supabase/migrations/<timestamp>_payments.sql`: `payment_methods`, `payments` (both `subscription_id` and `order_id` nullable — research.md §2), `webhook_events`, `orders`, `order_items` tables; owner-only `SELECT` RLS on the customer-facing four, no policy at all on `webhook_events`; **no `authenticated`-role `INSERT`/`UPDATE`/`DELETE` policy on any of them** (research.md §1) — per data-model.md
- [X] T004 [P] Update `lib/env.server.ts`: add `MOYASAR_SECRET_KEY` and `MOYASAR_WEBHOOK_SECRET` to the server-only schema
- [X] T005 [P] Update `lib/env.ts`: add `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY` to the public schema
- [X] T006 [P] Create `lib/supabase/serviceRole.ts`: service-role Supabase client, clearly commented as bypassing RLS and intended for import only from `lib/payments/processPaymentOutcome.ts` (research.md §1) — depends on T004
- [X] T007 [P] Create `lib/payments/moyasarClient.ts`: `fetch`-based wrapper — `createPayment` (Basic Auth with the secret key, 3DS on, `callback_url`, `metadata.subscription_id`) and `fetchPayment` (authoritative status lookup by id) — depends on T004
- [X] T008 [P] Write unit test `tests/unit/payments.halalas.test.ts` covering exact SAR→halalas conversion cases, including a case that would silently produce a 100× error if the conversion were done inline instead of through the shared helper
- [X] T009 Create `lib/payments/halalas.ts`: `toHalalas(sar)` — THE single conversion point (FR-017) — depends on T008

**Checkpoint**: Foundation ready — new tables + locked-down RLS, env vars, the service-role client, the Moyasar API wrapper, and the halalas conversion all exist; user story implementation can now begin.

---

## Phase 3: User Story 1 - Pay for a pending subscription with a card (Priority: P1) 🎯 MVP

**Goal**: A customer can enter a new card (tokenized browser-to-Moyasar directly) or pick a saved one, give explicit recurring-charge consent, and submit a 3DS-backed payment attempt for their pending-payment subscription.

**Independent Test**: Open the payment step for a pending-payment subscription, tokenize a Moyasar test card, check the consent box, submit, and confirm a `payments` row is recorded as `'initiated'` with the correct amount and the browser is redirected to Moyasar's 3DS challenge — per quickstart.md step 2 (submission half).

### Tests for User Story 1

> Write this test FIRST; it MUST fail until T011 exists.

- [X] T010 [P] [US1] Write unit test `tests/unit/payments.retryThrottle.test.ts` covering: under the failure threshold (not throttled), at the threshold (throttled), and outside the trailing time window (not throttled even with old failures)

### Implementation for User Story 1

- [X] T011 [US1] Create `lib/payments/retryThrottle.ts`: pure function deciding throttled/not-throttled from recent failed-attempt timestamps (FR-016a) — depends on T010
- [X] T012 [P] [US1] Create `lib/validation/paymentInitiate.ts`: zod schema for the `POST /api/subscriptions/[id]/pay` body — exactly one of `moyasarToken`/`paymentMethodId`, `consentGiven: true` required — per contracts/pay-initiate-api.md
- [X] T013 [P] [US1] Create `components/payment/CardTokenizationForm.tsx`: `"use client"` leaf — loads Moyasar's hosted tokenization script via `next/script` (research.md §5), mounts against `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY` with `save_only: true`, yields a token id to its parent; card fields never touch this app's own server
- [X] T014 [P] [US1] Create `components/payment/PaymentMethodSelector.tsx`: `"use client"` leaf — lists the customer's saved active payment methods plus an "add a new card" option (FR-002)
- [X] T015 [US1] Create `components/payment/PaymentSection.tsx`: `"use client"` orchestrator — method choice (`PaymentMethodSelector`, T014, vs. `CardTokenizationForm`, T013), the recurring-charge consent checkbox (FR-003), submit → `POST /api/subscriptions/[id]/pay` → redirect the browser to the returned `transactionUrl` — depends on T013, T014
- [X] T016 [US1] Implement `app/api/subscriptions/[id]/pay/route.ts`: `POST` — auth + ownership + `pending_payment` status check, throttle check via T011, resolve the token (T012), compute `amount_halalas` via T009 from the subscription's own snapshot (never the request body), call `moyasarClient.createPayment` (T007), insert the `'initiated'` `payments` row, return the 3DS `transactionUrl` — per contracts/pay-initiate-api.md — depends on T003, T006, T007, T009, T011, T012
- [X] T017 [US1] Update `app/subscription/confirmed/[id]/page.tsx` (Phase 4): make it status-aware — `pending_payment` now renders `PaymentSection` (T015) with the customer's saved payment methods and the subscription's price, replacing the previous static "coming soon" copy entirely for this status — depends on T015

**Checkpoint**: User Story 1 is fully functional and independently testable — a payment attempt can be submitted and recorded, even though nothing processes its outcome yet.

---

## Phase 4: User Story 2 - Successful payment activates the subscription (Priority: P1)

**Goal**: A confirmed-successful payment — via the customer's own redirect or the provider's independent webhook, whichever arrives first — activates the subscription, saves the card, generates the first order, and is never double-processed.

**Independent Test**: Simulate a confirmed-successful outcome for an `'initiated'` payment (directly, bypassing the UI) and confirm the subscription becomes `active`, a `payment_methods` row and an `orders` row (with `order_items`) now exist, and repeating the same simulated outcome is a no-op — per quickstart.md steps 2–4.

### Tests for User Story 2

> Write these tests FIRST; they MUST fail until T020/T022 exist.

- [X] T018 [P] [US2] Write unit test `tests/unit/payments.verifyWebhookSignature.test.ts` covering: a valid secret-token header (passes), an incorrect one (fails), and a missing header (fails)
- [X] T019 [P] [US2] Write unit test `tests/unit/payments.processPaymentOutcome.test.ts` covering the pure decision cases from contracts/payment-outcome-processing.md's table (an `'initiated'` payment proceeds; an already-`'paid'`/already-`'failed'` payment no-ops either direction; a `'failed'` outcome records the failure without touching the subscription; a customer with no existing active payment method gets `is_default: true`, one with an existing default does not) — using a fake/stub Supabase client to isolate the decision logic from live database calls

### Implementation for User Story 2

- [X] T020 [US2] Create `lib/payments/verifyWebhookSignature.ts`: constant-time comparison of the incoming secret-token header against `serverEnv.MOYASAR_WEBHOOK_SECRET` — depends on T018, T004
- [X] T021 [P] [US2] Create `lib/validation/moyasarWebhook.ts`: zod schema for the webhook payload shape (defensive layer behind T020's signature check, not a substitute for it)
- [X] T022 [US2] Create `lib/payments/processPaymentOutcome.ts`: the shared, idempotent activation function — conditional `UPDATE ... WHERE status NOT IN ('paid','failed')` first (research.md §3), then on `'paid'` upsert `payment_methods`, activate the subscription, generate `orders`/`order_items` from the subscription's snapshot, link the payment to its order, all via the service-role client (T006) — per contracts/payment-outcome-processing.md and data-model.md's Activation flow — depends on T019, T006
- [X] T023 [US2] Implement `app/api/payments/callback/route.ts`: `GET` — reads the Moyasar payment id from the query string, calls `moyasarClient.fetchPayment` (T007) for the authoritative status (never trusting the query string's own status parameter — FR-005), calls `processPaymentOutcome` (T022), redirects to `/subscription/confirmed/<subscription id>` — per contracts/payment-callback-and-webhook.md — depends on T007, T022
- [X] T024 [US2] Implement `app/api/webhooks/moyasar/route.ts`: `POST` — public, no session; verifies the signature (T020) before parsing anything as trusted, validates the payload (T021), inserts into `webhook_events` (a unique-constraint conflict on `moyasar_event_id` means "already processed," respond `200` without reprocessing — FR-013), calls `processPaymentOutcome` (T022) for actionable event types — per contracts/payment-callback-and-webhook.md — depends on T020, T021, T022
- [X] T025 [US2] Update `app/subscription/confirmed/[id]/page.tsx` (US1, T017): when `status === 'active'`, render the real success confirmation per `design/successfull-order.html`, replacing Phase 4's placeholder copy for that status (FR-010) — depends on T017

**Checkpoint**: User Stories 1 AND 2 both work — the phase's headline demo (pay with a test card, complete 3DS, land on the real success screen, see the payment in the Moyasar dashboard) is complete.

---

## Phase 5: User Story 3 - Failed or declined payment lets the customer retry (Priority: P2)

**Goal**: A declined or failed payment shows a specific, actionable message and lets the customer immediately retry, without losing their subscription.

**Independent Test**: Submit a Moyasar test card known to decline, confirm a specific message appears and the subscription stays `pending_payment`, then retry with a valid card and confirm it succeeds — per quickstart.md step 5.

### Implementation for User Story 3

- [X] T026 [US3] Update `app/subscription/confirmed/[id]/page.tsx` (US2, T025): when still `pending_payment`, also fetch the subscription's most recent `payments` row with `status = 'failed'` (if any) and pass its `failure_reason` down to `PaymentSection` — depends on T025
- [X] T027 [US3] Update `components/payment/PaymentSection.tsx` (US1, T015): surface the specific decline/failure message and the throttled (`429`) state from T016's endpoint with a clear, actionable message, keeping the form available for an immediate retry with the same or a different card — depends on T026, T015

**Checkpoint**: All three user stories are independently functional.

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all three stories

- [X] T028 [P] Write Playwright spec `tests/e2e/payment-flow.spec.ts`: payment step reachability + consent-gated submit button; signed-out redirect. Full test-card succeed/decline flows are marked `test.skip` pending real Moyasar test credentials and a seeded pending-payment subscription id (neither available in this sandbox) — quickstart.md steps 2 and 5
- [ ] T029 [P] Run the full `quickstart.md` validation (all 9 steps) end to end — **not run**: requires real Moyasar test-mode credentials, a public tunnel for webhook delivery, and a seeded pending-payment subscription, none available in this sandbox. `npm run build` was run instead and confirms every route/API handler compiles and type-checks; this does not substitute for the manual walkthrough with a real test card.
- [X] T030 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed files (Constitution Development Workflow gate) — both clean; also ran `npm run test:unit` (116/116 passing, including the halalas 100×-bug case, retry throttle, webhook signature, and processPaymentOutcome decision suites) and `npm run build` (all 28 routes compile) as additional verification. Also fixed two pre-existing tests (`tests/unit/env.test.ts`, `vitest.config.ts`'s placeholder env vars) that needed updating for the new required `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY`.
- [ ] T031 Manual RLS spot-check: as a signed-in customer, attempt to `PATCH` your own `subscriptions` row's `status` directly via the Supabase REST API, and attempt direct writes to `payment_methods`/`payments`/`orders`/`order_items` — confirm every attempt is rejected (Constitution Principle V; quickstart.md step 8 covers this at the walkthrough level, this task is the dedicated verification pass) — **not run**: requires a live linked Supabase project and a disposable test account (same constraint noted in every prior phase's tasks.md). The RLS policies themselves were authored in the migration (owner-only `SELECT` throughout, one deliberate `INSERT`-only exception on `payments` scoped to `status = 'initiated'`, and otherwise no `authenticated`-role write policy anywhere) but have not been exercised against a live project from this session.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only
- **User Story 2 (Phase 4, P1)**: Depends on Foundational and on US1's `app/subscription/confirmed/[id]/page.tsx` edit (T017) existing to extend further
- **User Story 3 (Phase 5, P2)**: Depends on US2's `processPaymentOutcome` (failure recording) and page edit (T025) — build last
- **Polish (Phase 6)**: Depends on all three user stories being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories — true MVP starting point (a recorded, submitted payment attempt, even before anything processes its outcome)
- **US2 (P1)**: Extends `confirmed/[id]/page.tsx` from US1 (T017) — build after US1
- **US3 (P2)**: Extends both `confirmed/[id]/page.tsx` (US2, T025) and `PaymentSection.tsx` (US1, T015) — build last

### Within Each User Story

- Tests (where included) written and failing before implementation
- The migration (Foundational) before any Route Handler or component that queries the new tables
- Validation schemas before the forms/handlers that use them
- Pure logic functions (`halalas`, `retryThrottle`, `verifyWebhookSignature`,
  `processPaymentOutcome`'s decision logic) before the Route Handlers that call them
- Server-side pieces (migrations, Route Handlers) before the client components that call them
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T001 and T002 (Setup) can run in parallel
- T004–T009 (Foundational, after T003) — T004/T005 in parallel; T006/T007 in parallel once T004 lands; T008 (test) in parallel with T004–T007
- Within US1: T012, T013, T014 (different files) in parallel; T010 (test) in parallel with all of them
- Within US2: T018 and T019 (tests, different files) in parallel; T021 in parallel with T020

---

## Parallel Example: User Story 1

```bash
# Launch the test and three independent implementation files together:
Task: "Write unit test tests/unit/payments.retryThrottle.test.ts"
Task: "Create lib/validation/paymentInitiate.ts"
Task: "Create components/payment/CardTokenizationForm.tsx"
Task: "Create components/payment/PaymentMethodSelector.tsx"
```

## Parallel Example: User Story 2

```bash
# Launch both tests together:
Task: "Write unit test tests/unit/payments.verifyWebhookSignature.test.ts"
Task: "Write unit test tests/unit/payments.processPaymentOutcome.test.ts"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: a payment attempt can be submitted and is correctly recorded as
   `'initiated'`, even though nothing activates the subscription yet
5. Demo: tokenize a test card, submit, watch the `payments` row appear and the browser redirect
   toward Moyasar's 3DS challenge

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US1 → validate → a payment attempt can be submitted (not yet processed)
3. Add US2 → validate → demo (the phase's full headline scenario: pay → 3DS → real success
   screen → order generated → payment visible in the Moyasar dashboard)
4. Add US3 → validate → demo (decline → specific message → successful retry)
5. Phase 6 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes:
- Developer A: US1 (submission side — tokenization, consent, the `/pay` endpoint)
- Developer B: starts US2's non-page pieces (T018–T024) in parallel with US1, holding T025 (the
  page edit) until US1's T017 lands
- Developer C: joins for US3 once US2's T025 exists

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- The migration (T003) and the service-role client (T006) are Foundational because every story
  either reads or writes through them; `retryThrottle.ts` is scoped to US1 because it's invoked
  directly inside US1's own `/pay` endpoint, even though the *behavior* it enforces is closely
  related to US3's retry story (research.md and plan.md both note this split)
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
