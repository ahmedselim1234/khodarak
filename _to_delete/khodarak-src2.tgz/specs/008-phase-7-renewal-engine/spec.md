# Feature Specification: Phase 7 — Renewal Engine & Dunning

**Feature Branch**: `008-phase-7-renewal-engine`

**Created**: 2026-08-11

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for Phase 7" — scoped from `plan.md` §4 "Phase 7 — Renewal Engine & Dunning": a scheduled job (pg_cron or a protected API route hit by an external scheduler), re-price → charge saved token → generate order on success, date advancement, idempotency guard, paused/cancelled handling, unavailable-product handling, failed-payment retry schedule, suspend-after-N-failures, card expiry pre-check. Also draws on `plan.md` §1's "Renewal Engine" function inventory and §3b's Moyasar recurring-charge design (3DS off for an already-verified token, the suggested +1/+3/+5-day dunning schedule, amounts always in halalas via one conversion point, idempotency before charging, webhooks as the source of truth). Demo target: "back-date a subscription, trigger the job, watch a real test charge go through and a fresh order appear. Then force a decline with a failing test card and show the retry/suspend path." This is the phase that generates every delivery's order *after* the first — Phase 5 (`specs/006-phase-5-moyasar-payment`) only ever generates one subscription's very first order upon initial activation; Phase 6 (`specs/007-phase-6-customer-dashboard`) added the pause/resume/cancel lifecycle and the pending-change fields a renewal must correctly resolve on the cycle they become effective.

## Clarifications

### Session 2026-08-11

- Q: When a renewal charge fails and enters the retry schedule, does that delivery cycle wait (delivery delayed until payment succeeds or the subscription is suspended) or does the schedule move on to the next cycle regardless of whether the failed one is ever paid? → A: The cycle waits — the next delivery date does not advance and no further cycle is attempted until the current one is resolved (paid, or the subscription is suspended after exhausting retries). A customer never receives a delivery out of order relative to what they've actually paid for.
- Q: What does "automatically suspended" mean concretely — is it the same `paused` state introduced in Phase 6 (customer-chosen resume date), or a distinct state? → A: It reuses the existing `paused` status, but with no resume date — it stays paused indefinitely until the customer takes an explicit action (updating their card and manually resuming), rather than auto-resuming on a timer the way a customer-initiated pause does.
- Q: Is "notify the customer" of a failed charge satisfied by what already exists (the dashboard's health indicator and payment history from Phase 6), or does this phase need to add a new outbound channel (email/SMS)? → A: Satisfied by what already exists — this phase's job is to make sure a failure is accurately reflected in the data those surfaces already read (payment status/failure reason, subscription health), not to build a new notification channel; outbound email/SMS is out of scope for this phase.
- Q: When the renewal job's call to Moyasar itself fails or times out (a network error or provider outage — not a card decline), is that treated exactly like a declined charge, or as a distinct case? → A: Treated exactly like a declined charge — recorded as a failed attempt entering the same retry schedule and the same failure-reason bucket as a decline, rather than a separate provider-error path with its own timer or operational surface (which this phase has nowhere to show anyway, since admin-facing operational views are Phase 8's scope).
- Q: Should the dunning retry schedule (attempt count, spacing) be a fixed built-in value, or an admin-configurable setting alongside Phase 3's other pricing/order rules? → A: A fixed constant — the +1/+3/+5-day, then-suspend schedule is hardcoded, with no new settings-table fields or admin UI changes; this keeps the phase scoped to the renewal engine itself, deferring configurability to a later phase if the business ever needs to tune it.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - A due subscription renews automatically (Priority: P1)

Without the customer doing anything, a subscription whose next delivery is due today gets re-priced against current rules, charged on its saved card, and — once the charge succeeds — a new order is generated and the subscription's next delivery date advances to the following cycle.

**Why this priority**: This is the entire reason the phase exists — every subscription created in earlier phases is otherwise stuck after its first delivery forever. It's also the phase's own stated demo target's first half ("back-date a subscription, trigger the job, watch a real test charge go through and a fresh order appear").

**Independent Test**: Can be fully tested by back-dating an active subscription's next delivery date to today, triggering the renewal job, and confirming a new payment record shows success, a new order (with items/price matching current rules) now exists, and the subscription's next delivery date has advanced by exactly one frequency period — delivers a complete, verifiable renewal independent of any failure-handling path.

**Acceptance Scenarios**:

1. **Given** an active subscription whose next delivery date is today (or earlier), **When** the renewal job runs, **Then** its box is re-priced using the admin's *current* settings and product prices (not the price it was charged when it first subscribed), and that fresh breakdown is what gets charged and snapshotted onto the new order.
2. **Given** the re-priced charge succeeds, **When** the charge is confirmed, **Then** a new order is created carrying that cycle's snapshotted items, address, and price — exactly mirroring how the very first order was generated in Phase 5, and the subscription's next delivery date advances by one full frequency period (weekly/bi-weekly/monthly) from the delivery that just happened.
3. **Given** a subscription has a pending change waiting to take effect from this exact delivery (an edit deferred past the cutoff window in Phase 6), **When** this cycle's renewal runs, **Then** the pending items/frequency/address become the subscription's new current configuration as of this renewal, and it's this new configuration — not the old one — that gets charged and delivered.
4. **Given** a subscription is paused or cancelled, **When** the renewal job runs, **Then** it is skipped entirely — no charge is attempted and no order is generated for it.
5. **Given** a subscription is paused with a resume date that has already passed, **When** the renewal job runs (whether or not the customer has opened their dashboard since), **Then** the subscription is treated as active for this run — its resume is recognized independently by the job itself, and if its delivery is also due, it renews normally in the same run.

---

### User Story 2 - A failed charge is retried on a schedule, then the subscription is suspended (Priority: P1)

When a renewal charge is declined or otherwise fails, the customer isn't charged again immediately — the system retries on a defined schedule, and if every retry in that schedule also fails, the subscription is automatically paused so the business stops attempting to deliver product nobody is paying for.

**Why this priority**: Declines are routine, not exceptional, for a recurring-billing product — without a retry/suspend path, a single bad decline either loses a paying customer permanently (no retry) or delivers product forever without payment (no suspension), both unacceptable. It's the second half of the phase's own stated demo target ("force a decline with a failing test card and show the retry/suspend path").

**Independent Test**: Can be fully tested by forcing a renewal charge to fail (a test card configured to decline), confirming the subscription's delivery does not advance and a specific failure reason is recorded, then simulating each scheduled retry attempt failing in turn, and confirming that after the last scheduled retry also fails, the subscription's status becomes paused with no resume date — delivers a complete, verifiable dunning path independent of the successful-renewal path.

**Acceptance Scenarios**:

1. **Given** a renewal charge is declined or fails, **When** the failure is recorded, **Then** no order is generated for that cycle, the subscription's next delivery date does not advance, and a specific, retrievable failure reason is stored against that payment attempt.
2. **Given** a renewal charge has just failed, **When** the next scheduled retry's time arrives, **Then** the system attempts the charge again against the same saved card and same re-priced amount for that same cycle — not a new attempt at a different, newly-computed price.
3. **Given** a retried charge succeeds, **When** it's confirmed, **Then** the subscription proceeds exactly as a first-attempt success would — order generated, next delivery date advanced — and no further retries are scheduled for that cycle.
4. **Given** every attempt in the retry schedule for one cycle has failed, **When** the last scheduled retry also fails, **Then** the subscription's status becomes paused with no resume date set, and no further renewal attempts are made for it until the customer takes explicit action.
5. **Given** a subscription has been automatically suspended this way, **When** the customer views it (per Phase 6's existing dashboard), **Then** its status and health indicator reflect this — the customer can see it needs attention and can update their saved card and manually resume, exactly as Phase 6's existing pause/resume/card-replacement capabilities already allow.

---

### User Story 3 - Renewal handles a discontinued product without failing the whole box (Priority: P2)

If a product in a subscription's box has been deleted or made unavailable since the last delivery, the renewal for that subscription doesn't simply crash or silently charge for a product that no longer exists — it re-prices using only what's still available and records what was dropped.

**Why this priority**: A real product catalog changes over time (Phase 2's admin CRUD already allows deleting/disabling products), so this is a routine operational reality once the renewal engine has been running for any length of time — but it's a secondary correctness concern behind the two P1 stories that make renewal and dunning work at all.

**Independent Test**: Can be fully tested by disabling a product that's part of an active subscription's box, triggering that subscription's renewal, and confirming the resulting charge/order excludes the unavailable product's cost and the order's snapshot records that it was dropped, without preventing the rest of the box from renewing normally — delivers a complete, verifiable degraded-but-successful renewal independent of the full-failure paths above.

**Acceptance Scenarios**:

1. **Given** a subscription's box includes a product that has since been deleted or marked unavailable, **When** its renewal runs, **Then** that product is excluded from the re-priced charge and the resulting order, while every other item in the box still renews normally.
2. **Given** a product was dropped this way, **When** the resulting order is later viewed (per Phase 6's order detail view), **Then** it's clear from that order's own record that a product was excluded from what was actually delivered/charged, not silently absent.
3. **Given** every product in a subscription's box has become unavailable, **When** its renewal runs, **Then** the renewal does not charge for or generate an empty order — it's treated as a failure needing the customer's attention (their box needs updating), following the same recorded-failure path as a declined charge, distinct from a card-related failure reason.

---

### Edge Cases

- What happens when the renewal job is triggered twice for the same subscription on the same day (a retried cron invocation, an overlapping run, a manual re-trigger)? The second run recognizes the cycle as already resolved (charged and order generated, or already scheduled for retry) and takes no further action — no double charge, no duplicate order, mirroring Phase 5's own idempotency guarantee for the first payment.
- What happens when a subscription's saved card is already expired as of the renewal date? The system doesn't attempt a charge doomed to fail — it records a specific "card expired" failure reason immediately and proceeds directly into the same retry/suspend path as a declined charge, since no retry against the same expired card would ever succeed differently (though the customer updating their card before a scheduled retry fires still lets that retry succeed against the new card).
- What happens when a customer updates their saved card (Phase 6's existing card-replacement capability) while a subscription is mid-retry-schedule for a failed cycle? The next scheduled retry attempts the charge against whichever card is currently saved and active at that moment, not whatever card was on file when the failure was first recorded.
- What happens when a customer cancels their subscription while it's mid-retry-schedule? No further retries are attempted — cancellation is immediate and terminal per Phase 6's own rule, and it overrides any pending retry the same way it already overrides a locked delivery.
- What happens when a customer manually resumes an automatically-suspended subscription without having fixed the underlying problem (e.g., resumes without updating an expired card)? The next renewal for it is attempted normally on its next due date and can fail and re-enter the retry/suspend cycle again — resuming doesn't retroactively fix the card, it only ends the suspension.
- What happens when the admin's settings (frequency discounts, VAT, delivery fee rules) change between two consecutive renewal attempts for the same still-unresolved cycle (e.g., between the first attempt and its first scheduled retry)? The originally-computed price for that cycle is what's retried, not a freshly recomputed one — a customer is never charged a different amount for the same delivery depending on which retry happened to succeed.
- What happens to a subscription's `subscription_pauses` history (Phase 6) when it's auto-suspended by dunning versus manually paused by the customer? Both are recorded the same way, distinguishable by having no customer-chosen resume date, so support and the customer's own history stay consistent regardless of which path caused the pause.
- What happens when the renewal job's own call to the payment provider fails or times out (a network error or provider outage), as opposed to the provider actively declining the card? It's recorded as a failed attempt exactly like a decline and enters the same retry schedule — no separate failure category, retry timer, or operational-alerting path exists this phase (per the clarification above).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST run on a recurring schedule (independent of any customer visiting the site) and identify every active subscription whose next delivery date has arrived.
- **FR-002**: System MUST, for each due subscription, recalculate its full price breakdown using the current admin settings and current product prices at the moment of renewal — never the price breakdown that was snapshotted when the subscription was created or last edited.
- **FR-003**: System MUST resolve a subscription's pending change (per Phase 6) onto its current configuration when that pending change's effective delivery has arrived, so the cycle being renewed reflects the customer's latest saved edit rather than a stale one.
- **FR-004**: System MUST exclude any product that has been deleted or marked unavailable since the subscription's items were chosen from that cycle's price calculation and order, and MUST record that an item was excluded on that cycle's resulting record.
- **FR-005**: System MUST treat a subscription whose entire box has become unavailable as a failed cycle requiring the customer's attention, not as a successful zero-value renewal.
- **FR-006**: System MUST check a subscription's saved card's expiry against the renewal date before attempting a charge, and MUST record a specific "card expired" failure immediately, without attempting a charge known in advance to fail.
- **FR-007**: System MUST charge the subscription's saved, active payment method for the freshly-computed amount, with no additional customer-facing verification step required (an already-verified saved token, per the existing Moyasar integration's own design), and MUST generate the cycle's order only after that charge is confirmed successful — never before.
- **FR-008**: System MUST advance a subscription's next delivery date by exactly one of its frequency's periods only upon that cycle's successful charge — a failed or still-retrying cycle MUST NOT advance the next delivery date.
- **FR-009**: System MUST skip a paused or cancelled subscription entirely on every run — no charge attempted, no order generated.
- **FR-010**: System MUST independently recognize, on each run, a paused subscription whose resume date has already passed as due for normal renewal consideration in that same run, without depending on the customer having opened their dashboard first.
- **FR-011**: System MUST guarantee that no subscription is ever charged twice or has two orders generated for the same delivery cycle, even if the renewal job is retried, overlaps with itself, or is invoked more than once for the same day.
- **FR-012**: System MUST record every renewal charge attempt — successful or failed — with its amount, outcome, and (when failed) a specific, distinguishable reason (e.g., declined, expired card, no remaining available items). A failure caused by the payment provider itself being unreachable or erroring (rather than actively declining the card) MUST be recorded using the same failure handling as a decline, per the clarification above — no separate category or timer.
- **FR-013**: System MUST retry a failed renewal charge on a fixed, built-in schedule of subsequent attempts (1 day, 3 days, and 5 days after the original failed attempt, per the clarification above), each attempt charging the same amount that was originally computed for that cycle rather than a freshly recalculated one — not an admin-configurable value in this phase.
- **FR-014**: System MUST use whichever payment method is currently the customer's saved active card at the moment each retry executes, not necessarily the same card that failed on the first attempt.
- **FR-015**: System MUST automatically transition a subscription to the paused state, with no resume date set, once every attempt in its retry schedule for a cycle has failed — and MUST NOT continue attempting charges for it beyond that point.
- **FR-016**: System MUST leave an automatically-suspended subscription exactly as visible and manageable through the existing dashboard (status, health indicator, resume action, card replacement) as any customer-initiated pause, per Phase 6's existing capabilities — this phase adds no new customer-facing surface of its own.
- **FR-017**: System MUST stop all further retries and any pending renewal consideration for a subscription immediately upon its cancellation, even mid-retry-schedule.
- **FR-018**: System MUST protect the renewal-trigering mechanism (the scheduled job's own entry point) from being invoked by anyone other than the trusted scheduler, since it performs real financial charges.

### Key Entities

- **Renewal Cycle** *(conceptual, tracked via existing Payment/Order records rather than a new standalone entity)*: One subscription's attempt to deliver and be charged for its next box on its next delivery date — spans from the first charge attempt through either a successful order or an exhausted retry schedule ending in suspension. Never re-priced mid-cycle once its first attempt has computed an amount.
- **Payment (extended)** *(existing, from Phase 5)*: This phase's renewal charges are additional attempts recorded the same way first-payment attempts already are — amount, outcome, failure reason, attempt number — with renewal attempts distinguishable from a subscription's original activation charge.
- **Order (extended)** *(existing, from Phase 5)*: Every order after a subscription's first is generated exclusively by this phase, on successful renewal, carrying that cycle's freshly-snapshotted items/price/address exactly as the first order already does; an order generated with one or more excluded unavailable items records that fact.
- **Subscription (extended)** *(existing, from Phase 4/6)*: Gains the operational state needed to track an in-progress retry schedule for its currently-unresolved cycle (which attempt it's on, when the next retry is due) and to distinguish an automatically-suspended pause (no resume date, dunning-caused) from a customer-chosen one (Phase 6) — both using the same underlying paused status.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of active, non-paused, non-cancelled subscriptions whose delivery is due are considered by the renewal job on the day they're due, with no manual intervention required.
- **SC-002**: 100% of successful renewal charges result in exactly one new order, carrying that cycle's own freshly-computed price — never the subscription's original signup price if admin rules or product prices have since changed.
- **SC-003**: 100% of renewal attempts — retried, overlapping, or repeated for the same day — result in at most one successful charge and at most one generated order per cycle; no customer is ever charged twice for the same delivery.
- **SC-004**: 100% of failed renewal charges are retried according to the defined schedule and, if every retry fails, result in the subscription being paused automatically — no subscription is left charging indefinitely against a card that keeps declining, and no subscription silently stops delivering without the customer being able to see why.
- **SC-005**: A subscription with an already-expired saved card never reaches Moyasar with a doomed charge attempt — its failure is recorded immediately and it enters the same recovery path as any other failure.
- **SC-006**: A subscription that loses one (but not all) of its box's products between deliveries still renews successfully with the remaining items, with no manual admin correction required.

## Assumptions

- This phase is scoped strictly to subscriptions already `active` (per Phase 4/5/6) — a subscription still `pending_payment` is never touched by this job; that remains Phase 5's own first-activation concern.
- Per the clarification above, a failed cycle blocks that subscription's own progression (its next delivery date does not advance) until resolved, but has no effect on any other subscription's renewal — this phase's job processes every due subscription independently in the same run.
- Per the clarification above, "automatically suspended" reuses Phase 6's existing `paused` status and its existing dashboard/health-indicator/resume/card-replacement surfaces verbatim; this phase introduces no new subscription status value and no new customer-facing screen.
- Per the clarification above, "notify the customer" is satisfied entirely by Phase 6's existing payment-history and subscription-health surfaces accurately reflecting each failure as it's recorded; building a new outbound notification channel (email/SMS) is explicitly out of scope for this phase.
- Per the clarification above, the retry schedule's exact spacing and the number of attempts before suspension follow `plan.md` §3b's own suggested default (retry at +1 day, +3 days, +5 days after the original failed attempt, then suspend) as a fixed, built-in value — not a new admin-configurable setting in this phase, even though every other business rule in the project (discounts, VAT, pause limits) is admin-controlled; this specific rule can become configurable in a later phase if the business needs to tune it.
- "Card expiry checked against the renewal date" means checked against the specific delivery date being renewed for, not merely today's date — a card expiring between today and a delayed retry's date is still caught before that retry fires.
- The scheduled job's trigger mechanism (a database-level scheduled function versus an authenticated endpoint an external scheduler calls) is an implementation choice for the planning phase; this specification only requires that it runs on a recurring schedule without manual intervention and cannot be invoked by an untrusted caller (FR-018).
- Admin-facing visibility into renewal/dunning activity beyond what a subscription's own owner already sees on their dashboard (e.g., an operations-wide view of failed renewals) is Phase 8's "Admin Operations" concern, not this phase's.
