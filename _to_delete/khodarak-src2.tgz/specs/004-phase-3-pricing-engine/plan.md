# Implementation Plan: Phase 3 — Admin Settings & the Pricing Engine

**Branch**: `004-phase-3-pricing-engine` | **Date**: 2026-08-10 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/004-phase-3-pricing-engine/spec.md`

## Summary

Give admins a single settings screen controlling every pricing/order rule (per-frequency
discounts, order rules, delivery mode, pause rules, VAT, rounding), implement the pricing
calculation itself as one pure, server-side function (`lib/pricing/calculate.ts`) that always
runs in the documented order (subtotal → frequency discount → delivery fee → VAT → total →
estimated monthly) and returns a full breakdown rather than a bare number, and expose it through a
public `POST /api/pricing/preview` Route Handler consumed by a new, minimal, signed-out-accessible
preview page — so that changing a discount in admin and reloading the preview is a real, working
demo two phases before the full subscription builder exists. Per the feature spec's 2026-08-10
Clarifications, this preview page lives at its own public route, not inside the customer-gated
`/subscription` path Phase 1 already protects.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0–2)

**Primary Dependencies**: `@supabase/ssr` + `@supabase/supabase-js` (settings reads/writes from
Route Handlers, product/city reads for the preview form), zod (settings update payload, pricing
preview request payload), Redux Toolkit + RTK Query (`settingsAdminApi` for the admin form,
`pricingApi` for the preview's recompute-on-change calls) — both following the
`lib/store/productsAdminApi.ts` / `lib/store/cartApi.ts` pattern from Phase 2. No new runtime
dependency.

**Storage**: Supabase (Postgres) — one new table, `settings`, enforced as a true singleton (a
`check (id = 1)` primary key, so there is exactly one row, matching FR-007's "one active
configuration" requirement at the database level, not just by convention). Per-frequency rules
(`weekly`/`biweekly`/`monthly`, each `{enabled, discountPercent, deliveriesPerMonth}`) are stored
as one `jsonb` column since they're a small, uniform, nested map (`plan.md` §3's own "json/columns"
framing); order rules, delivery configuration, pause rules, tax, and rounding are scalar columns
with `check` constraints, since each is a simple, independently-validated value that benefits from
a real database constraint rather than being buried in an untyped blob. No changes to existing
tables.

**Testing**: Vitest for `lib/pricing/calculate.ts` — per `plan.md` §3's own explicit "unit tests
before the UI" non-negotiable and Constitution Principle VI, this is written and passing *before*
the admin settings screen or preview page are wired up. The suite is a table of hand-verified
cases covering every edge case the spec calls out: minimum order value (met/not met), the
free-delivery threshold exactly hit, VAT inclusive vs. exclusive, and rounding boundaries for each
rounding mode. Playwright covers the phase's actual demo: change a frequency's discount in
`/admin/settings`, reload `/pricing-preview` with the same selections, confirm the price changed.

**Target Platform**: Same as Phase 0–2 — `npm run dev` locally, Linux container deferred to Phase
9; primary client is mobile Chrome/Safari.

**Project Type**: Web application — same single Next.js monolith, no new deployable.

**Performance Goals**: No new Core Web Vitals risk — `/pricing-preview` is a lightweight form (a
handful of product checkboxes/steppers, no large imagery required for a "minimal" preview per the
spec's own framing) rather than the full image-heavy grid from `/browse`. The calculation itself is
synchronous, in-memory arithmetic with no external calls, so its own latency is negligible; the
Route Handler's cost is dominated by the Supabase reads for current settings and product prices.

**Constraints**: The pricing calculation MUST run through exactly one server-side function, called
only from Route Handlers — the browser never computes or duplicates the formula, even for the
preview's "live" feel (Constitution Principle II). This is a stricter reading than Principle II's
own text technically requires yet ("the browser may render a preview using the same pure
function") because the *only* place this formula exists in this codebase is server-side; there is
no client-safe duplicate to share, so the preview calls the Route Handler on every selection change
rather than importing `calculate.ts` into client code. `/pricing-preview` MUST NOT be covered by
Phase 1's `/subscription` route-protection prefix (Clarifications, 2026-08-10) — it is a sibling
top-level route, not a `/subscription/*` sub-route, so `middleware.ts`'s existing prefix-matching
`/subscription/:path*` matcher does not need to change at all for this phase.

**Scale/Scope**: 1 new table (`settings`, exactly one row), 2 new pages (`/admin/settings`,
`/pricing-preview`), 2 new Route Handler groups (`/api/admin/settings`, `/api/pricing/preview`),
one pure calculation module, two new RTK Query API slices.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — `/admin/settings` and `/pricing-preview` are Server Components fetching their initial data (current settings, active products, active cities) via the server Supabase client; `"use client"` is scoped to `SettingsForm` and `PreviewForm` only | PASS |
| II. Server-Side Authority for Business Logic | Yes — this phase **is** the principle's core scenario. `calculate.ts` is the single server-side pricing function; every price shown anywhere (the preview, and later the real builder) is a fresh server recompute, never a client-trusted value | PASS — see Constraints above for why the preview calls the server on every change rather than mirroring the formula client-side |
| III. Performance Budget & Core Web Vitals | Yes but low-risk — no heavy client libraries, no large imagery required on the minimal preview page, calculation itself is cheap synchronous math | PASS |
| IV. Type Safety & Validation at Boundaries | Yes — `/api/admin/settings` PATCH body and `/api/pricing/preview` POST body are both zod-validated before touching `calculate.ts` or the database | PASS |
| V. Data Integrity, Idempotency & Security | Yes — `settings` RLS is public-read (non-sensitive business rules, needed by the public preview) / admin-write (mirrors the `products` table's policy shape from Phase 2); the singleton constraint is enforced at the database level (`check (id = 1)`), not just by only ever calling `PATCH` | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — `calculate.ts` is exactly the "bug silently costs real money" function Principle VI calls out by name; its Vitest suite is written and passing before any UI consumes it | PASS — scoped in Technical Context |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts (research.md, data-model.md, contracts/,
quickstart.md) keep `calculate.ts` as a pure function with no I/O (it receives settings and product
data as plain arguments rather than reading the database itself), so it's trivially unit-testable
without mocking Supabase; both Route Handlers validate their bodies with zod before calling it; the
`settings` table's singleton and range constraints are expressed as real `check` constraints, not
just application-level validation. Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/004-phase-3-pricing-engine/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── admin/
│   └── settings/
│       └── page.tsx                 # /admin/settings — Server Component, fetches the current
│                                     # (singleton) settings row, renders SettingsForm; no mockup
│                                     # exists (spec.md Assumptions, same treatment as
│                                     # /admin/products from Phase 2)
├── pricing-preview/
│   └── page.tsx                     # /pricing-preview — NEW top-level, public route (not under
│                                     # /subscription — Clarifications 2026-08-10). Server
│                                     # Component fetching sample products + active cities +
│                                     # enabled frequencies, renders PreviewForm
└── api/
    ├── admin/
    │   └── settings/
    │       └── route.ts             # GET (current settings), PATCH (update any subset of fields)
    └── pricing/
        └── preview/
            └── route.ts             # POST — public, zod-validates the request, calls
                                      # calculate.ts, returns the full breakdown (contracts/pricing-preview-api.md)

components/
├── admin/
│   └── settings/
│       └── SettingsForm.tsx         # "use client" — the full settings form (frequencies grid,
│                                     # order rules, delivery mode, pause rules, tax, rounding),
│                                     # wired to settingsAdminApi, rejects out-of-range values
│                                     # client-side to mirror the server's zod schema
└── pricing/
    ├── PreviewForm.tsx              # "use client" leaf — product/quantity/frequency/city
    │                                 # selection; calls pricingApi's preview query on every
    │                                 # change (debounced), never computes a price itself
    └── PriceBreakdownCard.tsx       # Presentational — renders the returned breakdown's lines
                                      # (subtotal, discount, delivery fee, VAT, total, estimated
                                      # monthly) plus the min-order/max-items compliance flags

lib/
├── pricing/
│   ├── calculate.ts                 # THE pricing engine — pure function, no I/O (data-model.md,
│   │                                 # contracts/pricing-calculation.md): (items, quantities,
│   │                                 # frequency, city, settings) → full breakdown
│   └── mapSettingsRow.ts            # snake_case → camelCase mapper (mirrors mapProductRow.ts)
├── validation/
│   ├── settings.ts                  # zod schema: settings update payload, range-checked to match
│   │                                 # the database's own check constraints
│   └── pricingPreview.ts            # zod schema: preview request payload (items[], frequency,
│                                     # cityId)
└── store/
    ├── settingsAdminApi.ts          # RTK Query (getSettings, updateSettings) against
    │                                 # /api/admin/settings — mirrors productsAdminApi.ts
    └── pricingApi.ts                # RTK Query (previewPrice query) against
                                      # /api/pricing/preview — mirrors cartApi.ts

supabase/
└── migrations/
    └── <timestamp>_settings.sql     # settings table (singleton via check (id = 1)), RLS
                                      # (public-read / admin-write, mirroring products), seed one
                                      # default row so the engine has something to calculate
                                      # against immediately

tests/
├── unit/
│   ├── pricing.calculate.test.ts    # THE critical suite — written first. Boundary-case table:
│   │                                 # below/at/above min order value, free-delivery threshold
│   │                                 # exactly met, VAT inclusive vs. exclusive, a rounding
│   │                                 # boundary for each rounding mode, a disabled frequency,
│   │                                 # a product dropped mid-calculation
│   └── validation.settings.test.ts  # zod schema edge cases (out-of-range percentages, negative
│                                     # amounts, invalid enum values)
└── e2e/
    └── pricing-preview.spec.ts      # admin changes a discount in /admin/settings → reload
                                      # /pricing-preview with the same selections → price changed
                                      # — the phase's demo scenario (quickstart.md)
```

**Structure Decision**: Stays inside the Phase 0–2 monolith. `calculate.ts` is deliberately a pure
function with settings/product data passed in as arguments rather than fetching them itself, so it
has zero I/O and can be unit-tested directly — matching `plan.md` §3's "one implementation,
server-side" and "unit tests before the UI" rules literally, and Constitution Principle VI's
test-first requirement for exactly this kind of money-adjacent logic. `/pricing-preview` is a new
top-level route rather than a `/subscription` sub-route specifically so `middleware.ts`'s existing
`/subscription/:path*` matcher (Phase 1) needs zero changes — no risk of accidentally loosening or
mis-scoping the protection Phase 4's real checkout will rely on. Both new Route Handler groups
follow the established `/api/admin/*` (role-gated, mirrors `/api/admin/products`) and public
`/api/*` (mirrors none directly, but follows the same zod-then-Supabase shape as every other
handler) split.

## Complexity Tracking

*No Constitution Check violations — table not needed.*
