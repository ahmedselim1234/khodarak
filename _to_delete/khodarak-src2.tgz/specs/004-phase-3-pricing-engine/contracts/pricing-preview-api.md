# Contract: `POST /api/pricing/preview`

The public Route Handler backing `/pricing-preview` (spec User Story 3, FR-017). No
authentication required (FR-017a) — this is the one Route Handler in the project so far with no
session check at all. The request body is validated with the zod schema in
`lib/validation/pricingPreview.ts`; the handler then resolves current product prices and the
current `settings` row and calls `lib/pricing/calculate.ts` (see
[pricing-calculation.md](./pricing-calculation.md) for the function's own contract) — it never
accepts a price, subtotal, or breakdown value from the request body itself (Constitution
Principle II).

## `POST /api/pricing/preview`

**Request**:
```json
{
  "items": [
    { "productId": "uuid", "quantity": 2 },
    { "productId": "uuid", "quantity": 1 }
  ],
  "frequency": "weekly",
  "cityId": "uuid"
}
```

Validation: `items` an array of `{productId: uuid, quantity: positive int}` (may be empty — FR-020's
empty state); `frequency` one of `'weekly' | 'biweekly' | 'monthly'`; `cityId` a valid uuid.

**Behavior**:
1. Look up each `productId` in `products`; any that don't exist or are unavailable are excluded
   and recorded in the response's `droppedItems` (FR-019) rather than failing the request.
2. Look up `cityId` in `cities` for its `delivery_fee_override` (falls back to the settings'
   `deliveryFlatFee` when null — research.md, data-model.md).
3. Look up the current `settings` row.
4. If the requested `frequency` is currently disabled, respond `422` (see below) rather than
   silently calculating against a frequency nobody should be able to select (FR-012).
5. Call `calculate.ts` with the resolved items, frequency, city, and settings.
6. Return the full breakdown.

**Response — success**:
```
200 OK
Content-Type: application/json

{
  "breakdown": {
    "itemsSubtotal": 45.00,
    "droppedItems": [],
    "frequencyDiscountAmount": 2.25,
    "afterDiscount": 42.75,
    "deliveryFee": 10.00,
    "taxableBase": 52.75,
    "vatAmount": 6.88,
    "totalPerDelivery": 59.50,
    "estimatedMonthly": 238.00,
    "meetsMinimumOrderValue": true,
    "withinMaxItemsPerBox": true
  }
}
```

**Response — empty selection** (FR-020): `200 OK` with `itemsSubtotal: 0` and every derived field
at its zero/floor value — not an error. The client renders this as the empty state.

**Response — disabled frequency**:
```
422 Unprocessable Entity

{ "error": "frequency_disabled" }
```

**Response — validation error**:
```
400 Bad Request

{ "error": "validation_failed", "fields": { "cityId": "must be a valid id" } }
```

## Notes

- This endpoint performs no writes and creates no order/subscription — it is purely a calculation
  preview (spec Assumptions), consistent with `cart-api.md`'s `GET /api/cart` precedent of
  returning a live, non-binding total from Phase 2.
- Every value in the response is freshly computed on this exact request from the current `products`
  prices and current `settings` — nothing here is cached or trusted from a prior call
  (Constitution Principle II, SC-002).
