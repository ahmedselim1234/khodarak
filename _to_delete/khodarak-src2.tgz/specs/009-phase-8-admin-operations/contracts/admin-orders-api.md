# Contract: `/admin/orders` list + `PATCH /api/admin/orders/[id]`

## `/admin/orders` list (Server Component read)

Read-only, no client-side mutation drives the list itself (only the row actions below do) — per
Constitution Principle I, `app/admin/orders/page.tsx` queries Supabase directly via
`lib/admin/queryAdminOrders.ts`, mirroring `lib/products/queryProducts.ts`'s exact shape. Requires
`requireAdmin()` (server-side redirect/deny otherwise — FR-001).

**`searchParams`**: `status?` (`pending|out_for_delivery|delivered|cancelled`), `date?` (ISO date,
matches `scheduled_date`), `search?` (matched against the owning customer's `full_name`, `email`,
`phone` via `profiles`), `page?`.

**Query**: `orders` joined to `profiles` (via `user_id`), filtered by the above, ordered by
`scheduled_date desc, created_at desc`, paginated (`PAGE_SIZE`, mirroring the catalog's own
convention) — relies on the new `orders_select_admin`/`profiles_select_admin` RLS policies
(data-model.md).

**Renders**: each row's customer (name), scheduled date, status, and total (from
`price_breakdown.totalPerDelivery`, same convention as every other order total display in this
project) — plus `OrderRowActions`, which only shows the buttons for transitions currently valid
from that row's own status (`orderStatusTransition.ts`).

---

## `PATCH /api/admin/orders/[id]`

**Request**:
```json
{ "status": "out_for_delivery" }
```
Validated by `lib/validation/adminOrderStatus.ts` — `status` must be one of
`out_for_delivery | delivered | cancelled` (an admin never sets `pending` — that's only ever the
order's own creation-time default).

**Behavior**:
1. `requireAdmin()` — `401`/`403` otherwise (FR-001).
2. Load the order's current `status`. `404` if it doesn't exist.
3. Call `orderStatusTransition(currentStatus, requestedStatus)` — `422
   { "error": "invalid_transition", "from": "...", "to": "..." }` if not a valid forward move
   (FR-003) — per `data-model.md`'s state diagram (no transition from `delivered`, no backward
   move, no skip).
4. Conditional update (research.md §3):
   `UPDATE orders SET status = $requestedStatus, status_updated_by = $adminId,
   status_updated_at = now()`, plus `delivered_at = now()` only when transitioning to
   `delivered` (FR-004) — `WHERE id = $id AND status = $currentStatus`. Zero rows updated → `409
   { "error": "status_changed", "currentStatus": "..." }` (someone else already changed it —
   research.md §3's own named edge case).
5. Uses the caller's own RLS-scoped client (`orders_update_admin` policy) — never service-role
   (research.md §1).

**Response — success**: `200 { "status": "out_for_delivery" }`.

**Response — invalid transition**: `422 { "error": "invalid_transition", "from": "pending", "to": "delivered" }`.

**Response — concurrent change**: `409 { "error": "status_changed", "currentStatus": "cancelled" }`.

**Response — not found**: `404 { "error": "not_found" }`.

**Response — not admin**: `401 { "error": "unauthenticated" }` or `403 { "error": "forbidden" }`.
