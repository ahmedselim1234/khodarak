# Contract: `/api/cart`

Route Handlers backing the signed-in customer's server-synced cart (spec User Story 3, FR-013
through FR-015). All three endpoints require an authenticated session; a guest never calls these —
the guest cart is pure client state (`lib/cart/cartSlice.ts`) until login triggers `POST
/api/cart/merge`. Every request body is validated with the zod schemas in `lib/validation/cart.ts`.
All queries run through the server Supabase client and rely on RLS (`user_id = auth.uid()`) as the
authorization boundary, matching the `addresses-api.md` precedent from Phase 1.

## `GET /api/cart`

Returns the caller's resolved cart — `cart_items` joined with current `products` data — plus
totals. This is what `CartBar` and any signed-in cart view read.

**Request**: no body, no query params.

**Response — success**:
```
200 OK
Content-Type: application/json

{
  "items": [
    {
      "productId": "uuid",
      "quantity": 2,
      "name": "طماطم عضوية طازجة",
      "price": 12.50,
      "unit": "kg",
      "imageUrl": "https://.../....jpg",
      "isAvailable": true,
      "maxQty": 10
    }
  ],
  "itemCount": 2,
  "total": 25.00
}
```

`total` is `Σ (price × quantity)` computed at request time from live `products` data — an unlocked
preview per Constitution Principle II's carve-out for previews (see research.md §4), not a
persisted or charged value. `itemCount` is the sum of `quantity` across items, matching what the
persistent cart bar shows (FR-013).

**Response — unauthenticated**: `401 Unauthorized`.

---

## `PUT /api/cart/items/[productId]`

Upserts the caller's quantity for one product. This is what the `QuantityStepper` calls for a
signed-in customer.

**Request**:
```json
{ "quantity": 3 }
```

Validation (FR-011, FR-012): `quantity` a non-negative integer. The handler clamps it to the
product's `[minQty, maxQty]` via `lib/cart/clampQuantity.ts` (the same pure function the client
uses for instant UI feedback, re-run server-side as the authoritative clamp) — a request quantity
outside those bounds is not rejected, it's silently clamped to the nearest bound, matching FR-012's
"the stepper prevents it and the quantity stays at the nearest allowed bound." `quantity: 0` deletes
the row instead of upserting it.

**Response — success**:
```
200 OK

{ "productId": "uuid", "quantity": 3 }
```

or, when clamped to 0:
```
200 OK

{ "productId": "uuid", "quantity": 0 }
```

**Response — product unavailable**: if the product is currently `is_available: false` and the
caller does not already have a `cart_items` row for it, `409 Conflict` — FR-018 prevents *adding*
an unavailable product, but a row already in the cart from before it went unavailable may still
have its quantity *decreased* (not increased) via the same endpoint.

**Response — not found**: `404 Not Found` (product doesn't exist). **Unauthenticated**: `401`.

---

## `POST /api/cart/merge`

Merges a guest's device-local cart into the caller's server-side cart at login (FR-015). Called
once, right after a successful sign-in, with the guest cart's raw `{productId, quantity}` pairs
read from `cartSlice`/`localStorage` — never the guest's cached price/name snapshot, which the
server re-resolves against live `products` data.

**Request**:
```json
{
  "items": [
    { "productId": "uuid", "quantity": 2 },
    { "productId": "uuid", "quantity": 1 }
  ]
}
```

**Behavior**: for each incoming item, the handler runs `lib/cart/mergeCartQuantities.ts` against
the caller's existing `cart_items` row (if any) for that product: the merged quantity is
`max(existingQuantity, incomingQuantity)`, clamped to that product's `maxQty`. Products with no
existing row are inserted as-is (clamped). Products deleted since the guest added them are silently
skipped (no error) — this is a merge, not a strict replay.

**Response — success**:
```
200 OK

{ "merged": 2, "skipped": 0 }
```

The client clears its guest `cartSlice`/`localStorage` state after a `200`, then refetches
`GET /api/cart` (RTK Query `invalidatesTags`) to render the merged, authoritative cart.

**Response — unauthenticated**: `401 Unauthorized`. **Response — validation error**: `400 Bad
Request` if `items` isn't an array of `{productId: uuid, quantity: non-negative int}`.

## Notes

- No endpoint here exposes another user's cart; every query is additionally scoped by RLS
  (`user_id = auth.uid()`) beneath the handler's own filtering, per Constitution Principle V.
- None of these endpoints touch `orders`, `subscriptions`, or any snapshot table — the cart remains
  a pre-subscription selection mechanism only, per spec Assumptions.
