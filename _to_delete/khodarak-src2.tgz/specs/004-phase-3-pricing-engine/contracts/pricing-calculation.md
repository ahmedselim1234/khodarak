# Contract: `lib/pricing/calculate.ts`

Not a network endpoint — the one, pure, server-side function every price in this product runs
through (`plan.md` §3's first non-negotiable). Documented as its own contract because it's the
piece both `POST /api/pricing/preview` (this phase) and the real subscription builder (Phase 4)
call, and because Constitution Principle VI requires its test suite to exist before any UI does.

## Signature

```ts
function calculate(input: {
  items: Array<{ productId: string; price: number; quantity: number }>;
  frequency: "weekly" | "biweekly" | "monthly";
  city: { id: string; deliveryFeeOverride: number | null };
  settings: Settings; // full shape per data-model.md
}): PriceBreakdown; // full shape per data-model.md
```

**No I/O.** Every value the function needs — item prices, the frequency's discount, the city's
delivery-fee override, VAT/rounding configuration — is passed in already resolved by the caller
(the Route Handler). This is what makes it directly unit-testable with a plain table of inputs and
expected outputs, with no database or network mocking required.

## Calculation order (exact, per `plan.md` §3 — this function MUST NOT reorder these steps)

1. `itemsSubtotal = Σ (item.price × item.quantity)` over items still present after any
   unavailable/deleted ones are dropped by the caller (this function receives only resolvable
   items; dropped-item bookkeeping is the Route Handler's job per
   [pricing-preview-api.md](./pricing-preview-api.md), not this function's).
2. `frequencyDiscountAmount = itemsSubtotal × (settings.frequencies[frequency].discountPercent / 100)`
3. `afterDiscount = itemsSubtotal − frequencyDiscountAmount`
4. `deliveryFee` resolved from `settings.deliveryMode`:
   - `'flat'` → `settings.deliveryFlatFee`
   - `'free_above_threshold'` → `0` when `afterDiscount >= settings.deliveryFreeThreshold`
     (inclusive — Edge Cases), else `settings.deliveryFlatFee`
   - `'per_city'` → `city.deliveryFeeOverride ?? settings.deliveryFlatFee` (fallback per
     research.md/data-model.md)
5. `taxableBase = afterDiscount + deliveryFee`
6. `vatAmount`:
   - if `settings.pricesIncludeVat` → VAT is *extracted* from `taxableBase`
     (`taxableBase − taxableBase / (1 + vatPercent/100)`), not added on top
   - else → VAT is *added* on top (`taxableBase × vatPercent/100`)
7. `totalPerDelivery = round(taxableBase + vatAmount if !pricesIncludeVat else taxableBase, settings.roundingMode)`
   — i.e. the pre-rounding total already includes VAT correctly either way per step 6; rounding is
   the last arithmetic step before the number is returned.
8. `estimatedMonthly = totalPerDelivery × settings.frequencies[frequency].deliveriesPerMonth`

Additionally, independent of the above (informational, not blocking — FR-016):
- `meetsMinimumOrderValue = itemsSubtotal >= settings.minOrderValue`
- `withinMaxItemsPerBox = Σ item.quantity <= settings.maxItemsPerBox`

## Rounding modes (`round(value, mode)`)

- `'none'` → value unchanged (still capped to 2 decimal places to avoid float noise)
- `'nearest_0.5'` → `Math.round(value * 2) / 2`
- `'nearest_1'` → `Math.round(value)`

## Required test cases (`tests/unit/pricing.calculate.test.ts` — written before any UI)

| Case | What it proves |
|---|---|
| Basic multi-item, enabled frequency, flat delivery | The happy path matches the formula by hand |
| `itemsSubtotal` below `minOrderValue` | `meetsMinimumOrderValue: false`, price still computed (FR-016) |
| Total quantity above `maxItemsPerBox` | `withinMaxItemsPerBox: false`, price still computed |
| `afterDiscount` exactly equal to `deliveryFreeThreshold` | Delivery fee is `0` (inclusive boundary — Edge Cases) |
| `afterDiscount` one cent below `deliveryFreeThreshold` | Delivery fee is the flat fee (boundary is not off-by-one) |
| `pricesIncludeVat: true` vs. `false` on the same inputs | Two different, both individually correct, totals |
| A pre-rounding total exactly on a `nearest_0.5` boundary (e.g. `12.25`) | Rounds to the documented target, not float-drifted |
| A pre-rounding total exactly on a `nearest_1` boundary (e.g. `12.5`) | Rounds per `Math.round`'s documented behavior, consistently |
| `roundingMode: 'none'` | Value passes through unchanged (to 2 decimals) |
| `deliveryMode: 'per_city'` with a city override set | Uses the city's override, not the flat fee |
| `deliveryMode: 'per_city'` with no override on that city | Falls back to `deliveryFlatFee` |
| Empty `items` array | `itemsSubtotal: 0`, every derived field at its floor value, no division-by-zero or NaN |
| `estimatedMonthly` for each frequency's `deliveriesPerMonth` | Multiplication is correct per frequency |
