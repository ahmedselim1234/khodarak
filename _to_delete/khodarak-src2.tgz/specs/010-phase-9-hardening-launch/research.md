# Phase 0 Research: Phase 9 — Hardening, Docker & Launch

## 1. Where do audit findings and the launch checklist actually live?

**Decision**: Two versioned markdown files in the feature's own spec directory —
`AUDIT_FINDINGS.md` (one row per finding: where, what, severity, resolution) and
`LAUNCH_CHECKLIST.md` (one line per functional requirement in spec.md, each resolved to
verified-complete-with-evidence or explicitly-deferred-non-blocking, per the clarification
session). Not database tables, not a project-management tool ticket, not a Slack thread.

**Rationale**: spec.md's own Key Entities section already frames "Audit Finding" and "Launch
Checklist" as records of a one-time verification process, not runtime application data — nothing
in the running application ever reads them. A markdown file in version control is durable (visible
in `git log`/`git blame` after launch, exactly the way the Edge Cases session says a deferred
finding must stay visible rather than being silently dropped), reviewable in a pull request like
everything else in this project, and requires no new infrastructure for a one-time, phase-scoped
artifact.

**Alternatives considered**: A `launch_audit` database table — rejected: it would need its own
migration, RLS policy, and admin UI to be useful, all for data nobody but the team preparing to
launch ever needs to see, and once launched this data has no further runtime purpose (unlike every
other table this project has, which the live application itself reads).

## 2. Where does the app actually get deployed?

**Decision**: A single Docker host (per the clarification session) — the smallest thing that "run
this `docker-compose.yml`" can mean: one VPS (or a managed single-container hosting product,
functionally equivalent for this project's purposes) with Docker installed, reachable at the
production domain, running `docker compose -f docker-compose.prod.yml up -d`.

**Rationale**: The clarification session settled this explicitly, and it's the only choice
consistent with every prior phase's own repeated architectural stance — a single Next.js monolith,
no microservices, no separate backend, Docker deliberately deferred until this exact phase rather
than designed around from day one. Introducing a container orchestrator (Kubernetes, ECS, a
serverless container platform with its own deployment model) at the very last phase of a
project that was never built with multi-service scaling in mind would be solving a problem this
project doesn't have.

**Alternatives considered**: A serverless/edge platform's own native Next.js deployment (bypassing
Docker) — rejected outright: the spec's own User Story 2 requires the *containerized* app to be
what's verified and deployed; bypassing the container for the actual deployment would make Docker
a checkbox exercise rather than the actual deployment artifact.

## 3. How does a deploy — and a rollback — actually work against one Docker host?

**Decision**: `docker-compose.prod.yml` overlays the existing `docker-compose.yml`, replacing
`build: .` with `image: ghcr.io/<org>/khodarak:${IMAGE_TAG}`. CI's deploy job (on `main`, after
every check passes) builds the image, tags it with the commit SHA, and pushes it to GitHub
Container Registry (GHCR — free for a GitHub-hosted repo, no new account). `scripts/deploy.sh`,
run on the host, sets `IMAGE_TAG` to the new SHA and runs
`docker compose -f docker-compose.prod.yml pull && ... up -d`. `scripts/rollback.sh` does the
identical restart, pointed at the *previous* known-good SHA instead — rollback is a tag change,
never a rebuild, which is what makes it fast and low-risk enough to actually exercise (per the
clarification session's own requirement that it be proven, not just documented).

**Rationale**: Tag-based rollback is the standard, low-complexity pattern for exactly this
deployment shape (one host, one container, no orchestrator to hand rollback off to) — it needs no
new tooling beyond Docker itself and a registry GitHub already provides for free. Keeping
`docker-compose.yml` itself unchanged (still `build: .`) preserves User Story 2's own local
dev-parity scenario exactly as specified, rather than conflating "the file that proves the
container works" with "the file that actually deploys it."

**Alternatives considered**: A managed PaaS with its own built-in rollback (e.g., a "redeploy
previous version" button) — rejected per research.md §2's own reasoning: it would mean the
container isn't really what gets deployed, undermining User Story 2. A blue-green/two-host setup
— rejected as unnecessary complexity for a single-host target with no stated uptime requirement
beyond FR-011's 5-minute *detection* window (not a zero-downtime *deploy* requirement).

## 4. What does "basic operational monitoring" actually consist of?

**Decision**: Three narrow, mostly-already-built pieces:
1. **Errors** (FR-010): server-side routes already follow this project's own established
   structured-logging convention (subscription id, order id, cycle number, etc., per the
   constitution's own Principle VI) — this phase's job is to confirm that convention is actually
   followed everywhere by the audit (User Story 1), and to configure the production container's
   log output to reach somewhere the team can actually see it (the hosting platform's own log
   viewer, or a minimal external log-drain service) rather than disappearing into an unwatched
   container's stdout.
2. **Uptime** (FR-011): a free-tier external uptime-checking service polling the existing
   `/api/health` endpoint (Phase 0, unchanged — already checks live Supabase reachability, exactly
   the signal an uptime check needs) every 1–5 minutes, alerting the team on failure — satisfying
   the clarified 5-minute SLA directly from the checker's own polling interval.
3. **Dunning rate** (FR-012): one new counter on Phase 8's existing `CountersOverview.tsx` —
   subscriptions auto-suspended (`subscription_pauses` rows with `initiated_by_admin_id IS NULL
   AND resume_date IS NULL`, Phase 7/8's own established shape for an auto-suspension) in the
   last 7 days — reusing the exact query pattern Phase 8 already established for every other
   admin counter, not a new monitoring system.

**Rationale**: spec.md's own Assumptions section already commits to "basic operational visibility
appropriate for a first public launch... not a full observability platform," and explicitly defers
the specific tool choice as a planning-level detail — this research resolves that detail by
maximizing reuse of what Phases 0–8 already built (the health endpoint, the logging convention,
the admin counters page) rather than introducing a dedicated observability *product* into the
application's own dependency tree for a "basic" need.

**Alternatives considered**: A dedicated APM/error-tracking SDK embedded in the application (e.g.
an error-tracking client library) — considered, and reasonable, but scoped as an *optional*
enhancement in `quickstart.md` rather than a hard requirement: FR-010 only requires the team
receives *a* record with enough context, which the existing logging convention plus a log-viewing
surface already satisfies without adding a new runtime dependency this phase's own Constitution
Check would need to separately justify.

## 5. What did the audit already find, just from reading the existing Dockerfile?

**Decision**: `Dockerfile`'s builder stage sets build-time placeholders for
`NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` (all
from Phase 0, when the Dockerfile was first written) but was missing placeholders for **four**
variables added across later phases and never back-filled: `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY`,
`MOYASAR_SECRET_KEY`, `MOYASAR_WEBHOOK_SECRET` (all Phase 5), and `CRON_SECRET` (Phase 7).

**Confirmed by actually reproducing the build** (not just by inspection) — with `.env.local`
temporarily removed and only the `Dockerfile`'s own `ENV` placeholders set, `npm run build` fails
twice in sequence: first on the missing `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY` (`lib/env.ts`, the
originally-hypothesized gap), and then — after adding that one — again on the missing
`MOYASAR_SECRET_KEY`/`MOYASAR_WEBHOOK_SECRET`/`CRON_SECRET` (`lib/env.server.ts`), because
`lib/supabase/server.ts` imports `lib/env.server.ts` at module level too, not only the public
schema. This is a larger gap than originally hypothesized in this section — not one missing
placeholder, but four. Adding all four (`AUDIT_FINDINGS.md` F-001) and re-running the identical
reproduction confirms the build now succeeds.

**Rationale**: This is exactly the kind of drift the whole phase exists to catch — three phases
each shipped a new required env var without ever actually running the build that env var would
have broken, because Docker was deliberately not part of the workflow until now (`plan.md` §5's
own stated reason for deferring it). Fixing it is a small, mechanical addition mirroring the
pattern the three original placeholders already established.

**Alternatives considered**: None — this is a straightforward, unambiguous bug found and confirmed
by reproduction, not a design decision with real alternatives.
