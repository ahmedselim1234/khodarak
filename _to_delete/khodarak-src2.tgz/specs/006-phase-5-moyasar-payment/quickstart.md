# Quickstart: Validating Phase 5 — Moyasar Integration & First Payment

Validates the three user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 4 checkout (a signed-in customer with at least one `pending_payment`
subscription).

## Prerequisites

- Phase 4's quickstart already passing
- A Moyasar **test-mode** account (`MOYASAR_SECRET_KEY`, `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY`,
  `MOYASAR_WEBHOOK_SECRET` configured — FR-018)
- A public tunnel (e.g. ngrok/cloudflared) pointed at local dev, with the Moyasar dashboard's
  webhook URL set to `<tunnel>/api/webhooks/moyasar` (`plan.md` §3b)
- Migration applied: `payment_methods`, `payments`, `webhook_events`, `orders`, `order_items`
  (see [data-model.md](./data-model.md))
- `npm run dev` running

## 1. Run the payments unit suite first (Constitution Principle VI)

```
npm run test:unit
```

**Expected**: `tests/unit/payments.halalas.test.ts` and `tests/unit/payments.retryThrottle.test.ts`
both pass, including the "classic 100× bug" boundary case for halalas conversion. This MUST be
green before manually trusting anything the payment UI shows.

## 2. Pay with a succeeding Moyasar test card (User Story 1 + 2, FR-001–010, SC-001/002/005/006)

```
# signed in, with a pending-payment subscription: open /subscription/confirmed/<id>
# choose "add a new card", enter a Moyasar test card known to succeed
# check the recurring-charge consent box, submit, complete the 3DS test challenge
```

**Expected**: card fields never appear in any request to this app's own server (check the network
tab — only a token id is ever sent, FR-001/SC-006); after completing 3DS, you land back on
`/subscription/confirmed/<id>` showing the real success screen (not Phase 4's "coming soon" copy);
the subscription's status is now `active`; a `payment_methods` row exists with only brand/last
four/expiry; a `payments` row shows `status: 'paid'` with `amount_halalas` matching the
subscription's snapshotted total exactly; an `orders` row (with `order_items`) now exists,
scheduled for the subscription's chosen delivery date; the payment appears in the Moyasar test
dashboard (the phase's own demo target).

## 3. Confirm the webhook path independently activates (User Story 2, FR-011, Edge Cases)

```
# start another payment with a succeeding test card, but close the browser tab
# immediately after the 3DS challenge is submitted (before the redirect completes)
# check the subscriptions table a few seconds later
```

**Expected**: the subscription still transitions to `active` and its order still gets generated,
driven entirely by the webhook notification — the customer never needed to see the redirect
complete. A `webhook_events` row exists with `processed_at` set.

## 4. Confirm double-delivery is a no-op (User Story 2 Acceptance Scenario 5, FR-013/014, SC-003)

```
# re-deliver the same webhook event from the Moyasar dashboard's webhook log (or replay the same
# payload against /api/webhooks/moyasar directly)
```

**Expected**: `200 OK`, but no second order, no duplicate payment record, and the subscription's
`started_at` is unchanged from the first activation.

## 5. Pay with a declining Moyasar test card (User Story 3, FR-016, SC-004)

```
# on a different pending-payment subscription: submit a Moyasar test card known to decline
```

**Expected**: a specific, actionable decline message (not a generic error); the subscription
remains `pending_payment`; a `payments` row exists with `status: 'failed'` and a `failure_reason`.

## 6. Confirm retry throttling (Clarifications 2026-08-10, FR-016a)

```
# on the same subscription from step 5, submit a declining test card several times in a row
```

**Expected**: after a small number of consecutive failures, further attempts are rejected with a
"too many attempts" message before Moyasar is even called (check the network tab — no outbound
Moyasar request on a throttled attempt).

## 7. Confirm server-side authority (Constitution Principle II)

```
# during a payment attempt, inspect the POST /api/subscriptions/[id]/pay request body
```

**Expected**: the body contains only `consentGiven` and either `moyasarToken` or
`paymentMethodId` — no amount, no price. Attempting the request with a fabricated large/small
amount field (if added manually) has no effect — the server always computes `amount_halalas` from
the subscription's own snapshot.

## 8. Confirm no client-writable path to financial state (Constitution Principle V)

```
# signed in as a customer: attempt to PATCH your own subscriptions row's `status` directly via
# the Supabase REST API (browser devtools or curl, using the anon key + your session)
```

**Expected**: rejected — no RLS policy grants this write at all (research.md §1); the same holds
for direct writes to `payment_methods`/`payments`/`orders`/`order_items`.

## 9. Run the full unit and e2e suites

```
npm run test:unit
npx playwright test tests/e2e/payment-flow.spec.ts
```

**Expected**: `payments.halalas.test.ts` and `payments.retryThrottle.test.ts` both pass; the
Playwright spec walks steps 2 and 5 above (succeed, then decline-and-retry) without manual
intervention.
