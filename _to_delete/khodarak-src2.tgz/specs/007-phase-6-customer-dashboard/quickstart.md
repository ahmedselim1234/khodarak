# Quickstart: Validating Phase 6 — Customer Dashboard

Validates the five user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 5 checkout (a signed-in customer with an `active` subscription and at least
one generated `orders` row, per Phase 5's own quickstart).

## Prerequisites

- Phase 5's quickstart already passing (an `active` subscription with a saved `payment_methods`
  row and one `orders` row exists for the test customer)
- Migration applied: `subscriptions` pending-change columns,
  `subscription_pending_items`, `subscription_pauses` (see [data-model.md](./data-model.md))
- `npm run dev` running

## 1. Run the new unit suites first (Constitution Principle VI)

```
npm run test:unit
```

**Expected**: `subscription.resolveEffectiveConfig.test.ts`,
`subscription.pauseEligibility.test.ts`, and `subscription.subscriptionHealth.test.ts` all pass.
This MUST be green before manually trusting anything the dashboard shows.

## 2. See status, next delivery, and health at a glance (User Story 1, FR-001–005, SC-001)

```
# signed in as the active-subscription customer: open /dashboard
```

**Expected**: status card shows "active," the correct next delivery date, its items/quantities,
and its charge amount, all matching the subscription's real `subscription_items` and
`price_breakdown`; the health indicator shows "good." Open `/dashboard` as a customer with no
subscription at all — see the first-time empty state pointing to `/subscription`, not a broken
page (Acceptance Scenario 4).

## 3. Edit the box outside the cutoff window and watch the price/next-delivery update (User Story 2, FR-006–008, SC-002, the phase's own demo target)

```
# on /dashboard, open the box editor; change a quantity and/or the frequency
```

**Expected**: the price breakdown updates live, using the exact same numbers
`/api/pricing/preview` would independently return for the same inputs (SC-002); saving commits
immediately (`"applied": "immediately"`); the status card's next delivery date and charge amount
now reflect the change without a page reload.

## 4. Confirm a deferred edit doesn't touch the locked delivery (User Story 2 Acceptance Scenarios 4 & 6, FR-009, SC-003)

```
# set a test subscription's next_delivery_date to fall inside settings.edit_cutoff_hours from now
# (directly in Supabase, for test purposes) — then open the box editor and save a change
```

**Expected**: the response is `"applied": "pending"` with an `effectiveFrom` date after the locked
delivery; the dashboard still shows the *original* items/price for the upcoming (locked) delivery,
plus a banner summarizing what changes starting after it (`PendingChangeBanner`). Save a second
edit before that date arrives — confirm it replaces the first pending change rather than stacking
(research.md §1).

## 5. Pause, then resume early (User Story 3, FR-010/FR-012, SC-005)

```
# on /dashboard, pause the subscription with a resume date a week out
# immediately resume it before that date
```

**Expected**: after pausing, status shows "paused" with the chosen resume date, and no delivery is
presented as scheduled — even if the next delivery had been inside the cutoff window a moment
earlier (pause overrides the lock, Clarification 4). After resuming early, status returns to
"active" immediately with a freshly recalculated next delivery date — this is the exact sequence
`plan.md`'s own demo target names ("pause a subscription, resume it, edit the box... next delivery
date and next charge recalculating correctly").

## 6. Hit the pause-limit and see it blocked (FR-011, SC-004)

```
# insert enough subscription_pauses rows (started_at within the last 365 days) to reach
# settings.max_pauses_per_year for the test subscription, then attempt one more pause
```

**Expected**: `422 { "error": "pause_limit_exceeded", "limit": "max_pauses_per_year" }`; the
subscription's status is unchanged.

## 7. Cancel and confirm it's terminal (User Story 3 Acceptance Scenarios 5–6, FR-014)

```
# on /dashboard, start the cancel flow, dismiss it without confirming — confirm nothing changed
# start it again, confirm this time
```

**Expected**: dismissing leaves status untouched; confirming sets status to "cancelled"
immediately (even if the next delivery was inside the cutoff window), and every other lifecycle
endpoint (`pause`, `resume`, another `PATCH` edit) now returns `409 { "error": "already_cancelled" }`
for this subscription.

## 8. View order history and detail (User Story 4, FR-016/017, SC-006)

```
# open /dashboard/orders, then open the one existing order's detail
```

**Expected**: the list shows the order with its real date/status/total; the detail view shows the
exact snapshotted items and price breakdown from generation time. As an experiment, change that
product's price in `/admin` — reload the order detail and confirm nothing about it changed.

## 9. Manage settings — address, card, payment history, profile (User Story 5, FR-018–023, SC-007)

```
# open /dashboard/settings
# add a new address, set it default
# replace the saved card using a Moyasar test card
# view payment history
# update the profile name
```

**Expected**: every action completes without leaving `/dashboard/settings`; the new address
becomes the subscription's default; the new card's brand/last-four appears and the old card is no
longer offered anywhere; payment history lists the existing Phase 5 payment; the profile name
updates immediately in the page header/anywhere it's shown. Attempt to delete the address
currently assigned to the active subscription — confirm it's blocked with
`409 { "error": "address_in_use" }` (FR-019).

## 10. Confirm no client-writable path to subscription state (Constitution Principle V)

```
# signed in as a customer: attempt to PATCH your own subscriptions row's `status` (or
# `price_breakdown`, or the pending-change columns) directly via the Supabase REST API
```

**Expected**: rejected — no RLS policy grants this write at all (research.md §3); the same holds
for direct writes to `subscription_pending_items` and `subscription_pauses`.

## 11. Run the full unit and e2e suites

```
npm run test:unit
npx playwright test tests/e2e/dashboard.spec.ts
```

**Expected**: all three new unit suites pass; the Playwright spec walks steps 3 and 5 above (edit
outside cutoff, then pause/resume) without manual intervention.
