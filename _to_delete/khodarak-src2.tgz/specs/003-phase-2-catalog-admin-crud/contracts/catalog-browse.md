# Contract: `/browse` query parameters

`/browse` is a Server Component, not a REST endpoint — there is no separate fetch call for the
grid itself (see [research.md](../research.md) §2 for why). Its contract is the set of
`searchParams` it reads, produced by `CategoryTabs`, `FilterSidebar`, `SortBar`, and `Pagination`
pushing/linking to new URLs. This doc exists so those Client Components and the Server Component's
`lib/products/queryProducts.ts` query builder agree on the same param names and semantics.

## Parameters

| Param | Values | Default | Set by |
|---|---|---|---|
| `category` | `vegetables` \| `fruits` | `vegetables` (first tab, FR-006 / spec Clarifications) | `CategoryTabs` |
| `sort` | `price_asc` \| `price_desc` \| `newest` | admin `sort_order` (spec Assumptions) | `SortBar` |
| `minPrice` | number, SAR | unset (no lower bound) | `FilterSidebar` |
| `maxPrice` | number, SAR | unset (no upper bound) | `FilterSidebar` |
| `available` | `1` (present) or absent | absent (shows unavailable too, flagged per FR-004) | `FilterSidebar` |
| `page` | positive integer | `1` | `Pagination` |

Query params are the sole source of truth for filter/sort/page state — there is no duplicate
client-side "current filters" store (research.md §2's rejected alternative). Switching tabs
(`CategoryTabs`) preserves whichever `minPrice`/`maxPrice`/`available`/`sort` params are already in
the URL, only replacing `category` and resetting `page` to `1` (Acceptance Scenario 2).

## Server-side resolution (`lib/products/queryProducts.ts`)

Given a `searchParams` object, builds a `products` query via the server Supabase client:

```
select * from products
where category = :category
  and (:minPrice is null or price >= :minPrice)
  and (:maxPrice is null or price <= :maxPrice)
  and (:available is null or is_available = true)
order by
  case :sort
    when 'price_asc' then price end asc,
  case :sort
    when 'price_desc' then price end desc,
  case :sort
    when 'newest' then created_at end desc,
  sort_order asc  -- default / tiebreaker
offset (:page - 1) * :pageSize
limit :pageSize
```

`pageSize` is a constant (spec Assumptions: "around a dozen products per page", matching
`design/products.html`'s mockup). The same `where` clause (minus `offset`/`limit`) backs a
`count`-only query used to compute total pages for `Pagination` and to decide whether the empty
state (FR-010) renders.

**Unavailable products**: never filtered out by default — `available=1` is an explicit customer
opt-in filter (FR-007). Without it, unavailable products still render in the grid, visibly flagged
(FR-004), matching the Edge Case where a product goes unavailable while already in someone's cart.

## Product detail: `/browse/[id]`

Not parameterized beyond the route segment. Reads a single `products` row by `id` via the same
server Supabase client. A missing or deleted `id` renders the route's `notFound()` boundary
(FR-017) rather than a broken page.
