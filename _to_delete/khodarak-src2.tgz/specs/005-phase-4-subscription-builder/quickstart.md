# Quickstart: Validating Phase 4 — Subscription Builder (no payment yet)

Validates the four user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 3 checkout (settings configured, pricing engine live, at least one
available product, at least one active city).

## Prerequisites

- Phase 3's quickstart already passing
- A signed-in customer test account with at least one saved address (Phase 1) and at least one
  item already in their cart (Phase 2)
- Migration applied: `subscriptions`, `subscription_items` (see [data-model.md](./data-model.md))
- `npm run dev` running

## 1. Run the delivery-date unit suite first (Constitution Principle VI)

```
npm run test:unit
```

**Expected**: `tests/unit/subscription.selectableDeliveryDates.test.ts` passes every lead-time and
blackout-weekday boundary case. This MUST be green before manually trusting the date picker.

## 2. Box customization reacts live (User Story 1, FR-001–003, SC-002)

```
# signed in, with items already in the cart: visit /subscription
# add a product from the box-customization grid, remove one, change a quantity
```

**Expected**: the cart's existing items appear pre-loaded; every change updates the order summary's
price breakdown immediately, with no manual refresh (SC-002); a quantity change respects that
product's min/max (same clamping as `/browse`'s stepper).

## 3. Frequency and delivery date (User Story 2, FR-004/006)

```
# on the builder: select each enabled frequency in turn
# open the delivery date picker
```

**Expected**: only admin-enabled frequencies are offered; the breakdown's discount and estimated
monthly figures change per frequency; dates before the configured lead time or on a blackout
weekday are not selectable (SC-005).

## 4. Checkout and confirm (User Story 3, FR-007–014)

```
# proceed to checkout: select a saved address, pick a delivery time slot, review totals
# confirm
```

**Expected**: with zero saved addresses, the customer is clearly prompted to add one before
continuing (FR-007, SC-006); after confirming, a `subscriptions` row exists in
`status = 'pending_payment'` with the correct items, frequency, address, delivery date/time, and a
price snapshot that exactly matches what `POST /api/pricing/preview` (Phase 3) would return for
the same inputs (SC-003); the cart is now empty; the customer lands on
`/subscription/confirmed/[id]` — a plain "saved, payment coming soon" page, not the design
mockup's post-payment success screen (Clarifications, 2026-08-10).

## 5. Checkout back-navigation (Clarifications 2026-08-10, FR-017a, SC-007)

```
# from checkout, navigate back to the build step
# change an item quantity or the frequency
# return to checkout
```

**Expected**: the previously selected address and time slot are still there (unless the address
was deleted in the meantime), and the price breakdown reflects the current box — no forced
restart.

## 6. Rule violations block confirmation (User Story 4, FR-009, SC-004)

```
# reduce the box below the admin-configured minimum order value (or exceed max items per box)
```

**Expected**: a specific, correct message appears and the confirm action is disabled; adjusting the
box back into range clears the message and re-enables confirm.

## 7. Server-side authority (Constitution Principle II)

```
# open browser devtools' network tab during confirm
```

**Expected**: the `POST /api/subscriptions` request body contains only `frequency`, `addressId`,
`nextDeliveryDate`, `deliveryTimeSlot` — no items, no price. Directly attempting the request with a
different `addressId` belonging to another test account returns `404`, never another user's data.

## 8. Signed-out and route-protection checks

```
# signed out: attempt to visit /subscription
```

**Expected**: redirected to `/login` (unchanged Phase 1 protection — this phase adds no new public
routes).

## 9. Run the full unit and e2e suites

```
npm run test:unit
npx playwright test tests/e2e/subscription-builder.spec.ts
```

**Expected**: `subscription.selectableDeliveryDates.test.ts` and `validation.subscription.test.ts`
(if present) both pass; the Playwright spec walks steps 2–4 above without manual intervention.
