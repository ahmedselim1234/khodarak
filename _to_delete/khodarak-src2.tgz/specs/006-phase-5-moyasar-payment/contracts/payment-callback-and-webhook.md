# Contracts: `GET /api/payments/callback` and `POST /api/webhooks/moyasar`

The two entry points into `lib/payments/processPaymentOutcome.ts`
(contracts/payment-outcome-processing.md) — the customer-visible redirect path and the durable,
provider-initiated notification path (spec User Story 2, Edge Cases). Both MUST confirm the
outcome with Moyasar directly before trusting it (FR-005); neither ever activates a subscription
or creates an order itself — both delegate that entirely to the shared processor.

## `GET /api/payments/callback`

Moyasar's 3DS `callback_url` target — the customer's browser is redirected here after completing
(or abandoning) the bank verification step.

**Request**: query string includes `id` (the Moyasar payment id) among other parameters Moyasar
appends. The query string's own `status`/`message` parameters are read only for a quick
loading-state hint in the redirect target — **never** as the basis for any write (FR-005): this
handler always calls `moyasarClient.fetchPayment(id)` to get the authoritative status before doing
anything else.

**Behavior**:
1. Read `id` from the query string; `400` (renders a generic error page, since there's nowhere
   useful to redirect without it) if missing.
2. Call `moyasarClient.fetchPayment(id)` — the authoritative status.
3. Call `processPaymentOutcome(id, <fetched status>, <fetched raw response>)`.
4. Look up the `payments` row by `moyasar_payment_id = id` to find its `subscription_id`.
5. Redirect (`302`) to `/subscription/confirmed/<subscription_id>` — that page reads the
   subscription's current status fresh (Server Component) and renders success or
   still-pending-with-error accordingly; this handler itself renders nothing.

**Response**: always a redirect (or, only if `id` is missing/unresolvable, a minimal generic error
page) — this route is never fetched by client code, only navigated to by the browser.

## `POST /api/webhooks/moyasar`

Public — no session, no cookies, not reachable through any authenticated-user flow. The one Route
Handler in this project reachable by a party this application doesn't control.

**Request**: Moyasar's webhook payload (event id, type, the payment object), with a secret-token
header per the webhook configuration on the Moyasar dashboard.

**Behavior**:
1. Verify the secret-token header via `lib/payments/verifyWebhookSignature.ts` **before** parsing
   the body as trusted data. Failure → `401`, nothing further happens.
2. Parse and zod-validate the payload shape (`lib/validation/moyasarWebhook.ts`) — a defensive
   layer behind step 1, not a substitute for it.
3. Insert into `webhook_events` (`moyasar_event_id`, `type`, `payload`). A unique-constraint
   conflict here means this exact event was already received — respond `200` immediately without
   calling the processor again (FR-013).
4. If the event's payment id isn't one this application recorded (e.g., a `payments` row was never
   created for it — shouldn't normally happen, but the processor's own conditional update handles
   "unknown id" safely as a no-op), or if the event type isn't one this phase acts on (e.g. a
   refund event — Edge Cases), record it (already done in step 3) and respond `200` without
   further action.
5. For a payment-outcome event type, call `processPaymentOutcome(<payment id from the event>,
   <the event's status>, <the event's payload>)`.
6. Mark the `webhook_events` row's `processed_at`.

**Response — success**: `200 OK` in every case that reaches step 3 successfully (including
duplicates and not-actionable event types) — Moyasar's own retry behavior on non-2xx responses
means "acknowledged, whether or not it changed anything" is the correct signal.

**Response — signature verification failed**: `401 Unauthorized`. Nothing is persisted.

**Response — malformed payload** (passes signature, fails schema): `400 Bad Request` — recorded
is not possible without a valid shape to extract `moyasar_event_id` from, so this is the one case
that isn't silently swallowed as a `200`.

## Notes

- Both entry points call the exact same `processPaymentOutcome` function with the exact same
  contract (contracts/payment-outcome-processing.md) — there is no separate "callback version" and
  "webhook version" of the activation logic to drift apart.
- Whichever of the two reaches `processPaymentOutcome`'s conditional update first performs the
  activation; the other finds the row already resolved and no-ops (research.md §3, spec User
  Story 2 Acceptance Scenario 5).
