# Contract: Route protection matrix (`middleware.ts`)

The redirect behavior FR-010/FR-011 and User Story 3 require, expressed as the literal matrix
`middleware.ts` implements and `tests/e2e/route-protection.spec.ts` verifies.

| Requested path | Signed-out visitor | Signed-in `customer` | Signed-in `admin` |
|---|---|---|---|
| `/subscription`, `/dashboard` (+ sub-routes) | Redirect → `/login?redirect=<original path>` | Allow | Allow |
| `/admin` (+ sub-routes) | Redirect → `/login?redirect=/admin` | Redirect → `/dashboard` (denied, not shown) | Allow |
| Everything else (`/`, `/browse`, `/login`, `/signup`, etc.) | Allow | Allow | Allow |

**Post-login redirect**: `LoginForm.tsx` reads the `redirect` query param (if present and it is a
same-origin relative path) and navigates there after a successful `signInWithPassword` call
instead of the default `/dashboard` (FR-010's "land on their intended page after signing in").

**Role source**: `middleware.ts` calls `supabase.auth.getUser()` (validates the session against
Supabase, not just a decoded-but-unverified cookie), then reads `role` from `profiles` for that
user id. A missing `profiles` row (should not happen given the creation trigger, but defensively)
is treated as `customer` for `/subscription`/`/dashboard` purposes and denied from `/admin`.

**What this middleware does NOT do**: it does not authorize row-level data access — that remains
RLS's job (Constitution Principle V). This matrix only controls whether a route *renders* for a
given caller; a bug here fails safe into an unhelpful redirect, never into exposing another
user's data, because RLS is a second, independent boundary underneath every query the resulting
page makes.
