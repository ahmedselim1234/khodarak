# Quickstart: Validating Phase 8 — Admin Operations

Validates the five user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 7 system (an admin test account, at least one customer with an active
subscription and an existing `pending` order from Phase 5/7).

## Prerequisites

- An admin test account (`role = 'admin'` on its `profiles` row — no self-serve path, same as
  every prior phase's admin testing note)
- Migration applied: `profiles.email` (+ backfill), `orders`/`subscriptions`/`subscription_pauses`
  attribution columns, admin RLS policies on `orders`/`subscriptions`/`subscription_pauses`/
  `cities`/`profiles`/`payments`/`order_items`/`subscription_items` (see
  [data-model.md](./data-model.md))
- `npm run dev` running

## 1. Run the new unit suite first (Constitution Principle VI)

```
npm run test:unit
```

**Expected**: `orders.orderStatusTransition.test.ts` passes, including every rejected-transition
case (backward, skip, post-`delivered`). This MUST be green before trusting the orders screen's
own validation.

## 2. Process an order from pending to delivered (User Story 1, FR-002/003/004, SC-001/002, the
phase's own demo target)

```
# signed in as admin: open /admin/orders, filter to a pending order
# advance it to out_for_delivery, then to delivered
```

**Expected**: each transition saves immediately; opening the same order as the owning customer
(`/dashboard/orders/<id>`, Phase 6) shows the updated status without any change on the customer's
end. Attempt a further status change on the now-`delivered` order — rejected with
`invalid_transition`.

## 3. Find and manage a customer's subscription as support (User Story 2, FR-005–011, SC-003/004)

```
# on /admin/subscriptions, search by that customer's name, email, or phone
# open the subscription's detail — confirm items, price, address, payment history, dunning state
# pause it without a reason — confirm it's rejected
# pause it with a reason and a resume date
```

**Expected**: search returns the correct subscription; the detail view shows every field FR-006
names; the reasonless pause attempt is blocked; the reasoned pause succeeds, and the customer's
own `/dashboard` (Phase 6) shows it as paused with the chosen resume date — but not the reason,
which stays admin-only. Repeat with cancel (reasoned) and confirm the customer's dashboard shows
it as permanently cancelled.

## 4. See business health at a glance (User Story 3, FR-015, SC-005)

```
# open /admin
```

**Expected**: three labeled counters (active subscriptions, orders today, revenue this month)
match a manual count/sum of the same underlying data. Advance an order or activate a subscription,
reload `/admin`, and confirm the counters reflect it immediately.

## 5. Review payment activity across all customers (User Story 4, FR-012)

```
# open /admin/payments, filter by status, search by a customer
```

**Expected**: results span more than one customer; a failed renewal attempt shows its specific
failure reason and attempt number, matching what Phase 7's own dunning engine recorded for it.

## 6. Manage delivery cities (User Story 5, FR-013/014, SC-006)

```
# open /admin/cities, add a new city, then open /subscription or the address form as a customer
# confirm the new city is selectable
# deactivate it from /admin/cities, confirm it's no longer offered on a new address
```

**Expected**: the new city appears immediately on the customer-facing address form once active;
deactivating removes it from selection without touching any existing address already using it.

## 7. Confirm no customer-session write path exists (FR-016, SC-007)

```
# signed in as a customer (not admin): attempt to PATCH an order's status, or POST an admin
# pause/cancel, or POST a new city, directly via the app's own API routes and via the Supabase
# REST API using the customer's own session
```

**Expected**: every attempt is rejected — the Route Handlers via `requireAdmin()`, and the
database itself via the admin-only RLS policies (data-model.md) as the actual authorization
boundary underneath.

## 8. Confirm the concurrent-edit guard (research.md §3)

```
# open the same pending order's admin row in two browser tabs
# advance it to out_for_delivery in tab 1
# without reloading tab 2, attempt to advance the same (still-showing-pending) order in tab 2
```

**Expected**: tab 2's attempt returns `409 status_changed` rather than silently succeeding or
corrupting the order's history.

## 9. Run the full unit and e2e suites

```
npm run test:unit
npx playwright test tests/e2e/admin-operations.spec.ts
```

**Expected**: `orderStatusTransition` suite passes; the Playwright spec walks step 2's full
pending → delivered flow without manual intervention.
