---

description: "Task list for Phase 2 — Catalog + Admin Product CRUD"
---

# Tasks: Phase 2 — Catalog + Admin Product CRUD

**Input**: Design documents from `/specs/003-phase-2-catalog-admin-crud/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/ (products-admin-api.md, catalog-browse.md, cart-api.md), quickstart.md

**Tests**: Included — plan.md's Technical Context and research.md explicitly scope a Vitest unit
suite (`clampQuantity`, `mergeCartQuantities`, product/cart schema edge cases) and a Playwright
end-to-end spec as part of this phase's design, so they are generated here rather than omitted.

**Organization**: Tasks are grouped by user story (US1/US2/US3/US4, matching spec.md's priorities:
US1 = P1, US2 = P1, US3 = P1, US4 = P2). Phases below are ordered by priority, and within the P1
tier by dependency: US1 (admin creates products) must exist before US2/US3 have anything real to
browse or add to a cart, even though US2/US3 are independently *testable* the moment at least one
product row exists (seeded manually or via US1).

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3, US4)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Create the `components/catalog/`, `components/product/`, `components/cart/`, and `components/admin/products/` directory scaffolds
- [X] T002 [P] Create the `lib/cart/` and `lib/products/` directory scaffolds

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T003 Create migration `supabase/migrations/<timestamp>_products.sql`: `products` table (`id, name_ar, category, price, unit, image_url, is_available, min_qty, max_qty, sort_order, created_at, updated_at`) with the `category`/`unit` enum checks, `price > 0`, `min_qty >= 1`, `max_qty >= min_qty` constraints, and RLS (public `SELECT`, `admin`-role-only `INSERT`/`UPDATE`/`DELETE` via the same `profiles.role` lookup pattern the Phase 1 migrations established) — per data-model.md
- [X] T004 [P] Create `lib/products/mapProductRow.ts`: snake_case → camelCase mapper for a `products` row (mirrors `lib/addresses/mapAddressRow.ts`)

**Checkpoint**: Foundation ready — `products` table + RLS and the shared row mapper exist; user story implementation can now begin.

---

## Phase 3: User Story 1 - Admin manages the product catalog (Priority: P1) 🎯 MVP

**Goal**: An admin can create, edit, remove, and toggle availability on products, including a required photo upload.

**Independent Test**: Create a new product with a photo in `/admin/products/new`, confirm it's saved with all fields, edit its price, then mark it unavailable — per quickstart.md step 1.

### Tests for User Story 1

> Write this test FIRST; it MUST fail until T006 fully covers these cases.

- [X] T005 [P] [US1] Write unit test `tests/unit/validation.product.test.ts` covering product payload edge cases: invalid `category`/`unit`, non-positive `price`, `minQty > maxQty`, missing/empty `imageUrl`

### Implementation for User Story 1

- [X] T006 [P] [US1] Create `lib/validation/product.ts`: zod schemas for the product create/update payload per contracts/products-admin-api.md
- [X] T007 [P] [US1] Create migration `supabase/migrations/<timestamp>_product_images_bucket.sql`: `product-images` Storage bucket, public read policy, `admin`-role-only write policy (research.md §3)
- [X] T008 [P] [US1] Create `lib/supabase/storage.ts`: browser-side helper that validates photo format/size before uploading to the `product-images` bucket (T007) and returns the public URL
- [X] T009 [US1] Create `lib/store/productsAdminApi.ts`: RTK Query slice (create/update/delete) against `/api/admin/products` per contracts/products-admin-api.md, following the `lib/store/addressesApi.ts` pattern — depends on T006
- [X] T010 [US1] Register the `productsAdminApi` reducer/middleware in `lib/store/index.ts` — depends on T009
- [X] T011 [US1] Implement `app/api/admin/products/route.ts`: `POST` — admin-role check, zod validation via T006, re-validates `imageUrl` resolves into the `product-images` bucket before persisting — depends on T003, T004, T006
- [X] T012 [US1] Implement `app/api/admin/products/[id]/route.ts`: `PATCH` (edit any field, including `isAvailable` toggle and photo replacement), `DELETE` — depends on T003, T004, T006
- [X] T013 [P] [US1] Create `components/admin/products/ImageUploadField.tsx`: `"use client"` leaf using T008, surfaces a specific error on rejected uploads without discarding the rest of the in-progress form (FR-005)
- [X] T014 [US1] Create `components/admin/products/ProductForm.tsx`: `"use client"`, name/category/price/unit/min-max-qty/availability fields plus `ImageUploadField` (T013), wired to `productsAdminApi` (T009) mutations, blocks submit without a photo (FR-001) — depends on T013, T009
- [X] T015 [US1] Create `components/admin/products/ProductTable.tsx`: Server Component reading `products` via the server Supabase client, edit links plus small client-leaf delete/availability-toggle actions — depends on T004
- [X] T016 [US1] Create `app/admin/products/page.tsx` rendering `ProductTable` (T015), no mockup exists — shared design tokens + standard admin table conventions per spec.md Assumptions — depends on T015
- [X] T017 [US1] Create `app/admin/products/new/page.tsx` rendering `ProductForm` (T014) in create mode — depends on T014
- [X] T018 [US1] Create `app/admin/products/[id]/edit/page.tsx` rendering `ProductForm` (T014) in edit mode, fetching the current product server-side — depends on T014

**Checkpoint**: User Story 1 is fully functional and independently testable — admin product CRUD with photo upload.

---

## Phase 4: User Story 2 - Customer browses and filters the catalog (Priority: P1)

**Goal**: A customer visiting `/browse` sees products under خضروات/فواكه tabs, can filter by price and availability, sort, and page through results.

**Independent Test**: Load `/browse` (with at least one product row seeded via US1 or manually), switch tabs, apply price/availability filters, change sort order, page to a second page — per quickstart.md step 3.

### Implementation for User Story 2

- [X] T019 [P] [US2] Create `lib/products/queryProducts.ts`: server-side query builder against `products` (category/price/availability/sort/pagination, plus a matching count query for total pages and the empty-state decision) per contracts/catalog-browse.md — depends on T003, T004
- [X] T020 [P] [US2] Create `components/catalog/EmptyState.tsx`: presentational empty state for a tab/filter combination with no matches (FR-010)
- [X] T021 [P] [US2] Create `components/catalog/Pagination.tsx`: Server Component, plain `<Link>`s reading/writing the `page` searchParam, disables/hides "next" on the last page
- [X] T022 [US2] Create `components/catalog/CategoryTabs.tsx`: `"use client"` leaf — خضروات/فواكه tabs pushing `?category=` while preserving the other active searchParams and resetting `page` to 1 (FR-006, Acceptance Scenario 2)
- [X] T023 [US2] Create `components/catalog/FilterSidebar.tsx`: `"use client"` leaf — price range + "available only" toggle pushing `?minPrice=&maxPrice=&available=` (FR-007)
- [X] T024 [US2] Create `components/catalog/SortBar.tsx`: `"use client"` leaf — sort `<select>` pushing `?sort=` (FR-008)
- [X] T025 [US2] Create `components/catalog/ProductCard.tsx`: Server Component shell — image, name, price/unit, unavailable badge (FR-004); no quantity control yet (wired on in US3)
- [X] T026 [US2] Create `components/catalog/ProductGrid.tsx`: Server Component rendering `ProductCard` (T025) entries, `EmptyState` (T020) when the result set is empty — depends on T020, T025
- [X] T027 [US2] Replace the Phase 0 placeholder in `app/browse/page.tsx`: Server Component reading `searchParams`, calling `queryProducts` (T019), rendering `CategoryTabs`/`FilterSidebar`/`SortBar`/`ProductGrid`/`Pagination` per `design/products.html` — depends on T019, T021, T022, T023, T024, T026

**Checkpoint**: User Stories 1 AND 2 both work — admin-created products are browsable, filterable, sortable, and paginated.

---

## Phase 5: User Story 3 - Customer adjusts quantities and sees the cart bar update (Priority: P1)

**Goal**: A customer adjusts a product's quantity via a stepper, a persistent cart bar reflects the running count/total, selections persist across reloads, and a guest cart merges into the account cart at login.

**Independent Test**: Increase a product's quantity via its stepper, confirm the cart bar updates immediately, reload and confirm it persists, then log in and confirm the guest cart merges (higher-quantity-wins) into the account's server-side cart — per quickstart.md steps 4–5.

### Tests for User Story 3

> Write these tests FIRST; they MUST fail until T031/T032 exist.

- [X] T028 [P] [US3] Write unit test `tests/unit/cart.clampQuantity.test.ts` covering at-min, at-max, one-below, one-above, and zero-removes-item cases
- [X] T029 [P] [US3] Write unit test `tests/unit/cart.mergeCartQuantities.test.ts` covering guest-only, account-only, both-present (higher wins), and cap-at-max cases

### Implementation for User Story 3

- [X] T030 [P] [US3] Create migration `supabase/migrations/<timestamp>_cart_items.sql`: `cart_items` table (`id, user_id, product_id, quantity, created_at, updated_at`), `unique(user_id, product_id)`, FK cascade on `product_id` deletion, owner-only RLS (`user_id = auth.uid()`) — depends on T003
- [X] T031 [P] [US3] Create `lib/cart/clampQuantity.ts`: pure function clamping a quantity to `[minQty, maxQty]`, treating 0 as "remove" (FR-012)
- [X] T032 [P] [US3] Create `lib/cart/mergeCartQuantities.ts`: pure function implementing the higher-quantity-wins merge capped at `maxQty` (FR-015)
- [X] T033 [P] [US3] Create `lib/validation/cart.ts`: zod schemas for the cart item upsert payload and the merge payload per contracts/cart-api.md
- [X] T034 [US3] Create `lib/cart/cartSlice.ts`: Redux slice holding the guest cart (`productId → {quantity, name, price, unit, imageUrl, maxQty}`), with set/increment/decrement/clear actions
- [X] T035 [US3] Create `lib/store/cartApi.ts`: RTK Query slice (`getCart`, `upsertItem`, `mergeCart`) against `/api/cart/*` per contracts/cart-api.md, following the `addressesApi.ts` pattern — depends on T033
- [X] T036 [US3] Register the `cartSlice` reducer and `cartApi` in `lib/store/index.ts` — depends on T034, T035
- [X] T037 [US3] Update `components/providers/StoreProvider.tsx`: hydrate `cartSlice` from `localStorage` on mount and persist changes back to `localStorage` — depends on T034
- [X] T038 [US3] Implement `app/api/cart/route.ts`: `GET` — resolved cart (joins `cart_items` with live `products` data), `itemCount`/`total` per contracts/cart-api.md — depends on T030, T004
- [X] T039 [US3] Implement `app/api/cart/items/[productId]/route.ts`: `PUT` — upserts the caller's quantity, server-side clamp via T031, `0` deletes the row, `409` on adding a currently-unavailable product (FR-018) — depends on T030, T031, T033
- [X] T040 [US3] Implement `app/api/cart/merge/route.ts`: `POST` — merges the guest payload into `cart_items` using T032, silently skips products deleted since the guest added them — depends on T030, T032, T033
- [X] T041 [US3] Create `components/cart/QuantityStepper.tsx`: `"use client"` leaf — calls `cartApi`'s `upsertItem` mutation (signed-in) or `cartSlice` actions (guest) depending on auth state, clamps via T031 for instant feedback — depends on T031, T034, T035
- [X] T042 [US3] Wire `QuantityStepper` (T041) into `components/catalog/ProductCard.tsx` (US2, T025) — depends on T041, T025
- [X] T043 [US3] Create `components/cart/CartBar.tsx`: `"use client"` persistent bar — reads `cartSlice` state (guest) or `cartApi`'s `getCart` query (signed-in), renders item count + total, zero state when empty — depends on T034, T035
- [X] T044 [US3] Mount `CartBar` (T043) into `components/ui/TopNav.tsx` — depends on T043
- [X] T045 [US3] Wire the post-login merge in `components/auth/LoginForm.tsx`: on successful sign-in, `POST /api/cart/merge` (T040) with the guest cart's raw `{productId, quantity}` pairs from `cartSlice`, then clear the guest cart and invalidate `cartApi`'s `getCart` tag — depends on T034, T035, T040

**Checkpoint**: User Stories 1, 2, AND 3 all work — the phase's headline demo ("admin adds a product → appears on browse; customer adds quantities → cart bar updates") is complete.

---

## Phase 6: User Story 4 - Customer views a single product's detail page (Priority: P2)

**Goal**: A customer opens a product from the grid to see a larger view and can adjust its quantity from the detail page.

**Independent Test**: Open a product from the grid, confirm details render, adjust quantity via the detail-page stepper, confirm the cart bar updates the same way — per quickstart.md step 6.

### Implementation for User Story 4

- [X] T046 [P] [US4] Create `components/product/ProductGallery.tsx`: Server Component — main image + thumbnails per `design/product-details.html`
- [X] T047 [US4] Create `components/product/ProductInfo.tsx`: Server Component shell — name/price/unit/description, embeds `QuantityStepper` (US3, T041) — depends on T041
- [X] T048 [US4] Replace the Phase 0 placeholder in `app/browse/[id]/page.tsx`: Server Component fetching the product by id via the server Supabase client, rendering `ProductGallery` (T046) + `ProductInfo` (T047), calling `notFound()` for a missing/deleted id (FR-017) — depends on T046, T047

**Checkpoint**: All four user stories are independently functional.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all four stories

- [X] T049 [P] Write Playwright spec `tests/e2e/catalog-cart.spec.ts`: admin creates a product with a photo → it appears on `/browse` → tab/filter/sort/paginate → stepper updates the cart bar → reload persists → login merges the guest cart — the full demo path from quickstart.md steps 1–5. Also fixed `tests/e2e/routes.smoke.spec.ts`, which asserted `/browse/[id]` always returns `200` — no longer true now that it's a real page enforcing FR-017's `notFound()` for a nonexistent id.
- [ ] T050 [P] Run the full `quickstart.md` validation (all 8 steps) end to end — **not run**: requires a live Supabase project with seeded product rows and a real browser session, neither available in this sandbox. `npm run build` was run instead and confirms every route/API handler compiles and type-checks; this does not substitute for the manual browser walkthrough.
- [X] T051 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed files (Constitution Development Workflow gate) — both clean; also ran `npm run test:unit` (60/60 passing, including one bad test assertion in `cart.mergeCartQuantities.test.ts` caught and fixed) and `npm run build` (all 21 routes compile) as additional verification beyond what this task strictly asked for.
- [ ] T052 Manual RLS/policy spot-check: as one signed-in customer, attempt to read/write another user's `cart_items` rows directly; as a non-admin (or signed-out) session, attempt `products` table writes and `product-images` bucket writes directly — confirm every attempt returns zero rows affected / is rejected (Constitution Principle V; quickstart.md step 7 covers the API-layer version, this covers the RLS/storage-policy layer directly) — **not run**: requires a live linked Supabase project and disposable test accounts (same constraint noted in `specs/002-phase-1-auth-address/tasks.md` T037). The RLS policies themselves were authored in the migrations (`products_insert_admin`/`update`/`delete`, `cart_items_*_own`, `product_images_*_admin`) but have not been exercised against a live project from this session.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only
- **User Story 2 (Phase 4, P1)**: Depends on Foundational; needs at least one `products` row to be meaningfully testable, so build after US1 even though it imports none of US1's files
- **User Story 3 (Phase 5, P1)**: Depends on Foundational and on `ProductCard.tsx` existing (US2, T025) to wire the stepper onto — build after US2
- **User Story 4 (Phase 6, P2)**: Depends on Foundational and on `QuantityStepper.tsx` existing (US3, T041) — build after US3
- **Polish (Phase 7)**: Depends on all four user stories being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories — true MVP starting point (nothing else has data to show without it)
- **US2 (P1)**: No file dependencies on US1, but needs product rows to exist to demo meaningfully
- **US3 (P1)**: Integrates into `ProductCard.tsx` from US2 (T042) and `LoginForm.tsx` from Phase 1 (T045) — build after US2
- **US4 (P2)**: Integrates `QuantityStepper.tsx` from US3 (T047) — build after US3

### Within Each User Story

- Tests (where included) written and failing before implementation
- Migrations before Route Handlers/services that query the new tables
- Validation schemas before the forms/handlers that use them
- Pure logic functions (`clampQuantity`, `mergeCartQuantities`) before the Route Handlers and components that call them
- Server-side pieces (migrations, Route Handlers) before the client components that call them
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T001 and T002 (Setup) can run in parallel
- T004 (Foundational) has no dependency on T003 within the same phase and can proceed in parallel with it being reviewed, though the migration should be applied first in practice
- Within US1: T005–T008 (different files) in parallel; T013 in parallel with T009/T010 (different files)
- Within US2: T019, T020, T021 in parallel; then T022, T023, T024 (different files) in parallel once T019 lands
- Within US3: T028/T029 (tests) in parallel; T030–T033 (different files, no dependencies on each other) in parallel
- Within US4: T046 in parallel with starting T047's non-stepper markup

---

## Parallel Example: User Story 1

```bash
# Launch the test and the independent foundation pieces together:
Task: "Write unit test tests/unit/validation.product.test.ts"
Task: "Create lib/validation/product.ts"
Task: "Create migration supabase/migrations/<timestamp>_product_images_bucket.sql"
Task: "Create lib/supabase/storage.ts"
```

## Parallel Example: User Story 3

```bash
# Launch both unit tests and all four independent lib files together:
Task: "Write unit test tests/unit/cart.clampQuantity.test.ts"
Task: "Write unit test tests/unit/cart.mergeCartQuantities.test.ts"
Task: "Create migration supabase/migrations/<timestamp>_cart_items.sql"
Task: "Create lib/cart/clampQuantity.ts"
Task: "Create lib/cart/mergeCartQuantities.ts"
Task: "Create lib/validation/cart.ts"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: quickstart.md step 1 passes independently
5. Demo: admin creates, edits, and removes a product with a photo

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US1 → validate → demo (admin product CRUD)
3. Add US2 → validate → demo (adds the browsable, filterable, sortable catalog — half of this phase's headline demo)
4. Add US3 → validate → demo (adds the stepper + cart bar + guest/login merge — completes the phase's full demo target: "admin adds a product → appears on browse; customer adds quantities → cart bar updates")
5. Add US4 → validate → demo (adds the product detail page)
6. Phase 7 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes:
- Developer A: US1 (no dependencies)
- Developer B: starts US2's non-integration pieces (T019–T021, T023, T024) in parallel with US1, holding T025/T026/T027 until product rows are available to verify against
- Developer C: joins for US3 once US2's `ProductCard.tsx` (T025) exists to integrate the stepper into

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- `products` (T003) is Foundational because every story reads or writes it; `cart_items` (T030) is
  scoped to US3 because only US3 needs it, matching the precedent set by Phase 1's `tasks.md`
  (shared `profiles` table was Foundational, `addresses`/`cities` were scoped to their one
  consuming story)
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
