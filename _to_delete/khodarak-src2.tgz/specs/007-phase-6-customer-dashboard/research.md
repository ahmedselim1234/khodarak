# Phase 0 Research: Phase 6 — Customer Dashboard

All items below were either resolved during `/speckit-clarify` (recorded in spec.md's
Clarifications section) or required one additional design decision to turn a clarified answer
into something buildable against the existing codebase (confirmed by reading the Phase 1/4/5
migrations and lib modules already in the repo, per `plan.md`'s own instruction: "if there's a
repo already, send me the folder tree and I'll fit the plan to it").

## 1. How is a deferred (pending) subscription edit represented in the data model?

**Decision**: Add nullable pending-change columns directly on `subscriptions`
(`pending_frequency`, `pending_address_id`, `pending_price_breakdown`,
`pending_effective_from`), plus a new `subscription_pending_items` table that mirrors
`subscription_items`'s exact shape (`subscription_id`, `product_id`, `quantity`). A pure function,
`lib/subscription/resolveEffectiveConfig.ts`, takes the subscription's current fields, its pending
fields (if any), and "now" vs. `next_delivery_date`, and returns which configuration is in effect
for the locked next delivery and which one (if different) takes over afterward. No proactive
snapshot is taken when the cutoff window opens — the *current* fields already are what the locked
delivery uses, unchanged, precisely because a deferred edit is written to the *pending* columns
instead of overwriting current ones (spec.md Clarification 3).

**Rationale**: `subscription_items` already exists as its own table (not a jsonb blob) from
Phase 4, so mirroring that shape for pending items keeps the same per-product-row structure the
rest of the codebase (pricing, order-item generation) already expects, rather than introducing a
second, differently-shaped representation. Keeping pending fields on the subscription row itself
(rather than a separate "scheduled change" entity, per spec.md's own Assumptions) means a single
row read gives the full picture — no join needed to know whether a pending change exists.

**Alternatives considered**:
- *Cutoff-triggered snapshot* (take a snapshot of current state the moment the cutoff window
  opens, let edits apply live, have the renewal engine prefer the snapshot): rejected during
  clarification — it requires a scheduled/triggered write at an arbitrary moment with no natural
  event to hang it on in this phase (no cron infrastructure exists yet; that's Phase 7's job), and
  produces a second state a bug could let drift from the truth.
- *jsonb blob for pending items* (single `pending_items jsonb` column instead of a mirroring
  table): rejected because it would need its own parsing/validation path completely separate from
  `subscription_items`'s existing row-shape handling, duplicating logic for no benefit.

**Who performs the actual promotion (pending → current) once the locked delivery has passed?**
Nobody, in this phase. `resolveEffectiveConfig` is a *read-time* resolver only — it never mutates
anything. The literal database promotion (copying pending fields into current fields once that
delivery cycle has actually been processed) is Phase 7's renewal-engine job, since that's the only
place in the whole system with a scheduled trigger and the concept of "this delivery cycle just
happened." This phase's dashboard always computes the correct *display* (what's locked vs. what
changes after it) live from current+pending, so nothing is ever shown stale even though no
promotion job exists yet — documented as a forward dependency for Phase 7, not something this
phase needs to build.

## 2. How is the "max pauses per year" rolling-365-day limit tracked?

**Decision**: A new, append-only `subscription_pauses` table (`subscription_id`, `started_at`
timestamptz, `resume_date` date, `resumed_early_at` timestamptz nullable). Every pause action
inserts one row. `lib/subscription/pauseEligibility.ts` is a pure function that takes the list of
a subscription's past pause rows, "now", and the settings' `max_pause_days`/`max_pauses_per_year`,
and returns allow/deny plus which limit (if any) was hit — counting only rows whose `started_at`
falls within the last 365 days (spec.md Clarification 2).

**Rationale**: A rolling window is naturally expressed as "count rows where `started_at >= now() -
interval '365 days'`" against a timestamped history table — a single resettable counter column
cannot express a rolling window at all (it can only express a fixed-period reset), so the
clarified answer directly implies a history table, not a counter.

**Alternatives considered**: A single `pauses_used_this_year integer` counter column on
`subscriptions` — rejected outright once the rolling-window answer was chosen; it's the wrong data
shape for what was asked for.

## 3. Why does this phase not add the owner-scoped `UPDATE` policy Phase 4's migration comment anticipated?

**Decision**: Every write that changes `subscriptions`/`subscription_items` state in this phase
(item/frequency/address edits, pause, resume, cancel) goes through a new server-only module,
`lib/subscription/mutateSubscription.ts`, using the existing `lib/supabase/serviceRole.ts` client
— called only from `app/api/subscriptions/[id]/*` Route Handlers, never given an owner-scoped RLS
`UPDATE` policy on `subscriptions` itself.

**Rationale**: `20260810150000_subscriptions.sql` (Phase 4) left a comment reading "No
update/delete policy yet (Phase 6 adds those alongside the dashboard actions that need them)" —
written before Phase 5 existed. Phase 5's own payments migration
(`20260811100000_payments.sql`) then established the actual precedent this project follows for
exactly this class of risk: "Deliberately NO authenticated-role INSERT/UPDATE/DELETE policy... a
direct, proactive response to the `profiles.role` self-escalation gap found in Phase 1... an
owner-scoped UPDATE policy restricts rows, not columns." `subscriptions.status` and
`subscriptions.price_breakdown` are exactly the columns that precedent warns about — an
owner-scoped `UPDATE` policy would let a customer's own session `PATCH` their subscription
straight to `active`/a lower price via the REST API, bypassing `calculate()` and every admin rule
this phase's requirements exist to enforce (FR-006 through FR-011). Following the same pattern
Phase 5 already established for `payments`/`orders` — rather than the different, now-superseded
plan Phase 4's comment described — keeps the codebase's authorization model consistent instead of
having two different rules for adjacent tables holding the same class of financial data.

**Alternatives considered**: An owner-scoped `UPDATE` policy restricted to a safe column allowlist
via a Postgres column-level `GRANT`/trigger guard (the same technique
`20260810120300_profiles_role_immutable.sql` used for `profiles.role`) — rejected as unnecessary
complexity once a Route Handler + service-role path is already the established, working pattern
for this exact problem from Phase 5; introducing a second technique for the same problem class
would be inconsistent for no benefit.

## 4. What does the "subscription health" indicator actually compute?

**Decision**: `lib/subscription/subscriptionHealth.ts`, a pure function taking
`{ status, consecutiveFailedPayments, hoursUntilNextDelivery, editCutoffHours }` and returning
`'good' | 'needs_attention'`. Returns `'needs_attention'` when `status === 'paused'` with a resume
date very close to now (edge case, informational only — not blocking), when
`consecutiveFailedPayments > 0`, or when the subscription is inside its edit cutoff window and has
an unresolved pending change waiting to apply after it (a soft nudge, not a warning about
anything broken); `'good'` otherwise, including the normal `active` steady state.

**Rationale**: Directly implements spec.md Clarification 1 — "derived only from the subscription's
own state already defined elsewhere in the plan... rather than any new scoring model... a small
set of plain states." `consecutiveFailedPayments` is computed by a small server-side query (most
recent `payments` rows for the subscription's user, counting back from the newest until a `'paid'`
row breaks the streak) — not stored as its own column, since Phase 7's dunning tracking (spec.md's
own Assumption: "if Phase 7's dunning/retry tracking doesn't exist yet, the indicator simply
treats that signal as zero") will eventually own a proper version of this count; this phase's
version is a read-time derivation from data that already exists in `payments`, nothing new stored.

**Alternatives considered**: A numeric health score (e.g. 0–100) — explicitly rejected by the
clarification itself in favor of plain states, avoiding an entire category of "what does 73% mean"
UX ambiguity a subscription-box customer has no reason to parse.

## 5. How does card replacement reuse Phase 5's tokenization flow without a new charge?

**Decision**: `ReplaceCardDialog.tsx` reuses `CardTokenizationForm` exactly as Phase 5 built it
(`save_only: true`, `amount: 0` — already what the component does, unchanged). Its `on_completed`
callback already receives Moyasar's `payment.id` for the `$0` save-only payment alongside the
token; this phase's new `POST /api/payment-methods` Route Handler takes that payment id (never
card fields) and calls the *existing* `moyasarClient.fetchPayment(paymentId)` — the exact same
function Phase 5's callback route already uses — to authoritatively read back `source.company`
(brand), `source.number` (masked, last four), and `source.month`/`source.year` before the
service-role client inserts the new `payment_methods` row and marks the customer's previous
default row `status = 'removed', is_default = false`.

**Rationale**: `moyasarClient.fetchPayment` already exists and already does exactly the
"authoritative status/detail lookup, never trust the client" job this needs (Constitution
Principle II) — reusing it is a direct application of Phase 5's own established rule ("a redirect's
own parameters are never treated as proof of success") to a second entry point, not a new pattern.
No SDK/API surface needs to grow; `extractCardDetails`'s parsing logic in
`processPaymentOutcome.ts` is the field-shape reference already validated in this codebase.

**Alternatives considered**: Trusting the client-side `payment` object's `source` fields directly
(skip the server-side `fetchPayment` call) — rejected: identical class of risk Phase 5's FR-005
("a redirect's own parameters are never treated as proof of success") already ruled out for the
charge-confirmation path; the same standard applies to what gets written into `payment_methods`.
