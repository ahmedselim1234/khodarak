# Phase 1 Data Model: Phase 7 — Renewal Engine & Dunning

Two existing tables are altered (`subscriptions`, `payments`); no new tables. `orders`,
`order_items`, and `payment_methods` keep their exact Phase 5 shapes — this phase writes to them
using the same columns Phase 5's own activation flow already writes.

## `subscriptions` (altered)

Adds three columns to the table Phase 4 created and Phase 6 already extended:

| Column | Type | Notes |
|---|---|---|
| `renewal_attempt_count` | integer, default `0`, `>= 0` | How many charge attempts have failed for the *current*, still-unresolved cycle. Reset to `0` the moment a cycle succeeds. `0` means no attempt has failed yet (either nothing due, or the first attempt hasn't run) |
| `next_renewal_attempt_date` | date, nullable | When the job should next consider this subscription for a charge. Starts equal to `next_delivery_date`; on a failure, set to `firstFailedAt + {1,3,5}` days per `dunningSchedule.ts` (research.md §4); cleared (set to the new `next_delivery_date`) on success |
| `renewal_claimed_at` | timestamptz, nullable | Short-lived claim lock (research.md §1) — set when a job run begins processing this subscription, cleared when `processRenewalOutcome.ts` resolves the cycle. A claim older than 10 minutes is treated as stale and reclaimable (dead-man's-switch for a crashed run, not a normal state) |

`next_renewal_attempt_date` is the query the job's claim step filters on
(`next_renewal_attempt_date <= current_date`), not `next_delivery_date` directly — for a
subscription with no open failure, the two are always equal, so this doesn't change first-attempt
behavior; it's what lets a mid-retry subscription be found on its *retry* date without its
`next_delivery_date` having moved (per the clarification that a failed cycle holds the delivery
date, spec.md Clarification 1).

**No new RLS policy.** `subscriptions_select_own` (Phase 4) already covers reading these columns
for the dashboard's own health-indicator use. No `authenticated`-role write policy is added — every
write to these columns goes through `mutateSubscription.ts`'s service-role client, extending
Phase 5/6's established rule (research.md §1).

## `payments` (altered)

Adds one column and relaxes one constraint on the table Phase 5 created:

| Column | Type | Notes |
|---|---|---|
| `kind` | text, `check (kind in ('initial', 'renewal'))`, default `'initial'` | Set once at insert time by whichever endpoint created the attempt. Existing rows backfilled `'initial'` (every payment before this phase's migration was a first-activation charge). Used by the webhook route to dispatch to the correct outcome processor (research.md §6) |
| `moyasar_payment_id` | text, unique, **now nullable** (was `not null` from Phase 5) | A renewal attempt that never reaches Moyasar at all (`no_available_items`, `card_expired`, `no_payment_method`, or a request-level `provider_error` — contracts/cron-renewals-api.md) still gets its own `payments` row per FR-012, with no id to record since Moyasar was never actually called. Postgres's `unique` constraint permits multiple `null`s, so uniqueness among real ids is unaffected |
| `amount_halalas` | integer, **now nullable** (was `not null` from Phase 5), check relaxed to `is null or > 0` | The same no-charge-attempted cases above also have no computed amount to record — `null` distinguishes "never charged" from a real, always-positive charged amount |

No RLS policy change — `payments_select_own` (Phase 5) already covers reading `kind` for the
dashboard's payment-history list (Phase 6), and the existing `payments_insert_own_initiated`
policy is unaffected since renewal-charge `payments` rows are inserted by the service-role client
(the cron route has no customer session at all), not a customer's own RLS-scoped session.

## Existing entities this phase reads and writes, unchanged in shape

- **`orders`, `order_items`** (Phase 5) — every order after a subscription's first is generated
  here, using the exact same columns Phase 5's `processPaymentOutcome.ts` already writes
  (`subscription_id`, `user_id`, `address_snapshot`, `status: 'pending'`, `scheduled_date`,
  `price_breakdown`) plus `order_items` rows for each surviving (non-dropped) item. An order
  generated with one or more excluded unavailable items additionally records that fact — see
  "Dropped items" below.
- **`payment_methods`** (Phase 5/6) — read-only this phase: the subscription's current default,
  active card is what gets charged (FR-014); this phase never inserts or replaces a payment
  method itself (that stays Phase 6's card-replacement flow).
- **`subscription_items`, `subscription_pending_items`** (Phase 4/6) — read this phase via
  `reprice.ts`, which calls Phase 6's existing `resolveEffectiveConfig.ts` unchanged to determine
  which set of items (current or, if this cycle is the pending change's effective date, pending)
  drives the charge. When a pending change resolves this way, `reprice.ts` also promotes it onto
  the subscription's current fields as part of the same successful-cycle write (this is the
  concrete promotion mechanism Phase 6's own research.md §1 deferred to this phase).
- **`subscription_pauses`** (Phase 6, altered) — this phase's auto-suspend transition inserts a
  row here exactly the way a customer-initiated pause already does, except with `resume_date`
  left `null` (distinguishing an automatic suspension from a customer's own chosen resume date,
  per the clarification session). Phase 6's original schema assumed every pause was
  customer-initiated with a chosen date, so this phase's migration also drops `resume_date`'s
  `not null` constraint — the one other schema change beyond `subscriptions`/`payments` above.
- **`settings`** (Phase 3) — read for every pricing input `calculate()` needs, plus
  `blackout_weekdays` for `advanceDeliveryDate.ts`, exactly as every prior phase already reads it.

## Dropped items (Renewal Cycle's degraded-success record)

No new column or table — an order generated with one or more excluded unavailable products
records that fact using `order_items`' own existing shape: the dropped product simply has no row
in that order's `order_items` (it was never charged for or delivered), which is already
sufficient for FR-004's "record that an item was excluded," since Phase 6's existing order-detail
view already renders exactly the items present in `order_items` — a box with fewer items than the
subscription's own current `subscription_items` list *is* the visible record of what was dropped,
without inventing a parallel "dropped items" log this phase's scope doesn't otherwise need.

## State transitions

### `subscriptions.status` (extends Phase 6's diagram)

```
active ──successful renewal──▶ active (next_delivery_date advances, retry state resets to 0)
active ──renewal charge fails──▶ active (renewal_attempt_count += 1, next_renewal_attempt_date
                                          set per dunningSchedule.ts; status itself unchanged —
                                          the subscription stays 'active' throughout retries)
active ──every scheduled retry exhausted──▶ paused (no resume_date; renewal_attempt_count reset
                                                     to 0, next_renewal_attempt_date cleared)
paused (auto-suspended) ──customer resumes (Phase 6, unchanged)──▶ active
```

A cycle's failure never itself changes `subscriptions.status` — only exhausting the entire retry
schedule does. This is why `renewal_claimed_at`/`renewal_attempt_count`/`next_renewal_attempt_date`
exist as separate columns from `status`: an in-retry subscription is still fully `active` (still
shown as such everywhere Phase 6 already renders that status), just with an unresolved cycle.

### `payments.status` per attempt (unchanged shape from Phase 5, `kind` distinguishes context)

```
(insert) ──▶ initiated ──charge confirmed paid──▶ paid   (processRenewalOutcome: generate order,
                                                            advance date, reset retry state)
initiated ──charge confirmed failed──▶ failed            (processRenewalOutcome: advance retry
                                                            state or suspend, per dunningSchedule)
```

Each retry attempt is its own `payments` row (`attempt_number` incrementing, same pattern Phase 5
already established for a customer's own manual retry after a decline) — never an update to a
prior attempt's row, preserving a full audit trail of every attempt in a cycle.
