# Phase 1 Data Model: Foundation

## Business entities

None. Per the feature spec's Key Entities section: "This phase is scaffolding only — it
establishes no new business data entities." The Supabase project is provisioned and reachable but
its schema stays empty; `profiles`, `products`, `subscriptions`, etc. (plan.md §2) are introduced
starting in Phase 1 (Auth & Address) onward.

## Configuration shape (not a business entity, but the one typed structure this phase owns)

`lib/env.ts` defines the runtime-validated shape of required environment configuration. This is
infrastructure configuration, not application data, and is not persisted anywhere — it exists only
as a zod schema validated once at process start.

| Field | Type | Required | Notes |
|---|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | string (URL) | Yes | Safe for browser exposure (Next.js `NEXT_PUBLIC_*` convention); used by `lib/supabase/client.ts` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | string | Yes | Safe for browser exposure; used by `lib/supabase/client.ts` |
| `SUPABASE_SERVICE_ROLE_KEY` | string | Yes | Server-only — MUST NOT be read outside `lib/supabase/server.ts`, MUST NOT carry the `NEXT_PUBLIC_` prefix |

**Validation rule**: all three fields MUST be present and non-empty at process start; parsing
failure throws synchronously naming the offending field (FR-006, Constitution Principle IV).

## State transitions

None — this phase has no stateful entities. (The env config above is either valid or the process
does not start; there is no intermediate state.)
