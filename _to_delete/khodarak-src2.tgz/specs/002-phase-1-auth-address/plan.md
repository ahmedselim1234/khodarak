# Implementation Plan: Phase 1 — Auth & Address

**Branch**: `002-phase-1-auth-address` | **Date**: 2026-08-10 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/002-phase-1-auth-address/spec.md`

## Summary

Wire up Supabase Auth (signup, login, logout, password reset) with a `profiles` table that
resolves every account to a `customer`/`admin` role, protect `/subscription`, `/dashboard`, and
`/admin` via Next.js middleware based on that role, and deliver a customer address book (create,
edit, delete, default-selection) backed by a new `addresses` table and an admin-managed `cities`
lookup table. This is the first phase that creates real database schema, the first phase with
authenticated, per-user data, and the access-control backbone every later phase depends on — per
`plan.md` §4 Phase 1 and the feature spec's four user stories.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0)

**Primary Dependencies**: `@supabase/ssr` + `@supabase/supabase-js` (already wired in Phase 0,
now used for real: Auth calls from the browser client, session refresh + role check in
middleware, address queries from the server client), zod (request/form validation), Redux Toolkit
+ RTK Query (first real API slice — the address book — introduced against `/api/addresses`, per
`plan.md`'s stated client data layer decision)

**Storage**: Supabase (Postgres). Three new tables this phase: `profiles`, `addresses`, `cities`
(per `plan.md` §2's target schema — `cities` created now with its full column set since Phase 1
needs it for address selection, even though `delivery_fee_override` stays unused until pricing
lands in Phase 3). RLS enabled on all three from creation, not retrofitted later.

**Testing**: Vitest for unit tests (phone-number validation, the "exactly one default address"
invariant logic, role-resolution helper), Playwright for the route-protection matrix (signed-out /
customer / admin × `/subscription`, `/dashboard`, `/admin`) and the address CRUD happy path —
chosen because Constitution Principle VI expects test-first discipline for logic where a bug has
real consequences, and an access-control bug here is exactly that class of bug even though no
money is involved yet

**Target Platform**: Same as Phase 0 — Linux container (Docker) in later phases, `npm run dev`
locally for now; primary client is mobile Chrome/Safari

**Project Type**: Web application — same single Next.js monolith, no new deployable

**Performance Goals**: No new budget beyond Phase 0's baseline; auth/address pages are
low-complexity forms, not performance-risk surfaces this phase

**Constraints**: RLS is the enforced authorization boundary for `profiles`/`addresses`/`cities`
(Constitution Principle V) — the app-layer middleware role check is a UX convenience on top of RLS,
never a substitute for it; every form submission and Route Handler body is validated at runtime
with zod (Principle IV); login attempts are throttled per the spec's Clarifications (2026-08-10)
via Supabase Auth's built-in rate limiting rather than a custom implementation (see research.md)

**Scale/Scope**: 3 new tables, ~6 new/updated routes (`/login` now functional, new `/signup`,
`/forgot-password`, `/reset-password`, address management inside `/dashboard/settings`), one
`middleware.ts`, one Route Handler group (`/api/addresses`, `/api/addresses/[id]`), a `profiles`
auto-creation trigger, and city seed data (at least one active city, per the spec's Assumptions)

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — auth forms (signup/login/forgot/reset) and the address form need `"use client"` for controlled inputs and direct Supabase Auth calls; everything else (route shells, address list rendering) stays a Server Component | PASS — `"use client"` scoped to the smallest leaf form components only, per plan below |
| II. Server-Side Authority for Business Logic | No pricing/money logic this phase; the closest analog — role resolution and address ownership — is enforced server-side (middleware + RLS + Route Handlers), never trusted from client state | PASS |
| III. Performance Budget & Core Web Vitals | No new risk surface — forms only, no heavy client libraries, `next/font` already established | PASS |
| IV. Type Safety & Validation at Boundaries | Yes — signup/login/reset forms, the `profiles` trigger's metadata read, and every `/api/addresses` request body MUST be zod-validated, not just typed | PASS — required in design below |
| V. Data Integrity, Idempotency & Security | Yes — first phase with real user data. RLS MUST be enabled on `profiles`, `addresses`, `cities` from creation; customers read/write only their own `profiles`/`addresses` rows; `cities` is public-read, admin-write (no admin-write UI yet — seeded directly) | PASS — designed in data-model.md; this is the gate Phase 0's plan explicitly flagged for this phase |
| VI. Test-First for Critical Logic & Observability | Yes — the default-address invariant (exactly one default per customer) and the route-protection matrix are exactly the kind of logic where a silent bug has real consequences (data corruption / access-control bypass) | PASS — unit + Playwright coverage scoped in Technical Context above |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts (research.md, data-model.md, contracts/,
quickstart.md) keep all Auth calls on the Supabase browser client (no service-role key exposed),
enforce the default-address invariant with a database-level partial unique index (not just
application code, so it holds even under concurrent requests), and scope every new Route Handler
to zod-validated input plus RLS-backed queries. No new Client Components beyond the four leaf auth
forms and the address form. Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/002-phase-1-auth-address/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── login/
│   └── page.tsx                  # /login — replaces Phase 0's disabled placeholder with a real,
│                                  # working form (Client Component leaf)
├── signup/
│   └── page.tsx                  # /signup — new, no mockup (per spec Assumptions: same
│                                  # generic-layout treatment as /login and /admin from Phase 0)
├── forgot-password/
│   └── page.tsx                  # /forgot-password — request a reset email
├── reset-password/
│   └── page.tsx                  # /reset-password — landing page for the emailed reset link;
│                                  # sets a new password
├── dashboard/
│   └── settings/
│       └── page.tsx               # /dashboard/settings — Phase 0 placeholder gains the address
│                                   # book section (design/settings.html's address cards)
├── admin/
│   └── page.tsx                   # /admin — now actually gated by middleware (Phase 0 left it
│                                   # reachable by anyone; this phase restricts it)
└── api/
    └── addresses/
        ├── route.ts                # GET (list own), POST (create)
        └── [id]/
            └── route.ts             # PATCH (edit / set default), DELETE

middleware.ts                        # New. Refreshes the Supabase session cookie every request,
                                      # resolves the caller's role, and enforces the route matrix
                                      # in FR-010/FR-011 for /subscription, /dashboard, /admin

components/
└── auth/
    ├── SignupForm.tsx               # "use client" leaf — calls supabase.auth.signUp
    ├── LoginForm.tsx                # "use client" leaf — calls supabase.auth.signInWithPassword
    ├── ForgotPasswordForm.tsx       # "use client" leaf — calls supabase.auth.resetPasswordForEmail
    └── ResetPasswordForm.tsx        # "use client" leaf — calls supabase.auth.updateUser
└── address/
    ├── AddressList.tsx              # Server Component — reads addresses via server Supabase client
    ├── AddressForm.tsx              # "use client" leaf — create/edit form, calls RTK Query mutation
    └── AddressCard.tsx              # Presentational — label, city, district, default badge, actions

lib/
├── validation/
│   ├── auth.ts                     # zod schemas: signup, login, forgot-password, reset-password
│   └── address.ts                  # zod schema: address create/update payload
├── supabase/
│   └── middleware.ts                # createServerClient variant tuned for the middleware runtime
│                                    # (cookie handling differs from server.ts's Server Component
│                                    # variant per @supabase/ssr's documented split)
└── store/
    ├── index.ts                     # Updated: registers the new addressesApi reducer/middleware
    └── addressesApi.ts              # RTK Query slice — first real API slice in the project,
                                     # against /api/addresses (per plan.md's client-data-layer
                                     # decision)

supabase/
└── migrations/
    ├── <timestamp>_profiles.sql     # profiles table + role enum + RLS + auth.users trigger
    ├── <timestamp>_cities.sql       # cities table + RLS + seed data (at least one active city)
    └── <timestamp>_addresses.sql    # addresses table + partial unique index (one default per
                                     # user) + RLS

tests/
├── unit/
│   ├── validation.auth.test.ts      # zod schema edge cases (malformed email, weak password)
│   ├── validation.address.test.ts   # KSA phone / address payload edge cases
│   └── address-default.test.ts      # default-address invariant logic (if expressed in app code
│                                     # as well as the DB constraint — see data-model.md)
└── e2e/
    └── route-protection.spec.ts     # signed-out / customer / admin × /subscription, /dashboard,
                                      # /admin — the spec's User Story 3 Independent Test
```

**Structure Decision**: Stays inside the Phase 0 monolith — no new deployable, no new top-level
directory beyond `supabase/migrations/` (the natural home for schema now that real tables exist)
and a `components/auth/` + `components/address/` split alongside Phase 0's `components/ui/`
primitives. Auth mutations go directly from Client Components to the Supabase browser client
(the documented `@supabase/ssr` pattern, and not price-related so Constitution Principle V's
"browser never talks to Supabase directly for anything price-related" doesn't apply); address
mutations go through `/api/addresses` Route Handlers instead, both because it is the first natural
home for the RTK Query pattern `plan.md` commits to for later phases (cart, subscription) and
because it gives the Route Handler a single place to run zod validation before touching RLS-backed
rows.

## Complexity Tracking

*No Constitution Check violations — table not needed.*
