# Quickstart: Validating Phase 7 — Renewal Engine & Dunning

Validates the three user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 6 dashboard (a signed-in customer with an `active` subscription, a saved
`payment_methods` row, and at least one existing `orders` row from Phase 5's activation).

## Prerequisites

- Phase 6's quickstart already passing
- `CRON_SECRET` configured (a random shared secret — FR-018)
- Migration applied: `subscriptions` renewal-scheduling columns, `payments.kind` +
  nullable `moyasar_payment_id` (see [data-model.md](./data-model.md))
- `npm run dev` running

## 1. Run the new unit suites first (Constitution Principle VI)

```
npm run test:unit
```

**Expected**: `subscription.advanceDeliveryDate.test.ts`, `payments.dunningSchedule.test.ts`, and
`payments.cardExpiry.test.ts` all pass, including the blackout-day-skip and
suspend-after-exhausted-retries boundary cases. This MUST be green before trusting anything a
real renewal run does.

## 2. A due subscription renews successfully (User Story 1, FR-001–003/007/008, SC-001/002, the
phase's own demo target's first half)

```
# back-date a test active subscription's next_delivery_date to today (directly in Supabase, for
# test purposes) and set next_renewal_attempt_date to the same date
curl -X POST http://localhost:3000/api/cron/renewals \
  -H "Authorization: Bearer $CRON_SECRET"
```

**Expected**: the response reports `"renewed": 1`; a new `payments` row exists with `kind:
'renewal'`, `status: 'paid'`, and `amount_halalas` matching a *freshly computed* breakdown (change
a product's price in `/admin` beforehand and confirm the new order reflects the new price, not
the subscription's original signup price); a new `orders` row (with `order_items`) now exists,
visible on `/dashboard/orders`; the subscription's `next_delivery_date` has advanced by exactly
one frequency period from the date that was just renewed.

## 3. A pending change resolves on its effective cycle (User Story 1 Acceptance Scenario 3)

```
# on that same subscription, defer an edit past the cutoff window (Phase 6) so it becomes a
# pending change effective on a date you then back-date to today
# re-run the same curl command from step 2
```

**Expected**: the renewal charges and delivers the *pending* configuration (items/frequency/
address), and afterward `/dashboard` shows it as the subscription's new current configuration —
no pending-change banner remains.

## 4. Paused/cancelled subscriptions are skipped; an overdue pause self-heals (User Story 1
Acceptance Scenarios 4–5)

```
# pause one active subscription with a future resume date; cancel another
# back-date a third subscription's pause resume_date to yesterday, with its next_delivery_date
# also due today
# re-run the curl command
```

**Expected**: the still-paused and cancelled subscriptions are entirely untouched (no `payments`
row, `renewal_claimed_at` never set); the overdue-resume subscription renews normally in the same
run, and its status is `active` afterward.

## 5. A declined charge enters the retry schedule (User Story 2 Acceptance Scenarios 1–2, FR-013,
SC-004, the phase's own demo target's second half)

```
# back-date a subscription with a saved Moyasar test card known to decline, next_delivery_date =
# today
curl -X POST http://localhost:3000/api/cron/renewals -H "Authorization: Bearer $CRON_SECRET"
```

**Expected**: response reports `"retryScheduled": 1`; a `payments` row shows `status: 'failed'`
with a specific `failure_reason`; the subscription's `next_delivery_date` is unchanged;
`renewal_attempt_count` is `1`; `next_renewal_attempt_date` is exactly one day after this attempt.

## 6. Every retry fails and the subscription is suspended (User Story 2 Acceptance Scenarios 3–5,
FR-015, SC-004)

```
# advance next_renewal_attempt_date to today for the same subscription from step 5 (simulating
# the +1/+3/+5-day schedule elapsing) and re-run the curl command three more times, once per
# simulated retry date, keeping the same declining test card each time
```

**Expected**: after the fourth total failed attempt (the original plus all three retries), the
response reports `"suspended": 1`; the subscription's status becomes `paused` with no
`resume_date`; opening `/dashboard` (Phase 6) shows it as paused with a "needs attention" health
badge, and the existing card-replacement + resume actions are available exactly as for a
customer-initiated pause.

## 7. A discontinued product doesn't fail the whole box (User Story 3, FR-004/005, SC-006)

```
# disable one (but not all) products in a due, active subscription's box via /admin
# re-run the curl command
```

**Expected**: the renewal still succeeds; the resulting order's `order_items` excludes the
disabled product and its price; opening that order's detail on `/dashboard/orders` shows fewer
items than the subscription's own current box, reflecting what was actually charged/delivered.

## 8. Every product unavailable is a recorded failure, not an empty success (User Story 3
Acceptance Scenario 3)

```
# disable every product in a due, active subscription's box
# re-run the curl command
```

**Expected**: no charge is attempted (check the network/provider logs — no outbound Moyasar
request); a `payments` row records `failure_reason: 'no_available_items'`; the subscription
enters the same retry schedule as a decline.

## 9. Confirm idempotency under a repeated/overlapping trigger (Edge Cases, FR-011, SC-003)

```
# immediately re-run the exact curl command from step 2 a second time, right after the first
```

**Expected**: `200 OK`, but no second charge, no duplicate order, and the subscription's
`next_delivery_date` is unchanged from the first run's result.

## 10. Confirm the protected endpoint rejects an untrusted caller (FR-018)

```
curl -X POST http://localhost:3000/api/cron/renewals
curl -X POST http://localhost:3000/api/cron/renewals -H "Authorization: Bearer wrong-secret"
```

**Expected**: both requests return `401 { "error": "unauthorized" }`, and no subscription is
touched.

## 11. Run the full unit and e2e suites

```
npm run test:unit
npx playwright test tests/e2e/renewal-engine.spec.ts
```

**Expected**: all three new unit suites pass; the Playwright spec walks steps 2 and 5–6 above
(successful renewal, then decline → retry → suspend) without manual intervention.
