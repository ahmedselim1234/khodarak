# Implementation Plan: Phase 2 — Catalog + Admin Product CRUD

**Branch**: `003-phase-2-catalog-admin-crud` | **Date**: 2026-08-10 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/003-phase-2-catalog-admin-crud/spec.md`

## Summary

Give admins a product-management screen (create/edit/remove, availability toggle, photo upload to
Supabase Storage, min/max orderable quantity) backed by a new `products` table, and give customers
a live `/browse` catalog (خضروات/فواكه tabs, price + availability filters, sort, pagination) and
`/browse/[id]` detail page built from `design/products.html` and `design/product-details.html`.
Layer a quantity stepper and persistent cart bar on top, backed by Redux Toolkit client state for
guests (device-local) and a new `cart_items` table for signed-in customers (server-synced across
devices, merged from the guest cart at login using a higher-quantity-wins rule) — per the feature
spec's four user stories and its 2026-08-10 Clarifications session.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0/1)

**Primary Dependencies**: `@supabase/ssr` + `@supabase/supabase-js` (product queries from Server
Components, Supabase Storage upload for product photos, `cart_items` reads/writes from Route
Handlers), zod (request/form validation — product payloads, cart payloads), Redux Toolkit +
`react-redux` (guest cart slice with localStorage hydration) + RTK Query (`cartApi`, following the
`addressesApi` pattern from Phase 1 at `lib/store/addressesApi.ts`). No new runtime dependency is
introduced — the guest cart is hydrated from `localStorage` by hand (a `useEffect` on the root
provider, same idea as Phase 1's `StoreProvider`), not via `redux-persist`, to avoid adding a
package for something this small.

**Storage**: Supabase (Postgres) — one new table `products` (fields already specified in `plan.md`
§2: `name_ar`, `category`, `price`, `unit`, `image_url`, `is_available`, `min_qty`, `max_qty`,
`sort_order`) and one new table `cart_items` (not listed in `plan.md` §2 — added per the spec's
2026-08-10 Clarifications on server-synced cart persistence; see research.md). Supabase Storage
gets one new public bucket, `product-images`, with an admin-only write policy. RLS enabled on both
new tables from creation.

**Testing**: Vitest for the pure logic that must never be wrong even though no money is at stake
yet — quantity clamping (`clampQuantity`), the guest/account cart merge rule
(`mergeCartQuantities`, higher-quantity-wins capped at max), and product/cart zod schema edge
cases. Playwright for the phase's actual demo target end to end: admin creates a product with a
photo → it appears on `/browse` → a customer switches category tabs, filters, sorts, adjusts a
stepper, sees the cart bar update, reloads and still has it, then logs in and sees their guest
selections merged into their account cart.

**Target Platform**: Same as Phase 0/1 — `npm run dev` locally, Linux container deferred to Phase
9; primary client is mobile Chrome/Safari.

**Project Type**: Web application — same single Next.js monolith, no new deployable.

**Performance Goals**: Constitution Principle III's budget (LCP < 2.5s, INP < 200ms, CLS < 0.1 on
mid-tier mobile) applies for the first time to a genuinely image-heavy, interactive page — the
product grid. Every product photo renders via `next/image` with explicit `sizes`, the grid's first
viewport of cards gets priority loading and everything below the fold lazy-loads, and category
tab/filter/sort changes are plain navigations (Server Component re-render via `searchParams`), not
client-side re-fetches, to keep the interactive JS surface small.

**Constraints**: Product photo uploads MUST be validated (format, size) before being written to
Supabase Storage (Constitution Principle IV). RLS is the authorization boundary for both new tables
(Principle V) — `products` is public-read/admin-write, `cart_items` is owner-only read/write.
Admin product mutations go through `/api/admin/products` Route Handlers (never a direct browser
Supabase table write) so role-checking and validation happen server-side in one place; the photo
file itself uploads browser-to-Storage directly (not through our server) since Storage's own
RLS-backed bucket policy — not our Route Handler — is what actually restricts writes to admins,
and piping large file bytes through our own server would only cost latency for no added safety.
Cart bar totals shown this phase are an unlocked, non-binding preview (per spec Assumptions) —
Constitution Principle II's "server is the sole authority for money owed" gate does not yet apply
to cart display, because the cart is not yet charging or snapshotting anything; that authority
starts with the Phase 3 pricing engine and the Phase 4/5 subscription snapshot.

**Scale/Scope**: 2 new tables (`products`, `cart_items`), 1 new storage bucket, ~9 new/updated
routes (`/browse` and `/browse/[id]` now functional instead of placeholders, new
`/admin/products`, `/admin/products/new`, `/admin/products/[id]/edit`), 5 new Route Handlers
(`/api/admin/products`, `/api/admin/products/[id]`, `/api/cart`, `/api/cart/items/[productId]`,
`/api/cart/merge`), one Redux slice (`cartSlice`) plus one RTK Query API (`cartApi`).

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — `/browse`, `/browse/[id]`, and `/admin/products` (list) stay Server Components reading via the server Supabase client and `searchParams`; `"use client"` is scoped to the leaf interactive pieces only: `CategoryTabs`, `FilterSidebar`, `SortBar` (they update the URL), `QuantityStepper`, `CartBar`, and the admin `ProductForm`/`ImageUploadField` | PASS — no client wrapper around the grid or list itself |
| II. Server-Side Authority for Business Logic | Partially — no pricing calculation exists yet (that's Phase 3), so there is no money-determining function to protect this phase. What's admin-writable (price, availability, min/max qty) is still only mutable through server-validated Route Handlers, never a direct client write, so the principle's spirit (client never dictates persisted values) already holds ahead of Phase 3 | PASS — see Constraints above for the explicit cart-preview carve-out |
| III. Performance Budget & Core Web Vitals | Yes — first genuinely image-heavy, interactive page. `next/image` with `sizes`, tab/filter/sort as Server Component navigations rather than client fetches, stepper/cart kept as small leaf Client Components | PASS — designed in Project Structure below |
| IV. Type Safety & Validation at Boundaries | Yes — `/api/admin/products` request bodies, `/api/cart/*` request bodies, and the product-photo upload (format/size) all validated at runtime with zod before touching Storage or Postgres | PASS |
| V. Data Integrity, Idempotency & Security | Yes — RLS on `products` (public-read, admin-write) and `cart_items` (owner-only); Storage bucket policy restricts `product-images` writes to admins; admin product mutations flow through Route Handlers so role-checking happens server-side once, not per-call in the client | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — `clampQuantity` and `mergeCartQuantities` are exactly the kind of small pure function that's easy to get subtly wrong (off-by-one at a bound, wrong side winning a merge) and hard to notice once wired into UI, so they get Vitest coverage first; the Playwright spec is this phase's actual demo script | PASS — scoped in Technical Context and Project Structure |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts (research.md, data-model.md, contracts/,
quickstart.md) keep `/browse` and `/browse/[id]` as Server Components driven by URL
`searchParams` (no client-side product fetching), scope every new Client Component to a single
interactive concern, enforce `products`/`cart_items` RLS and the `product-images` bucket policy at
the database/storage layer (not just in Route Handler code), and validate every admin/cart request
body with zod. Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/003-phase-2-catalog-admin-crud/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md         # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── browse/
│   ├── page.tsx                    # /browse — replaces the Phase 0 PagePlaceholder with the real
│   │                                # grid; Server Component, reads category/sort/price/available/
│   │                                # page from searchParams, queries `products` via the server
│   │                                # Supabase client (design/products.html)
│   └── [id]/
│       └── page.tsx                # /browse/[id] — replaces the Phase 0 placeholder; Server
│                                    # Component product detail (design/product-details.html)
├── admin/
│   └── products/
│       ├── page.tsx                # /admin/products — Server Component list + delete/availability
│       │                            # actions; no mockup (per spec.md Assumptions), shared design
│       │                            # tokens + standard admin table conventions
│       ├── new/
│       │   └── page.tsx             # /admin/products/new — hosts the "use client" ProductForm
│       └── [id]/
│           └── edit/
│               └── page.tsx         # /admin/products/[id]/edit — hosts ProductForm in edit mode
└── api/
    ├── admin/
    │   └── products/
    │       ├── route.ts             # POST (create)
    │       └── [id]/
    │           └── route.ts         # PATCH (edit / toggle availability), DELETE
    └── cart/
        ├── route.ts                 # GET — signed-in customer's resolved cart (joined with
        │                             # current product data) + totals
        ├── items/
        │   └── [productId]/
        │       └── route.ts         # PUT (upsert quantity, clamped) — removes the row at 0
        └── merge/
            └── route.ts             # POST — merges a guest cart payload into the caller's
                                      # server-side cart_items (FR-015's higher-quantity-wins rule)

components/
├── catalog/
│   ├── CategoryTabs.tsx             # "use client" leaf — خضروات/فواكه tabs, pushes ?category=
│   ├── FilterSidebar.tsx            # "use client" leaf — price range + availability toggle,
│   │                                 # pushes ?minPrice=&maxPrice=&available=
│   ├── SortBar.tsx                  # "use client" leaf — sort <select>, pushes ?sort=
│   ├── ProductGrid.tsx              # Server Component — renders the grid from server-fetched rows
│   ├── ProductCard.tsx              # Server Component shell embedding QuantityStepper
│   ├── Pagination.tsx               # Server Component — plain <Link>s, no client JS needed
│   └── EmptyState.tsx               # Presentational — used when a tab/filter combo has no matches
├── product/
│   ├── ProductGallery.tsx           # Server Component — image + thumbnails (design/product-details.html)
│   └── ProductInfo.tsx              # Server Component shell embedding QuantityStepper
├── cart/
│   ├── CartBar.tsx                  # "use client" — persistent bar; reads guest cartSlice or
│   │                                 # cartApi query depending on auth state
│   └── QuantityStepper.tsx          # "use client" leaf — used on both the grid card and detail
│                                     # page; calls cartApi mutation (signed-in) or cartSlice action
│                                     # (guest), clamped via lib/cart/clampQuantity.ts
└── admin/
    └── products/
        ├── ProductForm.tsx          # "use client" — name/category/price/unit/min-max/availability
        │                             # fields + ImageUploadField; calls the admin RTK Query API
        ├── ProductTable.tsx         # Server Component — list with edit links + availability/delete
        │                             # actions (actions themselves are small client leaves)
        └── ImageUploadField.tsx     # "use client" leaf — uploads directly to the `product-images`
                                      # Storage bucket via the browser Supabase client, returns the
                                      # public URL to the surrounding form

lib/
├── cart/
│   ├── cartSlice.ts                 # Redux slice — guest cart (productId → {quantity, snapshot}),
│   │                                 # hydrated from/synced to localStorage in StoreProvider
│   ├── clampQuantity.ts             # Pure function — clamp to [minQty, maxQty], 0 removes the item
│   └── mergeCartQuantities.ts       # Pure function — higher-quantity-wins merge capped at maxQty
│                                     # (FR-015); used by /api/cart/merge
├── products/
│   ├── mapProductRow.ts             # snake_case → camelCase mapper (mirrors mapAddressRow.ts)
│   └── queryProducts.ts             # Server-side query builder: category/price/availability/sort/
│                                     # pagination against Supabase `products`, used by /browse
├── validation/
│   ├── product.ts                   # zod schemas: product create/update payload, photo
│   │                                 # format/size constraints
│   └── cart.ts                      # zod schemas: cart item upsert payload, merge payload
├── supabase/
│   └── storage.ts                   # Browser-side helper: upload to `product-images`, return
│                                     # public URL; format/size validated by lib/validation/product.ts
│                                     # before this is ever called
└── store/
    ├── index.ts                     # Updated: registers cartSlice reducer + cartApi
    └── cartApi.ts                   # RTK Query slice against /api/cart/* — same pattern as
                                      # lib/store/addressesApi.ts

supabase/
└── migrations/
    ├── <timestamp>_products.sql     # products table + RLS (public-read, admin-write) + seed data
    ├── <timestamp>_product_images_bucket.sql  # storage bucket + admin-only write policy
    └── <timestamp>_cart_items.sql   # cart_items table + unique(user_id, product_id) + RLS
                                      # (owner-only)

tests/
├── unit/
│   ├── cart.clampQuantity.test.ts
│   ├── cart.mergeCartQuantities.test.ts
│   └── validation.product.test.ts
└── e2e/
    └── catalog-cart.spec.ts         # admin creates product → appears on /browse; tab/filter/sort;
                                      # stepper → cart bar update; reload persistence; guest → login
                                      # merge — the spec's demo target end to end
```

**Structure Decision**: Stays inside the Phase 0/1 monolith. `/browse` and `/browse/[id]` follow
the same Server-Component-plus-`searchParams` pattern the App Router is built for, instead of
introducing client-side product fetching — a deliberate change from treating everything as an RTK
Query slice, because the catalog grid is exactly the kind of colocated, cacheable read Constitution
Principle I asks Server Components to own. Cart and admin-product *mutations* go through Route
Handlers via RTK Query (`cartApi`, a new `productsAdminApi`), continuing the pattern
`addressesApi.ts` established in Phase 1, because mutations need optimistic client feedback (the
stepper, the admin form) that a Server Component re-render can't give on its own. Product photo
uploads bypass our server entirely (browser → Supabase Storage) for the same latency/no-added-safety
reasoning Phase 1 used for Auth calls going directly to Supabase from the browser.

## Complexity Tracking

*No Constitution Check violations — table not needed.*
