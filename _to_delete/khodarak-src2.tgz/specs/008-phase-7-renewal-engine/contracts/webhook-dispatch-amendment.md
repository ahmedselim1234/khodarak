# Contract Amendment: `POST /api/webhooks/moyasar` (Phase 5, extended)

Phase 5's webhook contract (`specs/006-phase-5-moyasar-payment/contracts/payment-callback-and-webhook.md`)
unconditionally called `processPaymentOutcome` for every actionable event. This phase changes only
the dispatch step — everything else (signature verification first, `webhook_events` deduplication
via the unique `moyasar_event_id` constraint, rejecting an invalid signature outright) is
unchanged.

## Amended behavior

After deduplication succeeds (the event hasn't been processed before) and the event type is
actionable (`payment_paid`/`payment_failed`, unchanged from Phase 5):

1. Look up the matching `payments` row by `moyasar_payment_id = data.id`.
2. If no matching row exists: acknowledge (`200 { "received": true }`) and do nothing further —
   an event for a payment this app never initiated (shouldn't happen, but never trusted blindly).
3. If the row's `kind = 'initial'`: call `processPaymentOutcome(data.id, verifiedStatus,
   payload)` — Phase 5's own function, completely unchanged.
4. If the row's `kind = 'renewal'`: call `processRenewalOutcome(row.id, verifiedStatus, payload)`
   (contracts/process-renewal-outcome.md) — keyed by the row's own `id`, looked up in step 1,
   not `data.id` directly (research.md §6).

`verifiedStatus` is still derived exactly as Phase 5 already does (`data.status === 'paid' ?
'paid' : 'failed'`) — this amendment changes only *which* processor receives it, never how the
event itself is authenticated or deduplicated.

## Why this is additive, not a rewrite

Every one of Phase 5's own webhook test cases (invalid signature rejected, duplicate event
acknowledged without reprocessing, `payment_paid`/`payment_failed` dispatched) still holds
unchanged for `kind = 'initial'` events — this amendment only adds a lookup and a branch in front
of the existing dispatch, per research.md §6's own reasoning for why a `payments.kind` column is
the smallest change that lets one shared endpoint route both charge flows correctly.
