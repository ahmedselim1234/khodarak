# Feature Specification: Phase 5 — Moyasar Integration & First Payment

**Feature Branch**: `006-phase-5-moyasar-payment`

**Created**: 2026-08-10

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for Phase 5" — scoped from `plan.md` §4 "Phase 5 — Moyasar Integration & First Payment": Moyasar test account + keys, client-side tokenization form slotted into the payment-method section of `design/complete-order.html`, first payment with 3DS, callback verification, `payment_methods`/`payments` tables, webhook endpoint with signature verification and event deduplication, subscription activation on confirmed payment landing on `design/successfull-order.html`, recurring-consent UI. Also draws on `plan.md` §3b "Moyasar Integration Design," which specifies the tokenization/charge/verification flow and its five non-negotiables (halalas not riyals, idempotency, webhooks as source of truth, dunning is later, card expiry is later). Demo target: "subscribe with a Moyasar test card, complete 3DS, land back on the success screen, and show the payment appearing in the Moyasar dashboard."

## Clarifications

### Session 2026-08-10

- Q: When a customer with an existing saved card starts paying for a new pending-payment subscription, should they be offered "use my saved card" as well as "add a new card"? → A: Offer both — if the customer already has an active saved payment method, they can pick it to pay instantly, or choose to add a different card instead.
- Q: Should there be any limit on how many times a customer can immediately retry a declined/failed payment for the same subscription in one sitting? → A: Basic throttling — after a small number of consecutive failed attempts for the same subscription, further attempts are temporarily blocked or slowed, mirroring the login-throttling precedent from Phase 1.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Pay for a pending subscription with a card (Priority: P1)

A customer with a subscription awaiting payment (created in the previous phase) enters their card details — or picks a card they've already saved — gives explicit consent to future recurring charges, and submits payment for that subscription's first charge, completing any additional verification their bank requires.

**Why this priority**: This is the phase's entire reason to exist — without it, every subscription created so far is permanently stuck waiting for payment. It's also the phase's own demo target.

**Independent Test**: Can be fully tested by opening the payment step for a pending-payment subscription, entering a Moyasar test card, checking the consent box, submitting, and completing the test bank's verification challenge — delivers a submitted payment attempt independent of what happens to it afterward.

**Acceptance Scenarios**:

1. **Given** a customer opens the payment step for their own pending-payment subscription, **When** the page loads, **Then** they see that subscription's saved price total and a card-entry form, with card number/expiry/CVV fields that submit directly to the card network rather than through the app's own server.
2. **Given** the customer has at least one existing saved, active card, **When** they open the payment step, **Then** they can choose to pay with that saved card or to add a new one instead.
3. **Given** the customer has entered card details (or selected a saved card), **When** they attempt to submit without checking the recurring-charge consent box, **Then** submission is blocked until they check it.
4. **Given** valid card details and consent given, **When** the customer submits, **Then** the payment is submitted with additional bank verification (3D Secure) and the customer is guided through completing it.
5. **Given** a customer attempts to open the payment step for a subscription that isn't theirs, or one that isn't in a pending-payment state, **When** they try, **Then** they are denied rather than shown someone else's or an already-resolved subscription's payment step.

---

### User Story 2 - Successful payment activates the subscription (Priority: P1)

Once a payment is confirmed successful — whether the customer is still waiting on the confirmation screen or has already left — the subscription becomes active, the card is saved for future use, the first delivery order is created from the subscription's already-agreed price, and the customer sees a clear success confirmation.

**Why this priority**: This is where the phase's value is actually captured — a submitted payment that never results in an active subscription and a real order is worthless. It depends on User Story 1 producing a payment attempt to confirm.

**Independent Test**: Can be fully tested by simulating a confirmed-successful payment for a pending subscription (via the verification path or the webhook path independently) and confirming the subscription's status becomes active, a first order now exists with the subscription's snapshotted items and price, and the payment method is saved — delivers verifiable activation independent of the payment UI itself.

**Acceptance Scenarios**:

1. **Given** a submitted payment is confirmed successful by directly checking with the payment provider (never by trusting a redirect's own parameters), **When** confirmation completes, **Then** the subscription's status changes from pending-payment to active.
2. **Given** a payment is confirmed successful, **When** the subscription activates, **Then** the customer's card is saved as a usable payment method (brand, last four digits, expiry — never the full card number or security code), and a first delivery order is created using the exact items, quantities, and price the customer agreed to when they built the subscription — not a value recalculated at this later moment.
3. **Given** a payment is confirmed successful, **When** the customer is still on the confirmation screen, **Then** they are shown a distinct success confirmation (not the earlier "payment coming soon" message from subscription creation).
4. **Given** a payment is confirmed successful through the provider's independent notification channel while the customer has already left the confirmation screen, **When** that notification is processed, **Then** the subscription still activates and the first order is still created, exactly as if the customer had waited.
5. **Given** the same successful-payment confirmation is somehow received or processed more than once (a page refresh, a repeated notification), **When** it's processed again, **Then** the subscription is not activated a second time, no duplicate order is created, and no duplicate charge record is created.

---

### User Story 3 - Failed or declined payment lets the customer retry (Priority: P2)

If a payment is declined, fails 3D Secure verification, or otherwise doesn't succeed, the customer sees a clear, specific reason and can immediately try again — with the same card or a different one — without losing their subscription.

**Why this priority**: Card declines are routine, not exceptional, so this matters for real usage — but the primary happy-path demo (User Stories 1–2) is complete and demonstrable without it, so it ranks behind them.

**Independent Test**: Can be fully tested by submitting a Moyasar test card known to decline, confirming a specific error is shown, and confirming the customer can immediately retry with another card and succeed — delivers a working recovery path independent of the success path.

**Acceptance Scenarios**:

1. **Given** a customer submits a card that is declined, **When** the decline is confirmed, **Then** they see a specific, actionable message (not a generic error) and the subscription remains in a pending-payment state.
2. **Given** a customer's 3D Secure verification fails or is abandoned, **When** that happens, **Then** they see a clear message and can retry rather than being stuck on a broken screen.
3. **Given** a previous attempt failed, **When** the customer retries with a different, valid card, **Then** the new attempt can succeed normally, following User Story 2's activation flow.
4. **Given** a payment attempt fails, **When** it's recorded, **Then** the failure and its reason are retained (for later support/troubleshooting use), without exposing raw card data.
5. **Given** a customer has failed several consecutive payment attempts for the same subscription, **When** they try again beyond that threshold, **Then** further attempts are temporarily blocked or slowed with a clear message, rather than allowed indefinitely.

---

### Edge Cases

- What happens when a customer closes their browser or loses connectivity during the 3D Secure step, and the payment actually succeeded on the provider's side? The provider's independent notification still reaches the system and activates the subscription (User Story 2, Acceptance Scenario 4) — the customer isn't permanently stuck just because they didn't see the redirect complete.
- What happens when the provider's notification and the customer's own redirect-triggered confirmation both arrive for the same payment? Whichever arrives first performs the activation; the second is recognized as already-processed and does nothing further (User Story 2, Acceptance Scenario 5).
- What happens if a subscription's saved price was somehow different from what's charged (e.g., a bug attempted to recompute at this stage)? Never allowed — the charge and the generated order always use the exact snapshot saved when the subscription was created, not a fresh calculation.
- What happens when a customer attempts to pay for a subscription that's already active (e.g., they reopen an old link)? They're shown that it's already active rather than being allowed to pay again or being shown a broken form.
- What happens when a customer's saved card has since expired by the time they try to reuse it for a new subscription? It's not offered as a usable option for a new charge (though full expiry-driven prompting ahead of a charge is a later phase's concern per `plan.md`).
- What happens when the webhook delivers an event type this phase doesn't otherwise act on (e.g., a refund event, which is a later phase's concern)? It's still recorded (so nothing is silently lost) but doesn't trigger any action this phase doesn't define.
- What happens when signature verification on an incoming webhook request fails? The request is rejected outright and nothing from it is trusted or processed.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST let a customer enter card details that are submitted directly to the payment provider from their own browser — card number, expiry, and CVV MUST NOT pass through the application's own server at any point.
- **FR-002**: System MUST offer an existing active saved payment method as a selectable option when the customer has one, alongside the option to add a new card instead.
- **FR-003**: System MUST require an explicit, checked consent to future recurring charges before a payment can be submitted for a subscription.
- **FR-004**: System MUST submit the first payment for a subscription with additional bank verification (3D Secure) and guide the customer through completing it.
- **FR-005**: System MUST verify a payment's outcome by checking directly with the payment provider — a redirect's own parameters are never treated as proof of success.
- **FR-006**: System MUST only offer the payment step for a subscription that belongs to the signed-in customer and is currently in a pending-payment state; any other subscription (not theirs, already active, already cancelled) MUST be denied rather than shown a payment form.
- **FR-007**: System MUST activate a subscription (transition it out of pending-payment) only after a payment for it has been independently confirmed successful by the provider.
- **FR-008**: System MUST save a successfully charged card as a reusable payment method — brand, last four digits, and expiry only — and MUST NOT store the full card number or security code anywhere in the system.
- **FR-009**: System MUST generate the subscription's first delivery order upon activation, using the exact items, quantities, and price breakdown already snapshotted when the subscription was created — never a value recalculated at activation time.
- **FR-010**: System MUST show the customer a distinct success confirmation once their subscription is confirmed active, replacing the "payment coming soon" state from subscription creation.
- **FR-011**: System MUST also receive and process the payment provider's own independent outcome notifications (not relying solely on the customer's redirect back to the app), applying the same activation/order-generation behavior regardless of which path confirms the outcome first.
- **FR-012**: System MUST verify the authenticity of every incoming provider notification before trusting or acting on it, and MUST reject one that fails verification.
- **FR-013**: System MUST process each distinct provider notification exactly once — a redelivered or duplicate notification for an already-processed outcome MUST NOT re-activate an already-active subscription, MUST NOT create a duplicate order, and MUST NOT create a duplicate payment record.
- **FR-014**: System MUST prevent a subscription's first payment from being charged more than once, even if verification is triggered more than once for the same attempt (e.g., a page refresh after redirect).
- **FR-015**: System MUST record every payment attempt — successful or failed — with its amount, outcome, and (when failed) a specific reason, without recording raw card data.
- **FR-016**: System MUST show a specific, actionable message when a payment is declined or fails verification, and MUST allow the customer to immediately retry with the same or a different card, leaving the subscription in a pending-payment state until an attempt succeeds.
- **FR-016a**: System MUST temporarily throttle or block further payment attempts against the same subscription after a small number of consecutive failures, to resist card-testing abuse, mirroring the login-throttling behavior established for authentication in Phase 1.
- **FR-017**: System MUST handle every monetary amount sent to or compared against the payment provider through one shared, single point of unit conversion — never an inline calculation duplicated across the codebase — to eliminate the class of bug where an amount is off by a factor of 100.
- **FR-018**: System MUST use the payment provider's test-mode credentials during development, and MUST NOT mix test and live credentials.

### Key Entities

- **Payment Method**: A customer's saved, reusable card reference — provider token, card brand, last four digits, expiry month/year, whether it's the customer's default, and its status (active/expired/removed). Never holds the actual card number or security code. Belongs to one customer; a customer may have several over time.
- **Payment**: A single charge attempt against a specific order — amount, outcome (success/failed/pending), failure reason when applicable, which attempt number it was, and the raw response retained for troubleshooting. One subscription's first payment produces one initial payment record per attempt (a decline followed by a retry produces two records, not one overwritten).
- **Provider Notification (Webhook Event)**: A durable, deduplicated record of every outcome notification received from the payment provider — its unique provider-assigned id (the basis for deduplication), its type, its payload, and when it was processed. Exists independently of whether the customer's own browser session ever confirmed the same outcome.
- **Order**: A subscription's first (and, in later phases, each subsequent) generated delivery — created only upon successful payment activation this phase, carrying a snapshot of the delivery address, the price breakdown, and its items at the moment it was generated, so it never silently changes if the subscription or products change afterward.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A customer can go from a pending-payment subscription to an active one with a completed first order in a single card-entry-and-verification attempt, without needing to contact support.
- **SC-002**: 100% of subscription activations are backed by a provider-confirmed payment outcome — none occur based on client-supplied information alone.
- **SC-003**: 100% of duplicate outcome notifications for the same payment are recognized and ignored — no subscription is ever activated twice, and no duplicate order or payment record is ever created from redelivery.
- **SC-004**: 100% of declined or failed payment attempts show the customer a specific, actionable message and leave them able to retry within the same session.
- **SC-005**: 100% of amounts charged match the subscription's snapshotted price exactly — no charge ever differs from what the customer agreed to when the subscription was created.
- **SC-006**: No full card number or security code is ever present in the application's own data at any point in the flow.

## Assumptions

- The payment step is reached from the existing Phase 4 subscription-confirmation page, which gains a real "pay now" action in place of its previous static "payment coming soon" messaging — Phase 4's own creation flow (the wizard, the `pending_payment` subscription it produces) is unchanged by this phase.
- The `orders`/`order_items` tables referenced in `plan.md` §2 do not exist yet (Phase 4 deliberately stopped short of generating any order) and are introduced by this phase, scoped to exactly what's needed to generate one subscription's first order on activation — the full recurring order-generation (renewal) engine is Phase 7's job, not this phase's.
- A declined or failed payment does not change the subscription's status or introduce a new status value — it simply stays `pending_payment` until a successful attempt activates it; a formal retry *schedule*/dunning process (contacting the customer after N failures, suspending after repeated failures) is explicitly out of scope this phase per `plan.md`'s own phase-7 framing.
- Card-expiry-aware prompting (warning a customer their saved card is about to expire before a future charge) is out of scope this phase per `plan.md`'s explicit later-phase framing; this phase only prevents an already-expired card from being offered for a new charge.
- Only the payment provider's test-mode ("pk_test_"/"sk_test_"-equivalent) credentials are used and validated this phase; going live with real credentials is a launch-readiness concern for the final hardening phase, not this one.
- Webhook delivery requires a publicly reachable endpoint; during local development this is assumed to be provided via a tunneling tool, consistent with `plan.md` §3b's own note — this is a development-environment detail, not a product behavior this spec constrains.
- "Recurring-charge consent" (FR-003) is a simple, explicit checkbox confirming the customer understands and agrees to future automatic charges per their chosen frequency — no additional legal/contract text beyond what `plan.md` itself calls for is assumed to be required.
