# Feature Specification: Phase 3 — Admin Settings & the Pricing Engine

**Feature Branch**: `004-phase-3-pricing-engine`

**Created**: 2026-08-10

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for Phase 3" — scoped from `plan.md` §4 "Phase 3 — Admin Settings & the Pricing Engine": `settings` table + admin settings UI, `calculate.ts` pure function, unit test suite, `/api/pricing/preview` route handler. Demo target: "change the weekly discount in admin from 5% to 15%, refresh the customer side, watch the price drop." Also draws on `plan.md` §3 "The Admin Settings → Pricing Rules Model," which specifies the settings shape and the exact calculation order this phase must implement.

## Clarifications

### Session 2026-08-10

- Q: `plan.md`'s Phase 3 demo is "change the weekly discount in admin, refresh the customer side, watch the price drop" — but the real customer-facing subscription builder doesn't exist until Phase 4. What should the customer-facing surface be in Phase 3 to make this demo possible? → A: A minimal, real (not full-wizard) customer-facing live preview page — pick a few products/quantities and a frequency, see the price breakdown update, driven by the same pricing engine that will power the full builder later.
- Q: Should the live pricing preview page require the visitor to be signed in, or should anyone (including a signed-out visitor) be able to open it? → A: Public, signed-out access — same treatment as `/browse`; matches the real customer journey of pricing being visible before signup.
- Q: Since the preview must be public but Phase 1 already gates `/subscription` behind sign-in (reserved for Phase 4's real checkout), which URL should this phase's public preview live at? → A: A new, separate public route (e.g. `/subscription/preview`) that Phase 1's route-protection matrix does not cover — `/subscription` itself stays gated for Phase 4's real checkout flow.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Admin configures the pricing and order rules (Priority: P1)

An admin opens a single settings screen and configures everything that drives how a box is priced and constrained: per-frequency discounts, order rules (minimum order value, max items per box, edit cutoff, first-delivery lead time, blackout weekdays), delivery fee mode, pause rules, VAT, and rounding.

**Why this priority**: Every other capability in this phase reads from these settings. Without a way to set them, there is nothing for the pricing engine to calculate against beyond hard-coded defaults, and the phase's own demo target (change a discount, watch the price react) is impossible.

**Independent Test**: Can be fully tested by opening the settings screen, changing the weekly frequency's discount percentage, saving, and confirming the new value is persisted and reflected on reload — delivers a working configuration surface independent of anything reading it yet.

**Acceptance Scenarios**:

1. **Given** an admin on the settings screen, **When** they change the weekly frequency's discount percentage and save, **Then** the new value is persisted and shown on the next page load.
2. **Given** an admin on the settings screen, **When** they disable a frequency (e.g., bi-weekly), **Then** it is saved as disabled and no longer offered as a selectable option anywhere it's presented to a customer.
3. **Given** an admin on the settings screen, **When** they set the minimum order value, maximum items per box, edit cutoff hours, first-delivery lead days, and blackout weekdays, **Then** each value is saved and reflected on reload.
4. **Given** an admin on the settings screen, **When** they choose a delivery fee mode (flat / free-above-threshold / per-city) and set its associated value(s), **Then** the choice and values are saved.
5. **Given** an admin on the settings screen, **When** they set the VAT percentage and whether displayed prices already include VAT, **Then** both are saved and used by every subsequent calculation.
6. **Given** an admin on the settings screen, **When** they choose a rounding mode, **Then** it is saved and applied by every subsequent calculation.
7. **Given** an admin submits a settings value outside a sane range (e.g., a negative discount percentage, a VAT percentage over 100, min order value below zero), **When** they save, **Then** the system rejects it with a specific error and keeps the previous valid value in effect.

---

### User Story 2 - The system calculates one correct, itemized price for any box (Priority: P1)

Given a set of items with quantities, a delivery frequency, and a delivery city, the system computes the exact same price breakdown every time — subtotal, frequency discount, delivery fee, VAT, and final total — using only the current admin settings, in one place, on the server.

**Why this priority**: This is the actual pricing engine — the single most consequential piece of logic in the product, since a bug here silently costs real money later once payments exist. It has to be correct and single-sourced before anything (a preview, later a real checkout) is allowed to build on top of it.

**Independent Test**: Can be fully tested by calling the pricing calculation with a fixed set of items, quantities, a frequency, and a city, and verifying the returned breakdown matches the documented formula by hand for a table of known cases — delivers a verifiably correct engine independent of any UI.

**Acceptance Scenarios**:

1. **Given** a set of items and quantities, **When** the price is calculated, **Then** the items subtotal equals the sum of each item's current price times its quantity.
2. **Given** a subtotal and a selected frequency, **When** the price is calculated, **Then** the frequency's configured discount percentage is applied to produce the after-discount amount.
3. **Given** an after-discount amount, a selected city, and the configured delivery mode, **When** the price is calculated, **Then** the delivery fee is resolved according to that mode (a flat fee; free once the after-discount amount reaches the configured threshold; or the selected city's fee when the mode is per-city).
4. **Given** an after-discount amount and a delivery fee, **When** the price is calculated, **Then** VAT is applied correctly whether the configured VAT setting treats prices as including or excluding tax.
5. **Given** a computed pre-rounding total, **When** the price is calculated, **Then** the configured rounding mode is applied to produce the final total per delivery.
6. **Given** a final total per delivery and the selected frequency's deliveries-per-month value, **When** the price is calculated, **Then** an estimated monthly cost is also returned.
7. **Given** any calculation, **When** its result is returned, **Then** the response includes every intermediate line (subtotal, discount, delivery fee, VAT, total, estimated monthly) rather than only a final number.
8. **Given** the same items, quantities, frequency, and city, **When** the price is calculated twice in a row with no settings change in between, **Then** both calculations return identical results.
9. **Given** an order whose items subtotal falls below the configured minimum order value, or whose total item count exceeds the configured maximum items per box, **When** the price is calculated, **Then** the breakdown clearly indicates the order does not currently meet those rules, alongside the price itself.

---

### User Story 3 - A live preview shows the price reacting to settings changes (Priority: P2)

Someone (an admin verifying their own settings changes, or a developer/stakeholder demoing the feature) can open a simple customer-facing page, pick a few sample products and quantities, choose a frequency and city, and see the resulting price breakdown — and when an admin then changes a setting (like a discount) and the preview page is refreshed, the new price is visible immediately.

**Why this priority**: This is what makes the engine's correctness observable and demoable — it's explicitly called out in `plan.md` as the strongest single demo in the whole project. It depends entirely on User Stories 1 and 2 already working, so it is not itself where the core value or risk lives.

**Independent Test**: Can be fully tested by opening the preview page while signed out, selecting sample items and a frequency, noting the displayed price, then changing that frequency's discount in the admin settings screen and reloading the preview page to confirm the price changed accordingly — delivers the phase's full demo scenario end to end without needing a test account.

**Acceptance Scenarios**:

1. **Given** a signed-out visitor opens the live preview page, **When** they select one or more products and quantities, a frequency, and a city, **Then** the full price breakdown (subtotal, discount, delivery fee, VAT, total per delivery, estimated monthly) is displayed, with no sign-in required.
2. **Given** the preview page is showing a breakdown, **When** an admin changes a relevant setting (e.g., a frequency's discount percentage) and the preview page is reloaded with the same selections, **Then** the displayed breakdown reflects the new setting.
3. **Given** the preview page, **When** a visitor selects a frequency that an admin has disabled, **Then** that frequency is not offered as a choice.
4. **Given** the preview page with no items selected, **When** it is viewed, **Then** it shows a clear empty/zero state rather than an error or a broken calculation.

---

### Edge Cases

- What happens when the after-discount amount is exactly equal to the free-delivery threshold? The delivery fee is free (the threshold is inclusive), not charged.
- What happens when `prices_include_vat` is toggled? The formula branches correctly — VAT is extracted from the taxable base rather than added on top when prices already include it, and added on top when they don't — and both produce a materially different total, which the breakdown must show correctly either way.
- What happens at a rounding boundary (e.g., a value exactly halfway between two rounding targets under "nearest 0.5")? The rounding mode's rule is applied consistently and predictably, not left to floating-point chance.
- What happens when the delivery mode is "per-city" but the selected city has no per-city fee override configured? The flat fee is used as the fallback for that city until an admin sets an explicit override (city fee management itself ships in a later phase per `plan.md` Phase 8).
- What happens when an order is below the minimum order value or exceeds the maximum items per box? The breakdown still computes and returns a price, but clearly flags that the order doesn't currently satisfy those rules — actually preventing checkout on this basis is the responsibility of the Phase 4 subscription builder, not this phase.
- What happens when every frequency is disabled? The preview and any future consumer has no selectable frequency and must show a clear "no delivery frequency currently available" state rather than defaulting to a hidden/disabled option.
- What happens when the calculation is invoked with a product that no longer exists or has become unavailable since it was selected? That item is excluded from the calculation and the breakdown indicates it was dropped, rather than the whole calculation failing.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST provide an admin settings screen for configuring, per delivery frequency (weekly, bi-weekly, monthly): whether it is enabled, its discount percentage, and its deliveries-per-month value.
- **FR-002**: System MUST provide admin configuration for order rules: minimum order value, maximum items per box, edit cutoff hours, first-delivery lead days, and blackout weekdays.
- **FR-003**: System MUST provide admin configuration for the delivery fee mode (flat / free-above-threshold / per-city) and its associated flat fee and free-delivery threshold values.
- **FR-004**: System MUST provide admin configuration for pause rules: maximum pause days and maximum pauses per year.
- **FR-005**: System MUST provide admin configuration for tax: the VAT percentage and whether displayed/entered prices already include VAT.
- **FR-006**: System MUST provide admin configuration for the rounding mode applied to calculated totals.
- **FR-007**: System MUST persist all settings as a single, current configuration that every calculation reads at the moment it runs — there is exactly one active settings record, not a history of versions.
- **FR-008**: System MUST reject a settings value that is out of a sane range (e.g., a negative percentage, a percentage over 100, a negative currency amount) with a specific, actionable error, leaving the previously saved valid value in effect.
- **FR-009**: System MUST calculate the price of a given set of items, quantities, frequency, and city through exactly one server-side calculation path, in this order: items subtotal → frequency discount → after-discount amount → delivery fee → taxable base → VAT → total per delivery → estimated monthly cost.
- **FR-010**: System MUST return the full breakdown of a calculation (every intermediate line, not just the final total) from that single calculation path.
- **FR-011**: System MUST NOT accept or trust a price or breakdown value supplied by a client as authoritative — every returned price is always freshly computed server-side from current settings and current item prices.
- **FR-012**: System MUST offer only frequencies currently marked enabled as selectable options anywhere a frequency is chosen.
- **FR-013**: System MUST resolve the delivery fee according to the configured mode: a flat fee; free once the after-discount amount meets or exceeds the configured threshold; or the selected city's configured fee (falling back to the flat fee when a city has no override) when the mode is per-city.
- **FR-014**: System MUST apply VAT correctly for both configurations of whether prices already include it, without double-charging or omitting tax in either case.
- **FR-015**: System MUST apply the configured rounding mode consistently to the final total per delivery.
- **FR-016**: System MUST flag, within the returned breakdown, whether the given order currently satisfies the minimum order value and maximum items per box rules, without itself blocking or preventing the calculation from completing.
- **FR-017**: System MUST provide a live, customer-facing preview surface where a visitor can select sample items and quantities, a frequency, and a city, and see the resulting price breakdown.
- **FR-017a**: System MUST make the preview surface reachable without signing in — the same public access as `/browse` — since pricing is part of the pre-signup browsing experience, not a gated account feature.
- **FR-017b**: System MUST expose the preview surface at a route separate from the customer-gated `/subscription` path (which stays protected for Phase 4's real checkout flow per the existing route-protection matrix), rather than loosening that path's protection or repurposing it.
- **FR-018**: System MUST reflect any settings change in the preview surface's next calculation (on reload/re-selection) without requiring a deployment or code change.
- **FR-019**: System MUST exclude a product from a calculation and flag it as dropped if that product no longer exists or is unavailable at calculation time, rather than failing the whole calculation.
- **FR-020**: System MUST show a clear empty/zero state on the preview surface when no items are selected, and a clear "no delivery frequency currently available" state if every frequency is disabled.

### Key Entities

- **Settings**: The single, admin-managed configuration record driving every price calculation — per-frequency rules (enabled, discount percent, deliveries per month), order rules (minimum order value, max items per box, edit cutoff hours, first-delivery lead days, blackout weekdays), delivery configuration (mode, flat fee, free-delivery threshold), pause rules (max pause days, max pauses per year), tax configuration (VAT percent, whether prices include VAT), and rounding mode.
- **Price Breakdown**: The structured, itemized result of a single calculation — items subtotal, frequency discount amount, after-discount amount, delivery fee, taxable base, VAT amount, total per delivery, estimated monthly cost, and rule-compliance flags (meets minimum order value, within max items per box) — plus any items dropped from the calculation. Not persisted; recomputed fresh on every request.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: An admin can change any pricing or order rule and see it take effect on the next calculation without any code change or deployment.
- **SC-002**: 100% of calculations for a given fixed set of inputs (items, quantities, frequency, city, settings) return identical results, no matter how many times or where the calculation is invoked from.
- **SC-003**: An admin can change a frequency's discount and, within one settings save and one preview-page reload, see the new price reflected — completing the phase's demo scenario in under one minute.
- **SC-004**: 100% of the documented boundary cases (order below minimum, free-delivery threshold exactly met, VAT inclusive vs. exclusive, a rounding boundary) produce the mathematically correct, hand-verifiable result.
- **SC-005**: 100% of prices shown anywhere in the product trace back to the single server-side calculation path — no second, divergent price-calculating code path exists.

## Assumptions

- The customer-facing preview surface built in this phase is intentionally minimal — a working, real page that exercises the pricing engine with sample product selections, not the fully designed wizard from `design/subscription-builder.html`, which is Phase 4's job. It lives at its own public route, separate from the customer-gated `/subscription` path (Clarifications, 2026-08-10), and may be retired or folded into the real subscription builder once Phase 4 ships rather than kept long-term.
- "Refresh the customer side" (the demo phrasing in `plan.md`) is interpreted literally: the preview reflects settings changes on its next calculation (e.g., a page reload or re-running the preview), not via a live/real-time push mechanism — no such requirement is stated anywhere in `plan.md` for this phase.
- Per-frequency `deliveries_per_month` and the pause/order-rule values (edit cutoff, lead time, blackout weekdays, max pause days/pauses) are configured and stored in this phase but only *displayed*/returned as part of the breakdown or settings — their actual enforcement against a real booking flow (blocking an edit, refusing a blackout date, etc.) is Phase 4's and Phase 6's responsibility, since no subscription or dashboard exists yet to enforce them against.
- Per-city delivery fee overrides are read from the `cities` table (already present since Phase 1, per `plan.md` §2's `delivery_fee_override` column) but *editing* those per-city values remains out of scope until Phase 8's cities/delivery-zones management — this phase only adds the settings that choose *which delivery mode* applies.
- The display convention for price (per-delivery as the headline figure with an estimated monthly figure alongside, rather than per-billing-cycle as the headline) follows `plan.md` §3's own stated recommendation, since no conflicting decision was supplied.
- Sample items for the preview surface are drawn from the real `products` catalog built in Phase 2 (`plan.md` Phase 2) rather than fabricated/mock data, since real product data already exists to use.
- "Sane range" validation on settings (FR-008) follows straightforward, common-sense bounds (e.g., percentages between 0 and 100, non-negative currency amounts and day/hour counts) rather than a bespoke, product-specific validation policy, since none was specified.
