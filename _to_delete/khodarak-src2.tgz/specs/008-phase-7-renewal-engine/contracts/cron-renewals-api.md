# Contract: `POST /api/cron/renewals`

The scheduled entry point (spec User Story 1/2, FR-001/FR-018). Never called by a customer's
browser — no session, no cookies, no RLS-scoped client anywhere in this route. Protected by a
shared-secret header, since it performs real financial charges.

## `POST /api/cron/renewals`

**Request**:
```
Authorization: Bearer <CRON_SECRET>
```
No body. Validated by `lib/validation/cronAuth.ts` (constant-time comparison against
`serverEnv.CRON_SECRET`, same technique as `verifyWebhookSignature.ts`).

**Behavior**:
1. `401 { "error": "unauthorized" }` if the header is missing or doesn't match — nothing below
   runs.
2. Select every subscription where `status = 'active' AND next_renewal_attempt_date <=
   current_date`.
3. For each one, **sequentially** (not in parallel — one subscriber's slow/failed charge must
   never contend with or block another's in the same run):
   1. **Claim** it: `UPDATE subscriptions SET renewal_claimed_at = now() WHERE id = $1 AND
      status = 'active' AND next_renewal_attempt_date <= current_date AND (renewal_claimed_at IS
      NULL OR renewal_claimed_at < now() - interval '10 minutes') RETURNING *`. Zero rows → skip
      (already claimed by a concurrent/overlapping run, or already resolved — research.md §1).
   2. Determine this attempt's outcome before recording anything, via three checks in order —
      **every** outcome below (including the two that never reach Moyasar) is still recorded as a
      real attempt in step 3.iii, since FR-012 explicitly names `card_expired` and
      `no_available_items` as failure reasons that must be recorded exactly like a decline:
      1. Call `reprice.ts`: resolves any due pending change (Phase 6's
         `resolveEffectiveConfig.ts`), drops unavailable products, calls `calculate()` for the
         fresh breakdown. If the resulting item list is empty (every product unavailable):
         `verifiedStatus = 'failed'`, `failureReason = 'no_available_items'`,
         `moyasarPaymentId = null` — no charge attempted (FR-005).
      2. Otherwise, check the subscription's current default active `payment_methods` row's
         expiry (`cardExpiry.ts`) against the cycle's delivery date. If already expired:
         `verifiedStatus = 'failed'`, `failureReason = 'card_expired'`, `moyasarPaymentId = null`
         — no charge attempted (FR-006).
      3. Otherwise, call `moyasarClient.createRecurringPayment()` (research.md §2) with the
         resolved token and the fresh breakdown's `totalPerDelivery` (via `toHalalas()` — never
         computed inline).
         - **Request-level failure** (network/timeout/non-2xx, no usable response at all):
           `verifiedStatus = 'failed'`, `failureReason = 'provider_error'`,
           `moyasarPaymentId = null` (spec.md Clarification 4).
         - **A response comes back**: `verifiedStatus` is the response's own status used
           directly (no 3DS redirect exists for this call to defer to — research.md §2),
           `moyasarPaymentId` is the response's own `id`.
   3. Insert a `payments` row: `subscription_id`, `user_id`, `kind: 'renewal'`,
      `moyasar_payment_id` (from 3.ii, possibly `null` — `payments.moyasar_payment_id` is
      nullable specifically for the three no-charge-attempted cases above, data-model.md),
      `amount_halalas`, `status: 'initiated'`, `attempt_number` (one more than this cycle's prior
      attempts).
   4. Call `processRenewalOutcome(paymentId, verifiedStatus, rawResponse)`
      (contracts/process-renewal-outcome.md) — keyed by this `payments` row's own `id` (not
      `moyasar_payment_id`, since three of the four outcome paths never have one), applying the
      same conditional-update idempotency guard as a defense against a fast webhook delivery
      racing this same synchronous resolution (only possible for the one path that did reach
      Moyasar).
4. Return a summary of the run (see Response below) — never exposes another customer's data, only
   aggregate counts, since this endpoint's caller is an operational trigger, not a person viewing
   a dashboard.

**Response — success**:
```json
{
  "considered": 12,
  "renewed": 9,
  "retryScheduled": 2,
  "suspended": 1
}
```

**Response — unauthorized**: `401 { "error": "unauthorized" }`.

## Notes

- This endpoint is deliberately synchronous end-to-end (no background queue) — acceptable per
  plan.md's Technical Context given this project's scale; a slow run is still a *correct* run.
- A caller invoking this endpoint twice in overlapping windows is expected and handled safely by
  the per-subscription claim step (3.1) — the endpoint itself has no top-level lock of its own,
  since correctness is already guaranteed at the row level.
