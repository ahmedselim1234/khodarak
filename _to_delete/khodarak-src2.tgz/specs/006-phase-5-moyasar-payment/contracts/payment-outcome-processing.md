# Contract: `lib/payments/processPaymentOutcome.ts`

Not a network endpoint — the one shared, idempotent function both
`GET /api/payments/callback` and `POST /api/webhooks/moyasar` call to turn a confirmed payment
outcome into database state (spec User Story 2). Documented as its own contract because two
different Route Handlers depend on it behaving identically, and because Constitution Principle V
requires its idempotency guarantee to be explicit, not incidental.

## Signature

```ts
async function processPaymentOutcome(
  moyasarPaymentId: string,
  verifiedStatus: "paid" | "failed",
  rawResponse: unknown
): Promise<void>;
```

`verifiedStatus` MUST already be the result of an authoritative check (either
`moyasarClient.fetchPayment()`'s own response, for the callback path, or a webhook event whose
signature has already been verified) — this function does not itself call Moyasar; it trusts its
caller to have already established authenticity (contracts/payment-callback-and-webhook.md).

## Behavior (exact order — see data-model.md's Activation flow for the full step list)

1. **Conditional update, always first**: `UPDATE payments SET status = $verifiedStatus, raw_response = $rawResponse WHERE moyasar_payment_id = $moyasarPaymentId AND status NOT IN ('paid', 'failed') RETURNING id, subscription_id, user_id, amount_halalas`.
   - Zero rows returned → this payment was already terminally resolved by an earlier call. Return
     immediately. This is the entire idempotency guarantee (research.md §3) — everything below
     only runs once, no matter how many times this function is invoked for the same payment.
2. If `verifiedStatus === 'failed'`: done. The subscription is untouched — it remains
   `pending_payment` (FR-016).
3. If `verifiedStatus === 'paid'`:
   - Upsert `payment_methods` for `(user_id, moyasar_token_id)` — insert if new; `is_default` only
     when the customer has no other `status = 'active'` method yet.
   - Activate the subscription: `status = 'active'`, `started_at = now()`.
   - Generate the order: `orders` row from the subscription's current address/price snapshot,
     `order_items` copied from `subscription_items` with product name/price snapshotted at this
     exact moment (FR-009).
   - Link the payment to its order: `payments.order_id = <the new order's id>`.

Every write in step 3 runs through the service-role client (`lib/supabase/serviceRole.ts`) —
never the caller's own request-scoped client, since the webhook path has no request-scoped client
at all and the callback path's activation writes must not depend on the customer's session being
the authorization boundary (research.md §1).

## Required test cases (unit-testable pieces; full end-to-end flow covered by
`tests/e2e/payment-flow.spec.ts`)

Because this function's own body performs live database writes, its **conditional-update
decision logic** and **payment_methods default-selection logic** are extracted into small, pure
helpers that get direct Vitest coverage (mirroring how `calculate.ts` and `selectableDeliveryDates`
were kept I/O-free in earlier phases wherever the core decision could be separated from the
database call):

| Case | What it proves |
|---|---|
| A payment currently `'initiated'`, outcome `'paid'` | Proceeds to activation |
| A payment already `'paid'`, called again with `'paid'` | No-ops (idempotency) |
| A payment already `'failed'`, called again with `'paid'` (a stale/out-of-order redelivery) | No-ops — a terminal state is never overwritten in either direction |
| Outcome `'failed'` on an `'initiated'` payment | Records the failure, subscription untouched |
| Customer has zero existing active payment methods | The new one becomes `is_default: true` |
| Customer already has an active default payment method | The new one is saved but not made default |
