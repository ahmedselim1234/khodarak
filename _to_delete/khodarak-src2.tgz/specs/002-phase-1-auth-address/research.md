# Phase 0 Research: Auth & Address

No `NEEDS CLARIFICATION` markers remain in the Technical Context. The stack was already fixed by
the root `plan.md` and Phase 0's implementation; this document records the decisions specific to
turning that stack into working auth and address features.

## Decision: Auth mutations call the Supabase browser client directly from Client Components

**Decision**: `signUp`, `signInWithPassword`, `signOut`, `resetPasswordForEmail`, and
`updateUser` (for setting a new password) are called directly from the four leaf form components
using `lib/supabase/client.ts`, not proxied through a Route Handler.

**Rationale**: This is the officially documented `@supabase/ssr` pattern — the browser client
manages the auth cookie exchange directly with Supabase, and `middleware.ts` refreshes that
cookie on every request. Constitution Principle V's "the browser never talks to Supabase directly
for anything price- or payment-related" is scoped to price/payment data; authentication is
explicitly out of that scope, and routing auth calls through a Route Handler would add a hop that
provides no additional safety (the Route Handler would just forward to the same Supabase Auth API
using the same anon key) while diverging from the pattern Supabase's own SSR guidance and tooling
assume.

**Alternatives considered**: Proxy all Auth calls through `/api/auth/*` Route Handlers — rejected,
adds an extra network hop and a second place to keep in sync with Supabase Auth's API surface for
no security benefit, since these calls carry no server secret.

## Decision: Role resolution and route protection happen in `middleware.ts`, backed by RLS

**Decision**: `middleware.ts` refreshes the session via a middleware-flavored Supabase server
client (`lib/supabase/middleware.ts`, per `@supabase/ssr`'s split cookie-handling requirements for
the middleware runtime), reads the caller's role from `profiles`, and redirects per the matrix in
FR-010/FR-011. This is a UX-layer gate; the actual authorization boundary is Postgres RLS on
`profiles`/`addresses` (Constitution Principle V), so even a middleware bug can't expose another
user's row.

**Rationale**: The spec's User Story 3 requires a specific redirect *experience* (send signed-out
visitors to log in and back, deny customers from `/admin` without exposing it) — that UX can only
be produced before the page renders, i.e. in middleware. RLS alone would only produce empty
query results or a database error inside an already-rendered admin page, which is not what the
spec's acceptance scenarios describe.

**Alternatives considered**: Per-page server-side checks inside each protected `page.tsx` instead
of middleware — rejected, easy to forget on a newly added sub-route (e.g. a future
`/dashboard/orders` addition) since it's not enforced structurally in one place the way middleware
is; middleware's route matcher makes the protected set explicit and auditable in one file.
Storing role as a Supabase custom JWT claim (avoiding a `profiles` query per protected request) —
rejected for this phase as premature optimization; the query is a single indexed lookup by primary
key, and the added complexity of wiring custom claims (a Postgres function + Auth hook) isn't
justified until role checks are observed to be a real latency contributor.

## Decision: `profiles` row is created by a Postgres trigger on `auth.users`, not application code

**Decision**: An `AFTER INSERT` trigger (`SECURITY DEFINER` function) on `auth.users` inserts the
matching `profiles` row, reading `full_name` and `phone` from `raw_user_meta_data` (passed via
`supabase.auth.signUp`'s `options.data`) and defaulting `role` to `'customer'`.

**Rationale**: FR-007/FR-008 require every account to end up with exactly one profile and role
without exposing a way to self-assign `admin`. A trigger makes profile creation atomic with
account creation — no window where an authenticated user has no profile row, and no client-side
"create profile after signup" step that could fail, be skipped, or be tampered with to pass a
different role.

**Alternatives considered**: Client-side `insert` into `profiles` immediately after `signUp`
succeeds — rejected, introduces a race/failure window (network drop between the two calls leaves
an account with no profile) and would require a `role` column insertable from the client, which
is exactly the self-escalation risk FR-008 rules out. A Route Handler that both signs up and
inserts the profile server-side — rejected as unnecessary given the trigger achieves the same
atomicity guarantee without adding a server-side auth code path that must be kept in sync with
Supabase's own signup flow (including future Supabase Auth features like OAuth, which would
bypass a custom Route Handler entirely but still fire the trigger).

## Decision: "Exactly one default address per customer" is enforced by a partial unique index, not just application logic

**Decision**: `CREATE UNIQUE INDEX ON addresses (user_id) WHERE is_default;` in the migration.
Setting a new default is a single transaction in the `/api/addresses/[id]` Route Handler: unset
the customer's current default (if any), then set the new one.

**Rationale**: FR-014/FR-015 and SC-005 require this invariant to hold *always*, including under
concurrent requests (e.g. a double-click submitting the same "set default" action twice, or two
browser tabs). Application-level "unset then set" logic alone is vulnerable to a race between two
concurrent requests both passing the unset step before either sets; a database constraint is the
only place this can be guaranteed regardless of request ordering.

**Alternatives considered**: Application-only enforcement (check-then-set in a Route Handler) —
rejected as the sole mechanism per the concurrency argument above, though the transactional
unset-then-set is still implemented as the normal-path behavior; the index is the backstop that
turns a rare race into a clean database error instead of silent data corruption (two defaults, or
zero).

## Decision: Login throttling relies on Supabase Auth's built-in rate limiting; no custom implementation this phase

**Decision**: FR-003a is satisfied by Supabase Auth's default rate limiting on the
`signInWithPassword` endpoint (per-IP and per-account throttling that ships enabled by default on
Supabase projects), verified during quickstart validation rather than re-implemented in
application code.

**Rationale**: The spec's Clarifications session recommended "standard throttling" specifically
because it matches "Supabase Auth's built-in default behavior" — building a custom rate limiter
(e.g. a Postgres-backed attempt counter) would duplicate protection Supabase already provides at
the platform level, adding a second system that can drift out of sync (e.g. different lockout
windows) for no additional protection.

**Alternatives considered**: Custom attempt-counting table + Route Handler-level throttling —
rejected as redundant for this phase; revisit only if Supabase's default limits prove insufficient
once real traffic patterns are observed (not knowable at MVP scope).

## Decision: `cities` table is created with its full target schema now, seeded with placeholder rows

**Decision**: Create `cities` with the complete column set from `plan.md` §2
(`id, name_ar, is_active, delivery_fee_override`), even though `delivery_fee_override` has no
consumer until Phase 3's delivery-fee rules. Seed at least one active city via the migration so
address creation is testable immediately (per the spec's Assumptions).

**Rationale**: Creating a narrower `cities` table now and widening it in Phase 3 would require a
follow-up migration for a column that's already fully specified and low-risk to add today —
splitting it serves no isolation purpose since the column sits unused rather than referenced by
code that would need to change later.

**Alternatives considered**: Create only `id`, `name_ar`, `is_active` now and add
`delivery_fee_override` in Phase 3 — rejected as unnecessary migration churn for a column whose
shape is already fixed by the approved data model.
