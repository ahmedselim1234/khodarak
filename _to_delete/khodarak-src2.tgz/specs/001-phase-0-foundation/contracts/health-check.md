# Contract: `GET /api/health`

The only interface this phase exposes beyond the page shell itself: a Route Handler used by the
Playwright smoke test and by developers (User Story 2's Independent Test) to confirm the app can
reach the configured Supabase project without needing to open any page.

## Request

```
GET /api/health
```

No parameters, no auth (this endpoint reveals no user/business data — only connectivity status).

## Response — success

```
200 OK
Content-Type: application/json

{
  "status": "ok",
  "supabase": "reachable"
}
```

## Response — backend unreachable

```
503 Service Unavailable
Content-Type: application/json

{
  "status": "error",
  "supabase": "unreachable",
  "detail": "<short, non-sensitive error summary>"
}
```

`detail` MUST NOT leak credentials or full stack traces — this endpoint may be hit by uptime
monitors later and should not become an information-disclosure surface (Constitution Principle V
spirit, applied defensively even though no financial data is involved yet).

## Notes

- This endpoint performs a lightweight read (e.g. a trivial `select` against a Supabase system
  view, or an Auth admin ping) — it does not require any application table to exist, since this
  phase creates none.
- Startup-time env validation (FR-006) is a separate, earlier check — the process refuses to start
  at all on missing/invalid config. This endpoint checks a *different* failure mode: valid config,
  but the backend project is unreachable at request time (the spec's edge case: "the environment
  configuration points at a backend project that is unreachable").
