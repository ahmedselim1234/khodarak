# Phase 0 Research: Foundation

No `NEEDS CLARIFICATION` markers remain in the Technical Context — the source `plan.md` (§0.A) had
already made the stack decisions for this project. This document records the rationale for how
those decisions get applied specifically in this scaffolding phase.

## Decision: Design tokens ported verbatim into `tailwind.config.ts`

**Decision**: Copy the `colors`, `borderRadius`, `spacing`, `fontFamily`, and `fontSize` objects
out of the inline `tailwind.config` block in `design/home.html` (lines 36–124) into
`tailwind.config.ts` `theme.extend`, unchanged.

**Rationale**: `plan.md` §0.B is explicit: "This is the literal source for `tailwind.config.ts`
`theme.extend` in Phase 0 — port it verbatim rather than re-deriving a palette." Re-deriving
risks subtle color drift (e.g. `primary: #00450d` vs. a "close enough" green) that would make
every later phase's pages visibly mismatch the mockups the plan is pinned to.

**Alternatives considered**: Re-deriving a palette from a design tool/spec — rejected, no such
source exists; the HTML mockups *are* the source of truth. Using Tailwind's default theme and
overriding ad hoc per component — rejected, defeats FR-002/FR-003 and would scatter the same
"organic" radius and color values across dozens of className strings instead of one config.

## Decision: `dir="rtl"` and `lang="ar"` set once, in the root layout

**Decision**: Set `<html lang="ar" dir="rtl">` in `app/layout.tsx`; no per-page RTL handling.

**Rationale**: FR-003 requires every rendered page to be RTL; setting it once at the root
guarantees no route can regress to LTR by omission. Matches how every mockup is built
(`dir="rtl"`, `flex-row-reverse` throughout, per plan.md §0.B).

**Alternatives considered**: Per-route `dir` attributes — rejected, adds a failure mode (a new
route added later without RTL is a silent bug) for zero benefit since the whole product is
Arabic-first with no LTR requirement in scope.

## Decision: Supabase client split into `lib/supabase/client.ts` (browser) and `lib/supabase/server.ts` (server)

**Decision**: Two separate thin wrappers around `@supabase/ssr`'s `createBrowserClient` and
`createServerClient`; only `server.ts` may read the service-role key.

**Rationale**: Constitution Principle V: "the browser never talks to Supabase directly for
anything price- or payment-related — only Route Handlers do." Splitting the helpers now, before
any real feature imports either one, makes it structurally awkward (an obvious wrong import) for
a later phase to leak the service-role key into client code — cheaper to prevent than to catch in
review later.

**Alternatives considered**: A single universal client factory — rejected, both Supabase's own
SSR guidance and the constitution call for the browser/server split; unifying them would silently
reintroduce the exact risk Principle V exists to prevent.

## Decision: Env validation via a zod schema read once at module load (`lib/env.ts`)

**Decision**: Define a zod object schema for all required env vars (Supabase URL, Supabase anon
key, Supabase service role key), parse `process.env` once at import time, and throw a descriptive
error (naming the missing/invalid key) if parsing fails.

**Rationale**: FR-006 requires startup to fail immediately with a message identifying the specific
missing/invalid value. Constitution Principle IV requires runtime validation at every external
boundary, and environment variables are explicitly named as one. A module-level parse (rather than
validating lazily inside each Route Handler) guarantees the failure surfaces at boot, satisfying
SC-004's "under 5 seconds" and "zero silent crash" requirements — a missing var can't slip through
to a request handled minutes later.

**Alternatives considered**: Manual `if (!process.env.X) throw` checks scattered per usage site —
rejected, easy to miss a var, and error messages are inconsistent; a typed schema in one place is
both the validation and the documentation of what's required.

## Decision: Playwright smoke test asserting every committed route returns 200 with `dir="rtl"`

**Decision**: A single Playwright spec (`tests/e2e/routes.smoke.spec.ts`) that iterates the 9
committed routes (using a placeholder id for `/browse/[id]`) and asserts a successful response
plus the root `dir` attribute.

**Rationale**: This is the direct, automatable form of the spec's Independent Test for User Story
1 and SC-001 ("100% of committed routes load successfully... zero broken or error-page results").
Automating it now means every later phase's route-shell changes get a regression check for free
instead of relying on manual demo-day clicking.

**Alternatives considered**: Manual QA checklist only — rejected; the whole point of Phase 0 is to
be the foundation every later phase builds on, so a cheap automated guardrail here pays for itself
immediately in Phase 1 onward. Full Lighthouse/perf assertions at this stage — rejected as
premature; Constitution Principle III scopes the formal performance gate to before each
customer-facing phase demo and fully to Phase 9, not to this scaffolding phase.

## Decision: `/login` and `/admin` render with shared design tokens and a generic layout (no bespoke design)

**Decision**: Both routes use the same `components/ui/` primitives (card, button, container) as
the mocked-up routes, styled with the ported tokens, but with a plain/generic layout rather than a
purpose-built design.

**Rationale**: Directly resolves the spec's Clarifications session answer (2026-08-10) — `/login`
has no mockup, same gap as `/admin`, and both get identical treatment: reachable, on-brand, not
bespoke, revisited when/if a mockup arrives.

**Alternatives considered**: Building a bespoke "finished-looking" login form now — rejected per
the clarification answer, since it risks being thrown away once a real mockup exists and adds
scope the spec explicitly didn't ask for.
