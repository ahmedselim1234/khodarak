# Contract: `/api/admin/products`

Route Handlers backing admin product CRUD (spec User Story 1). Every request MUST be an
authenticated `admin`-role session (enforced by `middleware.ts`'s existing `/admin` gate at the
route level, and re-checked server-side in each handler — the app-layer gate is a UX convenience,
RLS on `products` is the real authorization boundary underneath it, per Constitution Principle V).
Every request body is validated with the zod schema in `lib/validation/product.ts` before touching
the database.

Photo upload is **not** part of this contract — the browser uploads directly to the `product-images`
Storage bucket (see [research.md](../research.md) §3) and passes the resulting `imageUrl` into
these endpoints like any other field. The handler still re-validates that `imageUrl` points into
that bucket before persisting it (never trust a client-supplied URL blindly, even post-upload).

## `POST /api/admin/products`

Creates a new product.

**Request**:
```json
{
  "nameAr": "طماطم عضوية طازجة",
  "category": "vegetables",
  "price": 12.50,
  "unit": "kg",
  "imageUrl": "https://.../product-images/....jpg",
  "minQty": 1,
  "maxQty": 10
}
```

Validation (FR-001, FR-005): `nameAr` non-empty; `category` in `('vegetables', 'fruits')`; `price`
a positive number; `unit` in `('kg', 'piece')`; `imageUrl` non-empty and resolves into the
`product-images` bucket — the system MUST NOT allow saving a new product without one; `minQty >= 1`,
`maxQty >= minQty`.

**Response — success**:
```
201 Created
Content-Type: application/json

{
  "product": {
    "id": "uuid",
    "nameAr": "طماطم عضوية طازجة",
    "category": "vegetables",
    "price": 12.50,
    "unit": "kg",
    "imageUrl": "https://.../product-images/....jpg",
    "isAvailable": true,
    "minQty": 1,
    "maxQty": 10,
    "createdAt": "2026-08-10T12:00:00Z"
  }
}
```

**Response — validation error**:
```
400 Bad Request

{ "error": "validation_failed", "fields": { "imageUrl": "required" } }
```

**Response — unauthorized (not admin)**: `403 Forbidden`. **Unauthenticated**: `401 Unauthorized`.

---

## `PATCH /api/admin/products/[id]`

Edits any field of an existing product, including toggling `isAvailable` (FR-004) or replacing
`imageUrl` (FR-002).

**Request** (all fields optional; at least one MUST be present):
```json
{ "price": 13.00, "isAvailable": false }
```

**Response — success**: `200 OK`, same shape as `POST`'s success response, reflecting the updated
row. Per FR-002, the change is visible to customers on the next `/browse` page load — there is no
separate publish step.

**Response — not found**: `404 Not Found`. **Response — validation error**: `400 Bad Request`, same
shape as `POST`.

---

## `DELETE /api/admin/products/[id]`

Removes a product (FR-003). Hard delete — see [data-model.md](../data-model.md)'s Lifecycle note
for why no soft-delete/archival is needed this phase.

**Request**: no body.

**Response — success**: `204 No Content`. The product immediately stops appearing in `/browse`
(next Server Component render, no caching layer to invalidate — see spec Assumptions). Any
`cart_items` rows referencing it are removed via FK cascade (data-model.md), which is how the
Edge Case "admin deletes a product that's in someone's cart" resolves.

**Response — not found**: `404 Not Found`.

## Notes

- No endpoint here is reachable by a `customer`-role session; `products` reads for the storefront
  go through `/browse`'s Server Component query (see `contracts/catalog-browse.md`), not this API.
- RLS on `products` (`insert`/`update`/`delete` gated on `profiles.role = 'admin'`) is the actual
  authorization boundary beneath every handler here, matching the `addresses-api.md` precedent from
  Phase 1 — the handler's own role check fails safe into a `403`, RLS is what prevents a bypass.
