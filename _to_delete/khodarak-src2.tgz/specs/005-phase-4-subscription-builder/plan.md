# Implementation Plan: Phase 4 — Subscription Builder (no payment yet)

**Branch**: `005-phase-4-subscription-builder` | **Date**: 2026-08-10 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/005-phase-4-subscription-builder/spec.md`

## Summary

Turn `/subscription` from Phase 0's placeholder into a real, two-step wizard (build → checkout)
that reuses as much of Phases 1–3 as possible rather than duplicating it: the box *is* the
customer's existing server-synced cart (Phase 2's `cart_items`, `QuantityStepper`, `ProductCard`),
the live price breakdown *is* Phase 3's pricing engine and `PriceBreakdownCard` called on every
change, and the delivery address step *is* Phase 1's address book. The only genuinely new pieces
are: a frequency selector, a delivery-date picker that respects admin lead-time/blackout rules, a
fixed delivery-time-slot picker, and the confirm action itself — which creates a `subscriptions` +
`subscription_items` pair in a `pending_payment` state (server-recomputing the price one final
time, never trusting a client-supplied value), clears the cart, and lands the customer on a
dedicated confirmation page. No payment integration happens in this phase.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0–3)

**Primary Dependencies**: `@supabase/ssr` + `@supabase/supabase-js`, zod, Redux Toolkit + RTK
Query. No new runtime dependency — this phase is primarily *composition* of existing pieces:
`lib/store/cartApi.ts` and `components/cart/QuantityStepper.tsx` (Phase 2) for box editing,
`lib/store/pricingApi.ts` and `components/pricing/PriceBreakdownCard.tsx` (Phase 3) for the live
breakdown, `lib/store/addressesApi.ts` (Phase 1) for address selection. One new RTK Query slice,
`subscriptionsApi`, for the create mutation.

**Storage**: Supabase (Postgres) — two new tables, `subscriptions` and `subscription_items`, per
`plan.md` §2's original sketch plus the `pending_payment` status and `delivery_time_slot` field
the spec's Clarifications/Assumptions establish as necessary this phase. No changes to existing
tables; `cart_items` rows for the customer are deleted (not just emptied via API) once a
subscription is successfully created from them.

**Testing**: Vitest for `lib/subscription/selectableDeliveryDates.ts` — a pure function computing
which dates satisfy the admin's lead-time and blackout-weekday rules, written and passing before
the date-picker UI consumes it (Constitution Principle VI: date correctness here directly gates
whether a customer can complete the phase's core demo). Playwright for the full demo path: build a
box, watch the price change live as items/frequency change, complete checkout, land on the
confirmation page — plus the signed-out redirect and the min-order-value block.

**Target Platform**: Same as Phase 0–3 — `npm run dev` locally, Linux container deferred to Phase
9; primary client is mobile Chrome/Safari.

**Project Type**: Web application — same single Next.js monolith, no new deployable.

**Performance Goals**: No new Core Web Vitals risk beyond what `/browse` already established —
the box-customization grid reuses `ProductCard`'s existing `next/image` handling; price
recalculation reuses Phase 3's debounced-call pattern rather than firing on every keystroke.

**Constraints**: `POST /api/subscriptions` MUST recompute the full price via `calculate.ts` at the
moment of confirmation and MUST NOT accept a price or breakdown from the request body (Constitution
Principle II) — the confirm button's disabled/enabled state driven by the live preview's
`meetsMinimumOrderValue`/`withinMaxItemsPerBox` flags is a UX convenience, not the authority; the
server re-checks both before creating anything. Creating a subscription is two dependent inserts
(`subscriptions` then `subscription_items`) followed by a delete (`cart_items`) — this project has
no precedent for Postgres RPC transactions (Phase 1's default-address transition used two
sequential `UPDATE`s backstopped by a unique index, not a stored procedure), so this phase follows
that same sequential-calls-with-a-compensating-action pattern rather than introducing new
transaction infrastructure (see research.md §3).

**Scale/Scope**: 2 new tables (`subscriptions`, `subscription_items`), 1 new Route Handler (`POST
/api/subscriptions`), 2 route changes (`/subscription` goes from placeholder to real wizard, new
`/subscription/confirmed/[id]`), 1 new RTK Query slice, ~8 new components (mostly thin — the grid,
stepper, and breakdown card are reused as-is from Phase 2/3), 1 new pure lib module with its own
test suite.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — `/subscription` and `/subscription/confirmed/[id]` are Server Components fetching their initial data (cart, addresses, active cities, enabled frequencies, available products) via the server Supabase client; `"use client"` is scoped to `SubscriptionWizard` and its interactive children, reusing existing client leaves (`QuantityStepper`, `PriceBreakdownCard`) rather than introducing parallel ones | PASS |
| II. Server-Side Authority for Business Logic | Yes — `POST /api/subscriptions` recomputes the price via `calculate.ts` at confirmation and never persists a client-supplied value; this is the same discipline Phase 3's preview endpoint already established, now applied to an actual write | PASS — see Constraints above |
| III. Performance Budget & Core Web Vitals | Yes but low-risk — reuses Phase 2/3's already-budget-conscious components; no new heavy client libraries | PASS |
| IV. Type Safety & Validation at Boundaries | Yes — `POST /api/subscriptions`'s body (items, frequency, addressId, deliveryDate, timeSlot) is zod-validated before any database write | PASS |
| V. Data Integrity, Idempotency & Security | Yes — RLS on `subscriptions`/`subscription_items` is owner-only (mirrors `cart_items`); a duplicate confirm submission MUST NOT create two subscriptions (FR-013) — enforced client-side (disable-on-submit, matching every other form in this codebase) and server-side by requiring the cart to be non-empty (a second, immediate resubmission finds an already-emptied cart and fails safe rather than double-creating) | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — `selectableDeliveryDates.ts` is exactly the kind of small, easy-to-get-subtly-wrong function (off-by-one on the lead-time boundary, wrong weekday indexing) that Principle VI calls out; its Vitest suite is written and passing before the date-picker UI exists | PASS |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts (research.md, data-model.md, contracts/,
quickstart.md) keep the box as the literal `cart_items` rows (no parallel "draft box" state to
drift out of sync), keep `calculate.ts` as the only place a price is computed, and keep the
subscription-creation sequence's compensating-delete behavior explicit in the contract rather than
assumed. Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/005-phase-4-subscription-builder/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md         # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── subscription/
│   ├── page.tsx                     # /subscription — replaces the Phase 0 placeholder. Server
│   │                                 # Component: fetches the customer's cart (joined with
│   │                                 # products), addresses, active cities, available products
│   │                                 # (both categories), and settings.frequencies; renders
│   │                                 # SubscriptionWizard with all of it as initial props
│   └── confirmed/
│       └── [id]/
│           └── page.tsx             # /subscription/confirmed/[id] — Server Component, owner-
│                                     # scoped fetch of the just-created subscription + its items;
│                                     # the "simple confirmation page" from Clarifications
│                                     # (2026-08-10) — NOT the design mockup's post-payment screen
└── api/
    └── subscriptions/
        └── route.ts                 # POST — the only new Route Handler this phase
                                      # (contracts/subscriptions-api.md)

components/
└── subscription/
    ├── SubscriptionWizard.tsx       # "use client" orchestrator — holds step state
    │                                 # ('build' | 'checkout'), frequency/date/address/time-slot
    │                                 # selections; calls pricingApi.previewPrice (Phase 3) on
    │                                 # every relevant change; renders the two steps
    ├── WizardProgressHeader.tsx     # Presentational — the 2-step progress indicator
    ├── BoxCategoryTabs.tsx          # "use client" leaf — local (non-URL) category state over
    │                                 # the already-fetched product list, unlike /browse's
    │                                 # searchParams-driven CategoryTabs (this page isn't
    │                                 # URL-driven — it's a single continuous wizard)
    ├── FrequencySelector.tsx        # "use client" leaf — offers only settings.frequencies
    │                                 # entries with enabled: true
    ├── DeliveryDatePicker.tsx       # "use client" leaf — uses
    │                                 # lib/subscription/selectableDeliveryDates.ts to disable
    │                                 # invalid dates
    ├── TimeSlotPicker.tsx           # "use client" leaf — fixed 3-option set (research.md §2)
    ├── AddressSelector.tsx          # "use client" leaf — reads lib/store/addressesApi.ts's
    │                                 # existing listAddresses query; prompts to add an address
    │                                 # (links to /dashboard/settings) when none exist (FR-007)
    └── OrderSummarySidebar.tsx      # Wraps PriceBreakdownCard (Phase 3, reused as-is) plus the
                                      # confirm button, disabled per the breakdown's compliance
                                      # flags (FR-009) and while a submission is in flight (FR-013)

lib/
├── subscription/
│   ├── selectableDeliveryDates.ts   # Pure function: (today, leadDays, blackoutWeekdays) →
│   │                                 # which of the next N dates are selectable
│   └── timeSlots.ts                 # The fixed time-slot definitions (id, label, window) shared
│                                     # by TimeSlotPicker and the Route Handler's validation
├── validation/
│   └── subscription.ts              # zod schema for the POST /api/subscriptions body
└── store/
    └── subscriptionsApi.ts          # RTK Query slice (createSubscription) against
                                      # /api/subscriptions — mirrors addressesApi.ts's mutation shape

supabase/
└── migrations/
    └── <timestamp>_subscriptions.sql  # subscriptions + subscription_items tables, owner-only RLS
                                        # on both (data-model.md)

tests/
├── unit/
│   └── subscription.selectableDeliveryDates.test.ts  # lead-time boundary, blackout-weekday
│                                                        # exclusion, combined case
└── e2e/
    └── subscription-builder.spec.ts # build a box → watch price change live → checkout → confirm
                                      # → land on confirmation page; signed-out redirect;
                                      # min-order-value block — quickstart.md's full walkthrough
```

**Structure Decision**: Stays inside the Phase 0–3 monolith. `/subscription` remains a single
route hosting both wizard steps (matching `plan.md` §0.B's routing table, which maps *both*
`design/subscription-builder.html` and `design/complete-order.html` to the same `/subscription`
path) rather than splitting build/checkout into separate URLs — this is also what makes the
Clarifications' "can go back and re-edit" requirement trivial: it's just client-side step state,
not a navigation with data to re-fetch. The confirmation page is a genuinely new route
(`/subscription/confirmed/[id]`) because it's reached only after a successful, one-time creation
and needs its own shareable/bookmarkable identity distinct from the wizard itself. No new API
surface was introduced for reading products, cart, addresses, or cities — the wizard's Server
Component parent fetches all of it upfront (a single page load), consistent with Principle I,
instead of adding client-fetch endpoints purely to support category-tab switching that a few
kilobytes of already-loaded data can handle client-side instead.

## Complexity Tracking

*No Constitution Check violations — table not needed.*
