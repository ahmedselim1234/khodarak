# Feature Specification: Phase 4 — Subscription Builder (no payment yet)

**Feature Branch**: `005-phase-4-subscription-builder`

**Created**: 2026-08-10

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for Phase 4" — scoped from `plan.md` §4 "Phase 4 — Subscription Builder (no payment yet)": `/subscription` build step per `design/subscription-builder.html` (wizard progress header, sticky order-summary sidebar, box-customization product grid) — carried-over cart, frequency selector (only enabled options), first delivery date picker respecting lead time and blackout days, live price breakdown, rule validation; checkout step per `design/complete-order.html` — address selection, delivery time-slot picker, totals, confirm → create subscription in `pending_payment` state. Demo target: "build a box end to end and watch the total change live as items and frequency change."

## Clarifications

### Session 2026-08-10

- Q: Phase 4 explicitly stops before payment (Phase 5) and the dashboard that would normally show subscription status doesn't exist until Phase 6 — what happens immediately after "confirm"? → A: A simple, real confirmation page telling the customer their box is saved and payment/activation is coming soon — not the design mockup's post-payment success screen, which is reserved for Phase 5.
- Q: `design/complete-order.html` includes a "promo code" field, but `plan.md` never defines any promo-code system anywhere in the project. Should this phase build it? → A: Omit entirely — no promo code field is built this phase.
- Q: Once a customer reaches checkout, can they still go back and change the box contents or frequency, or is checkout a forward-only final review? → A: Can go back and re-edit — the customer can return to the build step, change items/quantities/frequency, and come back to checkout with the price breakdown recalculated fresh.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Customize the box and see the price react live (Priority: P1)

A signed-in customer arrives at the subscription builder with their current cart carried over, keeps adjusting which products and quantities are in the box (adding more from a product grid, removing items, changing quantities), and sees the full price breakdown update immediately after every change.

**Why this priority**: This is the core interaction the whole phase exists to deliver — the demo target itself ("watch the total change live as items and frequency change"). Nothing else in the builder is reachable without a box to build.

**Independent Test**: Can be fully tested by arriving at the builder with items already in the cart, adding another product from the grid, removing one, and changing a quantity, and confirming the displayed price breakdown updates correctly after each change — delivers a working, self-contained box-building experience independent of checkout.

**Acceptance Scenarios**:

1. **Given** a signed-in customer with items already in their cart, **When** they open the subscription builder, **Then** those items and quantities appear pre-loaded as the starting box.
2. **Given** the builder open, **When** the customer adds a product from the box-customization grid, **Then** it's added to the box and the price breakdown recalculates immediately.
3. **Given** a product already in the box, **When** the customer removes it or changes its quantity, **Then** the box and the price breakdown update immediately, respecting that product's admin-configured minimum/maximum quantity.
4. **Given** the builder open, **When** the customer views the order summary, **Then** it shows the current item count, a running subtotal, and the same full breakdown (discount, delivery fee, VAT, total per delivery, estimated monthly) the pricing engine produces.

---

### User Story 2 - Choose a frequency and first delivery date (Priority: P1)

The customer selects how often the box repeats (from only the frequencies an admin has enabled) and picks a first delivery date that respects the admin's configured lead time and blackout weekdays, with the price breakdown reflecting the chosen frequency's discount.

**Why this priority**: Frequency and delivery date are required inputs to both the price calculation and the subscription itself — nothing can be confirmed without them, and they're equally foundational to User Story 1's live-updating breakdown.

**Independent Test**: Can be fully tested by selecting each enabled frequency in turn and confirming the price breakdown's discount and estimated monthly figures change accordingly, then picking a first delivery date and confirming dates inside the lead-time window or on a blackout weekday are not selectable — delivers a fully working frequency/date step independent of checkout.

**Acceptance Scenarios**:

1. **Given** the builder open, **When** the customer views the frequency selector, **Then** only frequencies an admin has enabled are offered.
2. **Given** a frequency is selected, **When** the customer changes it, **Then** the price breakdown recalculates using that frequency's discount and delivery cadence.
3. **Given** the first delivery date picker, **When** the customer views selectable dates, **Then** dates earlier than the admin's configured lead time and dates falling on an admin-configured blackout weekday are not selectable.
4. **Given** every frequency is currently disabled by the admin, **When** the customer reaches this step, **Then** they see a clear "no delivery frequency currently available" message instead of a broken or empty selector.

---

### User Story 3 - Complete checkout and create the subscription (Priority: P1)

The customer moves to checkout, selects one of their saved delivery addresses (or is prompted to add one if they have none), picks a delivery time slot for the first delivery, reviews the final totals, and confirms — creating a subscription record awaiting payment, then landing on a simple confirmation page.

**Why this priority**: This is how the phase's value is actually captured — without it, the builder is just a calculator. It depends on User Stories 1 and 2 already producing a valid box and schedule.

**Independent Test**: Can be fully tested by completing the builder steps, selecting a saved address and a time slot, confirming, and verifying a subscription record now exists in a pending-payment state with the correct items, frequency, address, and price snapshot — delivers the full non-payment checkout flow end to end.

**Acceptance Scenarios**:

1. **Given** a customer with at least one saved address, **When** they reach checkout, **Then** they can select one of their saved addresses as the delivery address.
2. **Given** a customer with no saved addresses, **When** they reach checkout, **Then** they are clearly prompted to add one before they can continue, rather than being blocked with no explanation.
3. **Given** an address is selected, **When** the customer picks a delivery time slot for the first delivery, **Then** their choice is recorded and reflected in the order summary.
4. **Given** a complete, valid selection (box, frequency, date, address, time slot), **When** the customer confirms, **Then** a subscription is created in a pending-payment state with the exact items, quantities, frequency, address, delivery date/time, and a snapshot of the price breakdown at that moment, and the customer's cart is cleared.
5. **Given** a subscription was just created, **When** the confirmation completes, **Then** the customer lands on a simple confirmation page stating the box is saved and that payment/activation is coming soon — not a post-payment success screen.
6. **Given** the customer is signed out, **When** they attempt to reach the builder or checkout, **Then** they are redirected to sign in first (existing route protection).
7. **Given** the customer is at checkout, **When** they navigate back to the build step and change items, quantities, or frequency, **Then** they can return to checkout with the price breakdown, address selection, and time-slot choice all still intact or freshly recalculated as appropriate — no forced restart.

---

### User Story 4 - Rule violations block confirmation with a clear reason (Priority: P2)

If the box doesn't currently satisfy the admin's order rules — below the minimum order value, or over the maximum items per box — the customer sees exactly what's wrong and cannot confirm until it's resolved.

**Why this priority**: This protects data integrity and admin intent, but the builder and checkout are still usable and demoable without a customer ever hitting a violation, so it ranks below the core flow.

**Independent Test**: Can be fully tested by building a box below the minimum order value (or over the max items per box) and confirming the confirm action is blocked with a specific, correct message, then adjusting the box until it's valid and confirming the action becomes available — delivers rule enforcement independent of a successful checkout.

**Acceptance Scenarios**:

1. **Given** a box whose subtotal is below the admin-configured minimum order value, **When** the customer views the summary, **Then** a clear message states the box doesn't yet meet the minimum, and the confirm action is disabled.
2. **Given** a box whose total item count exceeds the admin-configured maximum items per box, **When** the customer views the summary, **Then** a clear message states the box exceeds the limit, and the confirm action is disabled.
3. **Given** a box that violated a rule, **When** the customer adjusts it so both rules are satisfied, **Then** the message clears and the confirm action becomes available again.

---

### Edge Cases

- What happens when a product in the customer's carried-over cart has since become unavailable or been deleted? It's excluded from the box (consistent with the cart's own existing behavior from Phase 2) and the customer sees it was dropped, rather than the builder failing to load.
- What happens when the customer's cart is completely empty when they arrive at the builder? The builder still loads, showing an empty box and the product grid, rather than redirecting away or erroring — the customer builds the box from scratch.
- What happens when a customer navigates directly to the checkout step without a valid box, frequency, or date chosen yet? They're routed back to the step that still needs attention rather than allowed to confirm an incomplete selection.
- What happens if settings (frequencies, order rules, delivery, VAT, rounding) change while a customer has the builder open? The next price recalculation (any change the customer makes) picks up the new settings, consistent with the pricing engine always being a fresh server-side computation — no stale, cached price is ever confirmed.
- What happens when a customer already has an existing subscription and starts building another one? Out of scope for this phase to prevent or merge — the phase covers creating *a* subscription; managing multiple/duplicate subscriptions is a dashboard-era (Phase 6) concern.
- What happens if the confirm action is submitted twice in quick succession (double-click)? Only one subscription is created — the second attempt is a no-op or is prevented at the interaction level, not a second pending-payment subscription.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST pre-load the subscription builder with the signed-in customer's current cart items and quantities as the starting box.
- **FR-002**: System MUST allow the customer to add products to the box from a product grid, remove products, and change quantities, with every change reflected immediately in both the box contents and the price breakdown.
- **FR-003**: System MUST enforce each product's admin-configured minimum and maximum orderable quantity when the customer adjusts quantities in the builder, consistent with the cart's existing enforcement.
- **FR-004**: System MUST offer only admin-enabled frequencies as selectable options, and MUST show a clear "no delivery frequency currently available" state if every frequency is disabled.
- **FR-005**: System MUST recalculate the full price breakdown (subtotal, frequency discount, delivery fee, VAT, total per delivery, estimated monthly) via the existing server-side pricing engine every time the box, frequency, or delivery city changes — the customer never sees a client-computed or stale price.
- **FR-006**: System MUST restrict the first delivery date picker to dates that satisfy the admin-configured minimum lead time and MUST exclude admin-configured blackout weekdays.
- **FR-007**: System MUST let the customer select one of their saved delivery addresses at checkout, and MUST clearly prompt them to add an address first if they have none, rather than allowing checkout to proceed without one.
- **FR-008**: System MUST let the customer choose a delivery time slot for the first delivery at checkout, and MUST reflect that choice in the order summary shown before confirming.
- **FR-009**: System MUST block the confirm action, with a specific and correct explanation, whenever the current box does not meet the admin-configured minimum order value or exceeds the maximum items per box.
- **FR-010**: System MUST create a subscription record in a pending-payment state upon confirmation, capturing the exact items and quantities, frequency, delivery address, first delivery date and time slot, and a snapshot of the price breakdown at the moment of confirmation.
- **FR-011**: System MUST NOT charge any payment or contact any payment provider as part of this phase's confirmation — that begins in a later phase.
- **FR-012**: System MUST clear the customer's cart once a subscription has been successfully created from it.
- **FR-013**: System MUST prevent a duplicate submission (e.g., a double-click on confirm) from creating more than one subscription for the same confirmation attempt.
- **FR-014**: System MUST show the customer a simple confirmation page after successful creation, stating the box is saved and that payment/activation is coming soon, distinct from any post-payment success screen.
- **FR-015**: System MUST restrict the builder and checkout to signed-in customers, consistent with the existing route protection for `/subscription`.
- **FR-016**: System MUST exclude a product from the box and indicate it was dropped if that product has become unavailable or been deleted since it was added to the cart.
- **FR-017**: System MUST route a customer who reaches the checkout step without a complete box, frequency, and delivery date back to the step that still needs attention, rather than allowing confirmation of an incomplete selection.
- **FR-017a**: System MUST allow a customer at the checkout step to navigate back to the build step, change items, quantities, or frequency, and return to checkout — without losing their already-selected address or time slot unless that choice is no longer valid (e.g., the selected address was deleted), and with the price breakdown always reflecting the current box when checkout is shown again.
- **FR-018**: System MUST NOT display a promo/discount code field this phase.

### Key Entities

- **Subscription**: A customer's recurring box order, created in a pending-payment state by this phase — owner (customer), delivery address, frequency, first/next delivery date, chosen delivery time slot, current status, and a snapshotted price breakdown captured at confirmation time. Later phases transition its status (payment activation, pausing, cancellation) and generate delivery orders from it.
- **Subscription Item**: One line within a subscription — the product, and the quantity of it, captured at confirmation time as part of that subscription's box.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A customer can go from an already-populated cart to a confirmed, pending-payment subscription in under five minutes on a first attempt.
- **SC-002**: Every change to items, quantities, frequency, or delivery city updates the displayed price breakdown with no perceptible delay and no manual refresh required.
- **SC-003**: 100% of confirmed subscriptions have a price snapshot that exactly matches what the pricing engine would compute for those exact inputs at that moment — no drift between what was shown and what was saved.
- **SC-004**: 100% of attempts to confirm a box that violates the minimum order value or maximum items per box are blocked, with a message a customer can act on without contacting support.
- **SC-005**: 100% of first-delivery-date selections respect the admin's configured lead time and blackout weekdays — no invalid date is ever accepted.
- **SC-006**: A customer with zero saved addresses is never able to reach a confirmed subscription without being clearly routed to add one first.
- **SC-007**: A customer can move from checkout back to the build step and return to checkout without losing progress (beyond a choice that's become invalid), in a single continuous session.

## Assumptions

- The product grid, frequency selector, delivery-date picker, and order summary all draw on infrastructure already built in earlier phases (the cart and product catalog from Phase 2, the pricing engine and its settings from Phase 3, the address book from Phase 1) — this phase's job is to assemble and gate them into the two-step wizard `plan.md` describes, not to rebuild any of them.
- The design mockup's three category tabs (خضروات/فواكه/ورقيات) are reduced to the two real product categories already established in Phase 2 (خضروات/فواكه) — there is no "ورقيات" (leafy greens) category in the actual product schema, and introducing a third category is out of scope for this phase.
- Delivery time slots are a small, fixed set of options (e.g., morning/afternoon/evening windows for the already-chosen first delivery date) rather than an admin-configurable list — `plan.md`'s settings model never defines time slots, so this is treated as a presentation-layer detail, not a new admin-configurable rule.
- The checkout mockup's address fields (name, phone, city/district, free-text details) are replaced with a selector over the customer's *existing* saved addresses from Phase 1's address book, per `plan.md`'s own Subscription Builder wording ("select delivery address") — this phase does not add a second, parallel way to enter an address inline during checkout.
- The checkout mockup's payment-method section (card fields, cash-on-delivery radio) is entirely out of scope for this phase, per its title ("no payment yet") — Phase 5 is where payment method selection and card entry are built.
- A subscription created by this phase is not yet visible anywhere else in the product (no dashboard exists until Phase 6) beyond the confirmation page shown immediately after creation and whatever an admin can see directly in the data — this is expected and not a gap this phase needs to fill.
- "Pending-payment" is an additional subscription status beyond the `active`/`paused`/`cancelled` set sketched in `plan.md` §2's original data model — needed because this phase creates subscriptions before Phase 5's payment step exists to activate them.
