# Phase 1 Design: Data Model — Phase 3 — Admin Settings & the Pricing Engine

One new table, `settings`. No changes to `products`, `cities`, `cart_items`, `addresses`,
`profiles` from prior phases — `calculate.ts` reads product prices and city delivery-fee
overrides but does not alter their schema. See [research.md](./research.md) §1 for why the
singleton shape is a `check (id = 1)` table rather than `jsonb`-only or normalized.

## `settings`

| Column | Type | Notes |
|---|---|---|
| `id` | `integer`, PK, default `1`, check `id = 1` | Enforces exactly one row (FR-007) |
| `frequencies` | `jsonb`, not null | `{ weekly: {enabled, discountPercent, deliveriesPerMonth}, biweekly: {...}, monthly: {...} }` — see shape below |
| `min_order_value` | `numeric(10,2)`, not null, check `>= 0` | FR-002 |
| `max_items_per_box` | `integer`, not null, check `>= 1` | FR-002 |
| `edit_cutoff_hours` | `integer`, not null, check `>= 0` | FR-002 — enforcement lands in Phase 6 (dashboard) |
| `first_delivery_lead_days` | `integer`, not null, check `>= 0` | FR-002 — enforcement lands in Phase 4 |
| `blackout_weekdays` | `integer[]`, not null, default `'{}'` | FR-002 — each value `0`–`6`; enforcement lands in Phase 4 |
| `delivery_mode` | `text`, not null, check in `('flat', 'free_above_threshold', 'per_city')` | FR-003 |
| `delivery_flat_fee` | `numeric(10,2)`, not null, check `>= 0` | FR-003 — also the per-city fallback (research.md, Edge Cases) |
| `delivery_free_threshold` | `numeric(10,2)`, not null, check `>= 0` | FR-003 |
| `max_pause_days` | `integer`, not null, check `>= 0` | FR-004 — enforcement lands in Phase 6 |
| `max_pauses_per_year` | `integer`, not null, check `>= 0` | FR-004 — enforcement lands in Phase 6 |
| `vat_percent` | `numeric(5,2)`, not null, check `>= 0 and <= 100` | FR-005 |
| `prices_include_vat` | `boolean`, not null, default `true` | FR-005 |
| `rounding_mode` | `text`, not null, check in `('none', 'nearest_0.5', 'nearest_1')` | FR-006 |
| `updated_at` | `timestamptz`, not null, default `now()` | Bumped on every admin edit |

**`frequencies` shape** (validated in `lib/validation/settings.ts`, not just documented):

```json
{
  "weekly":   { "enabled": true,  "discountPercent": 5,  "deliveriesPerMonth": 4 },
  "biweekly": { "enabled": true,  "discountPercent": 8,  "deliveriesPerMonth": 2 },
  "monthly":  { "enabled": true,  "discountPercent": 12, "deliveriesPerMonth": 1 }
}
```

Each entry's `discountPercent` is checked `0`–`100` and `deliveriesPerMonth` is checked `>= 1` at
the application layer (zod) — a `jsonb` column can't express per-key numeric range constraints in
Postgres without a `check` expression per key, which is more brittle to evolve than validating on
write, given this shape only ever changes through the single admin settings form.

**Seed data**: one default row (`id = 1`) is inserted by the migration itself, with every
frequency enabled and reasonable starter values (matching `plan.md` §3's example numbers), so the
pricing engine has something real to calculate against immediately — no separate manual seeding
step, unlike `cities` (Phase 1), which seeds only one city because address creation needs *a*
valid city, not specific values.

**RLS**: public-read (`select` for everyone, including anonymous — `/pricing-preview` must read
enabled frequencies and the current VAT/rounding/delivery configuration without requiring
sign-in), admin-write (`insert`/`update`/`delete` gated on `profiles.role = 'admin'`, identical
shape to `products`' policy from Phase 2). In practice `insert`/`delete` are never exercised by the
application (the seeded row is edited via `PATCH`, never replaced), but the policies exist for
completeness and to fail safe if ever attempted.

**Lifecycle**: no history — every `PATCH /api/admin/settings` updates the single row in place.
Nothing reads a "settings as of time X" — every calculation always uses whatever is currently
saved, which is the literal meaning of "current configuration" in FR-007.

## `calculate.ts` — inputs and output (not persisted)

Not a database entity — a pure function's shape, documented here because it's the other half of
this phase's data model (the spec's "Price Breakdown" key entity).

**Input**:
- `items: Array<{ productId, price, quantity }>` — prices passed in already resolved (the Route
  Handler looks them up from `products`; `calculate.ts` never queries the database itself, per
  research.md §3/§4 and the Constitution Principle VI test-first requirement — no I/O to mock)
- `frequency: 'weekly' | 'biweekly' | 'monthly'`
- `city: { id, deliveryFeeOverride: number | null }`
- `settings`: the full row shape above

**Output** (the spec's **Price Breakdown** entity):

```ts
{
  itemsSubtotal: number,
  droppedItems: string[],          // productIds excluded (unavailable/deleted) — FR-019
  frequencyDiscountAmount: number,
  afterDiscount: number,
  deliveryFee: number,
  taxableBase: number,
  vatAmount: number,
  totalPerDelivery: number,
  estimatedMonthly: number,
  meetsMinimumOrderValue: boolean, // FR-016
  withinMaxItemsPerBox: boolean,   // FR-016
}
```

Never written to any table — recomputed fresh on every `POST /api/pricing/preview` call
(FR-011), consistent with the spec's Key Entities note that the breakdown is "not persisted."

## Entity relationships

```
settings (singleton, id = 1)
   │  read by
   ▼
lib/pricing/calculate.ts ──consumes──▶ products.price (Phase 2)
        │                              cities.delivery_fee_override (Phase 1)
        │
        ▼
  Price Breakdown (ephemeral response, never stored)
```
