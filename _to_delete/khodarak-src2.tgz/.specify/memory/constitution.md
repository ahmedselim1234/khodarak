<!--
Sync Impact Report
- Version change: [TEMPLATE] → 1.0.0 (initial ratification)
- Modified principles: n/a (template placeholders replaced with concrete principles)
- Added sections:
  - Core Principles: I. Server Components & Rendering Strategy, II. Server-Side Authority for
    Business Logic, III. Performance Budget & Core Web Vitals, IV. Type Safety & Validation at
    Boundaries, V. Data Integrity, Idempotency & Security, VI. Test-First for Critical Logic &
    Observability
  - Technology & Architecture Constraints
  - Development Workflow & Quality Gates
  - Governance
- Removed sections: none (all bracketed placeholders resolved)
- Deferred/TODO items: none — RATIFICATION_DATE set to the date this constitution was first
  adopted for this repository
-->

# Khodarak Constitution

## Core Principles

### I. Server Components & Rendering Strategy
The App Router is the default architecture. Every component is a Server Component unless it
requires interactivity, browser APIs, or client-only state — `"use client"` MUST be justified
and pushed to the smallest leaf component possible, never applied to a layout or page wholesale.
Each route MUST make a deliberate rendering choice (static, ISR with an explicit `revalidate`, or
dynamic) rather than defaulting to dynamic rendering by omission. Data fetching happens in Server
Components or Route Handlers, colocated with the data it renders, using the framework's built-in
request memoization instead of hand-rolled caching layers.
**Rationale**: Over-using Client Components silently inflates the JS bundle and defeats the
App Router's main performance advantage. Being explicit about rendering mode is what makes
Core Web Vitals predictable instead of accidental.

### II. Server-Side Authority for Business Logic
Any calculation that determines money owed, inventory, or subscription state (pricing,
discounts, VAT, delivery fees, renewal charges) MUST be computed by a single server-side
function and MUST NOT be trusted from client input. The browser may render a preview using the
same pure function, but the value that is persisted or charged always comes from the server
recomputing it at the moment of the mutation. Route Handlers and Server Actions validate their
own inputs — they never assume a value passed from the client is authoritative just because the
UI already validated it.
**Rationale**: A subscription/payment product where the client could influence its own price or
charge amount is a direct financial vulnerability, not just a bug.

### III. Performance Budget & Core Web Vitals
Every page ships within an explicit performance budget: LCP < 2.5s, INP < 200ms, CLS < 0.1 on
mid-tier mobile hardware, reflecting that the primary audience browses on mobile in Saudi Arabia.
Images MUST use `next/image` with correct `sizes`/priority hints; fonts MUST use `next/font` with
no render-blocking external font requests; third-party scripts load via `next/script` with the
least-blocking strategy that still works. Route-level code splitting is the default — heavy
client libraries (charting, rich editors, payment widgets) are dynamically imported and never
included in the shared initial bundle. A Lighthouse (or equivalent) mobile pass is part of the
Phase 9 hardening gate and MUST NOT regress below the budget once established.
**Rationale**: Performance is a stated project requirement, not an incidental nice-to-have, and
regressions are cheap to catch early and expensive to unwind after launch.

### IV. Type Safety & Validation at Boundaries
TypeScript runs in `strict` mode across the codebase with no new `any` without a comment
explaining why it's unavoidable. Every external boundary — Route Handler request bodies, webhook
payloads (Moyasar), form submissions, environment variables — MUST be validated at runtime with a
schema (e.g. zod), not just typed. Types alone do not protect against a malformed webhook or a
tampered request body; only runtime validation does.
**Rationale**: TypeScript guarantees compile-time shape, not runtime trust — the two are
frequently confused and the confusion is where boundary bugs live.

### V. Data Integrity, Idempotency & Security
Financial and order records are immutable snapshots: `orders`, `order_items`, and stored price
breakdowns MUST NOT change retroactively when a product price or setting changes later. All
payment-affecting operations (renewal charges, webhook processing) MUST be idempotent — a retried
job or a duplicate webhook event MUST NOT double-charge or double-create records; dedupe on a
stable external id (e.g. Moyasar event id) before acting. Supabase Row Level Security is enabled
on every table holding user or financial data; the browser never talks to Supabase directly for
anything price- or payment-related — only Route Handlers do, using validated, server-side logic.
Card data is never handled by our server: tokenization happens client-to-Moyasar directly.
**Rationale**: These are the specific failure modes (double-charging, retroactive price drift,
RLS gaps) that turn a subscription-billing bug into a customer-trust or compliance incident.

### VI. Test-First for Critical Logic & Observability
The pricing engine and any other function where a bug silently costs real money MUST have a unit
test suite covering boundary cases (min-order threshold, free-delivery threshold exactly hit, VAT
inclusive vs exclusive, rounding) written before or alongside the implementation, not after the
UI is built on top of it. Route Handlers and background jobs (renewal, webhooks) use structured
logging with enough context (subscription id, order id, cycle number) to reconstruct what
happened during an incident, and user-facing errors are caught by error boundaries rather than
producing a blank screen.
**Rationale**: The pricing/payment path is the one place in this codebase where "we'll add tests
later" has a direct financial cost, and unattended background jobs are unobservable by default
unless logging is designed in from the start.

## Technology & Architecture Constraints

- **Framework**: Next.js App Router + TypeScript, single monolith serving both frontend and the
  `/api/*` Route Handler backend — no separate backend service for the MVP.
- **Styling**: Tailwind CSS, RTL-first (Arabic is the primary locale; layouts and logical
  properties MUST work correctly mirrored, not just LTR-with-Arabic-text-pasted-in).
- **Data & Auth**: Supabase (Postgres + Auth + Storage), accessed from Route Handlers/Server
  Components via server-side clients; RLS is the enforced authorization boundary, not just an
  app-layer check.
- **Payments**: Moyasar for card tokenization and recurring charges; amounts are always handled
  in halalas through a single conversion helper, never multiplied inline.
- **Client state**: Redux Toolkit + RTK Query against `/api/*` for client-side data needs that
  don't fit naturally as Server Component data fetching (e.g. cart state, optimistic UI).
- **Deployment**: Docker-based; environment configuration is validated at boot, not discovered at
  runtime via undefined-variable crashes.

## Development Workflow & Quality Gates

- TypeScript type-check and lint MUST pass before a change is considered done.
- New or changed Route Handlers MUST include input validation and, where they touch money or
  subscription state, unit tests for the underlying logic.
- Changes to rendering strategy (adding `"use client"`, switching a route's caching mode) require
  a one-line justification in the PR description — reviewers should be able to see *why* a route
  opted out of the default.
- A mobile performance pass (Lighthouse or equivalent) is required before each customer-facing
  phase demo described in the project plan, not deferred entirely to the final hardening phase.
- Webhook and payment code changes require a review pass specifically for idempotency and replay
  protection before merge.

## Governance

This constitution supersedes ad hoc conventions when they conflict. Amendments are made by
editing this file, incrementing the version per the policy below, and recording the change in the
Sync Impact Report comment at the top of the file.

**Versioning policy** (semantic versioning applied to governance):
- **MAJOR** — backward-incompatible removal or redefinition of a principle (e.g. dropping the
  server-side pricing authority rule).
- **MINOR** — a new principle or materially expanded section is added.
- **PATCH** — wording clarifications, typo fixes, non-semantic refinements.

All PRs and code reviews are expected to be checkable against these principles; a reviewer who
finds a violation should block merge or require a documented, explicit exception rather than
silently waiving it. Complexity that violates a principle (e.g. business logic computed
client-side "just for this one screen") MUST be justified in writing or removed.

**Version**: 1.0.0 | **Ratified**: 2026-08-08 | **Last Amended**: 2026-08-08
