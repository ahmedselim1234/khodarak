# Implementation Plan: Phase 0 — Foundation

**Branch**: `001-phase-0-foundation` | **Date**: 2026-08-10 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/001-phase-0-foundation/spec.md`

## Summary

Stand up the Khodarak project skeleton: a Next.js App Router + TypeScript monolith with every
committed route reachable and rendering the ported design system (colors, `organic` radius,
spacing tokens, Plus Jakarta Sans + Material Symbols, RTL base layout) taken verbatim from the
`design/*.html` mockups; a Supabase client/server helper pair wired to env-validated
configuration; a documented folder structure future phases build into; and a Docker skeleton that
builds and runs the app. No business logic, auth gating, or real data ships in this phase — it is
scaffolding only, per `plan.md` §4 Phase 0 and the feature spec's FR-010.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS (Next.js 14+ App Router requirement)

**Primary Dependencies**: Next.js (App Router), Tailwind CSS, `@supabase/supabase-js` +
`@supabase/ssr` (server/browser client helpers), Redux Toolkit (store scaffold only — no slices
with real logic yet), zod (env validation)

**Storage**: Supabase (Postgres + Auth + Storage) — connected but schema-empty in this phase; no
tables are created here (data model starts in later phases per plan.md §2)

**Testing**: Vitest (or Jest) for unit tests (env-validation helper), Playwright for a smoke test
that hits every committed route and asserts a 200 + expected `dir="rtl"` shell — chosen because
the constitution (Principle VI) requires test-first discipline to already be in place structurally
before Phase 3's pricing engine lands

**Target Platform**: Linux container (Docker), served over HTTP; primary client is mobile Chrome/
Safari per plan.md's stated Saudi mobile-first audience

**Project Type**: Web application — single Next.js monolith (frontend + `/api/*` Route Handlers
in one deployable), no separate backend service

**Performance Goals**: No enforced budget yet (Constitution Principle III's Lighthouse gate binds
starting at the Phase 9 hardening gate) — this phase only needs to avoid obviously blocking
patterns (no render-blocking font requests, `next/font` used from the start) since retrofitting is
costlier than starting correctly

**Constraints**: RTL-first rendering is non-negotiable in every page (Constitution Technology
constraint); TypeScript `strict` mode with no new `any` (Principle IV); env config validated at
boot, not discovered at runtime (Technology & Architecture Constraints)

**Scale/Scope**: 9 routes (`/`, `/browse`, `/browse/[id]`, `/subscription`, `/dashboard`,
`/dashboard/orders`, `/dashboard/settings`, `/admin`, `/login`), zero data tables, zero API
endpoints beyond a Supabase connectivity check — the smallest possible slice that satisfies the
spec's three user stories

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — every route is a Server Component shell by default; no route needs `"use client"` yet since there is no interactivity | PASS — plan puts zero Client Components in scope; any found during implementation must be justified |
| II. Server-Side Authority for Business Logic | No business/pricing logic exists yet (FR-010 explicitly forbids it) | PASS (not yet applicable) |
| III. Performance Budget & Core Web Vitals | Partially — `next/font` and `next/image` conventions are established now so later phases don't retrofit them, but the formal Lighthouse gate is Phase 9 | PASS — foundational choices only, no budget violation possible with empty pages |
| IV. Type Safety & Validation at Boundaries | Yes — env config is the only "boundary" this phase has, and FR-006 requires runtime validation, not just typing | PASS — zod schema required in design |
| V. Data Integrity, Idempotency & Security | No financial/order data exists yet; RLS has nothing to protect yet since no tables are created | PASS (not yet applicable) — flagged so Phase 1 (Auth) does not skip RLS when tables appear |
| VI. Test-First for Critical Logic & Observability | No critical money-path logic yet, but the constitution's spirit (test discipline established early) is honored via the route-smoke-test requirement | PASS — smoke test scoped in Phase 1 design below |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts (research.md, data-model.md, contracts/,
quickstart.md) introduce no new Client Components, no client-side business logic, no untyped
boundaries, and no new tables — the `lib/supabase/client.ts` vs `server.ts` split and the zod-based
`lib/env.ts` are exactly what Principles IV and V require, and the `/api/health` contract carries
no sensitive data. Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/001-phase-0-foundation/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/                          # Next.js App Router routes
├── (marketing)/
│   └── page.tsx               # /
├── login/
│   └── page.tsx               # /login (no mockup — shared tokens, generic layout)
├── browse/
│   ├── page.tsx                # /browse
│   └── [id]/
│       └── page.tsx            # /browse/[id]
├── subscription/
│   └── page.tsx                # /subscription
├── dashboard/
│   ├── page.tsx                 # /dashboard
│   ├── orders/
│   │   └── page.tsx             # /dashboard/orders
│   └── settings/
│       └── page.tsx             # /dashboard/settings
├── admin/
│   └── page.tsx                 # /admin (no mockup — shared tokens, generic layout)
├── api/
│   └── health/
│       └── route.ts             # Supabase connectivity check used by the smoke test
├── layout.tsx                    # Root layout: dir="rtl", lang="ar", font wiring
├── not-found.tsx                 # Styled 404 shell (FR-004)
└── globals.css                    # Tailwind base + ported utility classes (organic-shadow, etc.)
                                     # (colocated in app/, not a separate styles/ — Next.js App
                                     # Router convention; reconciled during US3, see Notes below)

components/
└── ui/                           # Shared primitives ported from design tokens (Card, Button,
                                    # Container, TopNav, PagePlaceholder)

lib/
├── supabase/
│   ├── client.ts                  # Browser Supabase client (public env only)
│   └── server.ts                  # Server-only Supabase client (service role never in browser)
├── env.ts                          # Public env (NEXT_PUBLIC_*) — safe to import client-side
├── env.server.ts                   # Server-only env (adds SUPABASE_SERVICE_ROLE_KEY); guarded
│                                    # by the `server-only` package (split from a single lib/env.ts
│                                    # during implementation — importing the service-role key from
│                                    # browser code would have crashed the client bundle)
└── store/
    └── index.ts                    # Redux Toolkit store scaffold (no slices with real logic yet)

tailwind.config.ts                  # Design tokens ported verbatim from design/*.html
instrumentation.ts                  # Forces lib/env.server's validation to run at process boot
                                     # (Next.js instrumentation hook), not just on first request

tests/
├── unit/
│   └── env.test.ts                 # env validation failure-mode coverage (FR-006)
└── e2e/
    └── routes.smoke.spec.ts        # Playwright: every committed route returns 200 + dir="rtl"
vitest.config.ts
playwright.config.ts

Dockerfile
docker-compose.yml
.dockerignore
.env.example
```

**Structure Decision**: Single Next.js monolith at the repository root (Constitution: "single
monolith serving both frontend and the `/api/*` Route Handler backend — no separate backend
service"). Route groups map 1:1 to the routes committed in the spec and `plan.md` §0.A/§0.B.
`lib/supabase/` splits browser vs. server clients so later phases can never accidentally import
the service-role client into client-side code. `components/ui/` exists now so later phases add
design-token-driven primitives into one place instead of duplicating card/button styling per page.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

[Gates determined based on constitution file]

## Project Structure

### Documentation (this feature)

```text
specs/[###-feature]/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)
<!--
  ACTION REQUIRED: Replace the placeholder tree below with the concrete layout
  for this feature. Delete unused options and expand the chosen structure with
  real paths (e.g., apps/admin, packages/something). The delivered plan must
  not include Option labels.
-->

```text
# [REMOVE IF UNUSED] Option 1: Single project (DEFAULT)
src/
├── models/
├── services/
├── cli/
└── lib/

tests/
├── contract/
├── integration/
└── unit/

# [REMOVE IF UNUSED] Option 2: Web application (when "frontend" + "backend" detected)
backend/
├── src/
│   ├── models/
│   ├── services/
│   └── api/
└── tests/

frontend/
├── src/
│   ├── components/
│   ├── pages/
│   └── services/
└── tests/

# [REMOVE IF UNUSED] Option 3: Mobile + API (when "iOS/Android" detected)
api/
└── [same as backend above]

ios/ or android/
└── [platform-specific structure: feature modules, UI flows, platform tests]
```

**Structure Decision**: [Document the selected structure and reference the real
directories captured above]

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
| [e.g., 4th project] | [current need] | [why 3 projects insufficient] |
| [e.g., Repository pattern] | [specific problem] | [why direct DB access insufficient] |
