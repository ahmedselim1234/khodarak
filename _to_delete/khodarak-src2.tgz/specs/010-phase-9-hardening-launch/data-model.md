# Phase 1 Data Model: Phase 9 — Hardening, Docker & Launch

**No database migration this phase.** Every prior phase's data-model.md documented schema
changes; this one documents artifact shapes instead, per research.md §1 — the entities spec.md
names (Audit Finding, Deployment, Launch Checklist) are process records, not application data the
running app ever reads back.

## `AUDIT_FINDINGS.md` (new artifact)

One row per finding from User Stories 1 and 6's audits:

| Column | Notes |
|---|---|
| ID | Sequential (`F-001`, `F-002`, ...) |
| Area | `RLS` \| `Validation` \| `Webhook` \| `Error/Loading/Empty State` \| `Arabic Copy` \| `Performance` |
| Location | File/route/table/screen the finding applies to |
| Finding | What was found, in one or two sentences |
| Severity | `Blocking` (per FR-004's own definition: could leak another customer's data, permit an unauthorized write, or break a core purchase/payment flow) \| `Non-blocking` |
| Resolution | `Fixed` (with a link/reference to the fix) \| `Deferred` (with a one-line reason it's safe to defer) |

**Invariant enforced by FR-004/SC-001**: every row with `Severity = Blocking` MUST have
`Resolution = Fixed` before `LAUNCH_CHECKLIST.md` can be marked complete — this is checked by
whoever completes the launch checklist (User Story 7), not by any automated tool, since the
severity judgment itself is a human call the audit makes.

## `LAUNCH_CHECKLIST.md` (new artifact)

One row per functional requirement in `spec.md` (FR-001 through FR-018):

| Column | Notes |
|---|---|
| Requirement | The FR id and a short restatement |
| Status | `Verified` \| `Deferred (non-blocking)` |
| Evidence | A concrete link/reference: a passing CI run, `AUDIT_FINDINGS.md`'s relevant rows all resolved, the live transaction's Moyasar payment id, the Lighthouse CI report, etc. — never a bare checkmark with no reference |

**Invariant enforced by FR-018/SC-008**: the checklist is not considered complete (and launch does
not proceed) while any row lacks both a `Status` and concrete `Evidence` — per User Story 7's own
Acceptance Scenario 1.

## Deployment (conceptual — tracked via existing Git/CI/registry history, not a new record)

A "deployment" is fully reconstructable from three things this phase's own infrastructure already
produces: the Git commit SHA, the CI run that verified it (`.github/workflows/ci.yml`'s own run
history, retained by GitHub), and the container image tag in the registry matching that SHA
(research.md §3). No separate `deployments` log is introduced — the registry's own tag history
and CI's own run history together already answer "what's running and when did it start."

## Live Transaction Record (existing `payments` row, Phase 5/7's own shape, unchanged)

The one real transaction proving the live cutover (User Story 5) is not a new entity — it's an
ordinary `payments` row, written by the exact same `processPaymentOutcome.ts`/
`processRenewalOutcome.ts` code paths every prior test-mode transaction already used, the only
difference being which Moyasar credentials were active in the environment at the moment it ran.
`LAUNCH_CHECKLIST.md`'s evidence column for FR-014 references this row's own `id` (and the
matching transaction visible in the live Moyasar dashboard) directly.

## `subscription_pauses` (existing, Phase 6/7/8 — read differently this phase, no schema change)

The one query this phase adds (`CountersOverview.tsx`'s fourth counter, FR-012) is a read against
the exact same table and columns Phase 7 (auto-suspend) and Phase 8 (admin attribution) already
established:

```sql
select count(*) from subscription_pauses
where initiated_by_admin_id is null
  and resume_date is null
  and started_at >= now() - interval '7 days'
```

`initiated_by_admin_id is null and resume_date is null` is exactly Phase 7's own established
signature for an automatic dunning suspension (distinct from a customer's own dated pause, and
distinct from an admin's own attributed pause per Phase 8's `initiated_by_admin_id`) — no new
column, no new distinguishing flag, this phase only adds the query that surfaces the existing
signal in aggregate.
