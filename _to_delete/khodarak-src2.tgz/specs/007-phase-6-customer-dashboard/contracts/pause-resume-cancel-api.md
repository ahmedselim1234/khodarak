# Contract: `POST /api/subscriptions/[id]/{pause,resume,cancel}`

Covers User Story 3's lifecycle actions. All three require an authenticated session and caller
ownership (`404` otherwise), and all three write via `mutateSubscription.ts` (service-role) — none
of them go through an owner-scoped RLS `UPDATE` policy (research.md §3). Unlike the box editor
above, **none of these three respect the edit cutoff window** — pause and cancel always take
effect immediately, including overriding an already-locked next delivery (spec.md Clarification 4,
FR-010/FR-014).

## `POST /api/subscriptions/[id]/pause`

**Request**:
```json
{ "resumeDate": "2026-09-15" }
```
Validated by `lib/validation/subscriptionPause.ts` — must be a future date.

**Behavior**:
1. `404` if not found/not owned. `409 { "error": "already_paused" }` if `status` is already
   `paused`; `409 { "error": "already_cancelled" }` if `cancelled` (spec.md Edge Cases).
2. Call `pauseEligibility()` with the subscription's `subscription_pauses` history, `resumeDate`,
   and the current `settings.maxPauseDays`/`maxPausesPerYear`. If denied: `422
   { "error": "pause_limit_exceeded", "limit": "max_pause_days" | "max_pauses_per_year" }`
   (FR-011).
3. If any pending change exists (from a prior deferred edit), it is left untouched — pausing
   doesn't discard it; it will still apply from `pending_effective_from` once the subscription is
   active again and that date arrives.
4. Write `status = 'paused'`, `paused_until = resumeDate`; insert a `subscription_pauses` row
   (`started_at = now()`, `resume_date = resumeDate`).

**Response — success**: `200 { "status": "paused", "pausedUntil": "2026-09-15" }`.

**Response — limit exceeded**: `422 { "error": "pause_limit_exceeded", "limit": "..." }`.

**Response — already paused/cancelled**: `409 { "error": "already_paused" | "already_cancelled" }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": {...} }`.

---

## `POST /api/subscriptions/[id]/resume`

**Request**: empty body.

**Behavior**:
1. `404` if not found/not owned. `409 { "error": "not_paused" }` if `status` isn't `paused`.
2. Recalculate `next_delivery_date` from *now* using `selectableDeliveryDates`/the subscription's
   frequency and current lead-time/blackout settings (FR-012 — a fresh calculation, not simply
   restoring whatever `next_delivery_date` was before the pause).
3. Update the matching `subscription_pauses` row: `resumed_early_at = now()`.
4. Write `status = 'active'`, `paused_until = null`, `next_delivery_date = <recalculated>`.

**Response — success**: `200 { "status": "active", "nextDeliveryDate": "2026-08-20" }`.

**Response — not paused**: `409 { "error": "not_paused" }`.

---

## `POST /api/subscriptions/[id]/cancel`

**Request**:
```json
{ "confirm": true }
```
`confirm` MUST be `true` — the explicit confirmation step FR-014 requires; anything else is a
validation error, not silently treated as confirmation.

**Behavior**:
1. `404` if not found/not owned. `409 { "error": "already_cancelled" }` if already `cancelled`.
2. Write `status = 'cancelled'`, `cancelled_at = now()`. Clears any pending-change fields (moot —
   there is nothing left to apply them to) but leaves `subscription_items`/order history
   untouched, since orders are immutable snapshots regardless of the subscription's later state
   (FR-017).
3. This subscription can never transition again — every other endpoint in this contract set
   returns `409 { "error": "already_cancelled" }` for it from this point on (FR-014's "cannot be
   reactivated").

**Response — success**: `200 { "status": "cancelled" }`.

**Response — already cancelled**: `409 { "error": "already_cancelled" }`.

**Response — validation error (confirm not true)**: `400 { "error": "validation_failed", "fields": { "confirm": "..." } }`.

---

All three endpoints additionally return `401 { "error": "unauthenticated" }` when there is no
session at all.
