# Phase 1 Design: Data Model — Phase 5 — Moyasar Integration & First Payment

Five new tables. Shapes follow `plan.md` §2's original sketch (`payment_methods`, `payments`,
`webhook_events`, `orders`, `order_items`) with the nullability amendment research.md §2 explains.
No changes to `subscriptions`/`subscription_items` (Phase 4) beyond what activation writes into
existing columns (`status`, `started_at`) — no new columns on either.

## `payment_methods`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `user_id` | `uuid`, not null, FK → `profiles(id)` on delete cascade | Owner |
| `moyasar_token_id` | `text`, not null, unique | The reusable token Moyasar returns from tokenization |
| `brand` | `text`, not null | e.g. `mada`, `visa`, `mastercard` |
| `last_four` | `text`, not null | Display only — never the full PAN |
| `exp_month` | `integer`, not null, check `>= 1 and <= 12` | |
| `exp_year` | `integer`, not null | |
| `is_default` | `boolean`, not null, default `true` | The customer's first saved card is their default (mirrors the address-book default-on-first-save precedent from Phase 1) |
| `status` | `text`, not null, default `'active'`, check in `('active', 'expired', 'removed')` | This phase only ever writes `'active'`; `'expired'`/`'removed'` are reserved for later phases (dashboard card management, expiry-aware prompting) |
| `created_at` | `timestamptz`, not null, default `now()` | |

**RLS**: owner-only `SELECT`. No `authenticated`-role `INSERT`/`UPDATE`/`DELETE` policy — every
write happens via the service-role client from `lib/payments/processPaymentOutcome.ts`
(research.md §1).

## `payments`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `subscription_id` | `uuid`, null, FK → `subscriptions(id)` | Set at attempt-creation time (research.md §2) |
| `order_id` | `uuid`, null, FK → `orders(id)` | Filled in once the order is generated on success |
| `user_id` | `uuid`, not null, FK → `profiles(id)` on delete cascade | |
| `moyasar_payment_id` | `text`, not null, unique | Moyasar's own id for this specific charge attempt — the join key both the callback and the webhook look up by |
| `amount_halalas` | `integer`, not null, check `> 0` | Always produced by `lib/payments/halalas.ts`, never an inline multiplication (FR-017) |
| `status` | `text`, not null, default `'initiated'`, check in `('initiated', 'paid', 'failed')` | `'initiated'` until the callback/webhook resolves it — this is the column the idempotency guard's conditional update targets (research.md §3) |
| `failure_reason` | `text`, null | Set only when `status = 'failed'` |
| `attempt_number` | `integer`, not null, default `1`, check `>= 1` | Which attempt this is for the subscription — a decline followed by a retry is two rows, not one overwritten (spec Key Entities) |
| `raw_response` | `jsonb`, null | Moyasar's response payload, retained for troubleshooting — never contains full PAN/CVV (Moyasar itself never returns those) |
| `created_at` | `timestamptz`, not null, default `now()` | |

**RLS**: owner-only `SELECT`, plus one deliberate exception: an `INSERT` policy scoped to
`user_id = auth.uid() and status = 'initiated'`, since `POST /api/subscriptions/[id]/pay`
records its own attempt using the caller's normal session, not the service-role client — this is
safe because it's insert-only and pinned to the non-terminal status; there is still no `UPDATE`
policy at all, so a customer can never move an attempt to `'paid'`/`'failed'`, set its `order_id`,
or touch any other table. Every other write (the transition to `'paid'`/`'failed'`, and
everything in step 3 below) is service-role only.

**Idempotency**: the unique constraint on `moyasar_payment_id` prevents a second row for the same
Moyasar-side payment; the conditional `UPDATE ... WHERE status NOT IN ('paid', 'failed')` in
`processPaymentOutcome.ts` prevents two processes from both successfully activating off the same
still-`'initiated'` row (research.md §3).

## `webhook_events`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `moyasar_event_id` | `text`, not null, unique | Deduplication key (FR-013) |
| `type` | `text`, not null | e.g. `payment_paid`, `payment_failed` |
| `payload` | `jsonb`, not null | The full received event, retained regardless of whether this phase acts on its type (Edge Cases: an event type this phase doesn't otherwise act on is still recorded) |
| `processed_at` | `timestamptz`, null | Set once `processPaymentOutcome.ts` has run for this event; a webhook delivery whose `moyasar_event_id` already exists is recognized as a duplicate at the `INSERT` (unique-constraint conflict) and short-circuits before processing again |

**RLS**: no `SELECT`/`INSERT`/`UPDATE`/`DELETE` policy for `authenticated` at all — this table has
no customer-facing reader; only the service-role webhook handler ever touches it.

## `orders`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `subscription_id` | `uuid`, not null, FK → `subscriptions(id)` | |
| `user_id` | `uuid`, not null, FK → `profiles(id)` on delete cascade | |
| `address_snapshot` | `jsonb`, not null | Captured from the subscription's address at generation time — never a live join, so the order's delivery address stays historically accurate even if the customer edits/deletes that address later |
| `status` | `text`, not null, default `'pending'`, check in `('pending', 'out_for_delivery', 'delivered', 'cancelled')` | This phase only ever creates `'pending'` orders; the later statuses are Phase 8's admin-operations concern |
| `scheduled_date` | `date`, not null | Copied from `subscriptions.next_delivery_date` at generation time |
| `delivered_at` | `timestamptz`, null | Unused this phase |
| `price_breakdown` | `jsonb`, not null | Copied verbatim from the subscription's own snapshot — never recomputed (FR-009) |
| `created_at` | `timestamptz`, not null, default `now()` | |

**RLS**: owner-only `SELECT`. No `authenticated`-role write policy — generated only by
`processPaymentOutcome.ts` via the service-role client.

## `order_items`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `order_id` | `uuid`, not null, FK → `orders(id)` on delete cascade | |
| `product_id` | `uuid`, not null, FK → `products(id)` | |
| `product_name_snapshot` | `text`, not null | Unlike `subscription_items` (deliberately live-referencing, Phase 4 data-model.md), `order_items` snapshots — this is the historical record `plan.md` §2's "orders and order_items store snapshots" rule is specifically about |
| `unit_price_snapshot` | `numeric(10,2)`, not null | Copied from the product's price at generation time |
| `quantity` | `integer`, not null, check `>= 1` | Copied from the subscription's items at generation time |

**RLS**: owner-only `SELECT` via the parent order (same join-based pattern as
`subscription_items`). No `authenticated`-role write policy.

## Activation flow (not a new entity — documents how `processPaymentOutcome.ts` uses all five)

```
processPaymentOutcome(moyasarPaymentId, verifiedStatus, rawResponse)
  1. UPDATE payments SET status = <paid|failed>, raw_response = ...
       WHERE moyasar_payment_id = $1 AND status NOT IN ('paid','failed')
       RETURNING id, subscription_id, user_id, amount_halalas
     — zero rows returned → already processed, STOP (research.md §3)

  2. if verifiedStatus == 'failed':
       UPDATE payments SET failure_reason = ... WHERE id = <the row from step 1>
       STOP — subscription stays pending_payment (FR-016)

  3. if verifiedStatus == 'paid':
       a. Read the subscription (by subscription_id from step 1) — items, address, frequency,
          price_breakdown
       b. Upsert payment_methods for this user_id/moyasar_token_id (insert if new; if the
          customer has no other active method, is_default = true)
       c. UPDATE subscriptions SET status = 'active', started_at = now() WHERE id = subscription_id
       d. INSERT orders (subscription_id, user_id, address_snapshot from the subscription's
          address, status: 'pending', scheduled_date: subscriptions.next_delivery_date,
          price_breakdown: subscriptions.price_breakdown) RETURNING id
       e. INSERT order_items — one row per subscription_items row, product_name_snapshot/
          unit_price_snapshot resolved from products at this exact moment
       f. UPDATE payments SET order_id = <id from step d> WHERE id = <the row from step 1>
```

Every step from 3b onward runs only when step 1's conditional update actually returned a row —
this is what makes the whole sequence safe to invoke from both the callback and the webhook
without coordination between them (research.md §3).

## Entity relationships

```
subscriptions (Phase 4, status: pending_payment → active here)
    │
    ├─< payments >── (subscription_id set at attempt time; order_id filled in on success)
    │
    └── on success ──▶ orders ──< order_items >── products (snapshotted, unlike subscription_items)

profiles ──< payment_methods
webhook_events (independent — durable log, no FK to the rest)
```
