# Quickstart: Validating Phase 0 — Foundation

Validates the three user stories in [spec.md](./spec.md) end to end. Run after implementation.

## Prerequisites

- Node.js 20 LTS, a Supabase project (URL + anon key + service role key)
- `.env.example` copied to `.env.local` and filled in with real Supabase credentials

## 1. Validate env-config fail-fast (User Story 2, FR-006, SC-004)

```
cp .env.example .env.local.broken
# remove or blank SUPABASE_SERVICE_ROLE_KEY in .env.local.broken
node -r dotenv/config -e "require('./lib/env.ts')" dotenv_config_path=.env.local.broken
```

**Expected**: process exits non-zero within ~5 seconds, error message names
`SUPABASE_SERVICE_ROLE_KEY` specifically — not a generic "undefined" crash.

## 2. Boot the app locally (User Story 2, SC-003)

```
npm install
npm run dev
```

**Expected**: dev server starts; `curl http://localhost:3000/api/health` returns
`{"status":"ok","supabase":"reachable"}` per [contracts/health-check.md](./contracts/health-check.md).
Total time from fresh clone to this point should be under 10 minutes.

## 3. Verify every committed route renders the styled RTL shell (User Story 1, SC-001, SC-002)

```
npx playwright test tests/e2e/routes.smoke.spec.ts
```

**Expected**: all 9 routes (`/`, `/browse`, `/browse/[id]`, `/subscription`, `/dashboard`,
`/dashboard/orders`, `/dashboard/settings`, `/admin`, `/login`) return a successful render with
`dir="rtl"` on the root element. Manually spot-check 2–3 routes in a browser against the matching
`design/*.html` file and confirm matching primary color (`#00450d`), `organic` (20px) card
radius, and Plus Jakarta Sans typography.

## 4. Verify not-found handling (Edge Case, FR-004)

```
curl -I http://localhost:3000/this-route-does-not-exist
```

**Expected**: styled not-found page, not a blank/broken response.

## 5. Verify the Docker build (User Story 2, FR-008, SC-005)

```
docker compose build
docker compose up
```

**Expected**: build completes with zero manual post-build steps; container serves the app and
`/api/health` responds as in step 2.

## 6. Confirm no business logic shipped (FR-010)

Manual code-review check, not a runnable script: confirm no page or Route Handler in this phase
computes pricing, processes payment, or reads/writes account data — every page here is shell-only.
