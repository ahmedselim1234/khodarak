# Implementation Plan: Phase 6 — Customer Dashboard

**Branch**: `007-phase-6-customer-dashboard` | **Date**: 2026-08-11 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/007-phase-6-customer-dashboard/spec.md`

## Summary

Turn a customer's already-active (or paused) subscription into something they can see and manage
day-to-day: `/dashboard` shows status, the next delivery, and a deterministic health indicator;
editing items/frequency/address re-prices through the exact same `lib/pricing/calculate.ts` used
at signup and either applies immediately or — when inside the admin's edit-cutoff window — is
held as a **pending change** on the subscription itself, never touching the already-locked next
delivery; pause and cancel are the one deliberate exception to that cutoff lock, always taking
effect immediately (Clarifications session 2). `/dashboard/orders` surfaces the customer's
existing, immutable order snapshots read-only. `/dashboard/settings` wires up the existing
Phase 1 address CRUD and Phase 5 card-tokenization components into a new card-replacement flow,
plus a new profile-update endpoint and a payment-history list. Every write that changes
subscription state (edit, pause, resume, cancel) goes through the service-role client from a
Route Handler — extending Phase 5's established pattern rather than adding owner-scoped RLS
`UPDATE` policies on `subscriptions`, for the same reason Phase 5 closed that door on `payments`:
an owner-scoped policy restricts rows, not columns, and would let a customer write
`subscriptions.status`/`price_breakdown` directly.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0–5)

**Primary Dependencies**: `@supabase/ssr` + `@supabase/supabase-js` (RLS-scoped client for reads;
the existing `lib/supabase/serviceRole.ts` service-role client for subscription-state writes, same
as Phase 5), zod, Redux Toolkit + RTK Query. No new third-party dependency — card replacement
reuses the existing `CardTokenizationForm` (Moyasar hosted tokenization script, already scoped via
`next/script` to the routes that need it).

**Storage**: Supabase (Postgres) — extends the existing `subscriptions` table with pending-change
columns and a pause-limit tracking table; no new top-level financial tables (`orders`,
`order_items`, `payments`, `payment_methods` all already exist from Phase 5 and are read-only or
insert-only from this phase's perspective, except `payment_methods` gaining its first
customer-triggered insert path for card replacement — still service-role only, per Phase 5's
established constraint).

**Testing**: Vitest for the phase's three new pure functions —
`lib/subscription/resolveEffectiveConfig.ts` (current vs. pending resolution, research.md §1),
`lib/subscription/pauseEligibility.ts` (rolling-365-day pause-limit check, research.md §2), and
`lib/subscription/subscriptionHealth.ts` (deterministic health indicator, research.md §4) — all
written before the Route Handlers that call them, per Constitution Principle VI. Playwright for
the phase's demo path: edit a box outside the cutoff and see the price/next-delivery update; pause
an active subscription, resume it early, and see status/next-delivery recalculate correctly
(`plan.md`'s own stated demo target).

**Target Platform**: Same as Phase 0–5 — `npm run dev` locally, Linux container deferred to
Phase 9; primary client is mobile Chrome/Safari, RTL Arabic.

**Project Type**: Web application — same single Next.js monolith, no new deployable.

**Performance Goals**: No new Core Web Vitals risk — `/dashboard`, `/dashboard/orders`, and
`/dashboard/settings` are Server Components fetching from Supabase directly; the only
`"use client"` leaves are the interactive edit forms, pause/cancel dialogs, and the reused
`CardTokenizationForm` (already `next/script`-scoped from Phase 5, unchanged here).

**Constraints**: Every write that changes `subscriptions` state (items, frequency, address,
pending-change fields, status, `paused_until`, `next_delivery_date`) happens exclusively through
the service-role client from a Route Handler under `app/api/subscriptions/[id]/*`, validated
server-side against the current admin `settings` row and re-priced through `calculate()` before
being persisted — never a value the client supplies directly, and never an owner-scoped `UPDATE`
policy granting a customer's session that write path (Constitution Principle II/V, extending
Phase 5's `payments`-migration precedent to `subscriptions`). Card replacement follows the same
rule: the new card's brand/last-four/expiry are read back from Moyasar's own API response
(`moyasarClient.fetchPayment`), never trusted from the client, before the service-role client
inserts the new `payment_methods` row. Address CRUD and the profile update stay on the existing,
lighter-weight owner-scoped RLS pattern from Phase 1 (`addresses`, `profiles`) — they are not
financial/pricing state, so Phase 5's stricter service-role-only rule doesn't apply to them.

**Scale/Scope**: 1 new migration (subscription pending-change columns + `subscription_pauses`
table), 9 new Route Handlers, 3 new pages replacing existing placeholders
(`/dashboard`, `/dashboard/orders`, `/dashboard/settings`), ~14 new components, 3 new pure lib
modules with their own test suites, 1 new RTK Query API slice.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — `/dashboard`, `/dashboard/orders`, `/dashboard/settings` are Server Components fetching directly from Supabase; `"use client"` is scoped to the edit/pause/cancel dialogs and the reused `CardTokenizationForm` only | PASS |
| II. Server-Side Authority for Business Logic | Yes — the central concern this phase. Every subscription edit is re-priced by `calculate()` server-side before saving (never a client-computed total accepted); rule validation (min order, per-product min/max, max items, cutoff, pause limits) all runs server-side against the current `settings` row | PASS |
| III. Performance Budget & Core Web Vitals | Yes — no new third-party script introduced; the one existing one (`CardTokenizationForm`) stays scoped to the settings route via `next/script`, same as Phase 5 | PASS |
| IV. Type Safety & Validation at Boundaries | Yes — every new Route Handler body (edit, pause, resume, cancel, payment-method replace, profile update) is zod-validated before use | PASS |
| V. Data Integrity, Idempotency & Security | Yes — pause/cancel/edit writes go through the service-role client exclusively (no owner-scoped `UPDATE` policy on `subscriptions`, mirroring the `payments` migration's rationale); order snapshots (`orders`/`order_items`) are never written or altered by this phase, only read; pending-change fields prevent a deferred edit from ever mutating an already-locked delivery's committed price | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — `resolveEffectiveConfig.ts`, `pauseEligibility.ts`, and `subscriptionHealth.ts` are the phase's money/state-correctness-bearing pure functions and ship with Vitest coverage before any Route Handler uses them | PASS |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts (research.md, data-model.md, contracts/,
quickstart.md) keep the service-role client's use narrowly scoped to
`lib/subscription/mutateSubscription.ts`-style server-only modules invoked only from
`app/api/subscriptions/[id]/*` Route Handlers (never imported into a component, never used for
ordinary reads — reads stay on the existing per-request RLS-scoped client throughout, including
for `/dashboard`'s own data fetching). `resolveEffectiveConfig`, `pauseEligibility`, and
`subscriptionHealth` remain pure, dependency-free functions callable from both the Route Handlers
and their Vitest suites. Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/007-phase-6-customer-dashboard/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── dashboard/
│   ├── page.tsx                       # REPLACED placeholder — status card, next-delivery
│   │                                   # preview (current vs. pending), health indicator, edit
│   │                                   # entry point, pause/resume/cancel actions
│   ├── orders/
│   │   ├── page.tsx                   # REPLACED placeholder — order history list
│   │   └── [id]/
│   │       └── page.tsx               # NEW — single order detail (snapshotted items/price)
│   └── settings/
│       └── page.tsx                   # REPLACED placeholder — AddressBook (reused from
│                                       # Phase 1), saved-card display + replace flow, payment
│                                       # history, profile form
└── api/
    ├── subscriptions/
    │   └── [id]/
    │       ├── route.ts               # GET (detail incl. pending fields; self-heals an
    │       │                          # overdue paused→active transition on read —
    │       │                          # data-model.md) + PATCH (items/frequency/address
    │       │                          # edit — re-prices, applies cutoff/pending-change
    │       │                          # logic per FR-009)
    │       ├── pause/
    │       │   └── route.ts           # POST — { resumeDate }; enforces max_pause_days /
    │       │                          # rolling-365-day max_pauses_per_year; immediate,
    │       │                          # bypasses the cutoff lock (FR-010/FR-011)
    │       ├── resume/
    │       │   └── route.ts           # POST — early resume; recalculates next_delivery_date
    │       │                          # from now (FR-012)
    │       └── cancel/
    │           └── route.ts           # POST — { confirm: true }; immediate, bypasses the
    │                                  # cutoff lock, terminal (FR-014)
    ├── addresses/
    │   └── [id]/
    │       └── route.ts               # UPDATED (Phase 1) — DELETE gains an in-use pre-check
    │                                  # against subscriptions (FR-019, contracts/settings-api.md)
    ├── payment-methods/
    │   └── route.ts                   # POST — replace saved card. Body carries the Moyasar
    │                                  # $0 save_only payment id (never card fields); server
    │                                  # calls moyasarClient.fetchPayment to authoritatively
    │                                  # read brand/last-four/expiry before inserting
    │                                  # (FR-020/FR-021)
    └── profile/
        └── route.ts                   # PATCH — full_name/phone, existing owner-scoped RLS
                                        # policy from Phase 1 (FR-023)

# NOTE: order history/detail and payment history are read-only with no client-side mutation, so
# — per Constitution Principle I and the precedent already set by
# app/subscription/confirmed/[id]/page.tsx (Phase 5) — they are fetched directly from Supabase
# inside their Server Component pages, not via a self-owned /api/orders* or
# /api/payments/history Route Handler (contracts/orders-api.md, contracts/settings-api.md).

components/
└── dashboard/
    ├── SideNav.tsx                    # Server Component — لوحة التحكم / طلباتي / اشتراكاتي /
    │                                  # العناوين / الإعدادات (design/dashboard.html's nav),
    │                                  # shared by all three dashboard pages via a layout
    ├── SubscriptionDashboard.tsx      # "use client" — the one live-updating region of the
    │                                  # page: fetches via dashboardApi.ts's
    │                                  # useGetSubscriptionQuery (so pause/resume/cancel/edit
    │                                  # mutations update the status card and next-delivery
    │                                  # info in place, no page reload — SC-005); renders
    │                                  # SubscriptionStatusCard/HealthBadge/PendingChangeBanner
    │                                  # below and hosts the editor/pause/cancel dialogs.
    │                                  # Everything else on /dashboard stays a Server Component
    │                                  # (SideNav, static bento copy)
    ├── SubscriptionStatusCard.tsx     # Presentational — status, next delivery date/contents/
    │                                  # charge, or paused/cancelled/empty variants (US1)
    ├── SubscriptionHealthBadge.tsx    # Presentational — renders subscriptionHealth.ts's
    │                                  # 'good' | 'needs_attention' output as the bento
    │                                  # layout's health indicator
    ├── PendingChangeBanner.tsx        # Presentational — shown when a pending change exists;
    │                                  # summarizes what will change and from which delivery
    │                                  # (US2 Acceptance Scenario 6)
    ├── SubscriptionEditor.tsx         # "use client" — item/quantity/frequency/address editor
    │                                  # with a live preview call to /api/pricing/preview
    │                                  # (reused from Phase 3/4) before PATCH submit
    ├── PauseDialog.tsx                # "use client" — resume-date picker, submits
    │                                  # POST .../pause, surfaces limit-violation messages
    ├── CancelDialog.tsx               # "use client" — explicit confirm step (US3 Acceptance
    │                                  # Scenario 6 — dismissing changes nothing)
    ├── orders/
    │   ├── OrderList.tsx              # Server Component — date/status/total rows
    │   └── OrderDetail.tsx            # Server Component — snapshotted items + price breakdown
    └── settings/
        ├── SavedCardSummary.tsx       # Server Component — brand/last-four display + "replace"
        │                              # entry point
        ├── ReplaceCardDialog.tsx      # "use client" — reuses CardTokenizationForm (Phase 5),
        │                              # posts to /api/payment-methods on completion
        ├── PaymentHistoryList.tsx     # Server Component — date/amount/outcome rows
        └── ProfileForm.tsx            # "use client" — name/phone, PATCH /api/profile

lib/
├── subscription/
│   ├── resolveEffectiveConfig.ts      # NEW pure fn — given current + pending fields and
│   │                                  # "now" vs. next_delivery_date, returns what the locked
│   │                                  # delivery contains and what applies after it
│   │                                  # (Clarification 3 / FR-009)
│   ├── pauseEligibility.ts            # NEW pure fn — given pause history + settings, decides
│   │                                  # allow/deny + which limit was hit (Clarification 2 /
│   │                                  # FR-011)
│   ├── subscriptionHealth.ts          # NEW pure fn — status + consecutive-failure count +
│   │                                  # cutoff proximity → 'good' | 'needs_attention'
│   │                                  # (Clarification 1 / FR-024)
│   ├── mutateSubscription.ts          # NEW server-only — the one module allowed to write
│   │                                  # subscription state via the service-role client; called
│   │                                  # only from app/api/subscriptions/[id]/* (Constraints)
│   ├── selectableDeliveryDates.ts     # EXISTING — reused unchanged for the post-frequency-
│   │                                  # change next-delivery-date recalculation
│   └── timeSlots.ts                   # EXISTING — unchanged
├── payments/
│   └── moyasarClient.ts               # UPDATED — no new function needed; fetchPayment already
│                                      # covers reading a save_only token's card details
│                                      # authoritatively (reused, not duplicated)
├── validation/
│   ├── subscriptionEdit.ts            # NEW zod schema — PATCH .../route.ts body
│   ├── subscriptionPause.ts           # NEW zod schema — POST .../pause body
│   ├── paymentMethodReplace.ts        # NEW zod schema — POST /api/payment-methods body
│   └── profileUpdate.ts               # NEW zod schema — PATCH /api/profile body
└── store/
    ├── dashboardApi.ts                # NEW RTK Query slice — subscription detail, edit, pause,
    │                                  # resume, cancel mutations; orders list/detail queries
    └── settingsApi.ts                 # NEW RTK Query slice — payment-method replace, payment
                                        # history, profile update

supabase/
└── migrations/
    └── <timestamp>_dashboard.sql      # ALTER subscriptions: pending_frequency,
                                        # pending_address_id, pending_price_breakdown,
                                        # pending_effective_from; NEW subscription_pending_items
                                        # table (mirrors subscription_items); NEW
                                        # subscription_pauses table (rolling-window history).
                                        # No new authenticated-role UPDATE/INSERT/DELETE policy
                                        # on subscriptions/subscription_items — all writes stay
                                        # service-role only (data-model.md)

tests/
├── unit/
│   ├── subscription.resolveEffectiveConfig.test.ts   # locked-delivery vs. pending-effective
│   │                                                  # cases, including "no pending change"
│   ├── subscription.pauseEligibility.test.ts          # at-limit, rolling-window-expiry,
│   │                                                  # duration-exceeded cases
│   └── subscription.subscriptionHealth.test.ts        # each status × failure-count × cutoff-
│                                                        # proximity combination
└── e2e/
    └── dashboard.spec.ts              # edit outside cutoff → price/next-delivery update;
                                        # pause → resume early → status/next-delivery correct —
                                        # quickstart.md's full walkthrough
```

**Structure Decision**: Stays inside the Phase 0–5 monolith. The three dashboard routes already
exist as Phase 0 placeholders (`app/dashboard/page.tsx`, `app/dashboard/orders/page.tsx`,
`app/dashboard/settings/page.tsx`) and are replaced in place rather than moved — middleware route
protection (`/dashboard/:path*` → customer-or-admin) already covers all three and needs no change.
`subscriptions`/`subscription_items` keep their existing owner-scoped `SELECT`/`INSERT` policies
from Phase 4 unchanged; this phase deliberately does **not** add the owner-scoped `UPDATE` policy
Phase 4's migration comment anticipated ("Phase 6 adds those alongside the dashboard actions that
need them") — research.md §3 documents why that plan changed: Phase 5 already established, for
exactly this class of table, that customer-facing state transitions belonging to money/subscription
correctness must go through a service-role Route Handler, not a direct RLS write path, and
`subscriptions.status`/`price_breakdown` are exactly the kind of column an owner-scoped `UPDATE`
policy cannot safely protect (RLS restricts rows, not columns — the same lesson from
`profiles.role`, Phase 1). Addresses and profile stay on their existing, already-correct
owner-scoped RLS pattern since they don't carry that same financial-tampering risk.

## Complexity Tracking

*No Constitution Check violations — table not needed.*
