# Phase 1 Data Model: Auth & Address

Three new tables, all with RLS enabled from creation (Constitution Principle V). This is the
first phase with real, per-user data — no retroactive RLS work is deferred to a later phase.

## `profiles`

Extends `auth.users` (Supabase-managed) with the application-level identity fields from the
spec's Account/Profile entity.

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | uuid | Yes | Primary key; `= auth.users.id`, `ON DELETE CASCADE` |
| `full_name` | text | Yes | From `signUp` metadata; no format constraint beyond non-empty |
| `phone` | text | Yes | KSA mobile format, validated by the zod schema at the form/Route boundary (FR-009) before reaching the trigger; not re-validated by a DB constraint in this phase (see Assumptions in spec.md — format is a presentation-layer detail) |
| `role` | text (`'customer'` \| `'admin'`) | Yes | Defaults to `'customer'`; no client-writable path sets `'admin'` (FR-008) |
| `created_at` | timestamptz | Yes | `default now()` |

**Creation**: an `AFTER INSERT` trigger on `auth.users` inserts this row (see research.md) — never
inserted directly by application code.

**RLS**:
- `SELECT`, `UPDATE`: allowed where `id = auth.uid()` — a user reads/updates only their own
  profile.
- `INSERT`, `DELETE`: no policy grants these to regular users — creation is trigger-only,
  deletion cascades from `auth.users` deletion (not exposed in this phase).

**`role` is immutable through normal updates**: RLS policies restrict *rows*, not *columns* — the
`UPDATE` policy above alone would let a signed-in customer PATCH their own `role` to `'admin'`
directly via the REST API (confirmed live during implementation; FR-008 requires no client-writable
path to admin). Closed with a `BEFORE UPDATE` trigger (`prevent_role_change`,
`supabase/migrations/20260810120300_profiles_role_immutable.sql` and
`20260810120400_profiles_role_immutable_scope.sql`) that resets `role` to its previous value
whenever a non-`service_role` session attempts to change it. A future privileged context (e.g.
Phase 8's admin panel, acting via the service role) is exempted and can still change it
legitimately.

## `cities`

Admin-managed lookup list a customer chooses from when saving an address (spec's City entity).
Full target schema from `plan.md` §2 created now (see research.md); only `is_active`-filtered rows
are relevant to this phase's UI.

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | uuid | Yes | Primary key, `default gen_random_uuid()` |
| `name_ar` | text | Yes | Arabic display name |
| `is_active` | boolean | Yes | `default true`; controls whether the city is offered for new/edited addresses (FR-016) |
| `delivery_fee_override` | numeric | No | Unused this phase — consumed starting Phase 3's delivery-fee rules |

**Seed data**: migration inserts at least one active city so address creation is testable
immediately (per spec.md Assumptions).

**RLS**:
- `SELECT`: allowed for any authenticated user (both customers picking an address city and the
  as-yet-unbuilt admin panel will need to read this table; no per-row sensitivity).
- `INSERT`, `UPDATE`, `DELETE`: no policy grants these to non-admin users this phase — city
  management ships in Phase 8's admin panel; until then rows are seeded/edited via migration only.

## `addresses`

The spec's Address entity — a customer's saved delivery location.

| Field | Type | Required | Notes |
|---|---|---|---|
| `id` | uuid | Yes | Primary key, `default gen_random_uuid()` |
| `user_id` | uuid | Yes | FK → `profiles.id`, `ON DELETE CASCADE` |
| `label` | text | Yes | e.g. "Home", "Work" — free text |
| `city_id` | uuid | Yes | FK → `cities.id`; UI offers only rows where `cities.is_active` at selection time (FR-016), but the FK itself does not restrict to active cities — a since-deactivated city stays valid on existing rows (FR-017) |
| `district` | text | Yes | Free text (Clarifications, 2026-08-10) — no predefined list this phase |
| `street_details` | text | Yes | Free-text street/building/unit details |
| `is_default` | boolean | Yes | `default false`; exactly one `true` row per `user_id` is enforced by the partial unique index below |
| `created_at` | timestamptz | Yes | `default now()` |

**Invariant — exactly one default per customer** (FR-014, FR-015, SC-005):

```sql
CREATE UNIQUE INDEX addresses_one_default_per_user
  ON addresses (user_id)
  WHERE is_default;
```

Enforced at the database level (see research.md's rationale on concurrency). The
`/api/addresses/[id]` Route Handler additionally implements the normal-path behavior as one
transaction: unset the caller's current default (if any), then set the target row's `is_default`
to `true`.

**No maximum row count per `user_id`** (Clarifications, 2026-08-10 — FR-013a).

**RLS**:
- `SELECT`, `INSERT`, `UPDATE`, `DELETE`: allowed where `user_id = auth.uid()` — a customer
  reads/writes only their own addresses (FR-013); no row is visible or mutable cross-user.

## State transitions

- **Account**: `(none)` → created (via `signUp` + trigger) → active. No suspended/deactivated
  state exists in this phase's scope.
- **Address `is_default`**: `false` → `true` on: (a) a customer's first-ever address being saved
  (auto-default, FR-015), or (b) an explicit "set as default" action, which atomically flips the
  previously-default row back to `false` in the same transaction. An address with no other
  addresses left after a deletion has no automatic promotion to default — a customer with zero
  addresses has no default until they add one (spec.md Edge Cases / Acceptance Scenario 5).
