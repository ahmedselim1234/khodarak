# Quickstart: Validating Phase 1 — Auth & Address

Validates the four user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 0 checkout (Supabase project reachable, `npm run dev` serving all routes).

## Prerequisites

- Phase 0's quickstart already passing (`.env.local` filled in, `npm run dev` boots)
- Migrations applied: `profiles`, `cities` (seeded with ≥1 active city), `addresses`
  (see [data-model.md](./data-model.md))

## 1. Sign up and land signed-in (User Story 1, FR-001/002/007, SC-001)

```
npm run dev
# in a browser: visit /signup, submit a new email + password + full name + KSA phone
```

**Expected**: a matching row exists in `profiles` with `role = 'customer'` immediately (the
trigger fires on account creation regardless of confirmation status). Since this project keeps
"Confirm email" enabled (Clarifications/Assumptions, 2026-08-10), the form shows a "check your
email to confirm" message rather than redirecting straight to `/dashboard` — click the emailed
link, then log in normally at `/login`. Re-submitting the same email on `/signup` shows a clear
"already registered" error and creates no duplicate row.

## 2. Log out and back in (User Story 1, FR-003/004)

```
# in the browser: sign out from the dashboard, then visit /login and sign back in
```

**Expected**: signed out lands you on `/`; protected pages are unreachable until you sign back in
via `/login`; reloading the page after signing back in keeps you signed in (no re-prompt).

## 3. Trigger login throttling (FR-003a, Clarifications 2026-08-10)

```
# in the browser: on /login, submit the wrong password 6+ times in a row for one account
```

**Expected**: after a small number of failures, further attempts are rejected with a
"too many attempts" message rather than a normal wrong-password error — see
[contracts/auth-flows.md](./contracts/auth-flows.md).

## 4. Reset a forgotten password (User Story 2, FR-005/006)

```
# in the browser: visit /forgot-password, submit a registered email, follow the emailed link,
# set a new password, then log in with the new password
```

**Expected**: same confirmation message shown whether or not the email is registered (check by
also submitting an unregistered email — response text must not differ); new password works, old
password no longer does; a reused or expired reset link shows "no longer valid" instead of
silently succeeding.

## 5. Verify the route-protection matrix (User Story 3, FR-010/011, SC-002)

```
npx playwright test tests/e2e/route-protection.spec.ts
```

**Expected**: every cell of [contracts/route-protection.md](./contracts/route-protection.md)'s
matrix passes — signed-out visitors redirected to `/login` (and returned to their original
destination after signing in), signed-in customers reach `/subscription`/`/dashboard` but are
redirected away from `/admin`, and a signed-in admin (create one by manually setting
`role = 'admin'` in `profiles` for a test account, per spec.md Assumptions) reaches `/admin`.

## 6. Manage delivery addresses (User Story 4, FR-012–017, SC-003/005)

```
# in the browser, signed in as a customer: go to /dashboard/settings
# add an address → confirm it's auto-marked default
# add a second address, mark it default → confirm the first is no longer default
# edit the first address's details → confirm changes persist
# delete the non-default address → confirm the remaining one stays default
```

**Expected**: at every step exactly one address is marked default whenever at least one exists
(SC-005); only cities seeded as active appear in the city selector (FR-016); the API contract in
[contracts/addresses-api.md](./contracts/addresses-api.md) is followed (check network tab for
`200`/`201`/`204` and correct payload shapes).

## 7. Confirm cross-user isolation (FR-013, Constitution Principle V)

```
# sign in as customer A, note an address id from the network tab
# sign in as customer B in a second session, attempt GET/PATCH/DELETE /api/addresses/<A's id>
```

**Expected**: `404 Not Found` in every case — never `200`, never a `403` that would confirm the
row exists.

## 8. Run the unit suite (Constitution Principle VI)

```
npm run test:unit
```

**Expected**: phone-format validation edge cases, address-payload validation edge cases, and the
default-address invariant logic all pass — see `tests/unit/` in [plan.md](./plan.md)'s Project
Structure.
