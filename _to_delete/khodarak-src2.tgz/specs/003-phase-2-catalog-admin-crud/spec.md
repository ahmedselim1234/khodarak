# Feature Specification: Phase 2 — Catalog + Admin Product CRUD

**Feature Branch**: `003-phase-2-catalog-admin-crud`

**Created**: 2026-08-10

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for Phase 2" — scoped from `plan.md` §4 "Phase 2 — Catalog + Admin Product CRUD": `products` table, admin product CRUD with image upload (Supabase Storage), `/browse` per `design/products.html` (filter sidebar, sort bar, product grid, pagination) and `/browse/[id]` per `design/product-details.html`, stepper, persistent cart bar, cart state (Redux Toolkit) with reload persistence. Demo target: "admin adds a product → it appears instantly on the customer browse page; customer adds quantities and sees the cart bar update."

## Clarifications

### Session 2026-08-10

- Q: `design/products.html` shows a filter-sidebar checkbox list for category, but the function inventory calls for browsing via two category tabs (خضروات/فواكه). How should these coexist on `/browse`? → A: A خضروات/فواكه tab strip sits above the product grid as the primary way to switch category; the sidebar's category checkbox list is removed (price and availability filters remain in the sidebar, scoped to whichever tab is active).
- Q: Should a signed-in customer's cart be saved on the server (same across devices) or kept only on that device, with guest-to-account merge happening only on that device? → A: Server-synced — the cart is stored server-side per account so a signed-in customer sees the same cart on any device; guest (pre-login) selections merge into it at login.
- Q: Should uploading a photo be required to create a product, or can an admin save one without a photo (placeholder shown until added)? → A: Required — a photo must be uploaded before a product can be saved.
- Q: When a guest's device-local cart and an existing signed-in account's server cart both have a quantity for the same product, how should the quantities be combined at login? → A: Keep the higher quantity for each shared product (capped at that product's max), rather than summing or letting the account cart unconditionally win.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Admin manages the product catalog (Priority: P1)

An admin creates, edits, and removes products — each with a name, category, price, unit, photo, and availability — so the storefront always reflects what's actually sellable.

**Why this priority**: Every other capability in this phase (browsing, filtering, adding to a box) depends on products existing. Without this, the catalog is empty and nothing else can be demonstrated or tested.

**Independent Test**: Can be fully tested by creating a new product with a photo in the admin panel, confirming it's saved with all fields, editing its price, then marking it unavailable — delivers a working product catalog independent of the customer-facing browse page.

**Acceptance Scenarios**:

1. **Given** an admin on the product management screen, **When** they create a new product with a name, category (خضروات or فواكه), price, unit, and photo, **Then** the product is saved and appears in the catalog as available.
2. **Given** an existing product, **When** the admin edits its price, photo, or availability, **Then** the change is saved and reflected the next time the catalog is loaded.
3. **Given** an existing product, **When** the admin removes it, **Then** it no longer appears in the customer-facing catalog.
4. **Given** an admin creating or editing a product, **When** they upload a photo, **Then** it is stored and displayed as the product's image; if the upload fails, they see a clear error and the rest of the product's fields are not lost.
5. **Given** an admin creating or editing a product, **When** they set a minimum and/or maximum orderable quantity, **Then** those bounds are saved and later enforced wherever the customer selects a quantity for that product.

---

### User Story 2 - Customer browses and filters the catalog (Priority: P1)

A customer visiting `/browse` sees products organized into خضروات (vegetables) and فواكه (fruits) tabs, can filter by price and availability, sort the results, and page through them.

**Why this priority**: Browsing is the entry point to the entire purchase flow (a box can't be built from products the customer never saw). It must work as soon as products exist, independent of any cart or checkout behavior.

**Independent Test**: Can be fully tested by loading `/browse`, switching between the خضروات and فواكه tabs, applying a price filter and an "available only" filter, changing the sort order, and paging to a second page — delivers a fully working, read-only catalog browsing experience.

**Acceptance Scenarios**:

1. **Given** a customer on `/browse`, **When** the page loads, **Then** products are shown in a grid under one of the two category tabs (خضروات or فواكه), defaulting to the first tab.
2. **Given** a customer viewing the خضروات tab, **When** they switch to the فواكه tab, **Then** the grid updates to show only فواكه products, and any active price/availability filters remain applied within the new tab.
3. **Given** a customer on `/browse`, **When** they adjust the price range filter or toggle "available only," **Then** the grid updates to show only matching products within the active category tab.
4. **Given** a customer on `/browse`, **When** they change the sort order (e.g., price low-to-high, newest), **Then** the grid re-orders accordingly.
5. **Given** more products than fit on one page, **When** the customer navigates to the next page, **Then** the next set of products for the active tab/filter/sort combination is shown.
6. **Given** a category tab or filter combination with no matching products, **When** the customer views it, **Then** they see a clear empty state instead of a blank or broken grid.
7. **Given** a product an admin has marked unavailable, **When** a customer views it in the grid or its detail page, **Then** it is visibly marked as unavailable and cannot be added to the box.

---

### User Story 3 - Customer adjusts quantities and sees the cart bar update (Priority: P1)

A customer adjusts a product's quantity directly on its grid card (or on its detail page) using a stepper, and a persistent cart bar reflects the running item count and total, staying accurate across page reloads.

**Why this priority**: This is the mechanism that carries a customer's selections toward the subscription builder in a later phase, and it's the second half of this phase's demo target ("customer adds quantities and sees the cart bar update"). It depends on User Story 2 (products must be browsable) but is independently verifiable once products exist.

**Independent Test**: Can be fully tested by increasing a product's quantity via its card stepper, confirming the cart bar's count and total update immediately, reloading the page, and confirming the cart bar still reflects the same selections — delivers a working cart independent of the subscription builder that will later consume it.

**Acceptance Scenarios**:

1. **Given** a product card with a quantity stepper, **When** the customer increases the quantity, **Then** the persistent cart bar's item count and total update immediately to reflect the change.
2. **Given** a customer has added quantities to one or more products, **When** they decrease a quantity to zero, **Then** that product is removed from the cart and the cart bar updates accordingly.
3. **Given** a customer has items in their cart, **When** they reload the page or navigate between `/browse` and `/browse/[id]`, **Then** their selected quantities and the cart bar's totals are unchanged.
4. **Given** a customer adjusts a product's quantity, **When** they attempt to go below the product's minimum orderable quantity or above its maximum, **Then** the stepper prevents it and the quantity stays at the nearest allowed bound.
5. **Given** a signed-out customer has added items to their cart, **When** they log in, **Then** their pre-login cart selections are preserved (merged with any existing saved selections for that account) rather than being lost.
6. **Given** an empty cart, **When** the customer views the persistent cart bar, **Then** it reflects a zero state rather than being missing or broken.

---

### User Story 4 - Customer views a single product's detail page (Priority: P2)

A customer opens a product from the grid to see a larger view, description, and quantity control, and can add it to their box from there.

**Why this priority**: It enriches the browsing experience and gives customers more confidence before committing quantity, but the core browse-and-cart loop (User Stories 2 and 3) is already usable without it, so it ranks just behind them.

**Independent Test**: Can be fully tested by opening a product from the grid, confirming its details render, adjusting its quantity via the stepper on the detail page, and confirming the cart bar updates — delivers a working detail view independent of the grid-level stepper.

**Acceptance Scenarios**:

1. **Given** a customer on `/browse`, **When** they select a product, **Then** they are taken to that product's detail page showing its name, price, unit, and photo.
2. **Given** a customer on a product's detail page, **When** they adjust the quantity stepper and add it to the box, **Then** the persistent cart bar updates the same way it would from the grid card.
3. **Given** a customer navigates directly to a detail page URL for a product that no longer exists or has been removed, **When** the page loads, **Then** they see a clear "not found" state rather than a broken page.

---

### Edge Cases

- What happens when an admin uploads a very large or wrong-format image? The upload is rejected with a specific error before saving, and any other product fields already entered are preserved so the admin doesn't have to re-enter them.
- What happens when an admin deletes a product that a customer currently has in their (unsaved) cart? The product disappears from the cart the next time the cart is loaded/synced, and the cart bar's totals adjust accordingly.
- What happens when an admin changes a product's price while it's sitting in a customer's cart? The cart reflects the current price the next time it's loaded/synced; carried-over pricing is not locked in until the subscription builder (a later phase) snapshots it.
- What happens when a customer's guest-session cart and their existing account's saved cart both have quantities for the same product at login? The higher of the two quantities is kept for that product (capped at its admin-configured maximum) rather than silently dropping one side.
- What happens when a customer tries to set a product's quantity above its admin-defined maximum, or below its minimum (other than zero, which removes it)? The stepper clamps to the nearest allowed value and does not accept the out-of-bounds input.
- What happens when the active category tab or filter/sort combination has zero matching products? A clear empty state is shown instead of an empty or broken grid.
- What happens when a customer reaches the last page of results and tries to page forward? Pagination controls disable/hide the "next" action rather than returning an error.
- What happens when a product is marked unavailable while a customer already has a nonzero quantity of it in their cart? It stays in the cart but is visibly flagged as unavailable, and the customer cannot increase its quantity or proceed past it into the subscription builder (enforced in a later phase).

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST allow an admin to create a product with a name, category (خضروات or فواكه), price, unit, a required photo, availability state, and minimum/maximum orderable quantity; the system MUST NOT allow saving a new product without a photo.
- **FR-002**: System MUST allow an admin to edit any field of an existing product, including replacing its photo, and MUST reflect changes in the customer-facing catalog without requiring a separate publish step.
- **FR-003**: System MUST allow an admin to remove a product, after which it MUST NOT appear in the customer-facing catalog.
- **FR-004**: System MUST allow an admin to toggle a product's availability independently of deleting it, and unavailable products MUST be visibly marked as such wherever a customer sees them.
- **FR-005**: System MUST reject an invalid product photo upload (wrong format or excessive size) with a specific error, without discarding the rest of the in-progress product form.
- **FR-006**: System MUST display customer-facing products grouped into exactly two category tabs — خضروات and فواكه — with the grid scoped to whichever tab is active.
- **FR-007**: System MUST allow a customer to filter the active category tab's products by price range and by availability ("available only").
- **FR-008**: System MUST allow a customer to sort the active category tab's products (at minimum: price ascending, price descending) and MUST re-apply the active filters after sorting.
- **FR-009**: System MUST paginate catalog results and allow the customer to navigate between pages of the active tab/filter/sort combination.
- **FR-010**: System MUST show a clear empty state when a category tab or filter combination has no matching products, and disable/hide forward pagination when no further pages exist.
- **FR-011**: System MUST provide a quantity stepper on each product grid card and on the product detail page, allowing the customer to increase or decrease the selected quantity for that product.
- **FR-012**: System MUST clamp a product's quantity stepper to that product's admin-configured minimum and maximum orderable quantity, and MUST remove the product from the cart when its quantity is reduced to zero.
- **FR-013**: System MUST maintain a persistent cart bar visible while browsing that reflects the current total item count and price total across all products the customer has added.
- **FR-014**: System MUST persist a customer's cart selections across page reloads and across navigation within the storefront, and MUST persist a signed-in customer's cart server-side so the same cart is visible from any device or browser they sign in on.
- **FR-015**: System MUST merge a signed-out (guest, device-local) cart into the customer's server-side account cart at login without silently discarding either side's selections; for any product present in both, the merged quantity MUST be the higher of the two, capped at that product's maximum orderable quantity.
- **FR-016**: System MUST provide a product detail page reachable from the catalog grid, showing the product's name, price, unit, and photo, and offering the same quantity stepper and add-to-box behavior as the grid card.
- **FR-017**: System MUST show a clear "not found" state when a product detail page is requested for a product that does not exist or has been removed.
- **FR-018**: System MUST prevent a customer from increasing the quantity of a product currently marked unavailable, while still allowing it to remain visible (flagged as unavailable) if already present in their cart from before it became unavailable.

### Key Entities

- **Product**: A sellable catalog item — name, category (خضروات or فواكه), price, unit (e.g. كجم / حبة), photo, availability state, minimum/maximum orderable quantity, and its position/order within listings. Managed exclusively by admins; read by customers.
- **Cart / Cart Item**: A customer's in-progress, pre-subscription selection of products and quantities — one entry per product, each carrying the selected quantity. A guest's cart is device-local; once signed in, the cart is stored server-side against the account (so it's consistent across devices/browsers), and the guest's device-local selections are merged into it at login rather than replacing it. Feeds into the subscription builder in a later phase but does not itself create an order or subscription.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A newly created or edited product (including its photo) is visible to customers on `/browse` within moments of the admin saving it, with no manual refresh step required beyond a normal page load.
- **SC-002**: A customer can go from landing on `/browse` to viewing a specific product's detail page in three actions or fewer (e.g., pick a tab, optionally filter, select a product).
- **SC-003**: Every quantity change a customer makes on a product card or detail page is reflected in the persistent cart bar's count and total instantly, with no page reload required.
- **SC-004**: 100% of cart selections a customer had before reloading the page, or before logging in, are still present afterward (accounting for merge behavior at login).
- **SC-005**: 100% of attempts to move a product's quantity outside its admin-configured min/max bounds are prevented at the point of interaction, never silently saved out-of-bounds.
- **SC-006**: A customer applying a category tab, price filter, availability filter, or sort order always sees a product grid consistent with that combination — including a clear empty state when nothing matches — with no stale or mismatched results.

## Assumptions

- "Instantly"/"without a publish step" (FR-002, SC-001) means the customer-facing catalog reads live product data on each page load — there is no separate draft/publish or caching-invalidation step to build in this phase.
- Photo uploads use Supabase Storage (per `plan.md`'s confirmed stack) with reasonable size/format limits (standard web image formats — JPEG/PNG/WebP — and a sane per-image size cap); the exact byte limit is an implementation detail, not a scope decision.
- Default catalog sort (before a customer picks one) is left to a sensible default (e.g., admin-defined `sort_order` / "best selling" per the mockup) rather than being a scope decision.
- Pagination page size follows the mockup's example (around a dozen products per page) rather than being a fixed contractual number.
- The persistent cart bar and stepper operate on client-side state (Redux Toolkit, per `plan.md`) that mirrors a lightweight server-side cart record for signed-in customers (a small addition to the `plan.md` §2 data model, not currently listed there) and device-local storage for guests; neither creates an order, subscription, or server-side price lock in this phase — that begins in the Phase 4 subscription builder.
- "Add to box" language in the mockups (`design/product-details.html`) and "cart" in `plan.md`'s function inventory refer to the same underlying selection mechanism described here as "cart" — the UI copy may say "الصندوق" (the box) while the underlying entity is the pre-subscription item selection.
- No customer-facing search bar is included in this phase's scope; `plan.md`'s Catalog module lists filtering, sorting, and category tabs but not search, and the mockup's header search icon is treated as a placeholder for a later phase.
- Admin authentication/authorization (who may reach product management) is already covered by Phase 1's route protection and role resolution; this phase only adds the product CRUD screens and logic behind that existing gate.
