# Contract: `.github/workflows/ci.yml`

Not an HTTP endpoint — the automated gate FR-007/FR-008 require. Documented as a contract because
every future change to this project depends on its exact behavior being predictable.

## Trigger

`push` and `pull_request` on every branch (so a check fails visibly on a PR before merge, not only
after).

## Job 1 — `verify` (runs on every trigger)

Steps, in order, any failure stopping the job immediately (FR-007's own ordering):

1. `actions/checkout`
2. `actions/setup-node` (Node 20, matching `Dockerfile`'s runtime target — research.md's own
   Technical Context)
3. `npm ci` (never `npm install` — a lockfile-exact install is what makes CI reproducible)
4. `npm run lint`
5. `npm run typecheck` (the new script this phase adds — `tsc --noEmit`)
6. `npm run test:unit`
7. `npm run build` — with the same build-time `NEXT_PUBLIC_*` placeholders the `Dockerfile`
   itself uses (research.md §5), since CI's own build step is what would have caught the missing
   `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY` placeholder had it existed before this phase

**A failure at any step MUST leave the run showing red on the commit/PR** — this is GitHub
Actions' own default behavior for a job with sequential steps, not something this workflow needs
to configure specially, but it's the behavior FR-007's acceptance scenario depends on.

## Job 2 — `deploy` (runs only on `push` to `main`, only after `verify` succeeds)

1. Build the production image (`docker build .`, using the `Dockerfile`'s `runner` stage).
2. Tag it with the commit SHA and push to `ghcr.io/<org>/khodarak:<sha>` (research.md §3).
3. SSH into the production host (credentials from a GitHub Actions secret, never committed) and
   run `scripts/deploy.sh <sha>` (contracts/deploy-and-rollback.md).

**A `verify` failure MUST prevent `deploy` from running at all** — GitHub Actions' own `needs:`
job dependency, not a custom check this workflow has to implement (FR-008).

## Notes

- No deploy job runs for a PR or a non-`main` branch — only `main`, and only after `verify`
  passes, is ever eligible to reach production (FR-008's own "no manual, unverified step" applies
  equally to "no unverified branch").
- Secrets used by `deploy` (registry credentials, SSH key, host address) live in GitHub Actions'
  own encrypted secrets store — never in this file, never in `.env.production.example` (which
  documents variable *names* the production host needs, never real values).
