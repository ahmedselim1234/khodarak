# Feature Specification: Phase 9 — Hardening, Docker & Launch

**Feature Branch**: `010-phase-9-hardening-launch`

**Created**: 2026-08-11

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for Phase 9" — scoped from `plan.md` §4 "Phase 9 — Hardening, Docker & Launch" and the ordering note in `plan.md` §5: RLS policy audit, server-side validation pass, webhook endpoint hardening, error/loading/empty states, Arabic copy review, Lighthouse/mobile pass — all verified running locally first — then, only once everything above already works outside a container, Dockerfile + compose, CI, deploy, monitoring, switch to live Moyasar keys, soft-launch checklist. Demo target: "the live URL, on a phone, in Arabic, with a real card." This is the ninth and **final** phase, closing out the project — every phase before it (`specs/001` through `specs/009`) built and demoed the complete customer-facing app, payment/renewal/dunning engine, and admin panel entirely via `npm run dev` against real Supabase/Moyasar TEST-mode services, deliberately with zero Docker involvement (`plan.md` §5: "Docker is deliberately last... to avoid debugging application logic and container config at the same time"). Unlike every prior phase, this one adds no new end-customer-facing feature — it takes the already feature-complete application through verification, containerization, and the operational readiness a real public launch requires.

## Clarifications

### Session 2026-08-11

- Q: Where does the application actually get deployed to run live — plan.md names Docker as the packaging format but not a hosting target? → A: A single Docker host (e.g. a VPS or a managed "run a container" service) running the existing `docker-compose.yml`, matching this project's already-committed stack (self-contained Next.js monolith, no separate backend service) rather than introducing a new platform-specific deployment model this late in the project.
- Q: Does the audit portion of this phase (RLS policies, server-side validation, webhook hardening, error/loading/empty states) block launch until every single finding is fixed, or is a severity-triaged list acceptable where only launch-blocking findings must be resolved? → A: Severity-triaged — every finding is documented and categorized (blocking vs. non-blocking), but only launch-blocking findings (anything that could leak another customer's data, allow an unauthorized write, or break a core purchase/payment flow) must be fixed before launch; lower-severity polish items may ship as known follow-up work.
- Q: Does verifying the live Moyasar cutover include executing one real, real-money transaction as a smoke test, or is confirming the live credentials are correctly configured (without an actual live charge) sufficient? → A: One real, minimal-amount live transaction is required as the actual proof the cutover works — configuration alone doesn't prove a live credential pair actually authorizes a real charge, and this is the one thing about payment integration that can't be verified any other way.
- Q: What's the actual target time for the team to be notified after the live application becomes unreachable? → A: 5 minutes — a standard, achievable target for a basic uptime-check-based monitoring setup, tight enough to catch a real outage quickly for a payment product without needing a more sophisticated monitoring stack than a first launch needs.
- Q: Does the rollback capability need to be actually exercised and verified during this phase, or is a written procedure that's never executed sufficient? → A: Must be exercised once — the team performs one real rollback and confirms it actually restores the previous known-good version, rather than trusting an untested procedure to work correctly the first time it's ever needed during a real incident.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - The team can trust the app is secure before it goes live (Priority: P1)

Before launch, the team systematically re-verifies — across every table and every mutation built in Phases 1 through 8 — that no customer can read another customer's data, no customer-writable path exists into financial or subscription state, and the one public/unauthenticated endpoint in the whole app (the Moyasar webhook) can't be spoofed or replayed.

**Why this priority**: This is a subscription-billing product handling real payment credentials and real customer PII — launching without confirming the authorization boundaries actually hold, rather than assuming they do because each phase said they would, is the single highest-consequence gap this phase could leave open.

**Independent Test**: Can be fully tested by systematically attempting, as an authenticated customer, every write this project has ever built that's supposed to be admin-only or system-only (subscription status, order status, payment records, another customer's addresses/profile) directly against the database and against every Route Handler, and confirming every attempt is rejected; separately, sending a forged or replayed webhook payload and confirming it's rejected — delivers a complete, verifiable security posture independent of every other story.

**Acceptance Scenarios**:

1. **Given** every table this project has ever created, **When** the audit reviews each one's Row Level Security policies, **Then** each policy is confirmed to match its own phase's documented intent (owner-only where specified, admin-only where specified, service-role-only where specified) — and any mismatch found is recorded with its severity.
2. **Given** every Route Handler this project has ever created, **When** the audit reviews each one's input handling, **Then** each is confirmed to validate its request body/params at the boundary before acting on them, not merely relying on client-side form validation — any gap found is recorded with its severity.
3. **Given** the Moyasar webhook endpoint, **When** it receives a request with a missing or incorrect signature, **Then** it's rejected outright before anything in the payload is trusted, exactly as originally built — this pass confirms it, rather than assuming it.
4. **Given** the Moyasar webhook endpoint, **When** it receives the same valid event delivered twice, **Then** the second delivery is a safe no-op, not a duplicate charge-outcome or duplicate order — this pass confirms the existing deduplication still holds.
5. **Given** every finding from this audit, **When** it's categorized by severity, **Then** every finding capable of leaking another customer's data, allowing an unauthorized write, or breaking a core purchase/payment flow is fixed before launch; lower-severity findings are documented as known follow-up work rather than blocking launch.

---

### User Story 2 - The app runs the same way in a container as it does in development (Priority: P1)

The team builds and runs the application from its Dockerfile and `docker-compose.yml` for the first time, confirming the containerized app behaves identically to the version that's been running via `npm run dev` throughout every prior phase — same routes reachable, same environment configuration, no container-specific breakage.

**Why this priority**: Docker is this phase's own explicitly named deliverable and the one genuinely new technical capability it adds (`plan.md` §4/§5) — without a working container, there is no deployable artifact for the next story to actually ship.

**Independent Test**: Can be fully tested by running `docker compose up` from a clean checkout with real environment variables supplied, and confirming every route reachable via `npm run dev` is equally reachable through the container, with no functional difference — delivers a complete, verifiable "the container is a faithful package of the app" independent of where it's ultimately hosted.

**Acceptance Scenarios**:

1. **Given** a clean checkout of the repository with no prior `npm run dev` session, **When** the team runs the documented Docker build-and-run steps, **Then** the application starts successfully and serves every route without requiring any change to the application code itself.
2. **Given** the containerized app is running, **When** the same core flows already demoed in every prior phase (browse, subscribe, pay with a test card, view the dashboard, use the admin panel) are exercised against it, **Then** they behave identically to how they behaved via `npm run dev`.
3. **Given** the containerized app needs its Supabase/Moyasar credentials, **When** it starts, **Then** it reads them from the environment the same documented way every prior phase's `.env.local` already established — no credentials are baked into the image itself.

---

### User Story 3 - A pipeline takes a code change from commit to a running deployment safely (Priority: P1)

Every change pushed to the project automatically runs linting, type-checking, the unit test suite, and a production build — and, once that passes, an actual deploy process takes the resulting container to the live environment, so shipping a change is a repeatable, verified process rather than a manual, ad-hoc one.

**Why this priority**: Nothing like this has existed at any point in the previous eight phases (every one of them was verified by hand, phase by phase) — without it, this phase's own hardening work has no way to stay enforced on the very next change made after launch.

**Independent Test**: Can be fully tested by pushing a change that intentionally fails one of the checks (e.g., a type error) and confirming the pipeline blocks it before deploy, then pushing a valid change and confirming it passes every check and results in the live environment actually running the new code — delivers a complete, verifiable commit-to-live pipeline independent of every other story.

**Acceptance Scenarios**:

1. **Given** a code change is pushed, **When** the pipeline runs, **Then** it executes linting, type-checking, the unit test suite, and a production build, in that order, and reports a clear pass/fail result.
2. **Given** any one of those checks fails, **When** the pipeline evaluates the change, **Then** the change is blocked from deploying — a failing build never reaches the live environment.
3. **Given** every check passes, **When** the deploy step runs, **Then** the live environment ends up running the exact code that was just verified, with no manual, unverified step in between.
4. **Given** a deploy has just completed, **When** the team performs a rollback as a deliberate test during this phase, **Then** the live environment is actually restored to the previous known-good version, confirmed by observation — not merely by a documented procedure that's never been run.

---

### User Story 4 - The team knows when something breaks in production (Priority: P1)

Once live, the team is notified when the application errors, becomes unreachable, or a payment/renewal cycle fails — rather than finding out from a customer complaint, since this is the first point in the project where "production" exists as a distinct, unattended environment at all.

**Why this priority**: Phase 7 built an unattended renewal engine that charges real money on a schedule with no human present — launching it live with no visibility into whether it's actually succeeding is the specific, named operational risk this story closes.

**Independent Test**: Can be fully tested by deliberately triggering a server error, an application-down condition, and a failed renewal charge in a controlled way, and confirming each one produces a visible signal the team can actually see — delivers a complete, verifiable "we would know" independent of every other story.

**Acceptance Scenarios**:

1. **Given** the live application throws an unhandled server-side error, **When** it happens, **Then** the team receives a record of it with enough context (which route, what error) to investigate, without needing to reproduce it blind.
2. **Given** the live application becomes unreachable, **When** that happens, **Then** the team is notified within 5 minutes rather than discovering it only when someone happens to check.
3. **Given** a scheduled renewal cycle (Phase 7) results in a subscription being automatically suspended after exhausting its retry schedule, **When** that happens, **Then** it's visible to the team as an aggregate signal (not just buried in one customer's own record), since a rising suspension rate is exactly the kind of trend that needs a human to notice.

---

### User Story 5 - The team safely cuts over from test to live payment credentials (Priority: P1)

The team replaces every `pk_test_`/`sk_test_` Moyasar credential used throughout every prior phase with real, live production credentials, through a deliberate, documented switch-over step — and proves the switch actually works by completing one real, minimal-amount live transaction, rather than assuming configuration alone is sufficient.

**Why this priority**: Every phase from 5 through 8 was built and explicitly constrained to test-mode credentials only (`plan.md`'s own repeated rule: "never mix test and live credentials") — this is the one deliberate, closely-controlled moment in the whole project where that constraint is lifted, and getting it wrong (e.g., leaving a test key live, or a live key active during further testing) has direct financial consequences.

**Independent Test**: Can be fully tested by following the documented cutover procedure end to end in the live environment and confirming a single real card can complete one real, minimal-amount transaction that appears correctly in the live Moyasar dashboard and in the application's own payment records — delivers a complete, verifiable live-payments capability independent of every other story.

**Acceptance Scenarios**:

1. **Given** the live environment is about to go live, **When** the team performs the credential cutover, **Then** every Moyasar credential in use (publishable key, secret key, webhook secret) is the live production value, and the previous test-mode values are no longer active anywhere in the live environment.
2. **Given** the cutover is complete, **When** the team completes one real, minimal-amount transaction with a real card, **Then** it succeeds, is correctly recorded in the application's own payment records, and appears in the live Moyasar dashboard — proving the live credential pair actually authorizes a real charge, not just that it's configured.
3. **Given** the live credential cutover has happened, **When** anyone inspects the live environment's configuration afterward, **Then** no test-mode Moyasar credential remains present anywhere reachable by the live application.

---

### User Story 6 - The whole app is verified end-to-end for consistency and performance (Priority: P2)

Across every screen built in Phases 0 through 8, the team confirms a real error state, loading state, and empty state exists (not a broken page or an infinite spinner), reviews every Arabic string for correctness and RTL layout, and confirms the primary customer-facing pages meet the project's own committed Core Web Vitals budget on mid-tier mobile hardware.

**Why this priority**: Every one of these screens already works as demoed phase-by-phase, so this is a polish/consistency pass rather than a correctness gap of the kind User Story 1 closes — valuable for a good launch, but the product functions without it, unlike the other stories in this phase.

**Independent Test**: Can be fully tested by walking every screen built across all eight prior phases while deliberately forcing each of the three states (a network failure, a slow response, and a genuinely empty data set) and confirming each renders a real, non-broken state; separately, running a mobile Lighthouse pass against the home, browse, subscription builder, and dashboard pages and confirming the constitution's own committed budget (LCP < 2.5s, INP < 200ms, CLS < 0.1) is met — delivers a complete, verifiable consistency/performance pass independent of every other story.

**Acceptance Scenarios**:

1. **Given** any screen built in a prior phase, **When** its data fails to load, **Then** it shows a real, specific error state rather than a blank page or an unhandled crash.
2. **Given** any screen built in a prior phase, **When** its data is still loading, **Then** it shows a real loading indicator rather than a flash of empty/broken layout.
3. **Given** any screen built in a prior phase, **When** the data it would show is genuinely empty (no orders yet, no products in a category, etc.), **Then** it shows a real, purpose-written empty state rather than an unstyled blank area.
4. **Given** every Arabic string surfaced anywhere in the app (customer-facing and admin-facing), **When** it's reviewed, **Then** it's correct, consistent in tone, and renders correctly in the app's RTL layout — any issue found is corrected.
5. **Given** the home, browse, subscription builder, and dashboard pages, **When** measured on mid-tier mobile hardware, **Then** each meets the constitution's committed budget (LCP < 2.5s, INP < 200ms, CLS < 0.1) — any page that doesn't is fixed until it does.

---

### User Story 7 - A go/no-go checklist gates the actual public launch (Priority: P1)

Before the team announces the product is live, a single, explicit checklist confirms every other story in this phase has actually been completed — security audit resolved, container verified, pipeline green, monitoring live, payment cutover proven, consistency/performance pass done — so "launch" is a deliberate, verified decision rather than an assumption that everything upstream must have gone fine.

**Why this priority**: This is the actual gate the whole phase exists to produce — the phase's own stated demo target ("the live URL, on a phone, in Arabic, with a real card") is only meaningful once this checklist confirms every precondition behind it is true, so it's the phase's own final, load-bearing deliverable.

**Independent Test**: Can be fully tested by walking the checklist itself against the live environment and confirming every item is either checked with verifiable evidence (a link to the passing pipeline run, the audit's findings log, the live transaction's record) or explicitly and knowingly deferred as documented non-blocking follow-up — delivers a complete, verifiable launch decision independent of re-deriving each story's own verification from scratch.

**Acceptance Scenarios**:

1. **Given** the checklist is being completed, **When** each item is checked off, **Then** it's backed by concrete evidence (a passing pipeline run, a recorded audit finding resolved, a real transaction id) rather than an unverified assumption.
2. **Given** any checklist item is not yet satisfied, **When** the team reviews the checklist, **Then** launch does not proceed until it's either satisfied or explicitly, knowingly accepted as non-blocking follow-up (per User Story 1's severity-triage rule) by whoever owns the launch decision.
3. **Given** every item is satisfied or explicitly accepted, **When** the team makes the launch decision, **Then** the live URL is reachable, in Arabic, on a mobile device, and capable of completing a real transaction — the phase's own demo target, now provably true rather than assumed.

---

### Edge Cases

- What happens when the RLS/validation/webhook audit (User Story 1) finds a launch-blocking issue close to the planned launch date? Launch is delayed until it's fixed — per the clarification session, only non-blocking findings may ship as follow-up work; a blocking finding is never knowingly shipped.
- What happens if the containerized app (User Story 2) behaves differently from the `npm run dev` version in some way? That's treated as a bug in the container packaging to fix, not an acceptable discrepancy — the whole point of this story is that containerization changes nothing about application behavior.
- What happens if the CI pipeline (User Story 3) itself is flaky (intermittently fails for reasons unrelated to the actual code change)? It's treated as a defect in the pipeline to fix, since a pipeline the team learns to routinely override or ignore stops providing the safety guarantee it exists for.
- What happens if the live-payment smoke test (User Story 5) fails? The team does not consider the cutover complete or proceed to public launch until a real transaction succeeds — a failed live smoke test is exactly what this story exists to catch before real customers encounter it.
- What happens to the one real live transaction used to prove the cutover (User Story 5)? It's a real, minimal-amount charge with real financial effect (per the clarification session) — the team is expected to handle it like any other real transaction (visible in the live Moyasar dashboard and the app's own records), not to treat it as consequence-free.
- What happens when a non-blocking finding from User Story 1 or 6 is deferred past launch — is it tracked anywhere? Yes — it's documented as known follow-up work as part of the audit's own findings log, not silently dropped, so it remains visible after launch even though it didn't block it.
- What happens if monitoring (User Story 4) itself goes down or stops reporting? This is the one meta-risk this phase's own scope doesn't fully close (monitoring the monitoring is a deeper operational maturity than a first launch needs) — documented as an assumption/limitation rather than a requirement this phase must solve.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST have every table's Row Level Security policy reviewed against that table's own originally-documented authorization intent (owner-only, admin-only, or service-role-only, per each prior phase's own data model), with every mismatch recorded and assigned a severity.
- **FR-002**: System MUST have every Route Handler's request-body/params validation reviewed to confirm it validates at the boundary rather than trusting client-side validation alone, with every gap recorded and assigned a severity.
- **FR-003**: System MUST confirm the Moyasar webhook endpoint rejects a request with a missing or invalid signature before trusting any part of its payload, and MUST confirm a redelivered/duplicate valid event is processed as a safe no-op.
- **FR-004**: System MUST resolve every audit finding (FR-001/002/003) capable of leaking another customer's data, permitting an unauthorized write, or breaking a core purchase/payment flow before launch; every other finding MUST be documented as known, non-blocking follow-up work rather than silently dropped.
- **FR-005**: System MUST build and run successfully from its own `Dockerfile`/`docker-compose.yml` from a clean checkout, serving every route the `npm run dev` version already serves, with credentials supplied via environment configuration rather than baked into the built image.
- **FR-006**: System MUST behave identically when accessed through the containerized version as it does via `npm run dev` for every core flow already demoed in Phases 0–8 (browse, subscribe, pay, dashboard, admin panel).
- **FR-007**: System MUST run linting, type-checking, the unit test suite, and a production build automatically on every code change, and MUST block that change from deploying if any of those checks fail.
- **FR-008**: System MUST deploy only a change that has passed every check in FR-007, with no manual, unverified step between a passing pipeline run and what actually runs in the live environment.
- **FR-009**: System MUST provide a way to return the live environment to its previous known-good version after a deploy, and this rollback MUST be actually exercised once during this phase — not merely documented — with the team confirming it correctly restores the previous version.
- **FR-010**: System MUST notify the team when the live application throws an unhandled server-side error, with enough context to identify which route/request produced it.
- **FR-011**: System MUST notify the team within 5 minutes of the live application becoming unreachable.
- **FR-012**: System MUST make the rate of automatically-suspended subscriptions (Phase 7's dunning outcome) visible as an aggregate operational signal, not only inside each individual customer's own record.
- **FR-013**: System MUST support replacing every Moyasar test-mode credential (publishable key, secret key, webhook secret) with live production values in the live environment through one deliberate, documented procedure, and MUST leave no test-mode credential active anywhere in the live environment afterward.
- **FR-014**: System MUST be proven to accept one real, minimal-amount live transaction after the credential cutover, correctly recorded both in the application's own payment records and in the live Moyasar dashboard, before the cutover is considered complete.
- **FR-015**: System MUST have every screen built in Phases 0–8 reviewed for a real error state, a real loading state, and a real empty state, with every gap found corrected before launch.
- **FR-016**: System MUST have every Arabic string surfaced anywhere in the app reviewed for correctness, consistent tone, and correct RTL rendering, with every issue found corrected before launch.
- **FR-017**: System MUST have the home, browse, subscription-builder, and dashboard pages verified against the constitution's committed mobile Core Web Vitals budget (LCP < 2.5s, INP < 200ms, CLS < 0.1), with any page that doesn't meet it fixed until it does.
- **FR-018**: System MUST have a single go/no-go launch checklist that enumerates every requirement in this specification, where each item is either backed by concrete verification evidence or explicitly accepted as non-blocking follow-up by whoever owns the launch decision, before the team treats the product as launched.

### Key Entities

- **Audit Finding** *(new, this phase only — a record, not a customer-facing entity)*: One discrepancy found during the RLS/validation/webhook/UX audits (User Stories 1 and 6) — what was found, where, its severity (blocking vs. non-blocking), and its resolution (fixed before launch, or accepted as documented follow-up).
- **Deployment** *(new, operational concept)*: One instance of the pipeline (User Story 3) taking a verified code change to the live environment — what was deployed, when, and the previous version it can roll back to.
- **Live Transaction Record** *(existing `Payment` entity from Phase 5/7, one specific real-money instance)*: The one real, minimal-amount transaction proving the live Moyasar cutover (User Story 5) — same shape as every other payment record already established, distinguished only by being the first to use live credentials.
- **Launch Checklist** *(new, this phase's own final deliverable)*: The single document gating public launch (User Story 7) — one line per requirement in this specification, each resolved to either verified-complete (with evidence) or explicitly-deferred-non-blocking.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 100% of audit findings (RLS, validation, webhook) capable of exposing another customer's data or permitting an unauthorized write are resolved before launch — zero known launch-blocking security gaps remain open at launch.
- **SC-002**: The containerized application serves 100% of the routes and core flows the `npm run dev` version serves, with no functional discrepancy between the two.
- **SC-003**: 100% of code changes reaching the live environment have passed lint, type-check, unit tests, and a production build first — no change reaches production having skipped the pipeline.
- **SC-003a**: A rollback is performed at least once during this phase and observably restores the live environment to its previous known-good version — not merely documented as a theoretical procedure.
- **SC-004**: A deliberately-triggered production error and a suspended-subscription trend are each detected and visible to the team without a customer having to report it first; a deliberately-triggered application-down condition is detected and notified to the team within 5 minutes.
- **SC-005**: One real, minimal-amount live transaction completes successfully and is correctly recorded in both the application and the live Moyasar dashboard, proving the live credential cutover works — not merely that it's configured.
- **SC-006**: Every screen built across Phases 0–8 shows a real error, loading, and empty state — none are observed to show a blank page, an unhandled crash, or an infinite spinner during this phase's own verification pass.
- **SC-007**: The home, browse, subscription-builder, and dashboard pages each meet the constitution's committed mobile Core Web Vitals budget.
- **SC-008**: The launch checklist's every item is either backed by verifiable evidence or explicitly accepted as non-blocking follow-up before the team declares the product launched — the phase's own demo target (the live URL, on a phone, in Arabic, completing a real transaction) is achieved and independently verifiable, not merely believed to be true.

## Assumptions

- Per the clarification session, this phase deploys to a single Docker host running the project's own already-committed `docker-compose.yml` (e.g. a VPS or a managed single-container hosting service) — not a container-orchestration platform (Kubernetes, ECS, etc.) or a platform-specific serverless deployment model, since introducing either this late would contradict the project's own consistently self-contained, single-monolith design across every prior phase.
- Per the clarification session, audit findings are severity-triaged rather than requiring 100% resolution — only findings capable of data leakage, unauthorized writes, or breaking a core purchase/payment flow block launch; everything else is documented, non-blocking follow-up work, consistent with a real launch needing to actually happen rather than chasing an unreachable "zero findings of any kind" bar.
- Per the clarification session, the live Moyasar cutover is only considered proven once one real, minimal-amount transaction succeeds — configuration alone is not sufficient evidence.
- Monitoring (User Story 4) is basic operational visibility (error tracking, uptime checking, a dunning-rate signal) appropriate for a first public launch — not a full observability platform (distributed tracing, custom dashboards, on-call rotation tooling); the specific tool/service used to provide it is a planning-level implementation detail, not constrained further here.
- "The monitoring system itself failing silently" is an accepted limitation of this phase's scope (Edge Cases) — monitoring the monitoring is a maturity level beyond what a first launch needs, and can be addressed in a future phase if it becomes a real problem.
- Per the clarification session, the rollback capability (FR-009) must be actually exercised once during this phase, not merely documented — it doesn't need to be an automated one-click action (a manual, documented procedure that the team runs and confirms works is sufficient), but it must be proven to work by actually running it at least once, not trusted on paper alone.
- This phase's Docker/CI/deploy/monitoring work targets the same single Supabase project and Moyasar account structure every prior phase already assumed (no separate staging-vs-production Supabase project split is introduced by this specification) — provisioning a fully separate staging environment, if desired, is a decision for whoever owns infrastructure, not a requirement this spec imposes.
- Every functional requirement in this phase is retrospective/verification-oriented (confirming Phases 0–8's own work) except Docker (FR-005/006), CI/deploy (FR-007/008/009), monitoring (FR-010/011/012), and the live cutover (FR-013/014) — those five are the only genuinely new capabilities this phase adds, consistent with the feature description's own framing.
