---

description: "Task list for Phase 1 — Auth & Address"
---

# Tasks: Phase 1 — Auth & Address

**Input**: Design documents from `/specs/002-phase-1-auth-address/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/ (addresses-api.md, auth-flows.md, route-protection.md), quickstart.md

**Tests**: Included — plan.md's Technical Context and research.md explicitly scope a Vitest unit
suite (phone/address validation, the default-address invariant) and a Playwright route-protection
spec as part of this phase's design, so they are generated here rather than omitted.

**Organization**: Tasks are grouped by user story (US1/US2/US3/US4, matching spec.md's priorities:
US1 = P1, US3 = P1, US2 = P2, US4 = P2). Phases below are ordered by priority — US1 and US3 (both
P1, and US3 depends on the role field US1's signup path establishes) come before the P2 stories.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3, US4)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Ensure `supabase/migrations/` exists at the repo root for this feature's schema files
- [X] T002 [P] Create the `lib/validation/` directory (destination for `auth.ts` and `address.ts` schema files added in later phases)
- [X] T003 [P] Create the `components/auth/` and `components/address/` directory scaffolds

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T004 Create migration `supabase/migrations/<timestamp>_profiles.sql`: `profiles` table (`id, full_name, phone, role, created_at`), `role` constrained to `'customer'`/`'admin'` defaulting to `'customer'`, an `AFTER INSERT` `SECURITY DEFINER` trigger on `auth.users` that populates the row from `raw_user_meta_data`, and RLS policies restricting `SELECT`/`UPDATE` to `id = auth.uid()` (no client `INSERT`/`DELETE`) — per data-model.md and research.md
- [X] T005 [P] Create `lib/validation/auth.ts`: zod schemas for signup, login, forgot-password, and reset-password payloads — valid email shape, minimum password strength, non-empty `full_name`, KSA mobile `phone` format (FR-009)
- [X] T006 [P] Create `lib/supabase/middleware.ts`: a middleware-flavored Supabase server client using `@supabase/ssr`'s split cookie handling for the middleware runtime (research.md)

**Checkpoint**: Foundation ready — `profiles` table + trigger + RLS, shared auth validation schemas, and the middleware Supabase client all exist; user story implementation can now begin.

---

## Phase 3: User Story 1 - Create an account and sign in (Priority: P1) 🎯 MVP

**Goal**: A visitor can create an account, and log in/out with a session that persists across page reloads.

**Independent Test**: Sign up with a new email/password, confirm a `profiles` row is created, log out, log back in with the same credentials — per quickstart.md steps 1–2.

### Tests for User Story 1

> Write this test FIRST; it MUST fail until the schemas in T005 fully cover these cases.

- [X] T007 [P] [US1] Write unit test `tests/unit/validation.auth.test.ts` covering signup/login schema edge cases: malformed email, weak password, empty `full_name`, invalid KSA `phone` format

### Implementation for User Story 1

- [X] T008 [P] [US1] Create `components/auth/SignupForm.tsx`: `"use client"` leaf, validates with `lib/validation/auth.ts` (T005), calls `supabase.auth.signUp` with `options.data.{full_name, phone}` per contracts/auth-flows.md, surfaces a clear "already registered" error, redirects to `/dashboard` on success
- [X] T009 [P] [US1] Create `components/auth/LoginForm.tsx`: `"use client"` leaf, validates with T005, calls `supabase.auth.signInWithPassword`, shows a generic invalid-credentials message (never confirms which field was wrong) and a distinct "too many attempts" message when Supabase's rate limiter rejects the request (FR-003a)
- [X] T010 [US1] Create `app/signup/page.tsx` rendering `SignupForm` (T008) inside the shared `components/ui/` primitives, generic layout — no mockup exists (spec.md Assumptions)
- [X] T011 [US1] Replace Phase 0's disabled placeholder in `app/login/page.tsx` with `LoginForm` (T009)
- [X] T012 [US1] Add a sign-out action calling `supabase.auth.signOut()` (redirect to `/` on completion) into `components/ui/TopNav.tsx`
- [X] T013 [US1] Update `components/ui/TopNav.tsx` to reflect signed-in state (name + sign-out vs. a login link) by reading the session from the server Supabase client

**Checkpoint**: User Story 1 is fully functional and independently testable — signup, login, logout, persisted session.

---

## Phase 4: User Story 3 - Land in the right place based on role (Priority: P1)

**Goal**: Signed-out visitors are sent to log in, customers reach `/subscription`/`/dashboard` but not `/admin`, admins reach `/admin`.

**Independent Test**: Attempt `/dashboard`, `/subscription`, and `/admin` as a signed-out visitor, a signed-in customer, and a signed-in admin, and confirm each gets the matrix outcome in contracts/route-protection.md — per quickstart.md step 5.

### Tests for User Story 3

> Write this test FIRST; it MUST fail until `middleware.ts` (T015) exists.

- [X] T014 [P] [US3] Write Playwright test `tests/e2e/route-protection.spec.ts` covering the full matrix in contracts/route-protection.md (signed-out / customer / admin × `/subscription`, `/dashboard`, `/admin`)

### Implementation for User Story 3

- [X] T015 [US3] Create root `middleware.ts`: refresh the session via `lib/supabase/middleware.ts` (T006), resolve `role` from `profiles` (T004), and enforce the route matrix from contracts/route-protection.md — redirect signed-out visitors to `/login?redirect=<path>`, deny signed-in customers from `/admin` (redirect to `/dashboard`), allow admins
- [X] T016 [US3] Update `LoginForm.tsx` (T009) to read the `redirect` query param and navigate there after a successful login instead of the default `/dashboard`

**Checkpoint**: User Stories 1 AND 3 both work — full account creation + role-based routing.

---

## Phase 5: User Story 2 - Recover a forgotten password (Priority: P2)

**Goal**: A user who forgot their password can request a reset, complete it, and log in with the new password.

**Independent Test**: Request a reset for a known account, complete the reset flow with a new password, log in with it — per quickstart.md step 4.

### Tests for User Story 2

- [X] T017 [US2] Extend `tests/unit/validation.auth.test.ts` (T007) with forgot-password / reset-password schema edge cases

### Implementation for User Story 2

- [X] T018 [P] [US2] Create `components/auth/ForgotPasswordForm.tsx`: `"use client"` leaf, calls `supabase.auth.resetPasswordForEmail` with `redirectTo` set to `/reset-password`, always shows the same non-enumerating confirmation message (FR-006) regardless of whether the email is registered
- [X] T019 [P] [US2] Create `components/auth/ResetPasswordForm.tsx`: `"use client"` leaf, calls `supabase.auth.updateUser({ password })`, handles the expired/already-used link case with a "no longer valid" message linking back to `/forgot-password`
- [X] T020 [US2] Create `app/forgot-password/page.tsx` rendering `ForgotPasswordForm` (T018)
- [X] T021 [US2] Create `app/reset-password/page.tsx` rendering `ResetPasswordForm` (T019), redirecting to `/login` with a success message on completion

**Checkpoint**: Password recovery is functional independently of the other stories.

---

## Phase 6: User Story 4 - Manage delivery addresses (Priority: P2)

**Goal**: A signed-in customer can create, edit, delete, and default their delivery addresses, choosing from admin-managed active cities.

**Independent Test**: Add an address, edit it, add a second and mark it default, delete the first — per quickstart.md step 6, plus the cross-user isolation check in step 7.

### Tests for User Story 4

- [X] T022 [P] [US4] Write unit test `tests/unit/validation.address.test.ts` covering address payload edge cases: empty `label`/`district`/`streetDetails`, invalid `cityId`
- [X] T023 [P] [US4] Write unit test `tests/unit/address-default.test.ts` covering the default-address invariant: auto-default on a customer's first address (FR-015), unset-previous-on-new-default (FR-014), no auto-promotion after deleting the default (data-model.md State Transitions)

### Implementation for User Story 4

- [X] T024 Create migration `supabase/migrations/<timestamp>_cities.sql`: `cities` table (`id, name_ar, is_active, delivery_fee_override`), RLS (public read, no non-admin write policy), seed ≥1 active city — per data-model.md
- [X] T025 Create migration `supabase/migrations/<timestamp>_addresses.sql`: `addresses` table (`id, user_id, label, city_id, district, street_details, is_default, created_at`), the partial unique index `addresses_one_default_per_user` (`ON addresses (user_id) WHERE is_default`), and owner-only RLS (`user_id = auth.uid()` for all of SELECT/INSERT/UPDATE/DELETE) — depends on T004, T024
- [X] T026 [P] [US4] Create `lib/validation/address.ts`: zod schema for the address create/update payload (`label`, `cityId` as uuid, `district`, `streetDetails` required; `isDefault` optional boolean)
- [X] T027 [US4] Create `lib/store/addressesApi.ts`: RTK Query slice (list/create/update/delete) against `/api/addresses` per contracts/addresses-api.md — depends on T025
- [X] T028 [US4] Register the `addressesApi` reducer/middleware in `lib/store/index.ts` — depends on T027
- [X] T029 [US4] Implement `app/api/addresses/route.ts`: `GET` (list the caller's own addresses), `POST` (create, auto-default when it's the caller's first address) per contracts/addresses-api.md — depends on T025, T026
- [X] T030 [US4] Implement `app/api/addresses/[id]/route.ts`: `PATCH` (edit fields and/or set default via the unset-previous-then-set-new transaction from data-model.md), `DELETE` — both scoped to the owner, returning `404` (not `403`) on not-found/not-owned — depends on T025, T026
- [X] T031 [P] [US4] Create `components/address/AddressCard.tsx`: presentational card — label, city name, district, street details, default badge, edit/delete/set-default actions
- [X] T032 [US4] Create `components/address/AddressForm.tsx`: `"use client"` leaf, create/edit form wired to `addressesApi` (T027) mutations, validated with T026's schema
- [X] T033 [US4] Create `components/address/AddressList.tsx`: Server Component reading the caller's addresses via the server Supabase client, rendering `AddressCard` (T031) entries plus an entry point into `AddressForm` (T032) for adding a new address
- [X] T034 [US4] Wire the address book into `app/dashboard/settings/page.tsx`, replacing Phase 0's placeholder, structurally referencing `design/settings.html`'s address cards — depends on T032, T033

**Checkpoint**: All 4 user stories are independently functional.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all four stories

- [X] T035 [P] Run the full `quickstart.md` validation (all 8 steps) end to end
- [X] T036 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed files (Constitution Development Workflow gate)
- [X] T037 Manual RLS spot-check: as one signed-in user, attempt to read/write another user's `addresses`/`profiles` rows directly and confirm zero rows are returned/affected (Constitution Principle V; quickstart.md step 7 covers the API-layer version, this covers the RLS layer directly) — run against the live linked project with two disposable test accounts (created via the Auth Admin API, deleted after). Found and fixed a real gap: a normal user could PATCH their own `profiles.role` to `'admin'` directly via the REST API (RLS restricts rows, not columns) — closed with a `BEFORE UPDATE` trigger (`supabase/migrations/20260810120300_profiles_role_immutable.sql`, scoped to non-service-role sessions in `20260810120400_profiles_role_immutable_scope.sql`). Addresses cross-user SELECT/UPDATE/DELETE all confirmed to return zero rows.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only
- **User Story 3 (Phase 4, P1)**: Depends on Foundational; in practice also needs `LoginForm` (T009) from US1 to wire the post-login redirect (T016), so implement after US1
- **User Story 2 (Phase 5, P2)**: Depends on Foundational only — independently testable without US1/US3, though it reuses `lib/validation/auth.ts` (T005)
- **User Story 4 (Phase 6, P2)**: Depends on Foundational (`profiles`, for the `addresses.user_id` FK) — independently testable without US1/US2/US3 once a test account exists
- **Polish (Phase 7)**: Depends on all four user stories being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories — true MVP starting point
- **US3 (P1)**: Reads `profiles.role` (from Foundational) and extends `LoginForm.tsx` (from US1) — implement after US1
- **US2 (P2)**: No dependencies on other stories; can be built in parallel with US3 by a second developer
- **US4 (P2)**: No dependencies on other stories; needs a signed-in test account (from US1) to exercise manually, but no US1 code is imported

### Within Each User Story

- Tests written and failing before implementation
- Migrations before Route Handlers/services that query the new tables
- Validation schemas before the forms/handlers that use them
- Server-side pieces (migrations, Route Handlers) before the client components that call them
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- All Setup tasks marked [P] (T002, T003) can run in parallel after T001
- T005 and T006 (Foundational) can run in parallel; T004 (migration) is independent of both
- Once Foundational completes: US1 and US2 can be staffed in parallel (US2 only reuses T005, doesn't touch US1's files); US4 can also start in parallel once a test account exists for manual verification
- US3 should start after US1's `LoginForm.tsx` exists, to avoid two developers editing the same file
- Within US1: T008 and T009 (different files) in parallel; T007 (test) in parallel with both
- Within US2: T018 and T019 (different files) in parallel
- Within US4: T022/T023 (tests) in parallel; T024/T025 migrations are sequential (FK dependency); T026 and T031 in parallel with each other and with the migrations

---

## Parallel Example: User Story 1

```bash
# Launch the test and both form components together (different files):
Task: "Write unit test tests/unit/validation.auth.test.ts covering signup/login schema edge cases"
Task: "Create components/auth/SignupForm.tsx"
Task: "Create components/auth/LoginForm.tsx"
```

## Parallel Example: User Story 4

```bash
# Launch both test files together:
Task: "Write unit test tests/unit/validation.address.test.ts"
Task: "Write unit test tests/unit/address-default.test.ts"

# Launch the validation schema and the presentational card together:
Task: "Create lib/validation/address.ts"
Task: "Create components/address/AddressCard.tsx"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: quickstart.md steps 1–2 pass independently
5. Demo: create an account, log in

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US1 → validate → demo (MVP: signup/login/logout)
3. Add US3 → validate → demo (adds correct role-based redirects — this is the phase's headline "get redirected correctly by role" demo target from `plan.md` §4)
4. Add US2 → validate → demo (adds self-service password recovery)
5. Add US4 → validate → demo (adds the address book — completes the full Phase 1 demo: "create an account, log in, add a delivery address, get redirected correctly by role")
6. Phase 7 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes:
- Developer A: US1, then US3 (sequential — US3 extends US1's `LoginForm.tsx`)
- Developer B: US2 (independent of US1/US3's files)
- Developer C: US4 (independent — only needs a test account, created manually or via US1 once available)

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Migrations (T004, T024, T025) are not marked [P] against each other where an FK dependency
  exists (`addresses.user_id → profiles.id`, `addresses.city_id → cities.id`)
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
