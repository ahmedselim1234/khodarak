# Feature Specification: Phase 8 — Admin Operations

**Feature Branch**: `009-phase-8-admin-operations`

**Created**: 2026-08-11

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for Phase 8" — scoped from `plan.md` §4 "Phase 8 — Admin Operations": subscriptions list + detail + manual pause/cancel, orders list with status transitions, payments list, cities/delivery zones management, basic counters dashboard. Also draws on `plan.md` §1's "Admin Panel" function inventory. Demo target: "process an order from pending to delivered as an operator, and see it reflect on the customer's side." Per `plan.md` §0.B: no mockup exists for `/admin` — this phase builds using the same design-system tokens (colors, `organic` radius, typography) and standard admin-panel conventions (data tables, filters, detail drawers) already established by Phase 2's product-CRUD admin screens, the first and only precedent so far. This is explicitly the first phase where subscriptions, orders, and payments — all customer-owned data since Phase 4/5/6/7 — become visible and actionable from an operator's perspective; every one of those phases' own specs deferred exactly this to "Phase 8's concern."

## Clarifications

### Session 2026-08-11

- Q: When an admin manually pauses or cancels a customer's subscription (a support/fraud action, distinct from the customer's own Phase 6 self-service controls), must a reason be recorded? → A: Yes — a short required reason/note is captured with every admin-initiated pause or cancel, kept as part of that action's own record, so support has an audit trail explaining why a customer's subscription changed state without the customer having done it themselves.
- Q: Can an admin set an order's status to any value at any time, or must transitions follow a defined forward progression? → A: A defined, enforced progression only — pending → out_for_delivery → delivered is the forward path, and cancellation is allowed from pending or out_for_delivery but not from delivered; no other transition (including moving backward) is permitted, so an order's history can't become internally inconsistent (e.g. "delivered" reverting to "pending").
- Q: When an admin manually pauses a subscription, does the admin choose a resume date (like a customer's own pause) or is it indefinite (like Phase 7's automatic dunning suspension) by default? → A: The admin may optionally choose a resume date, defaulting to indefinite (no resume date, requiring explicit resume) if left blank — giving support the same flexibility for a "pause for two weeks while we sort this out" case as for an open-ended hold, without forcing a date when none is known yet.
- Q: How does an operator locate a specific customer's subscription or orders — by searching customer name/email/phone, or only by browsing filtered by status/date? → A: Add customer search — subscriptions, orders, and payments lists each gain a search box matching customer name, email, or phone, alongside their existing status/date filters.
- Q: Do admin-initiated actions (order status changes, subscription pause/cancel) record which staff member performed them, or only that the action happened plus the reason text? → A: Every order status change and every admin-initiated pause/cancel is stamped with the id of the acting admin, alongside the existing timestamp (and, for pause/cancel, the reason) — full "who did this and why" accountability, not just "what happened."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Process an order from pending to delivered (Priority: P1)

An operator opens the orders list, finds today's orders, and updates each one's status as it physically moves through fulfillment — pending, then out for delivery, then delivered — with each change immediately visible to the customer on their own existing order-history view.

**Why this priority**: This is the phase's own explicitly stated demo target and the single piece of functionality that makes every order Phase 5 and Phase 7 have been generating actually mean something operationally — without it, every order ever generated stays permanently `pending` no matter what actually happens to it.

**Independent Test**: Can be fully tested by opening the orders list, filtering to today's pending orders, advancing one through out_for_delivery to delivered, and confirming both the admin list and the same order's existing customer-facing detail view (Phase 6) show the updated status — delivers a complete, verifiable status-transition loop independent of every other admin capability.

**Acceptance Scenarios**:

1. **Given** an operator viewing the orders list, **When** they filter by status and/or date, **Then** they see only orders matching those filters, each showing its customer, scheduled date, status, and total.
2. **Given** a `pending` order, **When** the operator advances it to `out_for_delivery`, **Then** the change is saved immediately and reflected the next time anyone (operator or the owning customer) views that order.
3. **Given** an `out_for_delivery` order, **When** the operator advances it to `delivered`, **Then** the order's delivered timestamp is recorded and its status becomes final for the normal fulfillment path.
4. **Given** an order not yet `delivered`, **When** the operator cancels it instead, **Then** its status becomes `cancelled` and it's excluded from any further fulfillment action.
5. **Given** a `delivered` order, **When** the operator attempts any further status change, **Then** it's rejected — a delivered order's status is final, and no path exists back to an earlier status.

---

### User Story 2 - View and manage a customer's subscription as support (Priority: P1)

An operator handling a support request or fraud concern finds a specific customer's subscription, reviews its full state (items, frequency, next delivery, price, payment/dunning history), and — when the situation calls for it — pauses or cancels it directly, leaving a reason on record.

**Why this priority**: Support and fraud intervention is a routine operational need for any subscription business, and until this phase an operator has no way to see or act on a customer's subscription at all — every control past Phase 4 has been customer-only. Ranks alongside order fulfillment as the phase's core value.

**Independent Test**: Can be fully tested by opening the subscriptions list, searching by that customer's name/email/phone to find their subscription, opening its detail view to confirm every relevant field is visible, then pausing it with a reason and confirming the customer's own dashboard (Phase 6) reflects the change — delivers a complete, verifiable admin-intervention loop independent of order fulfillment.

**Acceptance Scenarios**:

1. **Given** an operator viewing the subscriptions list, **When** they filter by status and/or search by a customer's name, email, or phone, **Then** they see only subscriptions matching those criteria, each showing its customer, frequency, next delivery date, and status.
2. **Given** an operator opens one subscription's detail, **When** the detail loads, **Then** they see its items, frequency, next delivery date, current price breakdown, delivery address, the customer's payment history for it, and — if applicable — its current dunning/retry state from Phase 7.
3. **Given** an operator pauses an active subscription, **When** they submit the action, **Then** they must provide a short reason before it's accepted, the subscription's status becomes `paused` (with the chosen resume date, or indefinite if none was chosen), and the customer sees this reflected on their own dashboard exactly as if they'd paused it themselves — except the recorded reason is visible only to admins, not the customer.
4. **Given** an operator cancels a subscription, **When** they submit the action, **Then** they must provide a short reason before it's accepted, the subscription's status becomes `cancelled` permanently (consistent with Phase 6's own terminal-cancellation rule — no reactivation), and it stops appearing as active on the customer's dashboard.
5. **Given** an operator attempts to pause or cancel a subscription that's already in that state, **When** they try, **Then** they're told its current state rather than allowed to submit a redundant or contradictory action.

---

### User Story 3 - See business health at a glance (Priority: P2)

An operator opens `/admin` and immediately sees how many subscriptions are currently active, how many orders are scheduled for today, and how much revenue has come in this month — without navigating anywhere else first.

**Why this priority**: Valuable orientation for daily operations, but the business already functions correctly without it (every underlying number is derivable by an operator manually browsing the lists from User Stories 1 and 2) — it's a convenience layer, not a functional gap, so it ranks behind the two stories that add real operational capability.

**Independent Test**: Can be fully tested by opening `/admin` and confirming the three counters match independently-verifiable totals (a manual count of active subscriptions, a manual count of today's orders, a manual sum of this month's successful payments) — delivers a verifiable read-only overview independent of any list or detail view.

**Acceptance Scenarios**:

1. **Given** an operator opens `/admin`, **When** the page loads, **Then** they see the current count of active subscriptions, the count of orders scheduled for today, and total revenue collected this calendar month, each labeled clearly.
2. **Given** the underlying data changes (a new subscription activates, an order is scheduled, a payment succeeds), **When** the operator next opens or refreshes `/admin`, **Then** the counters reflect the change — they are not cached indefinitely or only updated on a schedule.

---

### User Story 4 - Review payment activity across all customers (Priority: P2)

An operator investigating a billing question or dunning pattern opens a payments list spanning every customer, filters it, and sees each attempt's amount, outcome, failure reason, and which attempt number it was for its cycle.

**Why this priority**: This is the specific "operational visibility into renewal/dunning activity" that both Phase 6 and Phase 7's own specs explicitly named and deferred to this phase — necessary for diagnosing real billing problems at scale, but narrower in day-to-day use than order fulfillment or subscription support, so it ranks alongside the counters dashboard.

**Independent Test**: Can be fully tested by opening the payments list, filtering by status, and confirming every visible attempt's amount/status/failure reason/attempt number matches the underlying record, across more than one customer — delivers a complete, verifiable cross-customer read view independent of every other story.

**Acceptance Scenarios**:

1. **Given** an operator viewing the payments list, **When** they filter by status (succeeded/failed) or a date range, **Then** they see only matching attempts, each showing the customer, amount, outcome, failure reason (if failed), attempt number, and whether it was an initial or renewal charge.
2. **Given** a failed renewal attempt tied to a subscription currently mid-retry-schedule (Phase 7), **When** the operator views it, **Then** it's clear which cycle and which attempt number it represents, consistent with what Phase 7 itself recorded.

---

### User Story 5 - Manage delivery cities and zones (Priority: P3)

An operator adds a new serviceable city, adjusts an existing city's delivery fee override, or deactivates a city that's no longer served — all from an admin screen, where previously this data could only be seeded directly in the database.

**Why this priority**: Necessary for the business to actually expand or adjust its service area over time, but the cities table already has working data since Phase 1 and nothing about the rest of the system is blocked without an admin UI for it — it's the smallest, most self-contained piece of this phase.

**Independent Test**: Can be fully tested by adding a new city, confirming it appears as a selectable option in the existing customer-facing address form (Phase 1) once active, then deactivating it and confirming it's no longer offered to new addresses — delivers a complete, verifiable CRUD loop independent of every other story.

**Acceptance Scenarios**:

1. **Given** an operator on the cities screen, **When** they add a new city with a name and optional delivery fee override, **Then** it's saved and, once marked active, becomes selectable on the customer-facing address form.
2. **Given** an operator edits an existing city's delivery fee override, **When** they save it, **Then** future price calculations for addresses in that city use the new value — consistent with the pricing engine's existing per-city fee resolution (Phase 3), never applied retroactively to already-snapshotted orders.
3. **Given** an operator deactivates a city, **When** they save it, **Then** it's no longer offered as an option for a new or edited address, but existing addresses already using it remain valid and unaffected (consistent with Phase 1's own established rule for a since-deactivated city).

---

### Edge Cases

- What happens when an operator tries to advance an order's status but the order was already advanced (or cancelled) by another operator moments earlier? The second attempt sees the order's actual current status and the same forward-progression rule applies from there — no silent overwrite, no error that hides what actually happened.
- What happens when an operator pauses a subscription that's currently mid-retry-schedule from Phase 7's dunning engine? The pause takes effect immediately, exactly like a customer's own pause overriding a locked delivery (Phase 6/7's existing rule) — any pending retry is abandoned, consistent with pause already being the one action that bypasses cutoff/retry locks.
- What happens when an operator cancels a subscription that's currently `paused` (whether customer-initiated or a Phase 7 auto-suspension)? Cancellation is allowed from any non-cancelled state and is immediately terminal, matching Phase 6's own cancel rule.
- What happens when an operator tries to reactivate a `cancelled` subscription? Not offered — cancellation is permanent per Phase 6's own established rule, unchanged by this phase; the customer (or an operator on their behalf) would need to start a new subscription.
- What happens to the reason recorded on an admin pause/cancel — is it ever shown to the customer? No — it's an internal record for admin/support use only, never surfaced on the customer's own dashboard, so an operator can write it candidly (e.g. "possible fraud, hold pending review") without it appearing in a customer-facing screen.
- What happens when an operator deactivates a city that existing active subscriptions' addresses reference? Those subscriptions and their addresses are unaffected — deactivating only removes the city from selection for new/edited addresses, never invalidates existing ones, and no existing subscription is paused or altered as a side effect of a city change.
- What happens when the counters dashboard is viewed while a Phase 7 renewal job is actively mid-run? The counters reflect whatever is true in the data at the moment of viewing — a partially-completed batch run simply means some of today's renewals aren't reflected yet, not an inconsistent or broken count.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST restrict every screen and action described in this specification to signed-in users with the admin role, consistent with the existing `/admin` route-protection rule established in Phase 1 — a non-admin MUST be denied exactly as already happens for the existing product/settings admin screens.
- **FR-002**: System MUST show operators a list of every order across all customers, filterable by status and by date and searchable by the owning customer's name, email, or phone, each row showing customer, scheduled date, status, and total.
- **FR-003**: System MUST let an operator advance an order's status only along the defined forward progression (`pending` → `out_for_delivery` → `delivered`), and MUST allow cancellation from `pending` or `out_for_delivery` but never from `delivered`; any other transition, including moving to an earlier status, MUST be rejected.
- **FR-004**: System MUST record when an order becomes `delivered` and MUST treat that status as final — no further status change is permitted once an order is `delivered`.
- **FR-004a**: System MUST record which admin performed each order status change, alongside when it happened.
- **FR-005**: System MUST show operators a list of every subscription across all customers, filterable by status and searchable by the owning customer's name, email, or phone, each row showing customer, frequency, next delivery date, and status.
- **FR-006**: System MUST show an operator a subscription's full detail on request: its items and quantities, frequency, next delivery date, current price breakdown, delivery address, that customer's payment history for it, and its current Phase 7 dunning/retry state if it has one in progress.
- **FR-007**: System MUST let an operator pause an active subscription, requiring a short reason before the action is accepted, with an optional resume date (defaulting to indefinite — no resume date — if left blank), and MUST record which admin performed it and when.
- **FR-008**: System MUST let an operator cancel a non-cancelled subscription, requiring a short reason before the action is accepted, and MUST record which admin performed it and when; the resulting cancellation MUST be permanent, consistent with the customer-facing cancellation rule already established.
- **FR-009**: System MUST reject an operator's attempt to pause or cancel a subscription already in that exact state, or to cancel one that's already cancelled, with a message reflecting its actual current state.
- **FR-010**: System MUST keep every reason recorded on an admin-initiated pause or cancel — and the identity of the admin who performed it — visible only to admins, never surfaced on the customer's own dashboard or any customer-facing view.
- **FR-011**: System MUST make an admin-initiated pause or cancel immediately visible to the affected customer through their own existing dashboard (Phase 6), exactly as if they had taken the action themselves, aside from the admin-only reason.
- **FR-012**: System MUST show operators a payments list spanning every customer, filterable by status and by date range and searchable by the owning customer's name, email, or phone, each row showing customer, amount, outcome, failure reason (when applicable), attempt number, and whether it was an initial activation charge or a renewal charge.
- **FR-013**: System MUST let an operator add a new city (name, active flag, optional delivery fee override), edit an existing city's name/active flag/delivery fee override, and MUST make an active city immediately selectable on the existing customer-facing address form.
- **FR-014**: System MUST make a deactivated city immediately stop being offered for a new or edited address, without altering any existing address that already references it (consistent with the existing rule that an address referencing a since-deactivated city stays valid).
- **FR-015**: System MUST show, on `/admin`'s own landing view, the current count of active subscriptions, the count of orders scheduled for today, and the total revenue from successful payments this calendar month — computed fresh from current data on each view, not from a stale or manually-updated figure.
- **FR-016**: System MUST NOT allow any write in this specification (order status changes, subscription pause/cancel, city changes) to be performed by a customer's own session — every one of these is an operator-only action, enforced the same way the existing admin product/settings writes already are.

### Key Entities

- **Order** *(existing, from Phase 5/7, gains admin-facing status transitions)*: This phase adds the only operator-facing mutation orders have ever had — status advancement/cancellation — while every field already established (snapshotted items, price, address) remains untouched by this phase.
- **Subscription** *(existing, from Phase 4/6/7, gains admin-initiated pause/cancel)*: This phase adds an operator's own pause/cancel actions, functionally identical in effect to the customer's own (same status values, same terminal-cancellation rule) but distinguished by carrying an admin-only reason and being initiated by staff rather than the subscription's own owner.
- **Admin Action Record** *(new, minimal — attached to the order/subscription it acts on, not a standalone screen of its own)*: For every order status change, and every admin-initiated subscription pause/cancel, records which admin performed it and when; a pause/cancel additionally carries the required reason note. Exists only as part of that order's or subscription's own history, never a separately browsable audit-log screen in this phase's scope. Visible only to admins — never surfaced to the customer.
- **Payment** *(existing, from Phase 5/7, gains a cross-customer admin view)*: No new fields — this phase only adds an operator's ability to see every customer's attempts in one place, filtered, rather than each customer only seeing their own (Phase 6).
- **City** *(existing, from Phase 1, gains full admin CRUD)*: Name, active flag, delivery fee override — this phase adds create/edit capability where only read access (customer address selection, pricing engine's fee resolution) has existed until now.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: An operator can take an order from `pending` to `delivered` in a single admin session, with the change visible on the customer's own dashboard immediately afterward — the phase's own stated demo target.
- **SC-002**: 100% of order status changes follow the defined forward progression — no order is ever observed to move backward or skip directly to `delivered` from `pending` without passing through `out_for_delivery`, and no `delivered` order ever changes status again.
- **SC-003**: 100% of admin-initiated subscription pause/cancel actions have a recorded reason and a recorded acting admin — none can be submitted without both.
- **SC-004**: An operator can locate a specific customer's subscription and see its full state (items, price, payment history, dunning status) without needing direct database access, for the first time since the subscription lifecycle began in Phase 4.
- **SC-005**: The `/admin` landing view's three counters are never more than one page-load stale relative to the underlying data.
- **SC-006**: An operator can add a new city and have it appear as a selectable option on the customer-facing address form without any code deployment or direct database write.
- **SC-007**: 0% of the writes introduced by this phase (order status, subscription pause/cancel, city changes) are reachable from a customer's own session.

## Assumptions

- This phase covers *operational* actions only — the specific "refund from admin (manual, via Moyasar dashboard or API)" capability named elsewhere in `plan.md`'s broader function inventory is not included in this phase's own scope (`plan.md`'s Phase 8 description itself lists subscriptions/orders/payments/cities/counters, not refunds); refunding remains a manual action taken directly in the Moyasar dashboard for now.
- The payments list (User Story 4) is read-only in this phase — no admin action (retry, refund, manual resolution) is performed from it; it exists purely for visibility, per `plan.md`'s own "operational visibility" framing.
- "Revenue this month" (FR-015) is the gross sum of `paid` payments' amounts within the current calendar month, across both initial-activation and renewal charges — it is not net of any refund, since refunds are out of this phase's scope per the assumption above.
- An admin pausing or cancelling a subscription uses the exact same underlying status values and rules Phase 6/7 already established (`paused`/`cancelled`, terminal cancellation, pause overriding a locked/retry-in-progress cycle) — this phase does not introduce a new subscription status or a parallel state machine for admin-initiated actions.
- No new admin sub-role or granular permission system is introduced — every capability in this phase is available to any user with the existing single `admin` role from Phase 1, consistent with every admin screen built so far.
- Per `plan.md` §0.B's own note, `/admin`'s visual design has no source mockup; every screen in this phase follows the design-system tokens and admin-UI conventions (data tables, filters, detail views) already established by Phase 2's product-management screens, the only existing precedent.
- Bulk/batch actions (e.g., advancing many orders at once) are out of scope — every action in this phase's user stories operates on one record at a time, consistent with `plan.md`'s own phase description not mentioning bulk operations.
