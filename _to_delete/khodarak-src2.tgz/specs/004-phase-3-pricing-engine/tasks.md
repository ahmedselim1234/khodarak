---

description: "Task list for Phase 3 — Admin Settings & the Pricing Engine"
---

# Tasks: Phase 3 — Admin Settings & the Pricing Engine

**Input**: Design documents from `/specs/004-phase-3-pricing-engine/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/ (settings-admin-api.md, pricing-preview-api.md, pricing-calculation.md), quickstart.md

**Tests**: Included — plan.md's Technical Context, research.md, and contracts/pricing-calculation.md
all explicitly scope a Vitest suite for `calculate.ts` (written and passing *before* any UI, per
Constitution Principle VI and `plan.md` §3's own "unit tests before the UI" non-negotiable), plus a
Playwright spec for the phase's demo scenario.

**Organization**: Tasks are grouped by user story (US1/US2/US3, matching spec.md's priorities:
US1 = P1, US2 = P1, US3 = P2). Within the P1 tier, **US2 (the pricing engine) is built before US1
(the admin settings screen)**, even though spec.md lists US1 first — `calculate.ts` is a pure
function with zero dependencies on the settings *table* or any UI (it takes a settings value as a
plain argument), so it is the true dependency-free starting point, and Constitution Principle VI
requires its tests to exist before any UI consumes it. US1 and US3 each depend on the `settings`
table (Foundational); US3 additionally depends on `calculate.ts` (US2) and the admin form (US1) to
demo against.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Create the `components/admin/settings/` and `components/pricing/` directory scaffolds
- [X] T002 [P] Create the `lib/pricing/` directory scaffold

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T003 Create migration `supabase/migrations/<timestamp>_settings.sql`: `settings` table enforced as a true singleton (`id integer primary key default 1 check (id = 1)`), `frequencies jsonb` plus the scalar order-rules/delivery/pause/tax/rounding columns with `check` constraints, RLS (public `SELECT`, `admin`-role-only `INSERT`/`UPDATE`/`DELETE` mirroring the `products` policy shape from Phase 2), and a seed `INSERT` of one default row with every frequency enabled — per data-model.md
- [X] T004 [P] Create `lib/pricing/mapSettingsRow.ts`: snake_case → camelCase mapper for a `settings` row (mirrors `lib/products/mapProductRow.ts`), producing the `frequencies`/`minOrderValue`/etc. shape documented in contracts/settings-admin-api.md

**Checkpoint**: Foundation ready — `settings` table + RLS + seed row and the shared row mapper exist; user story implementation can now begin.

---

## Phase 3: User Story 2 - The system calculates one correct, itemized price for any box (Priority: P1) 🎯 MVP

**Goal**: A pure, server-side function computes the exact documented price breakdown for any set of items, frequency, city, and settings — the single source of truth every other piece of this phase (and later, Phase 4) calls.

**Independent Test**: Call `calculate()` directly with a fixed set of items, quantities, a frequency, a city, and a settings value, and verify the returned breakdown matches the documented formula by hand for every case in contracts/pricing-calculation.md's required-cases table — per quickstart.md step 1. No database, UI, or network involved.

### Tests for User Story 2

> Write this test FIRST; it MUST fail until T006 exists. This is the phase's most important test — Constitution Principle VI names exactly this kind of function ("a bug silently costs real money") as requiring test-first discipline.

- [X] T005 [P] [US2] Write unit test `tests/unit/pricing.calculate.test.ts` covering every case in contracts/pricing-calculation.md's required-cases table: happy path, below-minimum-order, above-max-items, free-delivery threshold exactly met vs. one cent short, VAT inclusive vs. exclusive, a rounding boundary for each of the three rounding modes, per-city delivery with and without an override, an empty item list, and `estimatedMonthly` for each frequency

### Implementation for User Story 2

- [X] T006 [US2] Create `lib/pricing/calculate.ts`: pure function, no I/O, implementing the exact calculation order from contracts/pricing-calculation.md (itemsSubtotal → frequencyDiscountAmount → afterDiscount → deliveryFee → taxableBase → vatAmount → totalPerDelivery → estimatedMonthly, plus the informational `meetsMinimumOrderValue`/`withinMaxItemsPerBox` flags), including the scale-round-unscale rounding helper for the three rounding modes (research.md §4) — depends on T005 (write test first)

**Checkpoint**: User Story 2 is fully functional and independently testable — the pricing engine is correct and fully covered by boundary-case tests, with nothing else in the codebase depending on it yet.

---

## Phase 4: User Story 1 - Admin configures the pricing and order rules (Priority: P1)

**Goal**: An admin can view and edit every setting (per-frequency discounts, order rules, delivery mode, pause rules, VAT, rounding) through one screen, with out-of-range values rejected.

**Independent Test**: Open `/admin/settings`, change the weekly frequency's discount percentage, save, and confirm the new value is persisted and shown on reload; submit an out-of-range value and confirm it's rejected with the previous value still in effect — per quickstart.md step 2.

### Tests for User Story 1

> Write this test FIRST; it MUST fail until T008 fully covers these cases.

- [X] T007 [P] [US1] Write unit test `tests/unit/validation.settings.test.ts` covering settings payload edge cases: a negative or >100 discount/VAT percentage, a negative currency amount, an invalid `deliveryMode`/`roundingMode` enum value, a `blackoutWeekdays` entry outside `0`–`6`

### Implementation for User Story 1

- [X] T008 [P] [US1] Create `lib/validation/settings.ts`: zod schema for the settings update payload per contracts/settings-admin-api.md, range-checked to match the database's own `check` constraints (T003)
- [X] T009 [US1] Create `lib/store/settingsAdminApi.ts`: RTK Query slice (`getSettings`, `updateSettings`) against `/api/admin/settings` per contracts/settings-admin-api.md, following the `lib/store/productsAdminApi.ts` pattern — depends on T008
- [X] T010 [US1] Register the `settingsAdminApi` reducer/middleware in `lib/store/index.ts` — depends on T009
- [X] T011 [US1] Implement `app/api/admin/settings/route.ts`: `GET` (current settings via T004's mapper), `PATCH` (partial update, admin-role check, zod validation via T008) — depends on T003, T004, T008
- [X] T012 [US1] Create `components/admin/settings/SettingsForm.tsx`: `"use client"`, full form (frequencies grid, order rules, delivery mode + fee fields, pause rules, VAT + inclusive toggle, rounding mode), wired to `settingsAdminApi` (T009) mutations, mirrors T008's range validation client-side for immediate feedback — depends on T009
- [X] T013 [US1] Create `app/admin/settings/page.tsx`: Server Component fetching the current settings row and rendering `SettingsForm` (T012), no mockup exists (spec.md Assumptions, same treatment as `/admin/products` from Phase 2) — depends on T012

**Checkpoint**: User Stories 1 AND 2 both work — settings are configurable and the engine that will consume them is already fully correct and tested.

---

## Phase 5: User Story 3 - A live preview shows the price reacting to settings changes (Priority: P2)

**Goal**: A signed-out visitor can select sample items, a frequency, and a city on a public page and see the live price breakdown, which changes when an admin updates a relevant setting.

**Independent Test**: Open `/pricing-preview` signed out, select items and a frequency, note the price, change that frequency's discount in `/admin/settings`, reload the preview with the same selections, and confirm the price changed — per quickstart.md steps 3–4, the phase's full demo scenario.

### Implementation for User Story 3

- [X] T014 [P] [US3] Create `lib/validation/pricingPreview.ts`: zod schema for the preview request payload (`items[]`, `frequency`, `cityId`) per contracts/pricing-preview-api.md
- [X] T015 [US3] Create `lib/store/pricingApi.ts`: RTK Query slice (`previewPrice`) against `/api/pricing/preview` per contracts/pricing-preview-api.md, following the `lib/store/cartApi.ts` pattern — depends on T014
- [X] T016 [US3] Register the `pricingApi` reducer/middleware in `lib/store/index.ts` — depends on T015
- [X] T017 [US3] Implement `app/api/pricing/preview/route.ts`: `POST` — no authentication required (FR-017a), zod validation via T014, resolves product prices and the city's delivery-fee override, rejects a disabled frequency with `422`, calls `calculate.ts` (T006) via T004's settings mapper, never accepts a price/breakdown from the request body — depends on T003, T004, T006, T014
- [X] T018 [P] [US3] Create `components/pricing/PriceBreakdownCard.tsx`: presentational — renders the returned breakdown's lines plus the min-order/max-items compliance flags
- [X] T019 [US3] Create `components/pricing/PreviewForm.tsx`: `"use client"` leaf — product/quantity/frequency/city selection; calls `pricingApi`'s `previewPrice` (T015) on every change (debounced), never computes a price itself; only offers frequencies currently enabled (FR-012); shows the empty/zero state with no items selected (FR-020) — depends on T015, T018
- [X] T020 [US3] Create `app/pricing-preview/page.tsx`: new top-level **public** route (not under `/subscription` — Clarifications 2026-08-10, no `middleware.ts` change needed), Server Component fetching sample products and active cities, rendering `PreviewForm` (T019) — depends on T019

**Checkpoint**: All three user stories are independently functional — the phase's headline demo ("change a discount in admin → reload the preview → price changed") is complete.

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all three stories

- [X] T021 [P] Write Playwright spec `tests/e2e/pricing-preview.spec.ts`: admin changes a frequency's discount in `/admin/settings` → reload `/pricing-preview` with the same selections → price changed — quickstart.md steps 2–4. Also covers `/pricing-preview` loading without a redirect and `/subscription` still redirecting to `/login` (quickstart.md step 6).
- [ ] T022 [P] Run the full `quickstart.md` validation (all 8 steps) end to end — **not run**: requires a live Supabase project with seeded products/cities and a real browser session, neither available in this sandbox. `npm run build` was run instead and confirms every route/API handler compiles and type-checks; this does not substitute for the manual browser walkthrough.
- [X] T023 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed files (Constitution Development Workflow gate) — both clean; also ran `npm run test:unit` (86/86 passing, including the 16-case `pricing.calculate.test.ts` boundary suite) and `npm run build` (all 25 routes compile) as additional verification beyond what this task strictly asked for.
- [ ] T024 Manual RLS/policy spot-check: as a non-admin (or signed-out) session, attempt `PATCH /api/admin/settings` and direct `settings` table writes — confirm both are rejected; confirm `/pricing-preview` never redirects to `/login` while `/subscription` still does (Constitution Principle V; quickstart.md step 7 covers the API-layer version, this covers the RLS layer directly) — **not run**: requires a live linked Supabase project and disposable test accounts (same constraint noted in `specs/002-phase-1-auth-address/tasks.md` T037 and `specs/003-phase-2-catalog-admin-crud/tasks.md` T052). The RLS policies themselves were authored in the migration (`settings_select_all`, `settings_insert_admin`/`update`/`delete`) but have not been exercised against a live project from this session.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 2 (Phase 3, P1)**: Depends on Foundational only — but in practice needs no data from the `settings` *table* itself (it's a pure function), so it could even be built in parallel with Foundational's migration; kept after Foundational here only because it's numbered as a later phase, not because of a real dependency
- **User Story 1 (Phase 4, P1)**: Depends on Foundational (`settings` table + mapper)
- **User Story 3 (Phase 5, P2)**: Depends on Foundational, US2 (`calculate.ts`), and benefits from US1 existing (to actually change a setting for the demo, though the preview page itself only needs the `settings` table to already have its seeded defaults)
- **Polish (Phase 6)**: Depends on all three user stories being complete

### User Story Dependencies

- **US2 (P1)**: No dependencies on other stories — true MVP starting point, and the one place Constitution Principle VI's test-first rule is non-negotiable
- **US1 (P1)**: No dependencies on US2's files; only needs the `settings` table (Foundational)
- **US3 (P2)**: Imports `calculate.ts` from US2 (via the Route Handler, T017) and is best demoed against US1's admin form, but does not import any US1 component file directly

### Within Each User Story

- Tests (where included) written and failing before implementation
- The migration (Foundational) before any Route Handler or component that queries `settings`
- Validation schemas before the forms/handlers that use them
- Server-side pieces (migrations, Route Handlers) before the client components that call them
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T001 and T002 (Setup) can run in parallel
- T003 and T004 (Foundational) can run in parallel — T004 only needs the documented row shape, not the applied migration, to be written
- Within US1: T007 (test) and T008 (schema) can start in parallel with T003/T004 review, though T008 should be finalized against T003's actual column names
- Within US3: T014 and T018 (different files, no dependencies) can run in parallel

---

## Parallel Example: User Story 2

```bash
# There is only one implementation task, but its test can be drafted immediately
# alongside Foundational work finishing up:
Task: "Write unit test tests/unit/pricing.calculate.test.ts"
```

## Parallel Example: User Story 3

```bash
# Launch the request schema and the presentational breakdown card together:
Task: "Create lib/validation/pricingPreview.ts"
Task: "Create components/pricing/PriceBreakdownCard.tsx"
```

---

## Implementation Strategy

### MVP First (User Story 2 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 2
4. **STOP and VALIDATE**: `npm run test:unit` — every boundary case in contracts/pricing-calculation.md's table passes
5. Demo: run the test suite and walk through a couple of cases by hand — the engine is correct before anything else exists

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US2 → validate → the pricing engine is correct and fully tested (no UI yet)
3. Add US1 → validate → demo (admin can configure every rule the engine reads)
4. Add US3 → validate → demo (the phase's full headline scenario: change a discount, reload the preview, watch it change)
5. Phase 6 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes:
- Developer A: US2 (`calculate.ts` + its test suite) — no dependencies on anyone else's work
- Developer B: US1 (admin settings screen) — only needs the `settings` table, not US2's engine
- Developer C: joins for US3 once both US1 and US2 land, to wire the preview route and page

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- `settings` (T003) is Foundational because both US1 (writes it) and US3 (reads it via the preview
  route) need it; `calculate.ts` (US2) deliberately takes settings as a plain argument rather than
  querying the table itself, which is what makes it independently testable without any database
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
