# Contract: `/api/addresses`

Route Handlers backing the address book (spec User Story 4). Every request MUST be an
authenticated session (enforced by `middleware.ts` at the `/dashboard` boundary and re-checked
server-side in each handler); every request body is validated with the zod schema in
`lib/validation/address.ts` before touching the database. All queries run through the server
Supabase client and rely on RLS (`user_id = auth.uid()`) as the authorization boundary — a
handler never accepts or trusts a `user_id` from the request body.

## `GET /api/addresses`

Lists the caller's own saved addresses.

**Request**: no body, no query params.

**Response — success**:
```
200 OK
Content-Type: application/json

{
  "addresses": [
    {
      "id": "uuid",
      "label": "Home",
      "cityId": "uuid",
      "cityName": "Riyadh",
      "district": "Al Olaya",
      "streetDetails": "Building 12, Apt 3",
      "isDefault": true,
      "createdAt": "2026-08-10T12:00:00Z"
    }
  ]
}
```

**Response — unauthenticated**: `401 Unauthorized`.

---

## `POST /api/addresses`

Creates a new address for the caller.

**Request**:
```json
{
  "label": "Work",
  "cityId": "uuid",
  "district": "Al Malaz",
  "streetDetails": "Office Tower, Floor 4"
}
```

Validation (FR-012): `label`, `district`, `streetDetails` non-empty strings; `cityId` a valid uuid
referencing an existing city (need not be active — see Notes).

**Response — success**:
```
201 Created
Content-Type: application/json

{
  "address": {
    "id": "uuid",
    "label": "Work",
    "cityId": "uuid",
    "cityName": "Riyadh",
    "district": "Al Malaz",
    "streetDetails": "Office Tower, Floor 4",
    "isDefault": true,
    "createdAt": "2026-08-10T12:05:00Z"
  }
}
```

`isDefault` is `true` automatically when this is the caller's first address (FR-015), `false`
otherwise.

**Response — validation error**:
```
400 Bad Request
Content-Type: application/json

{ "error": "validation_failed", "fields": { "district": "required" } }
```

**Response — unauthenticated**: `401 Unauthorized`.

---

## `PATCH /api/addresses/[id]`

Edits an existing address the caller owns, and/or sets it as the caller's default.

**Request** (all fields optional except at least one MUST be present):
```json
{
  "label": "Home (updated)",
  "cityId": "uuid",
  "district": "Al Olaya",
  "streetDetails": "Building 12, Apt 5",
  "isDefault": true
}
```

**Behavior**: if `isDefault: true` is present, the handler runs the unset-previous / set-new
transaction described in [data-model.md](../data-model.md) — the caller's previously-default
address (if different) is atomically un-defaulted first. `isDefault: false` is a no-op rejection
(`400`) — a customer cannot un-default their only default without designating a new one, since
that would violate FR-014's "exactly one default" for a customer with at least one address.

**Response — success**: `200 OK`, same shape as the `POST` success response, reflecting the
updated row.

**Response — not found / not owned**: `404 Not Found` (an address that exists but belongs to
another user returns `404`, not `403` — never confirms existence of another user's row).

**Response — validation error**: `400 Bad Request`, same shape as `POST`.

---

## `DELETE /api/addresses/[id]`

Deletes an address the caller owns.

**Request**: no body.

**Response — success**: `204 No Content`. If the deleted address was the caller's default, no
other address is automatically promoted (see data-model.md's State Transitions) — the caller has
zero default addresses until they add or designate a new one.

**Response — not found / not owned**: `404 Not Found`.

## Notes

- `cityId` is validated as "exists" but not required to be `is_active` on the server, matching
  FR-017: an address referencing a since-deactivated city stays valid. The UI is what restricts
  the *selectable options* to active cities (FR-016) — the API's job is only to not corrupt data
  that was valid when created.
- No endpoint here exposes another user's data; every query is additionally scoped by RLS as a
  second, database-enforced layer beneath the handler's own `user_id = auth.uid()` filter
  (Constitution Principle V — RLS is the authorization boundary, not just an app-layer check).
