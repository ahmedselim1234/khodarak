# Contract: `GET` / `PATCH /api/subscriptions/[id]`

Covers reading a subscription's full dashboard-facing detail (current + pending config, next
delivery, health) and editing its items/frequency/address (User Stories 1–2). Requires an
authenticated session; the caller must own the subscription in both directions — `404` if it
doesn't exist or isn't theirs (FR-001).

## `GET /api/subscriptions/[id]`

**Behavior**:
1. Load the subscription, its `subscription_items`, `subscription_pending_items` (if a pending
   change exists), and the `settings` row.
2. **Self-heal**: if `status = 'paused'` and `paused_until <= today`, write `status = 'active'`
   via `mutateSubscription.ts` (service-role) before continuing, then proceed as if it had already
   been active (FR-013, data-model.md's state-transitions note).
3. Compute `resolveEffectiveConfig()` — what the locked next delivery contains (current fields)
   and what applies after it (pending fields, if any).
4. Compute `subscriptionHealth()` from status, a `payments`-derived consecutive-failure count, and
   hours until `next_delivery_date` vs. `settings.edit_cutoff_hours`.
5. Compute whether the caller is currently inside the edit cutoff window for `next_delivery_date`
   (`hoursUntil(next_delivery_date) <= settings.edit_cutoff_hours`).

**Response — success**:
```json
{
  "id": "uuid",
  "status": "active",
  "frequency": "weekly",
  "nextDeliveryDate": "2026-08-18",
  "pausedUntil": null,
  "insideEditCutoff": false,
  "items": [{ "productId": "uuid", "productNameAr": "طماطم", "quantity": 2, "unitPrice": 6.5 }],
  "priceBreakdown": { "itemsSubtotal": 13, "totalPerDelivery": 21.5, "...": "…same shape as lib/pricing/calculate.ts's PriceBreakdown" },
  "addressId": "uuid",
  "pendingChange": {
    "frequency": "biweekly",
    "addressId": "uuid",
    "items": [{ "productId": "uuid", "productNameAr": "طماطم", "quantity": 3, "unitPrice": 6.5 }],
    "priceBreakdown": { "...": "…" },
    "effectiveFrom": "2026-08-25"
  },
  "health": "good"
}
```
`pendingChange` is `null` when no pending change exists.

**Response — not found / not owned**: `404 { "error": "not_found" }`.

**Response — unauthenticated**: `401 { "error": "unauthenticated" }`.

---

## `PATCH /api/subscriptions/[id]`

**Request**:
```json
{
  "items": [{ "productId": "uuid", "quantity": 2 }],
  "frequency": "weekly",
  "addressId": "uuid"
}
```
All three fields are required together — this is a full replace of the box's configuration, not a
partial patch of individual fields (mirrors how `subscription_items`/`subscription_pending_items`
are always replaced wholesale, data-model.md). Validated by
`lib/validation/subscriptionEdit.ts`.

**Behavior**:
1. `404` if not found/not owned. `409 { "error": "not_editable", "status": "..." }` if
   `status` isn't `active` (a paused or cancelled subscription's box can't be edited — pause/resume
   first, spec.md Edge Cases).
2. Look up current product prices/availability for every `productId`; `422
   { "error": "product_unavailable", "productId": "..." }` if any requested product is no longer
   available (spec.md Edge Cases — "if a chosen product has since become unavailable, the save is
   blocked with a message identifying that product").
3. Call `calculate()` (`lib/pricing/calculate.ts`) with the requested items/frequency/city, exactly
   as Phase 4's builder and Phase 3's preview endpoint do — the single source of truth for the new
   price breakdown (FR-006/FR-007, Constitution Principle II).
4. Validate `meetsMinimumOrderValue`, `withinMaxItemsPerBox`, and each item's
   `products.min_qty`/`max_qty`; `422 { "error": "rule_violated", "rule": "min_order_value" | "max_items_per_box" | "product_quantity", "productId"?: "..." }` on the first violation found
   (FR-008).
5. Determine `insideEditCutoff` the same way `GET` does. If **outside** the cutoff: write the new
   items/frequency/address/price directly to the subscription's *current* fields, clear any
   existing pending-change fields (a fresh in-cutoff edit supersedes an old deferred one), and
   recompute `next_delivery_date` if the frequency changed (via
   `lib/subscription/selectableDeliveryDates.ts`, respecting lead time/blackout days). If
   **inside** the cutoff: write the same new items/frequency/address/price to the *pending* fields
   instead (`pending_effective_from = next_delivery_date`), leaving current fields — and therefore
   the already-locked delivery — completely untouched (FR-009). Either way, this fully replaces
   any prior pending change rather than merging with it (research.md §1).
6. All writes happen via `mutateSubscription.ts` (service-role) in one transaction-equivalent
   sequence: update `subscriptions`, replace `subscription_items` or
   `subscription_pending_items` wholesale (delete-then-insert the new set).

**Response — success (applied immediately)**:
```json
{ "applied": "immediately", "priceBreakdown": { "...": "…" }, "nextDeliveryDate": "2026-08-18" }
```

**Response — success (deferred)**:
```json
{ "applied": "pending", "effectiveFrom": "2026-08-25", "priceBreakdown": { "...": "…" } }
```

**Response — rule violation**: `422 { "error": "rule_violated", "rule": "...", "productId"?: "..." }`.

**Response — product unavailable**: `422 { "error": "product_unavailable", "productId": "..." }`.

**Response — not editable**: `409 { "error": "not_editable", "status": "paused" }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": {...} }`.

**Response — not found / not owned**: `404 { "error": "not_found" }`.

**Response — unauthenticated**: `401 { "error": "unauthenticated" }`.
