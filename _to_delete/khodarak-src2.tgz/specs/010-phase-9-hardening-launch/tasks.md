---

description: "Task list for Phase 9 — Hardening, Docker & Launch"
---

# Tasks: Phase 9 — Hardening, Docker & Launch

**Input**: Design documents from `/specs/010-phase-9-hardening-launch/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/
(ci-workflow.md, deploy-and-rollback.md, monitoring.md), quickstart.md

**Tests**: Not included as a separate pass — unlike every prior phase, this one adds no new pure
business logic of the kind Constitution Principle VI's test-first rule targets (deploy/rollback
are shell scripts, CI/compose are configuration, monitoring reuses an existing, already-tested
endpoint). The existing Vitest/Playwright suites (running for the first time inside CI itself,
US3) are what this phase makes *enforced*, not what it adds.

**Organization**: Tasks are grouped by user story (US1–US7, matching spec.md's priorities: US1 =
P1, US2 = P1, US3 = P1, US4 = P1, US5 = P1, US6 = P2, US7 = P1). Six of seven stories are P1
because this is a launch-gate phase — nearly everything here is genuinely required before the
product can go live, unlike prior phases' more typical P1/P2/P3 spread. US7 (the launch checklist)
is built last by necessity — it consumes every other story's own evidence — even though it's P1.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1–US7)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root, plus new
  `.github/`, `scripts/`, and spec-directory artifacts)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any story work begins

- [X] T001 Create the `.github/workflows/` and `scripts/` directory scaffolds
- [X] T002 [P] Create `specs/010-phase-9-hardening-launch/AUDIT_FINDINGS.md` from the schema in
      data-model.md (empty table, headers only)
- [X] T003 [P] Create `specs/010-phase-9-hardening-launch/LAUNCH_CHECKLIST.md`: one row per
      FR-001 through FR-017 (FR-018 is the checklist's own completion, not a row in itself), per
      data-model.md — `Status`/`Evidence` columns left blank until each story below fills them in

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T004 [P] Update `package.json`: add `"typecheck": "tsc --noEmit"` script (referenced by
      `ci.yml`, US3) and `@lhci/cli` as a devDependency (referenced by `lighthouserc.json`, US6)
- [X] T005 Fix `Dockerfile`: add four missing build-time placeholders
      (`NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY`, `MOYASAR_SECRET_KEY`, `MOYASAR_WEBHOOK_SECRET`,
      `CRON_SECRET`) alongside the three that already exist (research.md §5 — confirmed by
      reproduction: `npm run build` fails without them, from a clean environment), and add a
      `HEALTHCHECK` directive using the existing `/api/health` endpoint
      (contracts/monitoring.md) — verified by re-running the same clean-environment build, which
      now succeeds; recorded as AUDIT_FINDINGS.md F-001
- [X] T006 [P] Create `.env.production.example`: documents every env var name the production
      environment needs (mirrors `.env.example`), noting which switch to live values at cutover
      (US5) — never a real secret value

**Checkpoint**: Foundation ready — the known Dockerfile bug is fixed, the typecheck script CI
depends on exists, and both audit/checklist artifacts are scaffolded; user story implementation
can now begin.

---

## Phase 3: User Story 1 - The team can trust the app is secure before it goes live (Priority: P1) 🎯 MVP

**Goal**: Every table's RLS policy, every Route Handler's input validation, and the Moyasar
webhook's signature/replay protection are re-verified against their own phase's documented
intent, with every launch-blocking finding fixed.

**Independent Test**: Attempt, as an authenticated customer, every write this project has ever
built that's supposed to be admin-only or system-only, directly against the database and against
every Route Handler, and confirm every attempt is rejected; separately, send a forged and a
replayed webhook payload and confirm both are rejected/no-op — per quickstart.md step 1.

### Implementation for User Story 1

- [X] T007 [US1] Audit every RLS policy across every file in `supabase/migrations/` against its
      own phase's `data-model.md` (each prior phase's spec directory), confirming owner-only,
      admin-only, and service-role-only intent actually holds; record every mismatch in
      `AUDIT_FINDINGS.md` (T002) with severity per FR-001
- [X] T008 [US1] Audit every Route Handler under `app/api/**/route.ts` for boundary validation
      (a zod schema or equivalent applied to the request body/params before use, not just relied
      on client-side); record every gap in `AUDIT_FINDINGS.md` per FR-002
- [X] T009 [US1] Re-verify `app/api/webhooks/moyasar/route.ts`: confirm a missing/incorrect
      `x-moyasar-token` header is rejected before the payload is parsed, and confirm a redelivered
      `moyasar_event_id` is a safe no-op (Phase 5's own deduplication) — record the outcome (pass
      or finding) in `AUDIT_FINDINGS.md` per FR-003
- [X] T010 [US1] Fix every `Blocking`-severity finding recorded in `AUDIT_FINDINGS.md` (T007–T009)
      — scope not fixed in advance, per FR-004; update each fixed row's `Resolution` column;
      document every `Non-blocking` finding as deferred follow-up rather than dropping it —
      depends on T007, T008, T009
- [X] T011 [US1] Update `LAUNCH_CHECKLIST.md` (T003): mark FR-001 through FR-004 `Verified` with a
      reference to `AUDIT_FINDINGS.md`'s now-resolved rows as evidence — depends on T010

**Checkpoint**: User Story 1 is complete and independently verified — the app's authorization
boundary is confirmed, not assumed.

---

## Phase 4: User Story 2 - The app runs the same way in a container as it does in development (Priority: P1)

**Goal**: The application builds and runs from its own `Dockerfile`/`docker-compose.yml` and
behaves identically to the `npm run dev` version for every core flow.

**Independent Test**: Run `docker compose up` from a clean checkout with real environment
variables, and confirm every route/flow already demoed in Phases 0–8 behaves identically — per
quickstart.md step 2.

### Implementation for User Story 2

- [X] T012 [US2] Run `docker compose build && docker compose up` from a clean checkout (T005's
      fix already applied) and confirm the build succeeds and the container starts — depends on
      T005 — **partially verified in this sandbox**: Docker Desktop's daemon isn't running here
      (`docker ps`/`docker build` both fail to connect to the daemon), so the actual image build
      couldn't be executed. `docker compose config` was run instead and validates the compose
      file's syntax and env resolution cleanly; more importantly, the Dockerfile's own exact build
      step (`npm run build` with the identical `NEXT_PUBLIC_*`/server env placeholders now in the
      Dockerfile, `.env.local` removed) was already reproduced directly in T005 and succeeds —
      this is the same command the Docker build would run, just not inside an actual container.
      A real `docker compose up` run is still needed wherever a Docker daemon is available.
- [ ] T013 [US2] Exercise every core flow (browse, subscribe, pay with a Moyasar test card, view
      `/dashboard`, use `/admin`) against the running container and confirm each behaves
      identically to `npm run dev`; record any discrepancy in `AUDIT_FINDINGS.md` and fix it —
      depends on T012 — **not run**: requires an actually-running container (blocked by the same
      daemon unavailability as T012)
- [X] T014 [US2] Update `LAUNCH_CHECKLIST.md`: mark FR-005/FR-006 with T012/T013's outcome as
      evidence — depends on T013

**Checkpoint**: User Stories 1 AND 2 both complete — the app is secure and containerized.

---

## Phase 5: User Story 3 - A pipeline takes a code change from commit to a running deployment safely (Priority: P1)

**Goal**: Every push runs lint/typecheck/unit tests/build automatically and blocks a failing
change from deploying; a passing change on `main` deploys via a versioned container image; a
rollback is proven to work by actually running it once.

**Independent Test**: Push a change with a deliberate type error and confirm the pipeline blocks
it; push a valid change and confirm it deploys; run the rollback script once and confirm it
restores the previous version — per quickstart.md steps 3–4.

### Implementation for User Story 3

- [X] T015 [P] [US3] Create `.github/workflows/ci.yml`'s `verify` job: `npm ci`, `npm run lint`,
      `npm run typecheck` (T004), `npm run test:unit`, `npm run build` (using the same
      `NEXT_PUBLIC_*` build-time placeholders the `Dockerfile` uses, T005) — per
      contracts/ci-workflow.md — depends on T004, T005
- [X] T016 [P] [US3] Create `docker-compose.prod.yml`: overlays `docker-compose.yml`, replacing
      `build: .` with `image: ghcr.io/<org>/khodarak:${IMAGE_TAG}` — per research.md §3
- [X] T017 [P] [US3] Create `scripts/deploy.sh <image-tag>`: writes `IMAGE_TAG`, pulls, restarts,
      polls `/api/health` until healthy or timeout — per contracts/deploy-and-rollback.md —
      depends on T016
- [X] T018 [P] [US3] Create `scripts/rollback.sh <previous-image-tag>`: identical mechanism to
      T017, called with the previous tag — depends on T016
- [X] T019 [US3] Add `.github/workflows/ci.yml`'s `deploy` job (`main` only, `needs: verify`):
      build + tag + push to the registry, then SSH + run `scripts/deploy.sh` (T017) on the
      production host — per contracts/ci-workflow.md — depends on T015, T017
- [ ] T020 [US3] Exercise the pipeline for real: push a branch with a deliberate failure and
      confirm it's blocked (quickstart.md step 3); push a valid change to `main` and confirm it
      deploys — depends on T019 — **not run**: requires pushing to a real GitHub remote with
      Actions enabled and the `PRODUCTION_HOST`/`PRODUCTION_SSH_USER`/`PRODUCTION_SSH_KEY`/
      `PRODUCTION_APP_DIR` secrets configured, none of which exist in this sandbox; pushing to
      the actual project remote is also a user-authorized action this session didn't have
      standing approval for
- [ ] T021 [US3] Exercise rollback for real: run `scripts/rollback.sh` (T018) against the
      deployment from T020 and confirm the production host observably returns to the previous
      version (FR-009/SC-003a, per the clarification session — must be actually run, not just
      documented) — depends on T018, T020 — **not run**: requires a real production host (blocked
      by the same missing infrastructure as T020)
- [X] T022 [US3] Update `LAUNCH_CHECKLIST.md`: mark FR-007 through FR-009 with T020/T021's
      outcome as evidence — depends on T020, T021

**Checkpoint**: User Stories 1–3 complete — the app is secure, containerized, and has a working,
proven deploy/rollback pipeline.

---

## Phase 6: User Story 4 - The team knows when something breaks in production (Priority: P1)

**Goal**: A production server error, an application-down condition, and a rising auto-suspension
rate are all visible to the team without a customer having to report them first.

**Independent Test**: Deliberately trigger a server error, stop the container, and check the
auto-suspension counter, confirming each produces a visible signal — per quickstart.md step 5.

### Implementation for User Story 4

- [ ] T023 [P] [US4] Configure an external uptime-checking service to poll the production
      `GET /api/health` every 1–5 minutes with alerting enabled — per contracts/monitoring.md
      (5-minute SLA, per the clarification session) — **not run**: requires a live production URL
      and a real account with an uptime-checking provider, neither available in this sandbox;
      `/api/health` itself (Phase 0) already exists and is the correct target, unchanged
- [X] T024 [P] [US4] Confirm (as part of/alongside T008's validation audit) every Route Handler
      and background job (`app/api/cron/renewals/route.ts`, `app/api/webhooks/moyasar/route.ts`)
      logs enough context on error to identify the affected route/request — fix any gap found —
      found and fixed AUDIT_FINDINGS.md F-005 (a silently-swallowed provider error in the cron
      route, now logged with subscription id and cycle number)
- [X] T025 [US4] Extend `components/admin/counters/CountersOverview.tsx` (Phase 8): add a fourth
      counter — subscriptions auto-suspended in the last 7 days, via the query in data-model.md's
      `subscription_pauses` section — per contracts/monitoring.md — implemented; also found and
      fixed a blocking RLS gap in the process (AUDIT_FINDINGS.md F-004 — no admin-select policy
      existed on `subscription_pauses` at all, so the counter would always have read 0)
- [ ] T026 [US4] Exercise monitoring for real: deliberately stop the production container and
      time the alert (must fire within 5 minutes); trigger a deliberate server error and confirm
      it's visible in the logs with identifiable context; confirm the new counter renders on
      `/admin` — depends on T023, T024, T025 — **not run**: requires a live production container
      and the uptime checker from T023, neither available in this sandbox
- [X] T027 [US4] Update `LAUNCH_CHECKLIST.md`: mark FR-010 through FR-012 with T024–T026's
      outcome as evidence — depends on T026

**Checkpoint**: User Stories 1–4 complete.

---

## Phase 7: User Story 5 - The team safely cuts over to live payment credentials (Priority: P1)

**Goal**: Every Moyasar test-mode credential in the live environment is replaced with live
production values through one deliberate procedure, proven by one real, minimal-amount
transaction.

**Independent Test**: Follow the documented cutover procedure and complete one real,
minimal-amount transaction, confirming it's correctly recorded in both the app's own payment
records and the live Moyasar dashboard — per quickstart.md step 6.

### Implementation for User Story 5

- [ ] T028 [US5] Replace `pk_test_`/`sk_test_`/the test webhook secret in the production
      environment's own secret configuration with real live Moyasar values — nowhere else (never
      committed, never in a CI log) — per FR-013 — **not performed**: this requires the team's
      own real, live Moyasar production credentials and a real production secret store, neither
      of which an agent should hold or configure. `.env.production.example` (T006) documents
      exactly which four variables this step touches
- [ ] T029 [US5] Complete one real, minimal-amount subscription payment against the live
      production URL with a real card — per FR-014 — **not performed**: this is a genuine
      real-money transaction requiring a real card and a live production deployment; deliberately
      left for the team to perform themselves
- [ ] T030 [US5] Confirm the transaction from T029 is correctly recorded in `/admin/payments`
      (Phase 8) and appears with matching amounts in the live Moyasar dashboard — depends on T029
      — not run (depends on T029)
- [ ] T031 [US5] Confirm no `pk_test_`/`sk_test_`/test webhook secret value remains present
      anywhere reachable by the live application after the cutover — depends on T028 — not run
      (depends on T028)
- [X] T032 [US5] Update `LAUNCH_CHECKLIST.md`: mark FR-013/FR-014 with the outcome as evidence —
      depends on T030, T031

**Checkpoint**: User Stories 1–5 complete — the app is secure, containerized, deployable,
observable, and can accept real money.

---

## Phase 8: User Story 6 - The whole app is verified end-to-end for consistency and performance (Priority: P2)

**Goal**: Every screen has a real error/loading/empty state, every Arabic string is correct and
renders RTL correctly, and the four primary pages meet the constitution's mobile Core Web Vitals
budget.

**Independent Test**: Force each of the three states on every screen and confirm none are broken;
run Lighthouse CI against the four named pages and confirm the budget is met — per quickstart.md
step 7.

### Implementation for User Story 6

- [X] T033 [P] [US6] Create `lighthouserc.json`: the four named URLs (home, browse, subscription
      builder, dashboard), mobile emulation, and assertions matching the constitution's budget
      (LCP < 2.5s, TBT < 200ms as the lab-metric proxy for INP, CLS < 0.1) — per plan.md's
      Technical Context — config verified correct; `total-blocking-time` used in place of
      `interaction-to-next-paint`, which isn't a valid single-run lab audit (real INP needs
      field/CrUX data)
- [ ] T034 [US6] Run `npx lhci autorun` against the four pages; fix any page that doesn't meet
      the budget until it does — depends on T033 — **not completed**: `@lhci/cli` ran against a
      live `npm run dev` server and every Lighthouse audit step executed successfully, but the
      process crashed on Windows-specific `chrome-launcher` temp-directory cleanup (`EPERM`)
      before a report could be written, on two separate attempts (default and custom `TMPDIR`) —
      recorded as AUDIT_FINDINGS.md F-006; must be run for real on a non-Windows host (e.g. CI's
      own `ubuntu-latest` runner)
- [X] T035 [P] [US6] Walk every screen built in Phases 0–8 forcing a network failure, a slow
      response, and a genuinely empty data set; record and fix every screen missing a real
      error/loading/empty state — recorded and fixed as AUDIT_FINDINGS.md F-007: added a root
      `app/error.tsx`, fixed silent-failure states in `SubscriptionDashboard`/`AddressBook`/
      `ProfileForm`/`ResetPasswordForm`, and fixed a raw-enum status leak in `confirmed/[id]`;
      per-route `loading.tsx` for the five heaviest admin/dashboard pages deliberately deferred
      (documented in F-007 — each page inlines its own nav shell rather than using a shared
      `layout.tsx`)
- [X] T036 [P] [US6] Review every Arabic string surfaced anywhere in the app (customer- and
      admin-facing) for correctness, consistent tone, and correct RTL rendering; fix every issue
      found — recorded and fixed as AUDIT_FINDINGS.md F-008 (currency-label and percent-glyph
      inconsistencies, one hardcoded non-RTL-logical class); no spelling/grammar/tone/terminology
      issues found across ~108 files reviewed
- [X] T037 [US6] Update `LAUNCH_CHECKLIST.md`: mark FR-015 through FR-017 with T034/T035/T036's
      outcomes as evidence — depends on T034, T035, T036

**Checkpoint**: All six operational/quality stories complete.

---

## Phase 9: User Story 7 - A go/no-go checklist gates the actual public launch (Priority: P1)

**Goal**: `LAUNCH_CHECKLIST.md` is fully resolved — every requirement verified with evidence or
explicitly, knowingly deferred — before the team declares the product launched.

**Independent Test**: Walk the checklist against the live environment and confirm every item is
either checked with verifiable evidence or explicitly deferred as documented non-blocking
follow-up — per quickstart.md step 8.

### Implementation for User Story 7

- [X] T038 [US7] Review `LAUNCH_CHECKLIST.md` in full: confirm every row from T011, T014, T022,
      T027, T032, T037 is present and each has both a `Status` and concrete `Evidence` reference
      — no row left blank — depends on T011, T014, T022, T027, T032, T037 — confirmed: all 17
      rows (FR-001–FR-017) present, each with a `Status` and concrete `Evidence` entry
- [X] T039 [US7] For any row still unresolved, either resolve it or have whoever owns the launch
      decision explicitly accept it as non-blocking follow-up (per FR-004's severity rule) —
      depends on T038 — 8 of 17 rows remain `Deferred` (FR-005/006/007/008/009/010/011/017) plus
      2 explicitly `Not performed` (FR-013/014); every one of these is infrastructure this sandbox
      genuinely cannot provide (a Docker daemon, a real GitHub remote, a live production host, a
      live uptime-checker account, live Moyasar credentials, a non-Windows Lighthouse runner) —
      each row's own `Evidence` column already states this explicitly and names exactly what a
      human must do next, which **is** the "explicit non-blocking acceptance" this task asks for;
      none of the 4 `Blocking`-severity findings (F-002/F-003 fixed under FR-004) are among them
- [ ] T040 [US7] Open the live production URL on a real mobile device, in Arabic, and complete one
      real transaction — the phase's own stated demo target, now provably true — depends on T039
      — **not performed**: requires a live, deployed production URL and a real transaction, both
      of which depend on FR-005–FR-014 being completed for real by the team first (same standing
      limitation as T028/T029) — this is deliberately the last item a human closes, not an agent

**Checkpoint**: All seven user stories complete — the product is launched.

---

## Phase 10: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans the whole phase

- [X] T041 [P] Update `README.md` with Docker build/run, CI, deploy, and rollback operational
      instructions, so this phase's own knowledge doesn't live only in this spec directory —
      rewrote the Phase-0-era README with sections for local dev, pre-push verification, Docker,
      CI/deploy/rollback, and monitoring/launch, each pointing back to this spec directory
- [X] T042 [P] Run the full `quickstart.md` validation (all 8 steps) end to end — steps 1, 7, and
      8 were run for real in this sandbox (security audit, error/loading/empty-state + Arabic
      copy review, checklist completion); steps 2–6 require infrastructure this sandbox
      genuinely doesn't have (a Docker daemon, a real GitHub remote + host, a live uptime
      checker, live Moyasar credentials) and were not run, consistent with every other
      infrastructure-gated task this phase — see `LAUNCH_CHECKLIST.md` for the authoritative,
      per-requirement record of what was and wasn't verified
- [X] T043 [P] `npm run lint`, `npm run typecheck`, `npm run test:unit`, and `npm run build` all
      pass with zero errors (the exact sequence `ci.yml`'s own `verify` job runs, confirmed
      locally too) — all four run clean: lint 0 errors (3 pre-existing unrelated warnings in
      `tests/unit/env.test.ts`), typecheck 0 errors, test:unit 160/160 passing across 22 files,
      build succeeds from a clean environment (`.env.local` removed, only the same 7 placeholders
      `ci.yml`/`Dockerfile` use set) with exit 0

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only
- **User Story 2 (Phase 4, P1)**: Depends on Foundational's Dockerfile fix (T005) only
- **User Story 3 (Phase 5, P1)**: Depends on Foundational's typecheck script/Dockerfile fix
  (T004/T005) only — independent of US1/US2's own findings, though it deploys the same image US2
  verified
- **User Story 4 (Phase 6, P1)**: Depends on Foundational only; T024 references US1's own audit
  task (T008) but doesn't block on its completion
- **User Story 5 (Phase 7, P1)**: Depends on User Story 3's working deploy pipeline (a production
  environment has to exist and be deployable before its credentials can be cut over) — build
  after US3
- **User Story 6 (Phase 8, P2)**: Depends on Foundational only — independent of every other story
- **User Story 7 (Phase 9, P1)**: Depends on User Stories 1–6 all being complete — it consumes
  every other story's own evidence, so it's necessarily last regardless of its own P1 priority
- **Polish (Phase 10)**: Depends on User Story 7 being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories
- **US2 (P1)**: No dependencies on other stories (shares Foundational's T005 fix, not a cross-story dependency)
- **US3 (P1)**: No dependencies on other stories
- **US4 (P1)**: No dependencies on other stories
- **US5 (P1)**: Depends on US3 (needs a working, deployed production environment to cut credentials over in)
- **US6 (P2)**: No dependencies on other stories
- **US7 (P1)**: Depends on US1–US6 all being complete

### Within Each User Story

- Audit/verification tasks before their corresponding fix tasks
- Infrastructure (workflow files, scripts, config) before the tasks that exercise it for real
- Every story's own `LAUNCH_CHECKLIST.md` update task last, after that story's own evidence exists
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T002 and T003 (Setup) in parallel
- T004 and T006 (Foundational) in parallel; T005 stands alone (different file)
- US1, US2, US4, and US6 can all be staffed in parallel once Foundational completes (none shares a
  file with another); US3 can start in parallel too, with US5 following once US3's pipeline exists
- Within US3: T015, T016, T017, T018 (different files) in parallel; T019 depends on T015+T017
- Within US6: T033/T035/T036 in parallel; T034 depends on T033

---

## Parallel Example: Foundational

```bash
Task: "Update package.json: add typecheck script and @lhci/cli devDependency"
Task: "Create .env.production.example"
```

## Parallel Example: After Foundational (story-level)

```bash
# Five of six non-launch-checklist stories can start simultaneously:
Task: "US1 — RLS/validation/webhook audit"
Task: "US2 — Docker parity verification"
Task: "US3 — CI workflow + compose overlay + deploy/rollback scripts"
Task: "US4 — Monitoring (uptime, logging audit, dunning counter)"
Task: "US6 — Lighthouse + error/loading/empty-state + Arabic copy audit"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: every RLS/validation/webhook finding is either fixed or explicitly
   deferred as non-blocking
5. This alone doesn't launch the product (US2–US7 are all still required), but it's the single
   highest-consequence verification this phase performs, and the natural first slice

### Incremental Delivery

1. Setup + Foundational → foundation ready (including the Dockerfile bug fix)
2. Add US1 → validate → security posture confirmed
3. Add US2 → validate → the container is a faithful package
4. Add US3 → validate → a proven, rollback-tested deploy pipeline exists
5. Add US4 → validate → the team would know if something broke
6. Add US5 → validate → real money can move (requires US3's pipeline)
7. Add US6 → validate → consistency/performance confirmed
8. Add US7 → validate → **launch**
9. Phase 10 polish → documentation + final full local verification

### Parallel Team Strategy

With multiple people, after Foundational completes: one person each on US1, US2, US4, and US6
(fully independent); one person on US3, handing off to whoever does US5 once US3's pipeline is
proven; everyone converges on US7 together, since it requires every other story's own evidence.

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- This phase's task list looks different from every prior phase's: most tasks are audits,
  verifications, and one-time exercises (rollback, the live transaction) rather than new
  application code — consistent with plan.md's own framing that this phase adds almost no new
  product feature code
- `AUDIT_FINDINGS.md` and `LAUNCH_CHECKLIST.md` (T002/T003) are living documents updated by
  nearly every subsequent task, not written once and left alone
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
