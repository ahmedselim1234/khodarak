---

description: "Task list for Phase 0 — Foundation"
---

# Tasks: Phase 0 — Foundation

**Input**: Design documents from `/specs/001-phase-0-foundation/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/health-check.md, quickstart.md

**Tests**: Included — the design phase (research.md, plan.md Technical Context) explicitly scoped
a Playwright route smoke test and an env-validation unit test as part of this phase's design, so
they are generated here rather than omitted.

**Organization**: Tasks are grouped by user story (US1/US2/US3, matching spec.md's P1/P2/P3
priorities) to enable independent implementation and testing of each.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and basic structure

- [X] T001 Initialize Next.js App Router + TypeScript project at repo root (`package.json`, `tsconfig.json` in strict mode, `next.config.js`)
- [X] T002 [P] Install and scaffold Tailwind CSS (`postcss.config.js`, `styles/globals.css` with Tailwind directives, empty `tailwind.config.ts`)
- [X] T003 [P] Install `@supabase/supabase-js`, `@supabase/ssr`, `zod`, `@reduxjs/toolkit`, `react-redux`
- [X] T004 [P] Configure ESLint + Prettier for TypeScript strict mode per Constitution Principle IV
- [X] T005 Create base folder skeleton per plan.md Project Structure: `app/`, `components/ui/`, `lib/`, `lib/supabase/`, `lib/store/`, `tests/unit/`, `tests/e2e/`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T006 Port design tokens (`colors`, `borderRadius`, `spacing`, `fontFamily`, `fontSize`) verbatim from `design/home.html` lines 36–124 into `tailwind.config.ts` `theme.extend` per research.md
- [X] T007 [P] Wire Plus Jakarta Sans via `next/font` and the Material Symbols Outlined icon font, referenced from `app/layout.tsx`
- [X] T008 Create root layout `app/layout.tsx` with `<html lang="ar" dir="rtl">`, global styles import, and font wiring from T007 (depends on T006, T007)
- [X] T009 [P] Create `lib/env.ts`: zod schema validating `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`; parse once at import time; throw a descriptive error naming the missing/invalid field (FR-006)
- [X] T010 [P] Create `lib/supabase/client.ts`: browser Supabase client via `@supabase/ssr`'s `createBrowserClient`, using only the `NEXT_PUBLIC_*` vars from T009
- [X] T011 [P] Create `lib/supabase/server.ts`: server-only Supabase client via `@supabase/ssr`'s `createServerClient`, using the service role key from T009 (never imported client-side)
- [X] T012 [P] Create `lib/store/index.ts`: Redux Toolkit store scaffold with no slices containing real business logic
- [X] T013 Create `app/not-found.tsx` styled with the ported tokens (T006) and RTL layout (T008) for FR-004 (depends on T006, T008)
- [X] T014 [P] Create `.env.example` listing `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` with comments

**Checkpoint**: Foundation ready — design tokens, RTL layout, env validation, and Supabase clients all exist; user story implementation can now begin.

---

## Phase 3: User Story 1 - Visitor reaches a styled, on-brand shell on every committed route (Priority: P1) 🎯 MVP

**Goal**: Every committed route (`/`, `/browse`, `/browse/[id]`, `/subscription`, `/dashboard`, `/dashboard/orders`, `/dashboard/settings`, `/admin`, `/login`) is reachable and renders the ported design system in RTL.

**Independent Test**: Visit each route directly; each MUST return a successful render (no 404/500) styled with the ported tokens and `dir="rtl"` — per quickstart.md step 3.

### Tests for User Story 1

> Write this test FIRST; it MUST fail until the routes below exist.

- [X] T015 [P] [US1] Write Playwright smoke test `tests/e2e/routes.smoke.spec.ts` asserting all 9 committed routes return a successful response with root `dir="rtl"` (per contracts and quickstart.md step 3)

### Implementation for User Story 1

- [X] T016 [P] [US1] Create shared UI primitives (`Card`, `Button`, `Container`) in `components/ui/` styled with the `organic` radius and design tokens from T006
- [X] T017 [P] [US1] Implement `/` (home) route in `app/(marketing)/page.tsx`, structurally referencing `design/home.html`, using primitives from T016
- [X] T018 [P] [US1] Implement `/browse` route in `app/browse/page.tsx`, structurally referencing `design/products.html`
- [X] T019 [P] [US1] Implement `/browse/[id]` route in `app/browse/[id]/page.tsx`, structurally referencing `design/product-details.html`
- [X] T020 [P] [US1] Implement `/subscription` route in `app/subscription/page.tsx`, structurally referencing `design/subscription-builder.html`
- [X] T021 [P] [US1] Implement `/dashboard` route in `app/dashboard/page.tsx`, structurally referencing `design/dashboard.html`
- [X] T022 [P] [US1] Implement `/dashboard/orders` route in `app/dashboard/orders/page.tsx`, structurally referencing `design/my-orders.html`
- [X] T023 [P] [US1] Implement `/dashboard/settings` route in `app/dashboard/settings/page.tsx`, structurally referencing `design/settings.html`
- [X] T024 [P] [US1] Implement `/admin` route in `app/admin/page.tsx` using shared tokens/primitives with a generic layout (no mockup exists — per Clarifications 2026-08-10)
- [X] T025 [P] [US1] Implement `/login` route in `app/login/page.tsx` using shared tokens/primitives with a generic layout (no mockup exists — per Clarifications 2026-08-10)
- [X] T026 [US1] Run the Playwright smoke test (T015) against T016–T025 and fix any route failing the 200/`dir="rtl"` assertion (depends on T015–T025)
- [X] T027 [US1] Manual visual spot-check: compare 2–3 rendered routes against their matching `design/*.html` file for primary color (`#00450d`), `organic` (20px) radius, and Plus Jakarta Sans typography, per quickstart.md step 3 (depends on T026)

**Checkpoint**: User Story 1 fully functional and independently testable — this is the plan.md Phase 0 demo ("empty but styled RTL shell... with all routes reachable").

---

## Phase 4: User Story 2 - Developer can run the project locally against a real backend project (Priority: P2)

**Goal**: A developer with valid env config can boot the app locally and reach the configured Supabase project; invalid/missing config fails fast with a clear error; the app builds and runs in Docker.

**Independent Test**: quickstart.md steps 1, 2, and 5 — env fail-fast, local boot + `/api/health`, and Docker build/run.

### Tests for User Story 2

> Write this test FIRST; it MUST fail until `lib/env.ts`'s fail-fast behavior is verified.

- [X] T028 [P] [US2] Write unit test `tests/unit/env.test.ts` asserting `lib/env.ts` (T009) throws a descriptive error naming the specific missing/invalid variable when required config is absent (FR-006, SC-004)

### Implementation for User Story 2

- [X] T029 [US2] Implement `app/api/health/route.ts` per `contracts/health-check.md`: lightweight Supabase reachability check, returns `200 {"status":"ok","supabase":"reachable"}` or `503` with a non-sensitive `detail` (depends on T011)
- [X] T030 [US2] Run T028 against T009 and confirm the fail-fast behavior passes (depends on T009, T028)
- [X] T031 [P] [US2] Create `Dockerfile` building and running the Next.js app in production mode
- [X] T032 [P] [US2] Create `docker-compose.yml` wiring the env vars from `.env.example` (T014) and exposing the app port
- [X] T033 [US2] Verify the Docker build/run flow end-to-end per quickstart.md step 5: `docker compose build && docker compose up`, confirm `/api/health` responds (depends on T029, T031, T032)
- [X] T034 [US2] Verify the fresh-clone-to-running-locally flow completes in under 10 minutes per quickstart.md step 2 (SC-003) (depends on T001–T014, T029)

**Checkpoint**: User Stories 1 AND 2 both work independently.

---

## Phase 5: User Story 3 - Developer can find a predictable place for each future phase's code (Priority: P3)

**Goal**: The repository has an obvious, documented location for routes, shared UI, design tokens, and server-side backend access, so Phase 1+ work has nowhere to guess.

**Independent Test**: Inspect the repo structure and confirm designated locations exist for routes, shared UI components, design token config, and server-side backend access code, matching plan.md's Project Structure.

### Implementation for User Story 3

- [X] T035 [P] [US3] Add a "Project Structure" section to `README.md` documenting `app/` (routes), `components/ui/` (shared UI), `lib/` (design tokens live in `tailwind.config.ts`, backend access in `lib/supabase/`), and where later phases should add business logic (e.g. a future `lib/pricing/`)
- [X] T036 [US3] Review the repository against plan.md's Project Structure and reconcile any drift introduced during Phase 3/4 implementation (no duplicate or ambiguous locations for the same kind of file) (depends on T001–T034)

**Checkpoint**: All three user stories independently functional — Phase 0 is demo-ready.

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Final verification across all three stories

- [X] T037 [P] Run the full `quickstart.md` validation (all 6 steps) end-to-end and confirm all pass
- [X] T038 [P] Confirm `tsc --noEmit` passes with zero errors and no unexplained `any` (Constitution Principle IV)
- [X] T039 [P] Confirm no page or Route Handler added in this phase computes pricing, payment, or account-data logic (FR-010) — final compliance check
- [X] T040 Baseline mobile spot-check (Lighthouse or equivalent) on `/` and `/browse` — informational only, not a hard gate until Phase 9 per Constitution Principle III

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — start immediately
- **Foundational (Phase 2)**: Depends on Setup — BLOCKS all user stories
- **User Story 1 (Phase 3)**: Depends on Foundational only
- **User Story 2 (Phase 4)**: Depends on Foundational only (T029 also depends on T011 from Foundational)
- **User Story 3 (Phase 5)**: Depends on Foundational; T036 depends on US1 and US2 being complete since it reconciles drift from both
- **Polish (Phase 6)**: Depends on US1, US2, and US3 all being complete

### User Story Dependencies

- **User Story 1 (P1)**: No dependency on US2/US3 — independently testable via the Playwright smoke test alone
- **User Story 2 (P2)**: No dependency on US1 — independently testable via `/api/health` + Docker alone; can be built in parallel with US1
- **User Story 3 (P3)**: Documentation/verification task; T035 is independent, T036 waits on US1+US2 output to verify against

### Parallel Opportunities

- All Setup tasks marked [P] (T002–T004) can run in parallel after T001
- All Foundational [P] tasks (T007, T009–T012, T014) can run in parallel once T005/T006 land
- Once Foundational completes, **US1 (Phase 3) and US2 (Phase 4) can be worked fully in parallel** — different files, no shared dependencies besides the Foundational phase
- Within US1, T017–T025 (all 9 route implementations) are [P] — different files
- Within US2, T031/T032 (Dockerfile/compose) are [P]

---

## Parallel Example: User Story 1

```bash
# After T016 (shared UI primitives) is done, launch all route implementations together:
Task: "Implement / route in app/(marketing)/page.tsx"
Task: "Implement /browse route in app/browse/page.tsx"
Task: "Implement /browse/[id] route in app/browse/[id]/page.tsx"
Task: "Implement /subscription route in app/subscription/page.tsx"
Task: "Implement /dashboard route in app/dashboard/page.tsx"
Task: "Implement /dashboard/orders route in app/dashboard/orders/page.tsx"
Task: "Implement /dashboard/settings route in app/dashboard/settings/page.tsx"
Task: "Implement /admin route in app/admin/page.tsx"
Task: "Implement /login route in app/login/page.tsx"
```

## Parallel Example: User Story 2

```bash
# After Foundational phase, launch these together:
Task: "Write unit test tests/unit/env.test.ts for env fail-fast behavior"
Task: "Create Dockerfile"
Task: "Create docker-compose.yml"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: run the Playwright smoke test + manual visual spot-check
5. This alone satisfies plan.md's stated Phase 0 demo ("empty but styled RTL shell... with all routes reachable")

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US1 → validate independently → demoable (matches plan.md's Phase 0 demo)
3. Add US2 → validate independently → local dev + Docker fully working
4. Add US3 → validate independently → structure documented, no drift
5. Polish → full quickstart.md pass, strict-mode clean, FR-010 compliance confirmed

### Parallel Team Strategy

With two developers:

1. Both complete Setup + Foundational together
2. Once Foundational is done:
   - Developer A: User Story 1 (routes + smoke test)
   - Developer B: User Story 2 (env test, `/api/health`, Docker)
3. Either developer picks up User Story 3 (lightweight) once both are done

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- This phase ships zero business logic (FR-010) — every task above is scaffolding, styling, or infrastructure wiring, never pricing/payment/account logic
- Commit after each task or logical group
- Stop at either the US1 or US2 checkpoint to validate that story independently before continuing
