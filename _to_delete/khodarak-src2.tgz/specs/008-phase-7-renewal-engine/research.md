# Phase 0 Research: Phase 7 — Renewal Engine & Dunning

## 1. How does the renewal job guard against double-processing the same subscription (FR-011)?

**Decision**: A single conditional `UPDATE subscriptions SET renewal_claimed_at = now() WHERE id
= $1 AND status = 'active' AND next_renewal_attempt_date <= current_date AND
(renewal_claimed_at IS NULL OR renewal_claimed_at < now() - interval '10 minutes') RETURNING id`.
Only the caller that gets a row back proceeds to charge that subscription; every other concurrent
or retried invocation sees zero rows returned and skips it. `renewal_claimed_at` is cleared by
`processRenewalOutcome.ts` once the cycle resolves (success, scheduled-for-retry, or suspended) —
the 10-minute expiry is a dead-man's-switch only, so a run that crashed mid-charge doesn't
permanently strand a subscription, not a normal part of the flow.

**Rationale**: This is the exact SQL-level compare-and-swap technique
`lib/payments/processPaymentOutcome.ts` already uses for payment-outcome idempotency
(`UPDATE ... WHERE status NOT IN ('paid','failed')`) — Postgres's own row-level locking makes the
`UPDATE ... WHERE ... RETURNING` atomic without needing an application-level lock or a queue.
Applying the identical pattern here (claiming a subscription row instead of resolving a payment
row) keeps this phase's idempotency story consistent with the one Phase 5 already established and
already trusted for real money.

**Alternatives considered**:
- *Advisory lock (`pg_advisory_lock`)*: rejected — solves the same problem but is a second,
  unfamiliar technique for the same class of guarantee the codebase already has one proven
  pattern for; introduces operational risk (a stuck advisory lock from a crashed connection)
  the conditional-`UPDATE`-with-expiry approach avoids entirely.
- *A separate `renewal_jobs` queue table*: rejected as over-engineering for this project's scope —
  a queue is the right tool for high-throughput/distributed job processing, not for a single
  sequential Route Handler processing however many subscriptions exist in one run.

## 2. What does the actual Moyasar renewal-charge call look like?

**Decision**: A new `lib/payments/moyasarClient.ts` function, `createRecurringPayment`, mirroring
`plan.md` §3b's own documented example verbatim: `{ amount, currency: 'SAR', description, source:
{ type: 'token', token }, metadata: { subscription_id, cycle_number, order_id } }` — critically,
**no `callback_url` and no explicit `3ds` field**, matching that exact example. `amount` is always
produced by the existing `toHalalas()` conversion point (Phase 5), never computed inline here.

**Rationale**: There is no browser present during an unattended renewal charge, so there is no
redirect target to send — omitting `callback_url` is not an oversight but the correct shape for
this call, and it's exactly what `plan.md` §3b's own snippet already shows for the renewal case
(distinct from the first-payment `createPayment` call, which does set `callback_url` for the
customer's 3DS redirect). `plan.md` §3b states directly that "for an active (already-verified)
token, 3DS defaults to false" — the absence of a `callback_url` is consistent with that default,
not a contradiction of it.

**Alternatives considered**: Reusing the existing `createPayment` function with an empty-string
`callback_url` — rejected as a misleading signature (a required-looking parameter silently made
optional in one caller) in favor of a second, narrowly-named function whose signature itself
documents that renewal charges never redirect anyone.

## 3. How is the subscription's next delivery date actually advanced?

**Decision**: A new pure function, `lib/subscription/advanceDeliveryDate.ts`, that adds exactly
one period to the subscription's *current* `next_delivery_date` — 7 days for `weekly`, 14 days for
`biweekly`, one calendar month (same day-of-month) for `monthly` — then, if the resulting date
falls on an admin-configured blackout weekday, advances day-by-day until it lands on a non-blackout
day.

**Rationale**: The existing `selectableDeliveryDates`/`isDateSelectable` (Phase 4) both anchor to
"today + lead time," which is the right anchor for *choosing* a brand-new first delivery date but
the wrong one for *advancing* an already-scheduled, already-communicated recurring delivery day —
a subscriber who signed up for "every Tuesday" should keep landing on Tuesdays indefinitely (offset
by their frequency), not silently drift onto whatever weekday happens to satisfy lead time from
whenever the renewal job happened to run. Blackout-day handling is still needed here (an admin
could add a new blackout weekday after a subscription was created), so that one piece of Phase 4's
logic is conceptually reused, but the anchor-from-today behavior is deliberately not.

**Alternatives considered**: Reusing `selectableDeliveryDates` directly by calling it with
`leadDays: 0` from "today" — rejected: it still anchors from *today* (the day the job runs), not
from the subscription's own established cycle date, so a job that happens to run a day late (or a
retried cycle resolved days after its original due date) would shift every future delivery's
weekday, which is exactly the drift this function exists to prevent.

## 4. How is the dunning retry schedule and suspend decision represented?

**Decision**: A new pure function, `lib/payments/dunningSchedule.ts`:
`nextRetryOrSuspend(attemptCount: number, firstFailedAt: Date): { action: 'retry'; retryAt: Date }
| { action: 'suspend' }`. `attemptCount` is the subscription's own `renewal_attempt_count` column
— 1 after the very first (non-retry) attempt fails, 2 after the first retry fails, 3 after the
second retry fails; a third retry's own failure (making it 4) triggers `suspend`. Retry offsets
(+1, +3, +5 days from `firstFailedAt`, per the clarification session) are internal constants, not
a parameter — this phase's own clarified decision was a fixed, non-configurable schedule.

**Rationale**: Keeping `firstFailedAt` fixed (rather than computing each retry's offset from the
*previous* attempt) is what makes "retry at +1/+3/+5 days" mean what it plainly reads as — offsets
from the original failure, not a compounding 1-then-3-more-then-5-more schedule that would push
the last retry out nine days rather than five. `attemptCount` living on the subscription itself
(rather than being derived by counting `payments` rows at read time) keeps the suspend decision a
pure, synchronous check the claim step can make without an extra query.

**Alternatives considered**: Deriving the schedule from stored `payments` timestamps at read time
instead of a counter column — rejected: it would work, but makes every renewal run's claim query
do more work (a join/subquery) to answer a question a single integer column answers directly, for
no correctness benefit given retries are always for the same still-open cycle by construction
(FR-013 requires the same computed amount is retried, which is only true if nothing else has
touched the cycle in between).

## 5. Why a protected Route Handler instead of `pg_cron`?

**Decision**: `POST /api/cron/renewals`, authenticated by a shared-secret header
(`Authorization: Bearer <CRON_SECRET>`) checked via `lib/validation/cronAuth.ts`, invoked by an
external scheduler (e.g. a platform's cron feature, or a simple `cron-job.org`/GitHub Actions
schedule hitting the URL) rather than Postgres's `pg_cron` extension.

**Rationale**: `plan.md` §4 itself frames this as a choice ("pg_cron *or* a protected API route hit
by an external scheduler"), and this project's actual deployment target (Phase 9,
`docker-compose.yml`) is a single Next.js web container with no separate scheduler process and no
existing `pg_net`/`pg_cron` setup anywhere in the repo — `pg_cron` would still need `pg_net` (or
equivalent) to reach this app's own business logic (the pricing engine, `calculate()`, item
availability checks) since none of that logic lives in the database itself, so choosing it would
add a second scheduling mechanism to configure in Supabase *in addition to* an HTTP entry point,
for no benefit this project's scale needs. A plain protected Route Handler is one thing to deploy,
consistent with every other phase's "no new infrastructure until Phase 9" discipline.

**Alternatives considered**: `pg_cron` calling a Postgres function directly (business logic moved
into SQL/`plpgsql`) — rejected outright: it would duplicate `calculate()`, `advanceDeliveryDate`,
`dunningSchedule`, and the Moyasar HTTP client in a second language/runtime, doubling the surface
area for the exact "a bug silently costs real money" risk the constitution calls out, for a
project with no throughput need that would justify it.

## 6. How does the existing webhook endpoint know which outcome processor to call?

**Decision**: `payments` gains a `kind` column (`'initial' | 'renewal'`), set once at
`INSERT` time by whichever endpoint created the attempt (`POST /api/subscriptions/[id]/pay` for
`'initial'`, this phase's cron route for `'renewal'`). The webhook route looks up the matching
`payments` row by `moyasar_payment_id` *before* deciding which processor to call, and dispatches
to `processPaymentOutcome.ts` or `processRenewalOutcome.ts` accordingly.

**Rationale**: The webhook route already has to look up context to act safely; adding one column
to key an `if` on is the smallest change that lets one shared, public, unauthenticated endpoint
correctly route both charge flows through their own (also independently idempotent) processors,
without either processor needing to guess or duplicate the other's responsibilities.

**Alternatives considered**: Inferring "renewal vs. initial" from subscription state instead (e.g.
"if `subscriptions.status` is already `'active'`, it must be a renewal") — rejected: fragile and
indirect (a paid renewal that already succeeded before the webhook arrives would make an *already*
`'active'` subscription look identical to one still stuck in initial activation under edge-case
timing), where an explicit column recorded at the moment of charge creation is unambiguous by
construction.
