# Implementation Plan: Phase 8 — Admin Operations

**Branch**: `009-phase-8-admin-operations` | **Date**: 2026-08-11 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/009-phase-8-admin-operations/spec.md`

## Summary

Gives operators, for the first time, visibility and limited write access into data every prior
phase has kept customer-owned: orders (advance/cancel status), subscriptions (pause/cancel with a
required reason, both stamped with the acting admin), payments (read-only, cross-customer), and
cities (full CRUD, previously seed-only) — plus a landing counters view for `/admin`. Every list
follows Phase 2's own established `queryProducts.ts`-style pattern (a Server Component parsing
typed `searchParams` — status/date/search — into a filtered, paginated Supabase query), and every
write follows Phase 2's own established RLS pattern (an inline `profiles.role = 'admin'` check in
the policy itself, plus a shared `requireAdmin()` app-layer guard in the Route Handler) — not the
service-role-only pattern Phase 5/6/7 use for customer-facing financial writes, since that pattern
exists specifically to block a *customer's own session* from self-escalating, a risk that doesn't
apply to a trusted, already-role-gated admin write. The one real schema gap this phase closes:
`profiles` has never stored email (it lives only in `auth.users`, unreadable through the ordinary
RLS-scoped client), so "search by name/email/phone" needs a denormalized `profiles.email` column,
synced by the existing signup trigger.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0–7)

**Primary Dependencies**: No new dependency. Extends the existing per-request RLS-scoped Supabase
client (`lib/supabase/server.ts`) for every read and write this phase introduces — this phase
introduces **no new service-role usage** (research.md §1), the first phase since Phase 4 not to.
Redux Toolkit + RTK Query for the row-level action mutations only (order status, subscription
pause/cancel, city create/edit), following `productsAdminApi.ts`'s exact shape.

**Storage**: Supabase (Postgres) — extends `profiles` (email), `orders` (status-change
attribution), `subscriptions` (cancel attribution/reason), `subscription_pauses` (Phase 6/7, admin
attribution/reason), and `cities` (admin write policies only — no new columns, per FR-013/014).
No new tables — "Admin Action Record" (spec.md's Key Entities) is realized as columns on the
records it describes, not a standalone audit-log table (research.md §2).

**Testing**: Vitest for this phase's one pure decision function —
`lib/orders/orderStatusTransition.ts` (the forward-progression rule, FR-003 — exactly the kind of
"a bug silently costs real money/trust" rule Constitution Principle VI calls out, since a bad
transition would misrepresent real deliveries) — written and passing before the Route Handler that
uses it. Playwright for the phase's demo path: advance an order from `pending` through
`out_for_delivery` to `delivered` as an admin, and confirm the same order's existing customer
detail view (Phase 6) reflects it.

**Target Platform**: Same as Phase 0–7 — `npm run dev` locally; no new infrastructure.

**Project Type**: Web application — same single Next.js monolith, no new deployable.

**Performance Goals**: Every list (orders/subscriptions/payments) is paginated server-side
(`PAGE_SIZE`, mirroring `queryProducts.ts`) rather than loading a growing table's full history at
once — the only new performance consideration this phase introduces, since every prior admin
screen (products, settings) had at most dozens of rows.

**Constraints**: Every write this phase introduces MUST go through an RLS policy that inline-checks
`profiles.role = 'admin'` (Phase 2's own established pattern, not Phase 5/6/7's service-role-only
pattern) — because the risk that pattern defends against (a *customer's own session* writing
financial/subscription state) doesn't apply here: these are trusted, already role-gated admin
writes, and Phase 2's own products/settings admin surfaces already prove this pattern is this
project's real precedent for admin CRUD, not an exception to it. Every admin write Route Handler
MUST record the acting admin's own id (from `requireAdmin()`'s already-fetched session) alongside
the change, per FR-004a/007/008.

**Scale/Scope**: 1 migration (`profiles.email` + trigger update + backfill, admin RLS policies on
`orders`/`subscriptions`/`subscription_pauses`/`cities`, attribution columns), 1 shared
`requireAdmin()` helper (extracted from its current per-route duplication), 8 new Route Handlers,
1 pure decision function with its own test suite, 3 new `searchParams`-driven query helpers
(mirroring `queryProducts.ts`), ~14 new components, 3 new RTK Query slices (order actions,
subscription actions, cities), 6 new/replaced `/admin/*` pages.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — every list/detail/counters view is a Server Component reading directly from Supabase (Constitution Principle I, `queryProducts.ts`'s own precedent); `"use client"` is scoped to row-action buttons and the pause/cancel/city-edit dialogs only | PASS |
| II. Server-Side Authority for Business Logic | Yes — order status transitions are validated server-side against the fixed forward-progression rule (`orderStatusTransition.ts`), never trusted from the client; revenue/counters are computed fresh from current data on every view (FR-015), never cached client-side | PASS |
| III. Performance Budget & Core Web Vitals | Yes — no new client bundle weight beyond small row-action leaves; server-side pagination keeps every list's initial payload bounded regardless of total row count | PASS |
| IV. Type Safety & Validation at Boundaries | Yes — every new Route Handler body (order status, pause/cancel reason, city fields) is zod-validated before use, mirroring `lib/validation/product.ts`'s existing shape | PASS |
| V. Data Integrity, Idempotency & Security | Yes — order status transitions are guarded by the same "only from its actual current status" rule a concurrent edit can't bypass (research.md §3, a conditional `UPDATE ... WHERE status = $expected`); every admin write is gated by an RLS policy checking `profiles.role = 'admin'` inline, closing the same class of gap Phase 1's `profiles.role` incident taught this project to take seriously — but via the *admin-write-policy* pattern Phase 2 already established, not by inventing a new one | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — `orderStatusTransition.ts` ships with Vitest coverage (every valid transition, every rejected one) before the Route Handler uses it | PASS |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts keep every admin write on the RLS-scoped client
with an inline-checked policy (no service-role import anywhere in this phase's own files),
`orderStatusTransition.ts` as a pure, dependency-free function, and every list's `searchParams`
parsing as a typed, pure helper separate from the Supabase query itself (mirroring
`parseCatalogSearchParams`). Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/009-phase-8-admin-operations/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── admin/
│   ├── page.tsx                       # REPLACED placeholder — the three counters (US3)
│   ├── orders/
│   │   └── page.tsx                   # NEW — list, searchParams-driven (status/date/search)
│   ├── subscriptions/
│   │   ├── page.tsx                   # NEW — list, searchParams-driven (status/search)
│   │   └── [id]/
│   │       └── page.tsx               # NEW — detail: items, frequency, price, address,
│   │                                  # payment history, Phase 7 dunning state, pause/cancel
│   │                                  # entry points
│   ├── payments/
│   │   └── page.tsx                   # NEW — list, searchParams-driven (status/date/search),
│   │                                  # read-only (no row actions — Assumptions)
│   └── cities/
│       └── page.tsx                   # NEW — list + inline add/edit (small enough for one
│                                      # page, no separate /new or /[id]/edit routes)
└── api/
    └── admin/
        ├── orders/
        │   └── [id]/
        │       └── route.ts           # NEW — PATCH: status transition, per
        │                              # contracts/admin-orders-api.md
        ├── subscriptions/
        │   └── [id]/
        │       ├── pause/
        │       │   └── route.ts       # NEW — POST: admin pause, reason required
        │       └── cancel/
        │           └── route.ts       # NEW — POST: admin cancel, reason required
        └── cities/
            ├── route.ts               # NEW — POST: create
            └── [id]/
                └── route.ts           # NEW — PATCH: edit (name/active/fee override)

components/
└── admin/
    ├── AdminShell.tsx                  # NEW — shared chrome (TopNav + admin SideNav + content
    │                                   # well), mirroring components/dashboard/DashboardShell.tsx
    │                                   # (Phase 6)'s exact shape, applied to every /admin/* page
    │                                   # including the existing products/settings screens
    ├── AdminSideNav.tsx                 # NEW — لوحة التحكم / المنتجات / الاشتراكات / الطلبات /
    │                                   # المدفوعات / المدن / الإعدادات, `activePath` prop
    ├── counters/
    │   └── CountersOverview.tsx        # NEW — Server Component, the three labeled counters
    ├── orders/
    │   ├── OrderTable.tsx              # NEW — Server Component, per queryAdminOrders.ts
    │   └── OrderRowActions.tsx         # NEW — "use client", status-advance/cancel buttons
    │                                   # (only the currently-valid next actions are shown,
    │                                   # mirroring orderStatusTransition.ts)
    ├── subscriptions/
    │   ├── SubscriptionTable.tsx       # NEW — Server Component, per queryAdminSubscriptions.ts
    │   ├── SubscriptionDetailView.tsx  # NEW — Server Component, full detail (FR-006)
    │   ├── AdminPauseDialog.tsx        # NEW — "use client", reason (required) + optional
    │   │                               # resume date, reusing Phase 6's PauseDialog's shape
    │   │                               # but posting to the admin endpoint
    │   └── AdminCancelDialog.tsx       # NEW — "use client", reason (required) confirm step
    ├── payments/
    │   └── PaymentTable.tsx            # NEW — Server Component, per queryAdminPayments.ts,
    │                                   # read-only
    └── cities/
        ├── CityTable.tsx               # NEW — Server Component
        └── CityForm.tsx                # NEW — "use client", create/edit (reused for both,
                                        # mirroring components/address/AddressForm.tsx's own
                                        # create-vs-edit-in-one-form shape)

lib/
├── admin/
│   ├── requireAdmin.ts                 # NEW — extracted shared helper (auth + role check),
│   │                                   # replacing the identical inline logic currently
│   │                                   # duplicated in app/api/admin/products/*/route.ts and
│   │                                   # app/api/admin/settings/route.ts (both updated to use
│   │                                   # it too — a small, safe dedup, not a behavior change)
│   ├── queryAdminOrders.ts             # NEW — searchParams → typed query → Supabase query,
│   │                                   # mirroring lib/products/queryProducts.ts
│   ├── queryAdminSubscriptions.ts      # NEW — same shape, subscriptions
│   └── queryAdminPayments.ts           # NEW — same shape, payments
├── orders/
│   └── orderStatusTransition.ts        # NEW pure fn — the forward-progression rule (FR-003)
├── validation/
│   ├── adminOrderStatus.ts             # NEW — zod schema, PATCH order status body
│   ├── adminSubscriptionAction.ts      # NEW — zod schema, pause/cancel body (reason required)
│   └── city.ts                         # NEW — zod schema, city create/edit body
└── store/
    ├── adminOrdersApi.ts               # NEW — RTK Query: updateOrderStatus mutation
    ├── adminSubscriptionsApi.ts        # NEW — RTK Query: pause/cancel mutations
    └── adminCitiesApi.ts               # NEW — RTK Query: create/update mutations

supabase/
└── migrations/
    └── <timestamp>_admin_operations.sql   # ALTER profiles (email + trigger update +
                                            # backfill); ALTER orders (status_updated_by,
                                            # status_updated_at); ALTER subscriptions
                                            # (cancelled_by_admin_id, cancel_reason); ALTER
                                            # subscription_pauses (initiated_by_admin_id,
                                            # reason); admin-write RLS policies on orders,
                                            # subscriptions, subscription_pauses, cities
                                            # (data-model.md)

tests/
├── unit/
│   └── orders.orderStatusTransition.test.ts   # every valid forward transition, every
│                                               # rejected one (backward, skip, post-delivered)
└── e2e/
    └── admin-operations.spec.ts        # pending → out_for_delivery → delivered as admin,
                                        # confirmed on the customer's own order detail —
                                        # quickstart.md's full walkthrough
```

**Structure Decision**: Stays inside the Phase 0–7 monolith. `AdminShell`/`AdminSideNav` are new
this phase (mirroring `DashboardShell`/`SideNav` from Phase 6) and are retrofitted onto the
*existing* products/settings admin pages too — `/admin` has never had a side nav or consistent
chrome before this phase, and since every `/admin/*` route needs the same navigation regardless of
which phase introduced it, building it once here and applying it everywhere is simpler than
leaving two different `/admin` visual treatments coexisting. Every list read and every admin write
uses the ordinary per-request RLS-scoped client (`lib/supabase/server.ts`) — this phase introduces
zero new service-role usage, a deliberate contrast with Phase 5/6/7 (research.md §1's own
reasoning for why that pattern doesn't apply to trusted admin writes the way it does to
customer-session writes).

## Complexity Tracking

*No Constitution Check violations — table not needed.*
