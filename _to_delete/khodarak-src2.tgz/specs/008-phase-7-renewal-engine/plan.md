# Implementation Plan: Phase 7 — Renewal Engine & Dunning

**Branch**: `008-phase-7-renewal-engine` | **Date**: 2026-08-11 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/008-phase-7-renewal-engine/spec.md`

## Summary

A protected Route Handler, called on a recurring schedule by an external trigger, finds every
`active` subscription whose next delivery (or next-due retry) has arrived, atomically claims each
one to guard against overlapping/retried invocations, re-prices its box against *current*
settings/prices (dropping any since-unavailable product), and charges its saved Moyasar token
with 3DS off and no `callback_url` (an unattended background charge, per `plan.md` §3b's own
example) — generating the cycle's order and advancing `next_delivery_date` only once that charge
is confirmed `paid`, exactly mirroring how Phase 5 already treats its first charge ("charge the
saved token, then generate the order only on successful payment"). A failed charge does **not**
advance the delivery date; instead it schedules a retry per a fixed +1/+3/+5-day schedule against
whatever card is currently saved at each attempt, and after the last scheduled retry also fails,
the subscription is paused with no resume date — reusing Phase 6's existing `paused` status and
every dashboard surface built for it, so this phase introduces no new customer-facing screen.
Outcome processing (`processRenewalOutcome.ts`) is a new sibling to Phase 5's
`processPaymentOutcome.ts`, using the identical idempotent-conditional-update technique, since a
renewal charge's outcome can arrive from either the job's own synchronous response or the existing
webhook endpoint — both must converge on the same result no matter which resolves it first.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0–6)

**Primary Dependencies**: No new dependency. Extends `@supabase/supabase-js` (the existing
`lib/supabase/serviceRole.ts` client — every write this phase makes is financial/subscription
state, so it follows the same service-role-only rule Phase 5/6 already established), and
`lib/payments/moyasarClient.ts` gains one new function for unattended token charges.

**Storage**: Supabase (Postgres) — extends `subscriptions` with renewal-scheduling/retry-tracking
columns and a short-lived claim lock; extends `payments` with a `kind` column
(`'initial' | 'renewal'`) so the existing webhook endpoint can dispatch to the correct outcome
processor. No new top-level tables — `orders`/`order_items`/`payment_methods` are read/written
using their existing Phase 5 shapes.

**Testing**: Vitest for this phase's pure decision functions —
`lib/subscription/advanceDeliveryDate.ts` (period advancement + blackout-day skip),
`lib/payments/dunningSchedule.ts` (the fixed +1/+3/+5-day retry schedule and the
attempt-count-to-suspend decision), and `lib/subscription/reprice.ts`'s
unavailable-item-exclusion logic — all written and passing before the Route Handler that calls
them, per Constitution Principle VI (this is explicitly the kind of function the constitution
calls out: "a bug silently costs real money"). Playwright for the phase's demo path: back-date a
subscription, trigger the job, confirm a new order/advanced date; force a decline, confirm the
retry schedule and eventual suspension.

**Target Platform**: Same as Phase 0–6 — `npm run dev` locally; the scheduled trigger itself is an
external concern (a `cron`-style caller hitting the protected endpoint) documented but not
deployed until Phase 9's Docker/launch work, consistent with every prior phase's "runs against
real test services with `npm run dev`, no infrastructure stood up early" discipline.

**Project Type**: Web application — same single Next.js monolith, no new deployable; the "job" is
just another Route Handler, not a separate process.

**Performance Goals**: The renewal endpoint processes subscriptions sequentially in one request
(no realistic near-term subscriber count in this project's scope justifies a queue/worker system);
each subscription's own charge is independent, so one slow/failed Moyasar call for one subscriber
never blocks or fails another's in the same run.

**Constraints**: Every write that changes `subscriptions`/`payments`/`orders`/`order_items`
state in this phase goes exclusively through the service-role client from
`lib/subscription/mutateSubscription.ts` (extended) and the new
`lib/payments/processRenewalOutcome.ts`, never an owner-scoped RLS write path — continuing
Phase 5/6's established rule, since a renewal charge is exactly the class of financial state a
customer's own session must never be able to influence. The claim-lock step (guarding FR-011's
idempotency guarantee against overlapping job runs) uses a single conditional `UPDATE ... WHERE
... RETURNING` — the same SQL-level compare-and-swap technique `processPaymentOutcome.ts` already
uses for payment-outcome idempotency (research.md §3), applied here to claiming a subscription for
processing rather than resolving a payment.

**Scale/Scope**: 1 migration (subscription renewal-scheduling columns + `payments.kind`), 1 new
protected Route Handler (`POST /api/cron/renewals`), 1 new Moyasar client function
(`createRecurringPayment`), 1 new outcome processor (`processRenewalOutcome.ts`, the phase's
central piece), 3 new pure lib modules with their own test suites, 1 small extension to the
existing webhook route's dispatch logic, 1 env var (`CRON_SECRET`).

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | No new pages/components this phase — it's a background Route Handler with no UI of its own (FR-016: reuses Phase 6's dashboard verbatim) | N/A |
| II. Server-Side Authority for Business Logic | Yes — the central concern. Every renewal charge amount is recomputed server-side by the same `calculate()` used everywhere else, never trusted from any stored value beyond the cycle's own already-locked first-attempt amount (retries reuse that amount, never a fresh one — spec.md's own edge case) | PASS |
| III. Performance Budget & Core Web Vitals | No customer-facing route or bundle change this phase | N/A |
| IV. Type Safety & Validation at Boundaries | Yes — the cron endpoint's own auth header and the extended webhook payload (`kind`-aware dispatch) are validated before use | PASS |
| V. Data Integrity, Idempotency & Security | Yes — this phase's defining concern. Orders remain immutable snapshots; every write goes through the service-role client (no RLS write gap); the claim-lock + conditional-update pattern makes a doubly-invoked job run, and a redelivered webhook for a renewal charge, both safe no-ops past the first resolution — directly extending Phase 5's own idempotency design to a second, unattended charge path | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — `advanceDeliveryDate.ts`, `dunningSchedule.ts`, and the unavailable-item re-pricing logic are exactly the "bug silently costs real money" functions the constitution names; all ship with Vitest coverage before the Route Handler uses them. Structured logging (subscription id, cycle date, attempt number) is added to the renewal endpoint for the same reason Phase 5's webhook/callback routes already log this way — an unattended job is unobservable by default otherwise | PASS |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts keep the service-role client's use narrowly scoped
to `mutateSubscription.ts`/`processRenewalOutcome.ts` (never imported elsewhere), keep
`advanceDeliveryDate.ts`/`dunningSchedule.ts`/the re-pricing helper as pure, dependency-free
functions, and keep the claim-lock step as an explicit, single conditional `UPDATE` rather than an
assumed-safe read-then-write. Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/008-phase-7-renewal-engine/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md        # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── api/
│   ├── cron/
│   │   └── renewals/
│   │       └── route.ts             # NEW — POST, protected by a shared-secret header
│   │                                 # (CRON_SECRET). Finds every subscription due for a
│   │                                 # first attempt or a scheduled retry, claims each one
│   │                                 # (research.md §1), re-prices, charges, and delegates
│   │                                 # outcome handling to processRenewalOutcome.ts. Never
│   │                                 # touches a browser session — no cookies/RLS client at
│   │                                 # all, service-role only throughout
│   └── webhooks/
│       └── moyasar/
│           └── route.ts             # UPDATED — dispatches to processPaymentOutcome.ts
│                                     # (Phase 5, unchanged) or processRenewalOutcome.ts
│                                     # (this phase) based on the matching payments row's
│                                     # `kind` column, looked up by moyasar_payment_id before
│                                     # either processor runs

lib/
├── payments/
│   ├── moyasarClient.ts             # UPDATED — adds createRecurringPayment: source: token,
│   │                                 # amount, currency, description, metadata — no
│   │                                 # callback_url, no 3ds field, per plan.md §3b's own
│   │                                 # example (research.md §2)
│   ├── processRenewalOutcome.ts     # NEW — the shared, idempotent renewal-resolution
│   │                                 # function (this phase's processPaymentOutcome.ts
│   │                                 # sibling): on 'paid', generates the order and advances
│   │                                 # next_delivery_date; on 'failed', advances the retry
│   │                                 # state (or suspends) via dunningSchedule.ts. Called
│   │                                 # from both the cron route's own synchronous response
│   │                                 # handling and the webhook route
│   ├── dunningSchedule.ts           # NEW pure fn — given an attempt count and "now", returns
│   │                                 # the next retry date or "suspend" (FR-013/FR-015,
│   │                                 # research.md §4)
│   └── cardExpiry.ts                # NEW pure fn — given a saved card's exp_month/exp_year
│                                     # and a target delivery date, returns whether it's
│                                     # already expired as of that date (FR-006)
├── subscription/
│   ├── advanceDeliveryDate.ts       # NEW pure fn — given a subscription's current
│   │                                 # next_delivery_date, its frequency, and blackout
│   │                                 # weekdays, returns the next cycle's date: +7/+14 days
│   │                                 # or +1 calendar month, then skipped forward past any
│   │                                 # blackout weekday (research.md §3) — deliberately NOT
│   │                                 # `selectableDeliveryDates` (Phase 4), which anchors to
│   │                                 # "today + lead time", the wrong anchor for keeping an
│   │                                 # existing subscriber on their established delivery day
│   ├── reprice.ts                   # NEW — server-only: loads a subscription's current
│   │                                 # items, drops any unavailable product (recording which
│   │                                 # were dropped), resolves a due pending-change per
│   │                                 # Phase 6's own resolveEffectiveConfig.ts (reused,
│   │                                 # unchanged), and calls the existing calculate()
│   │                                 # (Phase 3, unchanged) for the fresh breakdown
│   ├── mutateSubscription.ts        # UPDATED — adds the renewal claim-lock, retry-state,
│   │                                 # and suspend transitions (research.md §1), alongside
│   │                                 # Phase 6's existing edit/pause/resume/cancel functions
│   ├── resolveEffectiveConfig.ts    # EXISTING (Phase 6), reused unchanged by reprice.ts
│   └── selectableDeliveryDates.ts   # EXISTING (Phase 4), unchanged — still used by Phase 6's
│                                     # own resume flow; NOT reused by this phase's own date
│                                     # advancement (see advanceDeliveryDate.ts above)
├── validation/
│   └── cronAuth.ts                  # NEW — small helper validating the shared-secret header
│                                     # against serverEnv.CRON_SECRET (constant-time, same
│                                     # technique as verifyWebhookSignature.ts)
└── env.server.ts                    # UPDATED — adds CRON_SECRET

supabase/
└── migrations/
    └── <timestamp>_renewal_engine.sql   # ALTER subscriptions: renewal_attempt_count,
                                          # next_renewal_attempt_date, renewal_claimed_at;
                                          # ALTER payments: kind ('initial' | 'renewal',
                                          # backfilled 'initial' for existing rows). No new
                                          # authenticated-role write policy on either table
                                          # (data-model.md)

tests/
├── unit/
│   ├── subscription.advanceDeliveryDate.test.ts   # weekly/biweekly/monthly period math,
│   │                                                # blackout-day skip-forward cases
│   ├── payments.dunningSchedule.test.ts            # each attempt-count → next-retry-date or
│   │                                                # suspend transition
│   └── payments.cardExpiry.test.ts                 # already-expired, expires-before-delivery,
│                                                     # still-valid cases
└── e2e/
    └── renewal-engine.spec.ts       # back-dated subscription → successful renewal → new
                                      # order/advanced date; declining test card → retry
                                      # schedule → suspension — quickstart.md's full walkthrough
```

**Structure Decision**: Stays inside the Phase 0–6 monolith; the "job" is an ordinary, protected
Route Handler rather than new infrastructure — this project's Docker deployment (`plan.md`
§0.A/§4's Phase 9) is a single web container with no cron process of its own, so "a protected API
route hit by an external scheduler" (the option `plan.md` itself offers alongside `pg_cron`) is
the one that fits without inventing new infrastructure this phase doesn't otherwise need
(research.md §5). `processRenewalOutcome.ts` is a deliberate sibling to, not a modification of,
Phase 5's `processPaymentOutcome.ts` — the two charge flows differ enough (renewal re-prices and
advances a date instead of activating a subscription and saving a card) that forcing one function
to branch between both responsibilities would be harder to reason about than two focused
functions sharing only the idempotency technique and the service-role client, both already proven
patterns from Phase 5.

## Complexity Tracking

*No Constitution Check violations — table not needed.*
