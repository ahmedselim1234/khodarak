# Quickstart: Validating Phase 3 — Admin Settings & the Pricing Engine

Validates the three user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 2 checkout (products exist, admin account exists).

## Prerequisites

- Phase 2's quickstart already passing (an admin test account, at least a couple of products)
- Migration applied: `settings` (seeded with one default row — see
  [data-model.md](./data-model.md))
- `npm run dev` running

## 1. Run the pricing engine's unit suite first (Constitution Principle VI)

```
npm run test:unit
```

**Expected**: `tests/unit/pricing.calculate.test.ts` passes every boundary case in
[contracts/pricing-calculation.md](./contracts/pricing-calculation.md)'s required-cases table —
min order value, the free-delivery threshold exactly hit, VAT inclusive vs. exclusive, and
rounding boundaries for each mode. This MUST be green before manually trusting anything the UI
shows (SC-004).

## 2. Admin configures pricing and order rules (User Story 1, FR-001–008)

```
# signed in as the admin test account: visit /admin/settings
# change the weekly frequency's discount percent from its default to 15
# set a minimum order value, max items per box, and a rounding mode
# save
```

**Expected**: the page reflects the saved values on reload; submitting an out-of-range value (a
negative discount, a VAT percent over 100) is rejected with a specific error and the previous
valid value stays in effect (FR-008).

## 3. Live preview shows a correct breakdown (User Story 2, FR-009–016)

```
# signed out (no login): visit /pricing-preview
# select 2–3 sample products with quantities, a frequency, and a city
```

**Expected**: the full breakdown renders (subtotal, discount, delivery fee, VAT, total per
delivery, estimated monthly) per
[contracts/pricing-preview-api.md](./contracts/pricing-preview-api.md); hand-check the numbers
against [contracts/pricing-calculation.md](./contracts/pricing-calculation.md)'s formula for your
specific selections — they must match exactly (SC-002).

## 4. The phase's headline demo (User Story 3, SC-003)

```
# with /pricing-preview open in one tab showing a breakdown for a given selection...
# in another tab (or after), go to /admin/settings and change that frequency's discount
# reload /pricing-preview with the same selections
```

**Expected**: the displayed price changes to reflect the new discount, with no code change or
deployment — the exact scenario `plan.md` calls "the strongest single demo in the whole series."
Should complete in under a minute end to end (SC-003).

## 5. Confirm no client-side price is ever trusted (Constitution Principle II)

```
# on /pricing-preview, open browser devtools' network tab
# select items and watch the request/response for POST /api/pricing/preview
```

**Expected**: the request body contains only `items`/`frequency`/`cityId` — no price or breakdown
field; the response's breakdown is what's rendered verbatim, confirming the client never computes
or supplies a price (SC-005).

## 6. Confirm public access and disabled-frequency handling (FR-012, FR-017a, FR-020)

```
# while signed out: confirm /pricing-preview loads without any redirect to /login
# in /admin/settings, disable one frequency (e.g. bi-weekly) and save
# reload /pricing-preview
```

**Expected**: `/pricing-preview` never redirects to `/login` (unlike `/subscription`, which still
requires sign-in — confirm that route's protection is unchanged); the disabled frequency is no
longer offered as a selectable option (FR-012); with all products deselected, the preview shows a
clear empty/zero state rather than an error (FR-020).

## 7. Confirm admin-only write access (Constitution Principle V)

```
# signed in as a customer (not admin): attempt PATCH /api/admin/settings directly
# (browser devtools or curl with the customer's session cookie)
```

**Expected**: rejected with `401`/`403` — RLS on `settings` and the handler's own role check both
block it; `GET /api/admin/settings` behind the `/admin` page itself is likewise unreachable as a
customer (Phase 1's existing `/admin` route protection).

## 8. Run the full unit and e2e suites

```
npm run test:unit
npx playwright test tests/e2e/pricing-preview.spec.ts
```

**Expected**: `pricing.calculate.test.ts` and `validation.settings.test.ts` both pass; the
Playwright spec walks steps 2–4 above (admin changes a discount → preview reflects it) without
manual intervention.
