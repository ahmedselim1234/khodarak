---

description: "Task list for Phase 4 — Subscription Builder (no payment yet)"
---

# Tasks: Phase 4 — Subscription Builder (no payment yet)

**Input**: Design documents from `/specs/005-phase-4-subscription-builder/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/ (subscriptions-api.md), quickstart.md

**Tests**: Included — plan.md's Technical Context and research.md explicitly scope a Vitest suite
for `lib/subscription/selectableDeliveryDates.ts` (written and passing before the date-picker UI,
per Constitution Principle VI) and a Playwright spec for the phase's full demo scenario.

**Organization**: Tasks are grouped by user story (US1/US2/US3/US4, matching spec.md's priorities:
US1 = P1, US2 = P1, US3 = P1, US4 = P2). Within the P1 tier, tasks follow the wizard's actual build
order: US1 (box customization) lands first since it's usable and demoable on its own once the cart
and pricing engine are wired in; US2 (frequency + date) extends the same build step; US3 (checkout
+ confirm) is the only story that needs genuinely new server-side work (the creation endpoint) and
depends on US1/US2 producing a valid box/frequency/date to confirm. US4 (rule-violation blocking)
is a small, final layer on top of US3's summary sidebar.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3, US4)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Create the `components/subscription/` directory scaffold
- [X] T002 [P] Create the `lib/subscription/` directory scaffold

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T003 Create migration `supabase/migrations/<timestamp>_subscriptions.sql`: `subscriptions` table (`id, user_id, address_id, frequency, status default 'pending_payment', next_delivery_date, delivery_time_slot, paused_until, started_at, cancelled_at, price_breakdown, created_at, updated_at`) and `subscription_items` table (`id, subscription_id, product_id, quantity, created_at`), owner-only RLS on both (`subscription_items` via a join back to `subscriptions.user_id`, since it has no `user_id` column of its own) — per data-model.md
- [X] T004 [P] Create `lib/subscription/timeSlots.ts`: the fixed three-slot definitions (`morning`/`afternoon`/`evening`, id/label/window), shared by the picker component and the Route Handler's validation — per research.md §2

**Checkpoint**: Foundation ready — `subscriptions`/`subscription_items` tables + RLS and the shared time-slot constants exist; user story implementation can now begin.

---

## Phase 3: User Story 1 - Customize the box and see the price react live (Priority: P1) 🎯 MVP

**Goal**: The subscription builder pre-loads the customer's cart as the box, lets them keep adding/removing/adjusting it via the existing product grid and stepper, and shows the live price breakdown after every change.

**Independent Test**: Arrive at `/subscription` with items already in the cart, add a product from the grid, remove one, change a quantity, and confirm the price breakdown updates after each change — per quickstart.md step 2.

### Implementation for User Story 1

- [X] T005 [P] [US1] Create `components/subscription/WizardProgressHeader.tsx`: presentational 2-step progress indicator (per `design/subscription-builder.html`'s wizard header, collapsed to this phase's two real steps — build, checkout)
- [X] T006 [P] [US1] Create `components/subscription/BoxCategoryTabs.tsx`: `"use client"` leaf — local (non-URL) خضروات/فواكه tab state over an already-fetched product list, unlike `/browse`'s `searchParams`-driven `CategoryTabs` (this page is a single continuous wizard, not URL-driven)
- [X] T007 [US1] Create `components/subscription/SubscriptionWizard.tsx`: `"use client"` orchestrator — step state (`'build' | 'checkout'`, starting at `'build'`); the build step renders `WizardProgressHeader` (T005), `BoxCategoryTabs` (T006) over the passed-in product list, the existing `ProductGrid`/`ProductCard` (Phase 2, already embeds `QuantityStepper` wired to the real cart), and the existing `PriceBreakdownCard` (Phase 3) fed by `pricingApi.previewPrice` (Phase 3) re-called (debounced) whenever the cart, frequency, or city changes — depends on T005, T006
- [X] T008 [US1] Replace the Phase 0 placeholder in `app/subscription/page.tsx`: Server Component fetching the customer's cart (joined with `products`), available products (both categories, for the grid), active cities, and `settings.frequencies`; renders `SubscriptionWizard` (T007) with it all as initial props — depends on T007

**Checkpoint**: User Story 1 is fully functional and independently testable — box customization with a live-updating price breakdown.

---

## Phase 4: User Story 2 - Choose a frequency and first delivery date (Priority: P1)

**Goal**: The customer selects an admin-enabled frequency and a first delivery date that respects the configured lead time and blackout weekdays, with the price breakdown reflecting the chosen frequency.

**Independent Test**: Select each enabled frequency in turn and confirm the breakdown's discount/estimated-monthly figures change; open the date picker and confirm dates inside the lead-time window or on a blackout weekday are not selectable — per quickstart.md step 3.

### Tests for User Story 2

> Write this test FIRST; it MUST fail until T010 exists.

- [X] T009 [P] [US2] Write unit test `tests/unit/subscription.selectableDeliveryDates.test.ts` covering: a date before the lead time (not selectable), a date exactly at the lead-time boundary (selectable), a date on a blackout weekday (not selectable), an ordinary valid date (selectable), and a combined lead-time-plus-blackout case

### Implementation for User Story 2

- [X] T010 [US2] Create `lib/subscription/selectableDeliveryDates.ts`: pure function `(today, leadDays, blackoutWeekdays) → which of the next N dates are selectable` — depends on T009
- [X] T011 [P] [US2] Create `components/subscription/FrequencySelector.tsx`: `"use client"` leaf — offers only the `settings.frequencies` entries with `enabled: true`
- [X] T012 [US2] Create `components/subscription/DeliveryDatePicker.tsx`: `"use client"` leaf — uses `selectableDeliveryDates` (T010) to disable invalid dates — depends on T010
- [X] T013 [US2] Wire `FrequencySelector` (T011) and `DeliveryDatePicker` (T012) into `SubscriptionWizard.tsx` (US1, T007)'s build step, re-triggering the live price recalculation on frequency change — depends on T011, T012, T007

**Checkpoint**: User Stories 1 AND 2 both work — the full build step (box + frequency + date) is functional with a correct, live-updating price.

---

## Phase 5: User Story 3 - Complete checkout and create the subscription (Priority: P1)

**Goal**: The customer selects a saved address, picks a delivery time slot, reviews the final total, and confirms — creating a `pending_payment` subscription, clearing the cart, and landing on a dedicated confirmation page.

**Independent Test**: Complete the build steps, select a saved address and a time slot, confirm, and verify a `subscriptions` row now exists in `pending_payment` with the correct items, frequency, address, and price snapshot — per quickstart.md step 4.

### Implementation for User Story 3

- [X] T014 [P] [US3] Create `lib/validation/subscription.ts`: zod schema for the `POST /api/subscriptions` body (`frequency`, `addressId`, `nextDeliveryDate`, `deliveryTimeSlot`) per contracts/subscriptions-api.md
- [X] T015 [P] [US3] Create `lib/store/subscriptionsApi.ts`: RTK Query slice (`createSubscription`) against `/api/subscriptions` per contracts/subscriptions-api.md, following the `addressesApi.ts` mutation pattern — depends on T014
- [X] T016 [US3] Register the `subscriptionsApi` reducer/middleware in `lib/store/index.ts` — depends on T015
- [X] T017 [US3] Implement `app/api/subscriptions/route.ts`: `POST` — auth check, zod validation via T014, resolves the caller's `cart_items` (joined with `products`, dropping unavailable/deleted), resolves `addressId` → city (owner-checked, `404` on mismatch), rejects a disabled frequency (`422`) and an unselectable date via `selectableDeliveryDates` (T010), calls `calculate.ts` and blocks on a rule violation (`422`, per contracts/subscriptions-api.md step 5), inserts `subscriptions` then `subscription_items` with a compensating delete of the subscription row if the items insert fails (research.md §3), deletes the caller's `cart_items` only after both inserts succeed, returns the created id — depends on T003, T004, T010, T014
- [X] T018 [P] [US3] Create `components/subscription/TimeSlotPicker.tsx`: `"use client"` leaf — the fixed three-option set from `timeSlots.ts` (T004)
- [X] T019 [US3] Create `components/subscription/AddressSelector.tsx`: `"use client"` leaf — reads `addressesApi`'s existing `listAddresses` query (Phase 1), prompts to add an address (links to `/dashboard/settings`) when none exist (FR-007)
- [X] T020 [US3] Create `components/subscription/OrderSummarySidebar.tsx`: wraps the existing `PriceBreakdownCard` (Phase 3, reused as-is) plus the confirm button
- [X] T021 [US3] Extend `SubscriptionWizard.tsx` (US1/US2, T007/T013) with the checkout step: `AddressSelector` (T019) + `TimeSlotPicker` (T018) + `OrderSummarySidebar` (T020); a "back to box" action that returns to the build step without losing the address/time-slot selection (Clarifications 2026-08-10, FR-017a); confirm calls `subscriptionsApi.createSubscription` (T015), disables itself for the duration of the request (FR-013), and navigates to `/subscription/confirmed/[id]` on success — depends on T018, T019, T020, T015, T013
- [X] T022 [US3] Create `app/subscription/confirmed/[id]/page.tsx`: Server Component, owner-scoped fetch (via the server Supabase client, RLS-backed) of the just-created subscription and its items — the "simple confirmation page" from Clarifications (2026-08-10), stating the box is saved and payment/activation is coming soon, distinct from any post-payment success screen — depends on T017

**Checkpoint**: User Stories 1, 2, AND 3 all work — the phase's headline demo ("build a box end to end and watch the total change live") is complete.

---

## Phase 6: User Story 4 - Rule violations block confirmation with a clear reason (Priority: P2)

**Goal**: A box below the minimum order value or over the maximum items per box shows a specific message and disables the confirm action until resolved.

**Independent Test**: Build a box below the minimum order value (or over the max items per box), confirm the confirm action is disabled with a specific message, then adjust the box until valid and confirm the action becomes available — per quickstart.md step 6.

### Implementation for User Story 4

- [X] T023 [US4] Update `components/subscription/OrderSummarySidebar.tsx` (T020): disable the confirm button and surface the specific message whenever the live breakdown's `meetsMinimumOrderValue` or `withinMaxItemsPerBox` is `false` — `PriceBreakdownCard` (Phase 3) already renders the underlying compliance messages; this task wires the confirm button's own disabled state to those same flags — depends on T020

**Checkpoint**: All four user stories are independently functional.

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all four stories

- [X] T024 [P] Write Playwright spec `tests/e2e/subscription-builder.spec.ts`: build a box → watch the price change live as items/frequency change → checkout (address + time slot) → confirm → land on the confirmation page; signed-out visitors are redirected to `/login`; a below-minimum box blocks confirmation — quickstart.md steps 2–6, 8
- [ ] T025 [P] Run the full `quickstart.md` validation (all 9 steps) end to end — **not run**: requires a live Supabase project with seeded products/addresses/cities and a real browser session, neither available in this sandbox. `npm run build` was run instead and confirms every route/API handler compiles and type-checks; this does not substitute for the manual browser walkthrough.
- [X] T026 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed files (Constitution Development Workflow gate) — both clean (one lint warning found and fixed: an unused `setCityId` that should have been wired to address selection per research.md §4 — now fixed so the preview correctly switches to the selected address's city); also ran `npm run test:unit` (95/95 passing, including the 9-case `selectableDeliveryDates` boundary suite) and `npm run build` (all 26 routes compile) as additional verification beyond what this task strictly asked for.
- [ ] T027 Manual RLS spot-check: as one signed-in customer, attempt to read/write another user's `subscriptions`/`subscription_items` rows directly — confirm zero rows affected (Constitution Principle V; quickstart.md step 7 covers the API-layer version, this covers the RLS layer directly) — **not run**: requires a live linked Supabase project and disposable test accounts (same constraint noted in prior phases' tasks.md). The RLS policies themselves were authored in the migration (`subscriptions_select_own`/`insert_own`, `subscription_items_select_own`/`insert_own`) but have not been exercised against a live project from this session.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only (and Phase 2/3's existing cart/pricing infrastructure, already built)
- **User Story 2 (Phase 4, P1)**: Depends on Foundational; extends `SubscriptionWizard.tsx` from US1 (T007), so build after US1
- **User Story 3 (Phase 5, P1)**: Depends on Foundational, US1's wizard shell, and US2's `selectableDeliveryDates` (reused server-side for validation) — build after US2
- **User Story 4 (Phase 6, P2)**: Depends on US3's `OrderSummarySidebar` (T020) — a small final layer, build last
- **Polish (Phase 7)**: Depends on all four user stories being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories — true MVP starting point (a live-pricing box builder is demoable on its own)
- **US2 (P1)**: Extends `SubscriptionWizard.tsx` from US1 — build after US1
- **US3 (P1)**: Extends `SubscriptionWizard.tsx` from US1/US2 and reuses `selectableDeliveryDates` from US2 server-side — build after US2
- **US4 (P2)**: Extends `OrderSummarySidebar.tsx` from US3 — build after US3

### Within Each User Story

- Tests (where included) written and failing before implementation
- The migration (Foundational) before any Route Handler or component that queries the new tables
- Validation schemas before the forms/handlers that use them
- Pure logic functions (`selectableDeliveryDates`) before the Route Handler and component that call them
- Server-side pieces (migrations, Route Handlers) before the client components that call them
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T001 and T002 (Setup) can run in parallel
- T003 and T004 (Foundational) can run in parallel
- Within US1: T005 and T006 (different files) in parallel
- Within US2: T009 (test) can be drafted while T003/T004 are still being reviewed; T011 (different file) in parallel with T010
- Within US3: T014 and T018 (different files, no dependencies) in parallel; T015 depends on T014

---

## Parallel Example: User Story 2

```bash
# Launch the test and the independent frequency selector together:
Task: "Write unit test tests/unit/subscription.selectableDeliveryDates.test.ts"
Task: "Create components/subscription/FrequencySelector.tsx"
```

## Parallel Example: User Story 3

```bash
# Launch the validation schema and the time-slot picker together:
Task: "Create lib/validation/subscription.ts"
Task: "Create components/subscription/TimeSlotPicker.tsx"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: quickstart.md step 2 passes independently
5. Demo: a box that customizes live and shows a correct, reactive price breakdown

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US1 → validate → demo (live box customization)
3. Add US2 → validate → demo (adds frequency + delivery date — the build step is now complete)
4. Add US3 → validate → demo (adds checkout + confirm — completes the phase's full demo target:
   "build a box end to end and watch the total change live as items and frequency change")
5. Add US4 → validate → demo (adds rule-violation blocking)
6. Phase 7 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes:
- Developer A: US1, then US2 (sequential — US2 extends US1's `SubscriptionWizard.tsx`)
- Developer B: starts US3's non-wizard pieces (T014–T020) in parallel with US1/US2, holding T021
  (the wizard-integration task) until US2's build step exists to check out from
- Developer C: joins for US4 once US3's `OrderSummarySidebar.tsx` exists

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- `subscriptions`/`subscription_items` (T003) is Foundational because both US1 (the page reads the
  cart, but US3 writes these tables) and US3 need it to exist; `timeSlots.ts` (T004) is Foundational
  because it's shared between a US3 component and the US3 Route Handler's validation, matching the
  precedent set by Phase 3's `mapSettingsRow.ts` (shared foundation, not story-scoped)
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
