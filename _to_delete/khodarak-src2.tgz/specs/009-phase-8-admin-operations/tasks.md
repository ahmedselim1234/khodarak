---

description: "Task list for Phase 8 — Admin Operations"
---

# Tasks: Phase 8 — Admin Operations

**Input**: Design documents from `/specs/009-phase-8-admin-operations/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/
(admin-orders-api.md, admin-subscriptions-api.md, admin-payments-and-cities-api.md,
admin-counters.md), quickstart.md

**Tests**: Included — plan.md's Technical Context explicitly scopes a Vitest suite for
`orderStatusTransition.ts` (written and passing before the Route Handler that uses it, per
Constitution Principle VI), plus a Playwright spec for the phase's demo scenario.

**Organization**: Tasks are grouped by user story (US1–US5, matching spec.md's priorities: US1 =
P1, US2 = P1, US3 = P2, US4 = P2, US5 = P3). US1 (orders) and US2 (subscriptions) are the phase's
core value and share no files with each other, so either could be built first — US1 leads since
it's the phase's own stated demo target. US3/US4 are both thin, independent read-only additions
once the shared admin chrome (Foundational) exists. US5 is the smallest, most self-contained
slice, built last.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1–US5)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Create the `app/admin/orders/`, `app/admin/subscriptions/`, `app/admin/payments/`,
      `app/admin/cities/`, `app/api/admin/orders/`, `app/api/admin/subscriptions/`,
      `app/api/admin/cities/`, `components/admin/orders/`, `components/admin/subscriptions/`,
      `components/admin/payments/`, `components/admin/cities/`, `components/admin/counters/`, and
      `lib/admin/` directory scaffolds

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T002 Create migration `supabase/migrations/<timestamp>_admin_operations.sql`: `ALTER TABLE
      profiles ADD COLUMN email`, update `handle_new_user()` to set it, backfill existing rows
      from `auth.users`; `ALTER TABLE orders ADD COLUMN status_updated_by`,
      `status_updated_at`; `ALTER TABLE subscriptions ADD COLUMN cancelled_by_admin_id`,
      `cancel_reason`; `ALTER TABLE subscription_pauses ADD COLUMN initiated_by_admin_id`,
      `reason`; admin-role-checking RLS policies (`_select_admin` on `profiles`, `orders`,
      `subscriptions`, `payments`, `order_items`, `subscription_items`; `_update_admin` on
      `orders`; `_insert_admin`/`_update_admin` on `cities`) — per data-model.md. **No**
      `_update_admin` policy on `subscriptions` itself (research.md §2 — admin pause/cancel goes
      through the existing service-role `mutateSubscription.ts` instead)
- [X] T003 [P] Write unit test `tests/unit/orders.orderStatusTransition.test.ts` covering: each
      valid forward move (`pending`→`out_for_delivery`, `out_for_delivery`→`delivered`,
      `pending`→`cancelled`, `out_for_delivery`→`cancelled`), and each rejected one (any move from
      `delivered`, any backward move, `pending`→`delivered` skip, any move from `cancelled`)
- [X] T004 Create `lib/orders/orderStatusTransition.ts`: pure function per data-model.md's state
      diagram (FR-003) — depends on T003
- [X] T005 [P] Create `lib/admin/requireAdmin.ts`: extracted shared helper (auth + role check),
      same logic currently duplicated inline in `app/api/admin/products/*/route.ts` and
      `app/api/admin/settings/route.ts`
- [X] T006 Update `app/api/admin/products/route.ts`, `app/api/admin/products/[id]/route.ts`, and
      `app/api/admin/settings/route.ts` (Phase 2/3) to use `requireAdmin()` (T005) instead of
      their own inline copy — a dedup, not a behavior change — depends on T005
- [X] T007 [P] Create `components/admin/AdminSideNav.tsx`: لوحة التحكم / المنتجات / الاشتراكات /
      الطلبات / المدفوعات / المدن / الإعدادات, `activePath` prop, mirroring
      `components/dashboard/SideNav.tsx` (Phase 6)'s exact shape
- [X] T008 Create `components/admin/AdminShell.tsx`: wraps `TopNav` + `AdminSideNav` (T007) +
      content well, mirroring `components/dashboard/DashboardShell.tsx` (Phase 6) — depends on
      T007
- [X] T009 Update the existing `app/admin/products/page.tsx`, `app/admin/products/new/page.tsx`,
      `app/admin/products/[id]/edit/page.tsx`, and `app/admin/settings/page.tsx` (Phase 2/3) to
      render inside `AdminShell` (T008) instead of their own standalone `TopNav`-only shell —
      `/admin` has never had consistent chrome before this phase — depends on T008

**Checkpoint**: Foundation ready — new schema + admin RLS policies, the order-transition rule, the
shared admin-auth helper (deduplicated across old and new routes), and the shared admin chrome
(applied to every `/admin/*` page, old and new) all exist; user story implementation can now
begin.

---

## Phase 3: User Story 1 - Process an order from pending to delivered (Priority: P1) 🎯 MVP

**Goal**: An operator can list, filter, search, and advance any customer's order through its
fulfillment lifecycle, with every change immediately visible on the customer's own existing order
view.

**Independent Test**: Open the orders list, filter to a pending order, advance it through
`out_for_delivery` to `delivered`, and confirm both the admin list and the customer's own
`/dashboard/orders/[id]` (Phase 6) show the updated status — per quickstart.md step 2, the phase's
own stated demo target.

### Implementation for User Story 1

- [X] T010 [P] [US1] Create `lib/admin/queryAdminOrders.ts`: `searchParams` (status/date/search) →
      typed query → Supabase query joined to `profiles`, paginated — mirrors
      `lib/products/queryProducts.ts`'s exact shape — per contracts/admin-orders-api.md
- [X] T011 [US1] Create `components/admin/orders/OrderTable.tsx`: Server Component rendering
      `queryAdminOrders.ts`'s (T010) results — customer, scheduled date, status, total — depends
      on T010
- [X] T012 [P] [US1] Create `lib/validation/adminOrderStatus.ts`: zod schema for the `PATCH` body
      (`status: out_for_delivery | delivered | cancelled`)
- [X] T013 [US1] Implement `PATCH` handler in `app/api/admin/orders/[id]/route.ts`: `requireAdmin`
      (T005/T006's pattern) + validate (T012) + `orderStatusTransition` (T004) + the conditional
      `UPDATE ... WHERE status = $expected` guard (research.md §3) — per
      contracts/admin-orders-api.md — depends on T004, T005, T012
- [X] T014 [P] [US1] Create `lib/store/adminOrdersApi.ts`: RTK Query `updateOrderStatus` mutation
      against the `PATCH` endpoint — depends on T013
- [X] T015 [US1] Create `components/admin/orders/OrderRowActions.tsx`: `"use client"` — shows
      only the currently-valid next actions for that row's status (using
      `orderStatusTransition.ts`'s own rule, T004), submits via T014's mutation, calls
      `router.refresh()` on success — depends on T014, T004
- [X] T016 [US1] Create `app/admin/orders/page.tsx`: wraps `OrderTable` (T011) +
      status/date/search filter controls in `AdminShell` (T008) — depends on T011, T015, T008

**Checkpoint**: User Story 1 is fully functional and independently testable — the phase's own
demo target works end to end.

---

## Phase 4: User Story 2 - View and manage a customer's subscription as support (Priority: P1)

**Goal**: An operator can find any customer's subscription by search, review its full state, and
pause or cancel it with a required reason — both stamped with the acting admin — visible to the
customer exactly as their own self-service actions would be, minus the admin-only reason.

**Independent Test**: Search the subscriptions list by a known customer's name/email/phone, open
the detail view to confirm every field from FR-006 is present, pause it (reasonless attempt
rejected, reasoned attempt succeeds), and confirm the customer's own `/dashboard` (Phase 6)
reflects it — per quickstart.md step 3.

### Implementation for User Story 2

- [X] T017 [P] [US2] Create `lib/admin/queryAdminSubscriptions.ts`: `searchParams`
      (status/search) → typed query → Supabase query joined to `profiles`, paginated — per
      contracts/admin-subscriptions-api.md
- [X] T018 [US2] Create `components/admin/subscriptions/SubscriptionTable.tsx`: Server Component
      rendering T017's results — customer, frequency, next delivery date, status — depends on T017
- [X] T019 [P] [US2] Create `lib/validation/adminSubscriptionAction.ts`: zod schema for the
      pause/cancel body (`reason` required non-empty; pause's `resumeDate` optional)
- [X] T020 [US2] Extend `lib/subscription/mutateSubscription.ts`'s existing `pauseSubscription()`
      and `cancelSubscription()` (Phase 6/7) with optional `adminId`/`reason` parameters, writing
      `initiated_by_admin_id`/`reason` onto the `subscription_pauses` insert and
      `cancelled_by_admin_id`/`cancel_reason` onto the `subscriptions` update when present — no
      behavior change for the existing customer-facing callers, which simply omit them — depends
      on T002
- [X] T021 [US2] Implement `app/api/admin/subscriptions/[id]/pause/route.ts`: `requireAdmin` +
      validate (T019) + already-paused/cancelled check (FR-009) + calls T020's extended
      `pauseSubscription` — per contracts/admin-subscriptions-api.md — depends on T005, T019, T020
- [X] T022 [US2] Implement `app/api/admin/subscriptions/[id]/cancel/route.ts`: `requireAdmin` +
      validate (T019) + already-cancelled check + calls T020's extended `cancelSubscription` —
      depends on T005, T019, T020
- [X] T023 [P] [US2] Create `lib/store/adminSubscriptionsApi.ts`: RTK Query pause/cancel
      mutations — depends on T021, T022
- [X] T024 [P] [US2] Create `components/admin/subscriptions/AdminPauseDialog.tsx`: `"use client"`
      — required reason field + optional resume date, reusing Phase 6's `PauseDialog`'s layout
      shape, submits via T023 — depends on T023
- [X] T025 [P] [US2] Create `components/admin/subscriptions/AdminCancelDialog.tsx`: `"use client"`
      — required reason field + confirm step, reusing Phase 6's `CancelDialog`'s shape, submits
      via T023 — depends on T023
- [X] T026 [US2] Create `components/admin/subscriptions/SubscriptionDetailView.tsx`: Server
      Component — items, frequency, next delivery date, price breakdown, address, payment
      history, Phase 7 dunning state if present (FR-006); hosts T024/T025's dialogs, shown per
      current status — depends on T024, T025
- [X] T027 [US2] Create `app/admin/subscriptions/page.tsx`: wraps `SubscriptionTable` (T018) +
      status/search filter controls in `AdminShell` (T008) — depends on T018, T008
- [X] T028 [US2] Create `app/admin/subscriptions/[id]/page.tsx`: fetches the subscription +
      related data directly (owner-agnostic, admin RLS policies from T002), renders
      `SubscriptionDetailView` (T026) in `AdminShell` (T008) — depends on T026, T008

**Checkpoint**: User Stories 1 AND 2 both work — the phase's two core operational capabilities are
complete.

---

## Phase 5: User Story 3 - See business health at a glance (Priority: P2)

**Goal**: `/admin`'s own landing view shows active-subscription count, today's order count, and
this month's revenue, computed fresh on every view.

**Independent Test**: Open `/admin` and confirm the three counters match an independently
computed manual count/sum — per quickstart.md step 4.

### Implementation for User Story 3

- [X] T029 [US3] Create `components/admin/counters/CountersOverview.tsx`: Server Component
      running the three aggregate queries per contracts/admin-counters.md (research.md §5) —
      no caching
- [X] T030 [US3] Replace the Phase 0 placeholder `app/admin/page.tsx`: renders
      `CountersOverview` (T029) inside `AdminShell` (T008) — depends on T029, T008

**Checkpoint**: US1–US3 all independently functional.

---

## Phase 6: User Story 4 - Review payment activity across all customers (Priority: P2)

**Goal**: An operator sees every customer's payment attempts in one filterable, searchable list.

**Independent Test**: Open the payments list, filter by status, and confirm results span more
than one customer with accurate amount/outcome/failure-reason/attempt-number/kind — per
quickstart.md step 5.

### Implementation for User Story 4

- [X] T031 [P] [US4] Create `lib/admin/queryAdminPayments.ts`: `searchParams`
      (status/dateFrom/dateTo/search) → typed query → Supabase query joined to `profiles`,
      paginated — per contracts/admin-payments-and-cities-api.md
- [X] T032 [US4] Create `components/admin/payments/PaymentTable.tsx`: Server Component, read-only
      — customer, amount, outcome, failure reason, attempt number, `kind` (Phase 7's column) —
      depends on T031
- [X] T033 [US4] Create `app/admin/payments/page.tsx`: wraps `PaymentTable` (T032) + filter
      controls in `AdminShell` (T008) — depends on T032, T008

**Checkpoint**: US1–US4 all independently functional.

---

## Phase 7: User Story 5 - Manage delivery cities and zones (Priority: P3)

**Goal**: An operator adds, edits, and deactivates cities from an admin screen, with an active
city immediately selectable on the customer-facing address form.

**Independent Test**: Add a new city, confirm it's selectable on the address form once active,
deactivate it, and confirm it's no longer offered — per quickstart.md step 6.

### Implementation for User Story 5

- [X] T034 [P] [US5] Create `lib/validation/city.ts`: zod schema for create/edit
      (`nameAr` required, `deliveryFeeOverride` optional non-negative)
- [X] T035 [US5] Implement `POST` handler in `app/api/admin/cities/route.ts`: `requireAdmin` +
      validate (T034) + insert via the caller's own RLS-scoped client (`cities_insert_admin`,
      T002) — per contracts/admin-payments-and-cities-api.md — depends on T005, T034
- [X] T036 [US5] Implement `PATCH` handler in `app/api/admin/cities/[id]/route.ts`: `requireAdmin`
      + validate (T034) + update via `cities_update_admin` (T002) — depends on T005, T034
- [X] T037 [P] [US5] Create `lib/store/adminCitiesApi.ts`: RTK Query create/update mutations —
      depends on T035, T036
- [X] T038 [US5] Create `components/admin/cities/CityForm.tsx`: `"use client"` — create-and-edit
      in one component, mirroring `components/address/AddressForm.tsx`'s shape, submits via T037
      — depends on T037
- [X] T039 [US5] Create `components/admin/cities/CityTable.tsx`: Server Component — name, active
      flag, delivery fee override, edit/add entry points opening T038 — depends on T038
- [X] T040 [US5] Create `app/admin/cities/page.tsx`: wraps `CityTable` (T039) in `AdminShell`
      (T008) — depends on T039, T008

**Checkpoint**: All five user stories are independently functional.

---

## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all five stories

- [X] T041 [P] Write Playwright spec `tests/e2e/admin-operations.spec.ts`: pending →
      out_for_delivery status advance as admin (quickstart.md step 2) plus the always-runnable
      signed-out-redirect check across all four new `/admin/*` routes. The credentialed suite is
      `test.skip` pending `TEST_ADMIN_EMAIL`/`PASSWORD`/`TEST_PENDING_ORDER_ID` (none available in
      this sandbox, same constraint noted in every prior phase's tasks.md) — not executed against
      a live server this session.
- [X] T042 [P] Run the full `quickstart.md` validation (all 9 steps) end to end — **not run**:
      requires a live linked Supabase project, a seeded admin account, and real customer/order/
      subscription/payment data, none available in this sandbox. `npm run build` was run instead
      and confirms every new route/page (6 pages, 6 API routes) compiles and type-checks; this
      does not substitute for the manual walkthrough.
- [X] T043 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed
      files (Constitution Development Workflow gate) — both clean. Also ran `npm run test:unit`
      (160/160 passing, including the new `orderStatusTransition` suite) and `npm run build` (all
      36 routes compile, including all 6 new/replaced `/admin/*` pages and 6 new API routes).
- [ ] T044 Manual RLS spot-check: as a signed-in customer, attempt to `PATCH` an order's status,
      `POST` an admin subscription pause/cancel, and `POST`/`PATCH` a city, directly via the
      Supabase REST API — confirm every attempt is rejected (Constitution Principle V;
      quickstart.md step 7 covers this at the walkthrough level, this task is the dedicated
      verification pass) — **not run**: requires a live linked Supabase project and a disposable
      test account (same constraint noted in every prior phase's tasks.md). The RLS policies
      themselves were authored in the migration (admin-role-checking `_select_admin`/
      `_update_admin`/`_insert_admin` policies across `profiles`/`orders`/`subscriptions`/
      `payments`/`order_items`/`subscription_items`/`cities`; deliberately no new write policy on
      `subscriptions` itself) but have not been exercised against a live project from this
      session.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only
- **User Story 2 (Phase 4, P1)**: Depends on Foundational only — shares no files with US1, can be
  built in parallel with it
- **User Story 3 (Phase 5, P2)**: Depends on Foundational's `AdminShell` (T008) only
- **User Story 4 (Phase 6, P2)**: Depends on Foundational's `AdminShell` (T008) only
- **User Story 5 (Phase 7, P3)**: Depends on Foundational's `AdminShell`/`requireAdmin` (T005,
  T008) only — build last as the smallest, most self-contained slice
- **Polish (Phase 8)**: Depends on all five user stories being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories
- **US2 (P1)**: No dependencies on other stories — independent of US1, sharing only Foundational
- **US3 (P2)**: Independent of US1/US2/US4/US5
- **US4 (P2)**: Independent of every other story
- **US5 (P3)**: Independent of every other story

### Within Each User Story

- Tests (where included) written and failing before implementation
- The migration (Foundational) before any Route Handler or query helper that uses the new columns
  or admin RLS policies
- `requireAdmin()` (Foundational) before any admin Route Handler
- `AdminShell`/`AdminSideNav` (Foundational) before any `/admin/*` page
- Validation schemas before the Route Handlers that use them
- Server-side pieces (Route Handlers, query helpers, Server Component pages) before the client
  components/RTK slices that call them
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T003 (test) in parallel with T005/T007 (Foundational, different files); T006/T009 depend on
  T005/T008 respectively
- Once Foundational completes, US1, US2, US3, US4, and US5 can all be staffed in parallel — none
  share a file with any other
- Within US1: T010 (query helper) and T012 (validation) in parallel
- Within US2: T017 and T019 in parallel; T024 and T025 (the two dialogs) in parallel once T023
  lands

---

## Parallel Example: Foundational

```bash
# Launch the independent Foundational pieces together:
Task: "Write unit test tests/unit/orders.orderStatusTransition.test.ts"
Task: "Create lib/admin/requireAdmin.ts"
Task: "Create components/admin/AdminSideNav.tsx"
```

## Parallel Example: User Stories (after Foundational)

```bash
# Five independent developers could each start a different story simultaneously:
Task: "US1 — lib/admin/queryAdminOrders.ts + the orders Route Handler"
Task: "US2 — lib/admin/queryAdminSubscriptions.ts + the pause/cancel Route Handlers"
Task: "US3 — components/admin/counters/CountersOverview.tsx"
Task: "US4 — lib/admin/queryAdminPayments.ts"
Task: "US5 — lib/validation/city.ts + the cities Route Handlers"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: an order can be advanced pending → out_for_delivery → delivered as an
   admin, visible on the customer's own order view
5. Demo: the phase's own stated demo target

### Incremental Delivery

1. Setup + Foundational → foundation ready (including the shared chrome retrofitted onto every
   existing `/admin/*` page)
2. Add US1 → validate → demo (order fulfillment, MVP!)
3. Add US2 → validate → demo (subscription support intervention)
4. Add US3 → validate → demo (counters)
5. Add US4 → validate → demo (cross-customer payments visibility)
6. Add US5 → validate → demo (cities CRUD)
7. Phase 8 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes, every one of the five user stories can be
staffed independently and in parallel — none shares a file with any other (a genuine departure
from Phase 5/6/7's more sequentially-coupled stories, since this phase's five capabilities are
each their own vertical slice of the same shared admin chrome).

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- `requireAdmin()` (T005) and `AdminShell`/`AdminSideNav` (T007/T008) are Foundational because
  every one of the five user stories' pages and Route Handlers depends on them;
  `orderStatusTransition.ts` (T004) is Foundational rather than US1-scoped because, unlike Phase
  5/6/7's more story-specific pure functions, it's referenced directly in this plan's own
  Constitution Check as a cross-cutting correctness rule verified before any story work begins
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
