# Implementation Plan: Phase 5 — Moyasar Integration & First Payment

**Branch**: `006-phase-5-moyasar-payment` | **Date**: 2026-08-11 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/006-phase-5-moyasar-payment/spec.md`

## Summary

Turn a Phase 4 `pending_payment` subscription into an active one with a real first delivery
order, using Moyasar for card tokenization (browser-to-Moyasar directly, never through our
server) and a 3D-Secure charge that's confirmed two independent ways — a synchronous redirect
callback the customer sees, and an asynchronous, signature-verified webhook that's the durable
source of truth — both converging on one shared, idempotent activation function so the outcome
is identical no matter which path confirms it first or how many times either fires. The existing
Phase 4 confirmation page (`/subscription/confirmed/[id]`) becomes status-aware: still
`pending_payment` shows the new payment step; `active` shows the real success screen the mockups
call for. All financial-state writes (subscription activation, payment records, saved cards,
generated orders) go through the Supabase service-role client from trusted server code only —
no RLS policy ever grants a customer's own session write access to these columns, closing off
the class of privilege-escalation risk Phase 1 already hit once with `profiles.role`.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS, Next.js 16 App Router (unchanged from
Phase 0–4)

**Primary Dependencies**: `@supabase/ssr` + `@supabase/supabase-js` (including, for the first
time, the **service-role** client — see Constraints), zod, Redux Toolkit + RTK Query. Moyasar's
hosted tokenization script, loaded via `next/script` only on the payment step (Constitution
Principle III — no third-party payment script ships to routes that don't need it). No SDK
package for Moyasar's REST API — `lib/payments/moyasarClient.ts` is a small `fetch`-based wrapper
(Create Payment, Fetch Payment) authenticated with HTTP Basic Auth using the secret key, which is
all Moyasar's REST API requires; adding a dependency for two HTTP calls isn't justified.

**Storage**: Supabase (Postgres) — four new tables: `payment_methods`, `payments`, `orders`,
`order_items`, plus `webhook_events` for durable, deduplicated notification storage. Amends
`plan.md` §2's original `payments` sketch: both `order_id` and `subscription_id` are nullable on
`payments`, because — per `plan.md` §3b's own renewal description ("charge the saved token, then
generate the order only on successful payment") — an order never exists at the moment a charge is
attempted, only after it succeeds; a payment attempt row is created against a `subscription_id`
first and gets its `order_id` filled in once activation generates the order (research.md §2).

**Testing**: Vitest for `lib/payments/halalas.ts` (the SAR↔halalas conversion — `plan.md` §3b
names this exact bug class, "the classic 100× production bug," as the reason a single, tested
conversion point is non-negotiable) and `lib/payments/retryThrottle.ts` (the throttling decision
from this phase's Clarifications session), both written and passing before the Route Handlers
that use them. Playwright for the phase's demo path using Moyasar's published test cards: pay
with a succeeding test card, complete 3DS, land on the real success screen; pay with a declining
test card, see a specific error, retry successfully.

**Target Platform**: Same as Phase 0–4 — `npm run dev` locally (webhook delivery requires a
public tunnel in local development, per `plan.md` §3b), Linux container deferred to Phase 9;
primary client is mobile Chrome/Safari.

**Project Type**: Web application — same single Next.js monolith, no new deployable.

**Performance Goals**: No new Core Web Vitals risk to routes other than the payment step itself,
which is inherently third-party-script-heavy (Moyasar's tokenization form) — that script is
scoped to `/subscription/confirmed/[id]` only via `next/script`'s lazy strategy, never included
in the shared bundle other routes pay for.

**Constraints**: Every write that changes financial/subscription state — `subscriptions.status`,
`payment_methods`, `payments`, `orders`/`order_items` — happens exclusively through a new
service-role Supabase client (`lib/supabase/serviceRole.ts`), never the RLS-scoped per-request
client, and never in response to a value the client claims (Constitution Principle II/V). This is
deliberately stricter than "just add an owner-scoped UPDATE policy" — Phase 1's
`20260810120300_profiles_role_immutable.sql` migration exists because an owner-scoped `UPDATE`
policy on `profiles` let a customer PATCH their own `role` to `'admin'` directly via the REST API
(RLS restricts rows, not columns). Granting customers any direct write path to
`subscriptions.status` would recreate exactly that risk for money, not roles, so this phase closes
it proactively rather than patching it after the fact (research.md §1). Payment outcome
confirmation MUST run through one shared function regardless of entry point (redirect callback or
webhook), guarded by a conditional `UPDATE ... WHERE status NOT IN (<terminal>)` so a second,
concurrent, or redelivered confirmation is a safe no-op rather than a race (research.md §3 extends
Phase 4's "no DB transaction infrastructure yet" precedent with this specific idempotency
technique).

**Scale/Scope**: 5 new tables, 3 new Route Handlers (`POST /api/subscriptions/[id]/pay`, `GET
/api/payments/callback`, `POST /api/webhooks/moyasar`), 1 updated page
(`/subscription/confirmed/[id]` becomes status-aware), ~5 new components, 1 new service-role
Supabase client, 2 new pure lib modules with their own test suites.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Yes — `/subscription/confirmed/[id]` stays a Server Component; `"use client"` is scoped to `PaymentSection`, `CardTokenizationForm`, and `PaymentMethodSelector` only | PASS |
| II. Server-Side Authority for Business Logic | Yes — this phase is Principle II applied to real money for the first time. The charged amount always comes from the subscription's already-saved `price_breakdown` snapshot (never recomputed, never client-supplied); the outcome is always confirmed via a direct server-to-Moyasar call, never a redirect parameter or webhook field trusted blindly ahead of processing | PASS |
| III. Performance Budget & Core Web Vitals | Yes — Moyasar's tokenization script loads via `next/script`, scoped to the one route that needs it | PASS |
| IV. Type Safety & Validation at Boundaries | Yes — the pay-request body and the webhook payload are both zod-validated before use; for the webhook, schema validation is a defensive second layer behind the actual security boundary (signature verification), not a substitute for it | PASS |
| V. Data Integrity, Idempotency & Security | Yes — this phase's central concern. Card data never reaches our server (browser-to-Moyasar tokenization only); every financial-state write goes through the service-role client from trusted server code, with no RLS write-policy gap for customers to exploit (see Constraints); webhook signatures are verified before any payload is trusted; `webhook_events` deduplicates by Moyasar's own event id; a conditional-update guard makes outcome processing idempotent across the callback/webhook race | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — `halalas.ts` is the exact function `plan.md` §3b calls out by name as the classic money bug; `retryThrottle.ts` is this phase's own Clarifications-driven security control. Both ship with Vitest coverage before any Route Handler uses them | PASS |

No violations requiring justification. Complexity Tracking table is not needed.

**Post-Phase-1 re-check**: The design artifacts (research.md, data-model.md, contracts/,
quickstart.md) keep the service-role client's usage narrowly scoped to `lib/payments/`'s
activation logic (never imported into a component, never used for ordinary reads), keep the
conditional-update idempotency guard explicit in the contract rather than assumed, and keep
`halalas.ts`/`retryThrottle.ts` as pure, dependency-free functions. Gate status unchanged: all
PASS.

## Project Structure

### Documentation (this feature)

```text
specs/006-phase-5-moyasar-payment/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output (/speckit-plan command)
├── data-model.md         # Phase 1 output (/speckit-plan command)
├── quickstart.md        # Phase 1 output (/speckit-plan command)
├── contracts/           # Phase 1 output (/speckit-plan command)
└── tasks.md             # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
app/
├── subscription/
│   └── confirmed/
│       └── [id]/
│           └── page.tsx             # UPDATED — status-aware: still pending_payment renders
│                                     # PaymentSection (new); active renders the real success
│                                     # screen (design/successfull-order.html), replacing Phase 4's
│                                     # placeholder "coming soon" copy
└── api/
    ├── subscriptions/
    │   └── [id]/
    │       └── pay/
    │           └── route.ts         # POST — customer-authenticated. Creates the Moyasar payment
    │                                 # (3DS on), records the attempt, returns the 3DS transaction
    │                                 # URL for the client to redirect to
    ├── payments/
    │   └── callback/
    │       └── route.ts             # GET — Moyasar's 3DS redirect target. Fetches the
    │                                 # authoritative status from Moyasar (never trusts the query
    │                                 # string), runs the shared outcome processor, redirects to
    │                                 # the confirmation page
    └── webhooks/
        └── moyasar/
            └── route.ts             # POST — public, no session. Verifies the signature header,
                                      # dedupes via webhook_events, runs the same shared outcome
                                      # processor

components/
└── payment/
    ├── PaymentMethodSelector.tsx    # "use client" leaf — lists the customer's saved active
    │                                 # payment methods plus an "add a new card" option
    ├── CardTokenizationForm.tsx     # "use client" leaf — mounts Moyasar's hosted tokenization
    │                                 # form (next/script), yields a token id to its parent;
    │                                 # never sees this component's data touch our server
    └── PaymentSection.tsx           # "use client" orchestrator — method choice, the
                                      # recurring-charge consent checkbox, submit → POST
                                      # /api/subscriptions/[id]/pay → redirect to the returned 3DS
                                      # URL; surfaces a throttled/declined state from the most
                                      # recent failed attempt (passed down from the Server
                                      # Component parent)

lib/
├── payments/
│   ├── moyasarClient.ts             # fetch-based wrapper: createPayment, fetchPayment — the
│   │                                 # only place that calls Moyasar's REST API
│   ├── halalas.ts                   # toHalalas(sar) — THE single conversion point (FR-017)
│   ├── retryThrottle.ts             # Pure: given recent failed-attempt timestamps, decide
│   │                                 # throttled or not (FR-016a)
│   ├── verifyWebhookSignature.ts    # Compares the incoming secret-token header against
│   │                                 # serverEnv.MOYASAR_WEBHOOK_SECRET (constant-time)
│   └── processPaymentOutcome.ts     # THE shared, idempotent activation/failure function —
│                                     # called by both the callback route and the webhook route
│                                     # (contracts/payment-outcome-processing.md)
├── validation/
│   ├── paymentInitiate.ts           # zod schema: POST /api/subscriptions/[id]/pay body
│   └── moyasarWebhook.ts            # zod schema: webhook payload shape (defensive layer behind
│                                     # signature verification, not a substitute for it)
├── env.server.ts                    # UPDATED — adds MOYASAR_SECRET_KEY, MOYASAR_WEBHOOK_SECRET
├── env.ts                           # UPDATED — adds NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY
└── supabase/
    └── serviceRole.ts               # NEW — service-role Supabase client. Bypasses RLS entirely;
                                      # imported only from lib/payments/processPaymentOutcome.ts
                                      # and nowhere else (Constraints above)

supabase/
└── migrations/
    └── <timestamp>_payments.sql     # payment_methods, payments, orders, order_items,
                                      # webhook_events — owner-only SELECT policies, no
                                      # authenticated-role INSERT/UPDATE/DELETE policy on any of
                                      # them (all writes are service-role only — data-model.md)

tests/
├── unit/
│   ├── payments.halalas.test.ts     # THE critical suite — exact SAR→halalas conversion cases,
│   │                                 # including the 100× bug this exists to prevent
│   └── payments.retryThrottle.test.ts  # at-threshold, under-threshold, window-expiry cases
└── e2e/
    └── payment-flow.spec.ts         # succeeding test card → 3DS → real success screen;
                                      # declining test card → specific error → successful retry —
                                      # quickstart.md's full walkthrough
```

**Structure Decision**: Stays inside the Phase 0–4 monolith. The confirmation page from Phase 4
is extended in place (status-aware) rather than split into separate routes, since it already has
exactly the right identity — "this specific subscription's status page" — for both the
payment-pending and the activated states; introducing a second URL would just be two views of the
same fact. The service-role client is new infrastructure, introduced narrowly and only where RLS
categorically cannot express the trust boundary needed (a webhook has no user session at all, and
a customer's own session should never be trusted to write `subscriptions.status` even when one
exists) — everywhere else in this phase (reading subscriptions, listing payment methods) continues
using the existing per-request RLS-scoped client, unchanged from every prior phase.

## Complexity Tracking

*No Constitution Check violations — table not needed.*
