# Contract: `POST /api/subscriptions/[id]/pay`

Initiates a payment attempt for a `pending_payment` subscription (spec User Story 1). Requires an
authenticated session; the caller must own the subscription (FR-006). The request body is
validated with `lib/validation/paymentInitiate.ts`. Never accepts an amount from the client — the
charge amount always comes from `subscriptions.price_breakdown.totalPerDelivery`, converted via
`lib/payments/halalas.ts`.

## `POST /api/subscriptions/[id]/pay`

**Request** (adding a new card):
```json
{
  "consentGiven": true,
  "moyasarToken": "token_xxx"
}
```

**Request** (using an existing saved card):
```json
{
  "consentGiven": true,
  "paymentMethodId": "uuid"
}
```

Exactly one of `moyasarToken` (a freshly tokenized card id from `CardTokenizationForm`, per
research.md §5) or `paymentMethodId` (an existing, owned, active `payment_methods` row) MUST be
present. `consentGiven` MUST be `true` (FR-003) — its absence or falsiness is a validation error,
not silently ignored.

**Behavior**:
1. Load the subscription; `404` if it doesn't exist or isn't owned by the caller. `409
   { "error": "not_pending" }` if its status isn't `pending_payment` (FR-006, Edge Cases — already
   active or already paid).
2. Count the subscription's recent `payments` rows with `status = 'failed'` within the throttle
   window; if `lib/payments/retryThrottle.ts` says throttled, respond `429
   { "error": "too_many_attempts", "retryAfterSeconds": <n> }` without calling Moyasar at all
   (FR-016a).
3. Resolve the token: if `paymentMethodId` was given, look up that `payment_methods` row
   (owned, `status = 'active'`) and use its `moyasar_token_id`; if not found, `404`. If
   `moyasarToken` was given, use it directly.
4. Compute `amount_halalas` from `subscriptions.price_breakdown.totalPerDelivery` via
   `toHalalas()` — never from anything in the request body.
5. Call Moyasar's Create Payment API with `source: { type: 'token', token: <resolved token> }`,
   `amount: amount_halalas`, `currency: 'SAR'`, `3ds: true`, `callback_url:
   <this app's /api/payments/callback>`, `metadata: { subscription_id }`, `save_only: false`.
6. Insert a `payments` row: `subscription_id`, `user_id`, `moyasar_payment_id` (from the response),
   `amount_halalas`, `status: 'initiated'`, `attempt_number` (one more than the subscription's
   prior attempt count).
7. Return the response's 3DS transaction URL for the client to redirect to.

**Response — success**:
```
200 OK

{ "transactionUrl": "https://..." }
```

**Response — not pending / already resolved**: `409 { "error": "not_pending" }`.

**Response — throttled**: `429 { "error": "too_many_attempts", "retryAfterSeconds": 900 }`.

**Response — invalid saved method**: `404 { "error": "not_found" }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": {...} }`.

**Response — Moyasar create-payment call itself fails** (network/4xx from Moyasar): `502
{ "error": "provider_error" }` — no `payments` row is created in this case, since no
`moyasar_payment_id` exists to key it on.

**Response — unauthenticated**: `401 { "error": "unauthenticated" }`.

## Notes

- This endpoint never marks a subscription active or creates an order itself — it only ever
  initiates an attempt and records it as `'initiated'`. Resolution is exclusively
  `processPaymentOutcome.ts`'s job, reached only via the callback or the webhook
  (contracts/payment-outcome-processing.md).
