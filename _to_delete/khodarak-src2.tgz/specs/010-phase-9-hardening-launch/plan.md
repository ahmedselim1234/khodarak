# Implementation Plan: Phase 9 — Hardening, Docker & Launch

**Branch**: `010-phase-9-hardening-launch` | **Date**: 2026-08-11 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/010-phase-9-hardening-launch/spec.md`

## Summary

Unlike every prior phase, this plan produces almost no new product feature code — its two
outputs are (1) a documented, executed **audit** of everything Phases 0–8 already built (RLS
policies, Route Handler validation, the Moyasar webhook, every screen's error/loading/empty
states, every Arabic string, and Core Web Vitals on the four primary pages), with findings
triaged and launch-blocking ones fixed; and (2) the five genuinely new operational capabilities
the spec names — a CI workflow (`.github/workflows/ci.yml`), a production-oriented Docker Compose
overlay pointing at a versioned, registry-hosted image (making rollback a one-line tag change), a
lightweight monitoring setup built almost entirely on infrastructure already in the codebase (the
existing `/api/health` endpoint, the existing structured logging convention, and one small
extension to Phase 8's admin counters view for the dunning-rate signal), the live Moyasar
credential cutover proven by one real transaction, and the launch checklist itself
(`specs/010-phase-9-hardening-launch/LAUNCH_CHECKLIST.md`) that ties every other piece together
with verifiable evidence.

## Technical Context

**Language/Version**: TypeScript 5.x on Node.js 20 LTS runtime target (unchanged) — the existing
`Dockerfile` already builds on `node:22-alpine`; this phase does not change the app's own runtime
version, only formalizes it as the CI/container target.

**Primary Dependencies**: No new application dependency. Adds one new `devDependency`-level
tool choice for Lighthouse auditing (`@lhci/cli` — Lighthouse CI, the standard way to run
Lighthouse non-interactively in a pipeline/script rather than only from Chrome DevTools by hand)
and relies on GitHub Actions' own hosted runners for CI (no new SaaS account required beyond what
a GitHub-hosted repository already implies). Monitoring (research.md §4) deliberately reuses
existing infrastructure — `/api/health` (Phase 0) plus a free-tier external uptime checker hitting
it, and a minimal error-logging sink — rather than introducing a heavyweight observability
dependency into the application itself.

**Storage**: No schema change. This phase's own artifacts (audit findings, the launch checklist)
are markdown documents in the spec directory, not database tables — `data-model.md` documents why
(research.md §1).

**Testing**: The existing Vitest/Playwright suites are what CI (User Story 3) now runs
automatically rather than only by hand — no new test *framework*. One new, genuinely new kind of
verification this phase adds: a scripted Lighthouse run (`npx lhci autorun`) against the four
named pages, and a manual (but logged) execution of the rollback procedure (User Story 3's own
Acceptance Scenario 4, per the clarification session) and the one live-mode transaction (User
Story 5).

**Target Platform**: The first phase where "production" is a real, distinct target — a single
Docker host (research.md §2, per the clarification session) reachable at a real domain, running
the existing `docker-compose.yml`'s shape via a new `docker-compose.prod.yml` overlay
(research.md §3).

**Project Type**: Web application — still the same single Next.js monolith; this phase adds
deployment/CI scaffolding around it, not a second deployable.

**Performance Goals**: The constitution's own already-committed budget (LCP < 2.5s, INP < 200ms,
CLS < 0.1 on mid-tier mobile) is the target this phase verifies and, where unmet, fixes — not a
new goal this phase invents.

**Constraints**: Live Moyasar credentials (User Story 5) exist only in the production
environment's own secret configuration — never committed, never present in a CI log, never used
in a non-production run of the app (extending every prior phase's own "test keys only until now"
rule to its logical, deliberate endpoint). Rollback (FR-009) must be exercised at least once
during this phase, not merely documented, per the clarification session.

**Scale/Scope**: 1 CI workflow file, 1 production compose overlay + a small deploy/rollback
script pair, 1 Dockerfile fix (a missing `NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY` build-time
placeholder — research.md §5, a real gap this plan found), 1 small extension to Phase 8's
`CountersOverview.tsx` (the dunning-rate signal), 1 new `npm run typecheck` script, 2 markdown
artifacts (an audit findings log and the launch checklist), and the audit/fix work itself across
however many findings surface (scope not fixed in advance — spec.md's own severity-triage rule
governs what must be fixed before launch vs. deferred).

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

| Principle | Applies in this phase? | Gate status |
|---|---|---|
| I. Server Components & Rendering Strategy | Indirectly — the audit (User Story 6) re-verifies every existing page's rendering choice and `"use client"` scoping is still correct, but this phase authors no new page | PASS |
| II. Server-Side Authority for Business Logic | Yes — the validation audit (User Story 1, FR-002) exists specifically to re-confirm this principle holds everywhere it's supposed to, across every phase, not just where it was originally built | PASS |
| III. Performance Budget & Core Web Vitals | Yes — this phase is the first actual verification against the committed budget (User Story 6, FR-017) — every prior phase asserted it wouldn't regress the budget but none was ever measured end-to-end until now | PASS — gate is the audit itself |
| IV. Type Safety & Validation at Boundaries | Yes — the validation audit (FR-002) and the new CI typecheck step (FR-007) both directly enforce this principle going forward, not just at a point in time | PASS |
| V. Data Integrity, Idempotency & Security | Yes — the entire RLS/webhook audit (User Story 1, FR-001/003/004) is this principle's own verification pass; the live-credential cutover (User Story 5) is this principle's financial-security concern taken to its final, real-money conclusion | PASS — designed in data-model.md |
| VI. Test-First for Critical Logic & Observability | Yes — CI (FR-007) is what makes "tests exist and pass" an enforced gate rather than a discipline that could quietly lapse after this phase; monitoring (FR-010/011/012) is this principle's "unattended background jobs are unobservable by default unless logging is designed in" concern, addressed for the first time at the production-environment level | PASS |

No violations requiring justification. Complexity Tracking table is not needed — this phase adds
operational scaffolding, not new architectural complexity to the application itself.

**Post-Phase-1 re-check**: The design artifacts keep monitoring built on existing infrastructure
(`/api/health`, existing logging conventions, Phase 8's counters view) rather than a new
dependency inside the application; the CI workflow and production compose overlay stay
configuration, not application code; and the audit findings log stays a durable, versioned
markdown artifact rather than a Slack thread or verbal handoff that would evaporate after launch.
Gate status unchanged: all PASS.

## Project Structure

### Documentation (this feature)

```text
specs/010-phase-9-hardening-launch/
├── plan.md                    # This file (/speckit-plan command output)
├── research.md                # Phase 0 output (/speckit-plan command)
├── data-model.md               # Phase 1 output (/speckit-plan command)
├── quickstart.md               # Phase 1 output (/speckit-plan command)
├── contracts/                  # Phase 1 output (/speckit-plan command)
├── AUDIT_FINDINGS.md           # Phase 2 (/speckit-tasks + implementation) output — the audit's
│                                # own findings log (data-model.md's "Audit Finding" entity)
├── LAUNCH_CHECKLIST.md         # Phase 2 output — the go/no-go checklist (User Story 7)
└── tasks.md                    # Phase 2 output (/speckit-tasks command - NOT created by /speckit-plan)
```

### Source Code (repository root)

```text
.github/
└── workflows/
    └── ci.yml                       # NEW — on push/PR: npm ci, lint, typecheck, test:unit,
                                      # build, in that order (FR-007); a follow-up deploy job
                                      # (main branch only, after CI passes) builds and pushes the
                                      # image to a container registry (FR-008)

Dockerfile                            # UPDATED — adds four missing build-time placeholders
                                      # (NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY, MOYASAR_SECRET_KEY,
                                      # MOYASAR_WEBHOOK_SECRET, CRON_SECRET — research.md §5, a
                                      # real gap this plan found and confirmed by reproduction:
                                      # only the three Phase-0-era vars had placeholders; these
                                      # four were added across Phase 5/7 after the Dockerfile
                                      # existed and were never back-filled); adds a HEALTHCHECK
                                      # directive using the existing /api/health endpoint

docker-compose.yml                    # UNCHANGED — still the local/dev-parity compose file
                                      # (`build: .`), per User Story 2's own scope
docker-compose.prod.yml               # NEW — production overlay: references a versioned image
                                      # tag (`image: ghcr.io/<org>/khodarak:${IMAGE_TAG}`) instead
                                      # of `build: .`, so a deploy is "pull this tag" and a
                                      # rollback (FR-009) is "point back at the previous tag and
                                      # redeploy" — no rebuild required for either

scripts/
├── deploy.sh                        # NEW — pulls docker-compose.prod.yml's referenced tag on
│                                     # the production host and restarts the service
└── rollback.sh                      # NEW — re-points IMAGE_TAG at the previous known-good tag
                                      # and re-runs the same restart step deploy.sh uses — the
                                      # concrete mechanism behind FR-009, exercised once per the
                                      # clarification session (quickstart.md)

app/
└── api/
    └── health/
        └── route.ts                 # UNCHANGED (Phase 0) — reused as-is by both the Docker
                                      # HEALTHCHECK directive and the external uptime checker
                                      # (research.md §4) — no new endpoint needed

components/
└── admin/
    └── counters/
        └── CountersOverview.tsx     # UPDATED (Phase 8) — adds a fourth counter: subscriptions
                                      # auto-suspended in the last 7 days (FR-012's aggregate
                                      # dunning-rate signal), reusing the exact same
                                      # subscription_pauses query shape Phase 7/8 already
                                      # established, no new table

package.json                          # UPDATED — adds `"typecheck": "tsc --noEmit"` (referenced
                                      # by ci.yml; every prior phase ran this ad hoc via `npx tsc
                                      # --noEmit`, never as a named script) and `@lhci/cli` as a
                                      # devDependency

lighthouserc.json                     # NEW — Lighthouse CI config: the four named URLs (home,
                                      # browse, subscription builder, dashboard), mobile
                                      # emulation, and the constitution's own asserted budget
                                      # (LCP/INP/CLS thresholds) as pass/fail assertions

.env.production.example               # NEW — documents every env var the production environment
                                      # needs, mirroring .env.example but noting which ones
                                      # switch to live values at cutover (User Story 5) — never
                                      # itself containing a real secret
```

**Structure Decision**: Stays inside the existing monolith; this phase's own new files are
almost entirely infrastructure/configuration (`.github/`, `docker-compose.prod.yml`,
`scripts/`) plus two small, targeted application changes (the Dockerfile placeholder fix and one
new counter). The audit itself (User Stories 1 and 6) produces no new source files by definition
— its output is the findings log plus whatever fixes each individual finding turns out to need,
which can't be enumerated until the audit actually runs (tasks.md scopes the audit as a task, not
its unknown-in-advance fixes).

## Complexity Tracking

*No Constitution Check violations — table not needed.*
