# Phase 0 Research: Phase 8 — Admin Operations

## 1. Should admin writes in this phase use the service-role client (Phase 5/6/7's pattern) or an admin RLS policy (Phase 2's pattern)?

**Decision**: Phase 2's pattern — an RLS policy that inline-checks
`exists (select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin')`,
combined with an app-layer `requireAdmin()` guard in the Route Handler (defense in depth, not the
actual authorization boundary — RLS is). Every write this phase introduces (order status,
subscription pause/cancel, city create/edit) uses the caller's own per-request RLS-scoped client,
never `lib/supabase/serviceRole.ts`.

**Rationale**: Phase 5/6/7's service-role-only rule exists to solve one specific problem: an
owner-scoped RLS policy restricts *rows*, not *columns*, so a policy like "a customer can update
their own subscription" would also let that customer PATCH `status`/`price_breakdown` directly —
exactly the `profiles.role` self-escalation class of bug Phase 1 hit once. That risk is about a
**customer's own session** having any write path into financial/subscription state at all. An
admin write is a categorically different case: the writer isn't the row's owner self-escalating
privilege, they're a *separately role-gated* actor whose entire authorization already depends on
`profiles.role = 'admin'` — and `profiles.role` itself is immutable outside a trigger/service-role
context (`20260810120300_profiles_role_immutable.sql`, Phase 1), so there is no client-writable
path to becoming that admin in the first place. Phase 2 already proved this exact pattern is safe
and is this project's actual, working precedent for admin writes (`products_insert_admin` etc.) —
adopting the service-role pattern here instead would be treating a defense built for a different
threat model as if it were the project's general rule, when the actual established rule (visible
in two different migrations built by two different phases, Phase 1's `profiles` and Phase 2's
`products`) is "gate the write with an admin-role-checking RLS policy."

**Alternatives considered**:
- *Service-role client for all admin writes, matching Phase 5/6/7*: rejected — see above; this
  would be applying the wrong precedent. It would also make every admin write path indistinguishable
  from Phase 7's fully-automated, no-human-session renewal engine, which is the actual reason that
  phase needs no RLS write policy at all (a webhook has no session to check). An admin write always
  has a real, checkable session — using it is simpler and more auditable (`auth.uid()` is available
  to the policy itself) than routing everything through an unconditional bypass.

## 2. Where does "Admin Action Record" (spec.md's Key Entity) actually live?

**Decision**: No new table. Attribution/reason columns are added directly to the records they
describe:
- `orders.status_updated_by` (uuid → `profiles.id`) + `orders.status_updated_at` (timestamptz) —
  every status change, including the terminal `delivered`/`cancelled` ones.
- `subscriptions.cancelled_by_admin_id` (uuid → `profiles.id`, nullable) +
  `subscriptions.cancel_reason` (text, nullable) — set only when the cancellation was
  admin-initiated; both stay `null` for a customer's own cancellation (Phase 6).
- `subscription_pauses.initiated_by_admin_id` (uuid → `profiles.id`, nullable) +
  `subscription_pauses.reason` (text, nullable) — the existing pause-history table from Phase 6/7
  already records *every* pause (customer-initiated, Phase 7 auto-suspend, and now admin-initiated);
  these two nullable columns distinguish which kind a given row is without a new table.

**Rationale**: spec.md's own Key Entities section already frames this as "attached to the
order/subscription it acts on, not a standalone screen of its own" — a separate audit-log table
would be the right call if this phase needed a browsable, cross-entity activity feed, but it
doesn't (no such screen is in any user story). Reusing `subscription_pauses` for admin pause
attribution is a direct extension of a table Phase 6/7 already designed for exactly this shape of
data (one row per pause, whoever/whatever caused it) — Phase 7's own auto-suspend already left
`resume_date` null to distinguish itself from a customer's dated pause; adding
`initiated_by_admin_id`/`reason` is the same pattern, one more distinguishing signal on the same
row shape, not a new concept.

**Alternatives considered**: A single generic `admin_actions` table (`entity_type`, `entity_id`,
`admin_id`, `action`, `reason`, `created_at`) — considered because it would generalize cleanly if
a future phase needs a real audit-log screen, but rejected for *this* phase: spec.md's Assumptions
explicitly rule out "a separately browsable audit-log screen... in this phase's scope," and
building the general table now without the screen that would ever query it back is speculative
schema the constitution's own "no half-finished implementations" spirit argues against.

## 3. How does an order status change stay safe under a concurrent edit (the spec's own edge case)?

**Decision**: `PATCH /api/admin/orders/[id]` performs a conditional update:
`UPDATE orders SET status = $newStatus, ... WHERE id = $id AND status = $expectedCurrentStatus`.
The Route Handler first validates the requested transition against `orderStatusTransition.ts`
using the status it *read* moments earlier, then makes the write conditional on that same status
still being current; zero rows updated means someone else already changed it, and the handler
returns a `409` telling the operator to reload rather than silently overwriting.

**Rationale**: This is the same SQL-level compare-and-swap idea Phase 5/7 already use for payment
idempotency (`UPDATE ... WHERE status NOT IN (...)`), applied here to prevent the spec's own named
edge case ("the order was already advanced... by another operator moments earlier") — Postgres's
row-level locking makes the check-then-write atomic without needing an application lock, consistent
with this project's now-repeated preference for that technique over any alternative.

**Alternatives considered**: Optimistic-locking via a version/`updated_at` column compared
client-side — rejected as unnecessary complexity; `orders` has no natural "version" concept beyond
its own `status`, and the status itself is exactly what needs to be current, so conditioning on it
directly is simpler than adding a column whose only purpose would be this one check.

## 4. Where does customer email come from for the "search by name/email/phone" requirement?

**Decision**: Add `profiles.email` (text, nullable — backfilled for existing rows, populated going
forward by the existing `handle_new_user()` trigger, which already has `new.email` available since
it fires on `auth.users` insert). Admin search queries `profiles.email` directly through the
ordinary RLS-scoped client, exactly like `full_name`/`phone` already are.

**Rationale**: `profiles` has never stored email — it lives only in `auth.users`, a schema
PostgREST (and therefore the RLS-scoped Supabase client every read in this project uses) cannot
query at all, regardless of role or policy; only the service-role client's separate Admin API
(`supabase.auth.admin.*`) can reach it, and using that just for a search box would contradict this
phase's own decision (research.md §1) to keep every read/write on the ordinary RLS-scoped client.
Denormalizing email onto `profiles` — a single trigger-maintained column — is the smallest change
that makes "search by name, email, or phone" (the clarification session's own explicit requirement)
actually queryable the same way every other admin list filter already is. The one-time backfill for
existing rows runs as a plain migration statement joining `auth.users`, which executes with the
migration's own elevated privileges (not through PostgREST/RLS), so it isn't subject to the same
restriction.

**Alternatives considered**: Calling `supabase.auth.admin.listUsers()` (service-role) from each
admin list's Server Component to cross-reference emails at read time — rejected: it would be the
only service-role usage in this entire phase (research.md §1 commits to zero), it doesn't compose
with Postgres-side filtering/pagination (the search would have to happen in application code after
fetching everything), and it reintroduces exactly the "why does this one screen use a different
data-access pattern than every other admin screen" inconsistency this phase is otherwise avoiding.

## 5. How does the counters view avoid becoming its own performance/consistency risk?

**Decision**: `CountersOverview.tsx` runs three independent, simple aggregate queries
(`count()` on `subscriptions` filtered by `status = 'active'`; `count()` on `orders` filtered by
`scheduled_date = today`; `sum(amount_halalas)` on `payments` filtered by `status = 'paid'` and
`created_at` within the current calendar month, divided by 100 via the existing halalas
convention) directly in the Server Component, computed fresh on every request — no caching layer,
no materialized view, no scheduled recomputation.

**Rationale**: spec.md's own SC-005 requires the counters be "never more than one page-load stale,"
which a fresh-per-request query trivially satisfies without needing to invalidate anything; at
this project's stated scale (no throughput requirement anywhere in `plan.md`), three `count()`/`sum()`
aggregates are cheap enough that a caching layer would be solving a performance problem that
doesn't exist yet, at the cost of exactly the staleness SC-005 explicitly rules out.

**Alternatives considered**: A scheduled job (Phase 7-style) that periodically recomputes and
stores the three numbers — rejected: adds a second moving part (another cron-triggered endpoint)
for a read three cheap queries already satisfy directly, and would violate SC-005 the moment the
job's own interval elapses without a fresh trigger.
