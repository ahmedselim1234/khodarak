# Contract: `POST /api/subscriptions`

The only new Route Handler this phase (spec User Story 3). Requires an authenticated session
(the `/subscription` page is already customer/admin-gated by `middleware.ts` since Phase 1; this
handler re-checks server-side since `/api/subscriptions` is not itself under a gated path prefix,
same reasoning as every other authenticated Route Handler in this project). The request body is
validated with the zod schema in `lib/validation/subscription.ts`. Never accepts a price or
breakdown from the client — the server always recomputes via `lib/pricing/calculate.ts`
(Constitution Principle II), reading the box from the caller's own `cart_items` rows rather than
from the request body at all (research.md §1: the box *is* the cart).

## `POST /api/subscriptions`

**Request**:
```json
{
  "frequency": "weekly",
  "addressId": "uuid",
  "nextDeliveryDate": "2026-08-20",
  "deliveryTimeSlot": "morning"
}
```

Note there is no `items` field — the box is read server-side from the caller's current
`cart_items` (joined with `products`), never trusted from the client (research.md §1).

Validation (FR-004/006/007/008):
- `frequency` one of `'weekly' | 'biweekly' | 'monthly'`, and MUST currently be `enabled: true` in
  the live `settings.frequencies` — otherwise `422 { "error": "frequency_disabled" }` (same
  contract shape as Phase 3's `pricing-preview-api.md`)
- `addressId` a valid uuid belonging to the caller — otherwise `404` (never confirms existence of
  another user's address, same non-enumeration posture as `addresses-api.md`)
- `nextDeliveryDate` MUST be selectable per `lib/subscription/selectableDeliveryDates.ts` given the
  live `settings.firstDeliveryLeadDays`/`blackoutWeekdays` — otherwise
  `400 { "error": "validation_failed", "fields": { "nextDeliveryDate": "..." } }`
- `deliveryTimeSlot` one of the three fixed values in `lib/subscription/timeSlots.ts`

**Behavior**:
1. Resolve the caller's current `cart_items` (joined with `products`); drop any unavailable/deleted
   products (FR-016), same as the cart's and pricing preview's existing behavior.
2. If the resulting box is empty, respond `400 { "error": "empty_box" }` — nothing to subscribe to.
3. Resolve `addressId` → its `cityId`.
4. Call `calculate.ts` with the resolved items, `frequency`, city, and the live `settings` row.
5. If `!breakdown.meetsMinimumOrderValue || !breakdown.withinMaxItemsPerBox`, respond
   `422 { "error": "rule_violation", "breakdown": { ...same shape as pricing-preview-api.md... } }`
   (FR-009) — the client already disables confirm in this state via the same flags, but the server
   is the actual gate.
6. Insert `subscriptions` (`status: 'pending_payment'`, the freshly computed `price_breakdown`).
7. Insert `subscription_items`, one row per surviving cart line. On failure, delete the
   `subscriptions` row created in step 6 (research.md §3) and respond `500`.
8. Delete the caller's `cart_items` rows (FR-012) — only reached after steps 6–7 both succeed.
9. Return the created subscription's id.

**Response — success**:
```
201 Created
Content-Type: application/json

{ "subscriptionId": "uuid" }
```

The client navigates to `/subscription/confirmed/[subscriptionId]`, which independently re-fetches
the subscription (owner-scoped) rather than trusting anything held in client state from before the
request (Constitution Principle I/II — the confirmation page is a fresh Server Component read).

**Response — rule violation**: `422` as in step 5.

**Response — disabled frequency**: `422 { "error": "frequency_disabled" }`.

**Response — invalid date**: `400 { "error": "validation_failed", "fields": {...} }`.

**Response — address not found/not owned**: `404 { "error": "not_found" }`.

**Response — empty box**: `400 { "error": "empty_box" }`.

**Response — unauthenticated**: `401 { "error": "unauthenticated" }`.

## Notes

- No endpoint here reads or lists subscriptions — the confirmation page reads the one it just
  created directly via the server Supabase client (owner-scoped by RLS), consistent with every
  other Server-Component read in this project (`ProductTable`, `AddressList`) rather than round-
  tripping through a JSON API purely to render a page that already knows which row to fetch.
- FR-013 (no duplicate subscription from a double-submit): the client disables the confirm button
  for the duration of the request (same pattern as every other mutating form in this codebase —
  `ProductForm`, `SettingsForm`); server-side, a second near-simultaneous request finds the cart
  already emptied by step 8 of the first request and fails at step 2 (`empty_box`) rather than
  creating a second subscription.
