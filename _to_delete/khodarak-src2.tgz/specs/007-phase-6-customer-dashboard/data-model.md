# Phase 1 Data Model: Phase 6 — Customer Dashboard

All tables below already exist except `subscription_pending_items` and `subscription_pauses`
(new) and the pending-change columns added to `subscriptions` (altered). Nothing in this phase
alters `orders`, `order_items`, `payments`, or `payment_methods`'s existing shape from Phase 5 —
this phase only adds a first customer-triggered insert path into `payment_methods` (via
service-role, per research.md §5) and reads the rest.

## `subscriptions` (altered)

Adds four nullable columns to the table Phase 4 created
(`20260810150000_subscriptions.sql`):

| Column | Type | Notes |
|---|---|---|
| `pending_frequency` | text, same check constraint as `frequency` | Null when no pending change exists |
| `pending_address_id` | uuid, references `addresses(id)` | Null when no pending change exists |
| `pending_price_breakdown` | jsonb | The re-priced breakdown for the pending config, computed at save time — never recalculated later from stale prices |
| `pending_effective_from` | date | The delivery date the pending change becomes current for (always `next_delivery_date`, computed at save time — stored rather than re-derived so a later `next_delivery_date` advance, which is Phase 7's job, has an unambiguous cutover point) |

`pending_items` is **not** a jsonb column here — see `subscription_pending_items` below, which
mirrors `subscription_items`'s row-per-product shape.

A pending change exists exactly when `pending_effective_from is not null`. All four pending
columns are always written or cleared together (never partially) by
`lib/subscription/mutateSubscription.ts` — there is no state where only some of them are set.

**No new RLS policy.** `subscriptions_select_own` (Phase 4) already covers reading these new
columns. No `UPDATE` policy is added — see research.md §3 for why; every write to any column on
this table (including these four) goes through the service-role client from
`app/api/subscriptions/[id]/*` only.

## `subscription_pending_items` (new)

Mirrors `subscription_items` exactly, one row per product in the *pending* configuration:

| Column | Type | Notes |
|---|---|---|
| `id` | uuid, PK | |
| `subscription_id` | uuid, references `subscriptions(id)` on delete cascade | |
| `product_id` | uuid, references `products(id)` | |
| `quantity` | integer, `>= 1` | |
| `created_at` | timestamptz, default `now()` | |

When a new pending change is saved, this phase's mutation logic deletes any existing pending-item
rows for the subscription and inserts the new set — a full replace, not a diff, matching how
`subscription_items` itself is expected to be managed (research.md §1: "pending changes never
stack or merge" — the same replace-not-merge rule applies to items).

RLS: owner-scoped `SELECT` only, via the same join-through-parent pattern as `subscription_items`
(`exists (select 1 from subscriptions where subscriptions.id = subscription_pending_items.subscription_id and subscriptions.user_id = auth.uid())`).
No `INSERT`/`UPDATE`/`DELETE` policy — service-role only, same rule as the parent table.

## `subscription_pauses` (new)

Append-only history of every pause a subscription has had — the basis for the rolling-365-day
`max_pauses_per_year` check (research.md §2):

| Column | Type | Notes |
|---|---|---|
| `id` | uuid, PK | |
| `subscription_id` | uuid, references `subscriptions(id)` on delete cascade | |
| `started_at` | timestamptz, default `now()` | When the pause was initiated |
| `resume_date` | date | The customer's chosen resume date at the time of pausing |
| `resumed_early_at` | timestamptz, nullable | Set if the customer resumed before `resume_date` arrived; null if the pause ran its full course (auto-resumed) or was superseded by a cancel |

`pauseEligibility.ts` counts rows where `started_at >= now() - interval '365 days'` against
`max_pauses_per_year`, and computes the requested pause's span (`resume_date - today`) against
`max_pause_days` — both from the same settings row `lib/pricing/mapSettingsRow.ts` already exposes
(`maxPauseDays`, `maxPausesPerYear`).

RLS: owner-scoped `SELECT` only, same join-through-parent pattern. No customer-writable policy —
inserts happen exclusively from `POST /api/subscriptions/[id]/pause` via service-role.

## Existing entities this phase reads but does not alter

- **`subscription_items`** (Phase 4) — the subscription's *current*, in-effect items. Read for
  the status card's "next delivery contents" (US1) and as the baseline `resolveEffectiveConfig`
  compares pending items against.
- **`addresses`** (Phase 1) — read for the address selector in both the subscription editor and
  settings; `AddressBook`/`AddressForm`/`AddressCard`/`AddressList` components are reused as-is,
  wired into `/dashboard/settings` for the first time in this phase.
- **`orders`, `order_items`** (Phase 5) — read-only, `/dashboard/orders` (US4). Never written by
  this phase; snapshots stay exactly as Phase 5's activation flow created them (FR-017).
- **`payment_methods`** (Phase 5) — read for the settings display; this phase adds the *second*
  ever insert path (card replacement, research.md §5) alongside Phase 5's activation-time insert,
  both service-role only.
- **`payments`** (Phase 5) — read-only, for both the payment-history list (US5) and the
  `consecutiveFailedPayments` input to `subscriptionHealth.ts` (research.md §4).
- **`profiles`** (Phase 1) — `full_name`/`phone` updated via the existing owner-scoped
  `profiles_update_own` policy and `profiles_role_immutable` trigger, unchanged from Phase 1;
  no schema change needed.
- **`settings`** (Phase 3) — read for every rule this phase enforces (`edit_cutoff_hours`,
  `min_order_value`, per-product min/max via `products`, `max_items_per_box`, `max_pause_days`,
  `max_pauses_per_year`, plus the full pricing-calculation inputs), via the existing
  `mapSettingsRow.ts`.

## Derived (not stored) values

- **Effective configuration** (what the locked next delivery contains vs. what applies after) —
  `lib/subscription/resolveEffectiveConfig.ts`, computed at read time from `subscriptions` +
  `subscription_items` + `subscription_pending_items`, never persisted separately (research.md §1).
- **Subscription health** (`'good' | 'needs_attention'`) — `lib/subscription/subscriptionHealth.ts`,
  computed at read time, never persisted (research.md §4).
- **Pause eligibility** (`allow | deny + which limit`) — `lib/subscription/pauseEligibility.ts`,
  computed at request time from `subscription_pauses` + `settings`, never persisted ahead of an
  actual pause attempt (research.md §2).

## State transitions (`subscriptions.status`)

```
pending_payment ──(Phase 5, out of scope here)──▶ active
active ──pause──▶ paused
paused ──resume (early, customer-initiated) OR resume_date passes (automatic, out of scope this
         phase's write path — see note)──▶ active
active ──cancel──▶ cancelled  (terminal)
paused ──cancel──▶ cancelled  (terminal)
```

Note: the *automatic* paused→active transition when `resume_date` passes with no customer action
(FR-013) requires something to notice the date has passed. This phase does not introduce a
scheduled job for it (no cron infrastructure exists until Phase 7). Instead, `GET
/api/subscriptions/[id]` self-heals on read: if it finds `status = 'paused'` and `paused_until` is
today or earlier, it performs the `paused → active` write itself (service-role, same
`mutateSubscription.ts` path as every other transition) before returning the response — so the
very next time anyone (the customer opening `/dashboard`, or a future Phase 7 job) reads the
subscription, the transition has already happened and stays consistent for every subsequent read
or write. This is a lazy/self-healing transition, not a background job — it costs nothing when the
resume date hasn't arrived yet, and guarantees the database is never more than one read behind
reality.
