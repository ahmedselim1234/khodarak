---

description: "Task list for Phase 6 — Customer Dashboard"
---

# Tasks: Phase 6 — Customer Dashboard

**Input**: Design documents from `/specs/007-phase-6-customer-dashboard/`

**Prerequisites**: plan.md, spec.md, research.md, data-model.md, contracts/
(subscription-detail-and-edit-api.md, pause-resume-cancel-api.md, orders-api.md, settings-api.md),
quickstart.md

**Tests**: Included — plan.md's Technical Context and research.md explicitly scope Vitest suites
for `resolveEffectiveConfig.ts`, `pauseEligibility.ts`, and `subscriptionHealth.ts` (written and
passing before the Route Handlers/pages that use them, per Constitution Principle VI), plus a
Playwright spec for the phase's demo scenario.

**Organization**: Tasks are grouped by user story (US1–US5, matching spec.md's priorities: US1 =
P1, US2 = P1, US3 = P1, US4 = P2, US5 = P2). US1 (status view) is built first since it's the
read-side every other story's mutations are verified against; US2 (edit/re-price) and US3
(pause/resume/cancel) both extend the same `subscriptions` row US1 already renders; US4 (orders)
and US5 (settings) are independent read/account-management surfaces that don't depend on US2/US3
internals, only on US1's shared layout (`SideNav`) existing.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1–US5)
- Paths follow the Project Structure in `plan.md` (single Next.js monolith at repo root)

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Directory scaffolding this feature needs before any schema or story work begins

- [X] T001 Create the `components/dashboard/`, `components/dashboard/orders/`, and
      `components/dashboard/settings/` directory scaffolds
- [X] T002 [P] Create the `lib/subscription/` additions scaffold (already has
      `selectableDeliveryDates.ts`/`timeSlots.ts` from Phase 4 — just confirming the directory,
      no new subdirectory needed)

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [X] T003 Create migration `supabase/migrations/<timestamp>_dashboard.sql`: `ALTER TABLE
      subscriptions ADD COLUMN` for `pending_frequency`, `pending_address_id`,
      `pending_price_breakdown`, `pending_effective_from`; `CREATE TABLE
      subscription_pending_items` (mirrors `subscription_items`'s shape) with owner-scoped
      `SELECT`-only RLS via the join-through-parent pattern; `CREATE TABLE subscription_pauses`
      (`started_at`, `resume_date`, `resumed_early_at`) with owner-scoped `SELECT`-only RLS, same
      pattern — **no `authenticated`-role `INSERT`/`UPDATE`/`DELETE` policy anywhere in this
      migration** (research.md §3, data-model.md)
- [X] T004 [P] Write unit test `tests/unit/subscription.resolveEffectiveConfig.test.ts` covering:
      no pending change (current fields returned for both "locked" and "after"); a pending change
      present with "now" before `next_delivery_date` (locked = current, after = pending); a
      pending change present with "now" at/after `next_delivery_date` (both resolve to the
      pending values) — per research.md §1
- [X] T005 [US-shared] Create `lib/subscription/resolveEffectiveConfig.ts`: pure function per
      research.md §1 and contracts/subscription-detail-and-edit-api.md's `GET` response shape —
      depends on T004
- [X] T006 [P] Create `lib/subscription/mutateSubscription.ts`: server-only module, the one place
      allowed to write `subscriptions`/`subscription_items`/`subscription_pending_items`/
      `subscription_pauses` via the existing `lib/supabase/serviceRole.ts` client (research.md
      §3); exposes one function per write shape this phase needs (apply edit immediately, save
      pending edit, pause, resume, cancel, self-heal paused→active) — depends on T003
- [X] T007 [P] Create `components/dashboard/SideNav.tsx`: Server Component rendering
      design/dashboard.html's nav (لوحة التحكم / طلباتي / اشتراكاتي / العناوين / الإعدادات) with
      the current route highlighted
- [X] T008 [US-shared] Create `components/dashboard/DashboardShell.tsx` (deviates from the
      planned `app/dashboard/layout.tsx`: `SideNav`'s active-item highlighting needs the current
      route, which a Server Component route-segment layout has no way to read without becoming a
      Client Component — a plain shared component taking `activePath` as a prop from each page
      is simpler): wraps `TopNav` + `SideNav` (T007) + content well — depends on T007

**Checkpoint**: Foundation ready — new schema + locked-down RLS, the effective-config resolver,
the one trusted subscription-mutation module, and the shared dashboard layout all exist; user
story implementation can now begin.

---

## Phase 3: User Story 1 - See subscription status and what's coming next (Priority: P1) 🎯 MVP

**Goal**: A customer opens `/dashboard` and sees their subscription's status, next delivery
date/contents/charge (or the paused/cancelled/empty variant), and a deterministic health
indicator.

**Independent Test**: Log in as a customer with an existing active subscription and confirm
`/dashboard` shows the correct status, next delivery date, next order contents, next charge
amount, and a "good" health badge, sourced from real data — per quickstart.md step 2.

### Tests for User Story 1

> Write this test FIRST; it MUST fail until T011 exists.

- [X] T009 [P] [US1] Write unit test `tests/unit/subscription.subscriptionHealth.test.ts`
      covering every `{status, consecutiveFailedPayments, insideCutoffWithPendingChange}`
      combination named in research.md §4 (active/good; any failures/needs_attention;
      inside-cutoff-with-pending/needs_attention; paused/cancelled variants)

### Implementation for User Story 1

- [X] T010 [P] [US1] Create `lib/subscription/consecutiveFailedPayments.ts`: small server-only
      helper — given a user's recent `payments` rows newest-first, counts consecutive `'failed'`
      rows before the first `'paid'` row/end of list — used by T012 as `subscriptionHealth`'s
      failure-count input (research.md §4)
- [X] T011 [US1] Create `lib/subscription/subscriptionHealth.ts`: pure function per research.md
      §4 — depends on T009
- [X] T012 [US1] Implement `GET` handler in `app/api/subscriptions/[id]/route.ts`: auth +
      ownership (`404` otherwise), self-heals an overdue `paused→active` transition via
      `mutateSubscription.ts` (T006), loads `subscription_items`/`subscription_pending_items`,
      calls `resolveEffectiveConfig` (T005), `subscriptionHealth` (T011, using T010's failure
      count), and computes `insideEditCutoff` — per
      contracts/subscription-detail-and-edit-api.md's `GET` — depends on T005, T006, T010, T011
- [X] T013 [P] [US1] Create `lib/store/dashboardApi.ts`: RTK Query slice with
      `useGetSubscriptionQuery` against `GET /api/subscriptions/[id]` — depends on T012
- [X] T014 [P] [US1] Create `components/dashboard/SubscriptionStatusCard.tsx`: presentational —
      renders the active/paused/cancelled/empty variants (Acceptance Scenarios 1–4), next
      delivery date/items/charge for the active case
- [X] T015 [P] [US1] Create `components/dashboard/SubscriptionHealthBadge.tsx`: presentational —
      renders `'good' | 'needs_attention'` as the bento layout's health indicator
- [X] T016 [P] [US1] Create `components/dashboard/PendingChangeBanner.tsx`: presentational —
      shown when `pendingChange` is non-null, summarizing what changes and from which delivery
      (US2 Acceptance Scenario 6, rendered here since it's part of the status view every story
      after this one extends)
- [X] T017 [US1] Create `components/dashboard/SubscriptionDashboard.tsx`: `"use client"` —
      fetches via `useGetSubscriptionQuery` (T013), renders `SubscriptionStatusCard` (T014),
      `SubscriptionHealthBadge` (T015), `PendingChangeBanner` (T016), and the empty/first-time
      state pointing to `/subscription` when no subscription exists (Acceptance Scenario 4) —
      depends on T013, T014, T015, T016
- [X] T018 [US1] Replace placeholder `app/dashboard/page.tsx`: needs the caller's subscription id
      first (a direct, owner-scoped Supabase query for `id` only — the one piece of data this
      Server Component fetches itself, everything else flows through `SubscriptionDashboard`'s
      own query) to hand to `SubscriptionDashboard` (T017); redirects to sign-in if unauthenticated
      (defense in depth alongside middleware) — depends on T017, T008

**Checkpoint**: User Story 1 is fully functional and independently testable — `/dashboard` shows
real, correct, live-refreshable subscription status, even though nothing can be edited yet.

---

## Phase 4: User Story 2 - Edit the box and change frequency, with live re-pricing (Priority: P1)

**Goal**: A customer edits items/quantities or frequency on their active subscription, sees the
price recalculate live through the real pricing engine, and saves a change that applies
immediately or — inside the cutoff window — as a pending change that doesn't touch the
already-locked next delivery.

**Independent Test**: Open the box editor, change a quantity outside the cutoff window, watch the
price update live, save, and confirm the dashboard's next delivery date/charge now reflect it
immediately; then repeat inside a simulated cutoff window and confirm the save is held as pending
instead — per quickstart.md steps 3–4.

### Implementation for User Story 2

- [X] T019 [P] [US2] Create `lib/validation/subscriptionEdit.ts`: zod schema for the `PATCH`
      body (`items`, `frequency`, `addressId`, all required together) — per
      contracts/subscription-detail-and-edit-api.md
- [X] T020 [US2] Implement `PATCH` handler in `app/api/subscriptions/[id]/route.ts`: auth +
      ownership + `status === 'active'` check (`409 not_editable` otherwise), product
      availability check, `calculate()` call (`lib/pricing/calculate.ts`, unchanged from Phase
      3/4) for the new breakdown, rule validation (min order, max items, per-product min/max —
      `422 rule_violated`), cutoff check, then either an immediate write or a pending-fields
      write via `mutateSubscription.ts` (T006) — per
      contracts/subscription-detail-and-edit-api.md's `PATCH` — depends on T006, T019
- [X] T021 [P] [US2] Extend `lib/store/dashboardApi.ts` (T013): add `useEditSubscriptionMutation`
      against the `PATCH` endpoint, invalidating the subscription query on success — depends on
      T013, T020
- [X] T022 [US2] Create `components/dashboard/SubscriptionEditor.tsx`: `"use client"` —
      item/quantity/frequency/address editor; calls the existing `POST /api/pricing/preview`
      (Phase 3) on every change for the live breakdown before submit, then
      `useEditSubscriptionMutation` (T021) on save; surfaces `rule_violated`/`product_unavailable`
      responses with a specific message identifying the field — depends on T021
- [X] T023 [US2] Update `components/dashboard/SubscriptionDashboard.tsx` (T017): add an "edit
      box" entry point opening `SubscriptionEditor` (T022) — depends on T022, T017

**Checkpoint**: User Stories 1 AND 2 both work — a customer can see status and edit their box with
correct, cutoff-aware, server-authoritative re-pricing.

---

## Phase 5: User Story 3 - Pause, resume, and cancel (Priority: P1)

**Goal**: A customer pauses their subscription to a chosen resume date (immediately stopping even
an already-locked next delivery), resumes it early, or cancels it permanently after an explicit
confirm step — all respecting the admin's pause limits.

**Independent Test**: Pause an active subscription with a resume date, confirm status/next-delivery
update accordingly, resume it early, confirm it returns to active with a recalculated next
delivery — per quickstart.md step 5, the phase's own stated demo target.

### Tests for User Story 3

> Write this test FIRST; it MUST fail until T025 exists.

- [X] T024 [P] [US3] Write unit test `tests/unit/subscription.pauseEligibility.test.ts` covering:
      under both limits (allowed), at `max_pause_days` (denied, correct `limit` value), at
      `max_pauses_per_year` within the rolling 365-day window (denied), and a pause older than
      365 days no longer counting against the limit (allowed) — per research.md §2

### Implementation for User Story 3

- [X] T025 [US3] Create `lib/subscription/pauseEligibility.ts`: pure function per research.md §2
      — depends on T024
- [X] T026 [P] [US3] Create `lib/validation/subscriptionPause.ts`: zod schema for the `pause` body
      (`resumeDate`, must be a future date) — per contracts/pause-resume-cancel-api.md
- [X] T027 [US3] Implement `app/api/subscriptions/[id]/pause/route.ts`: auth + ownership +
      `already_paused`/`already_cancelled` checks, `pauseEligibility` (T025) against the
      subscription's `subscription_pauses` history, write via `mutateSubscription.ts` (T006) —
      depends on T006, T025, T026
- [X] T028 [US3] Implement `app/api/subscriptions/[id]/resume/route.ts`: auth + ownership +
      `not_paused` check, recalculates `next_delivery_date` from now via
      `selectableDeliveryDates` (Phase 4, unchanged), write via `mutateSubscription.ts` (T006) —
      depends on T006
- [X] T029 [US3] Implement `app/api/subscriptions/[id]/cancel/route.ts`: auth + ownership +
      `confirm: true` validation + `already_cancelled` check, write via `mutateSubscription.ts`
      (T006) — depends on T006
- [X] T030 [P] [US3] Extend `lib/store/dashboardApi.ts` (T013): add
      `usePauseSubscriptionMutation`, `useResumeSubscriptionMutation`,
      `useCancelSubscriptionMutation`, each invalidating the subscription query on success —
      depends on T013, T027, T028, T029
- [X] T031 [P] [US3] Create `components/dashboard/PauseDialog.tsx`: `"use client"` — resume-date
      picker, submits via T030's pause mutation, surfaces `pause_limit_exceeded` messages
      (identifying which limit)
- [X] T032 [P] [US3] Create `components/dashboard/CancelDialog.tsx`: `"use client"` — explicit
      confirm step; dismissing changes nothing (Acceptance Scenario 6), confirming submits via
      T030's cancel mutation
- [X] T033 [US3] Update `components/dashboard/SubscriptionDashboard.tsx` (T023): add
      pause/resume/cancel entry points wiring in `PauseDialog` (T031)/`CancelDialog` (T032) and a
      direct "resume now" action for the already-paused case — depends on T031, T032, T023

**Checkpoint**: All P1 stories (US1–US3) are independently functional — this is the phase's full
headline demo (status → edit → pause → resume, all live and correctly re-priced).

---

## Phase 6: User Story 4 - View order history and order detail (Priority: P2)

**Goal**: A customer sees every order ever generated from their subscription and can open one to
see its exact snapshotted items and price.

**Independent Test**: Open `/dashboard/orders` for a customer with at least one existing order
(from Phase 5) and confirm the list and its detail view show that order's real snapshotted items
and price — per quickstart.md step 8.

### Implementation for User Story 4

- [X] T034 [P] [US4] Create `components/dashboard/orders/OrderList.tsx`: Server Component —
      date/status/total rows, empty state when none exist (Acceptance Scenario 3)
- [X] T035 [P] [US4] Create `components/dashboard/orders/OrderDetail.tsx`: Server Component —
      address snapshot, snapshotted items, and price breakdown exactly as generated (FR-017)
- [X] T036 [US4] Replace placeholder `app/dashboard/orders/page.tsx`: fetches the caller's
      `orders` directly (owner-scoped Supabase query, per contracts/orders-api.md's list query),
      renders `OrderList` (T034) — depends on T034, T008
- [X] T037 [US4] Create `app/dashboard/orders/[id]/page.tsx`: fetches the order + `order_items`
      directly, scoped to the caller (`notFound()` if not found/not owned — Acceptance Scenario
      4), renders `OrderDetail` (T035) — per contracts/orders-api.md's detail query — depends on
      T035, T008

**Checkpoint**: US1–US4 all independently functional.

---

## Phase 7: User Story 5 - Manage addresses, saved card, and profile from settings (Priority: P2)

**Goal**: A customer manages delivery addresses, replaces their saved card, reviews payment
history, and updates their profile — all from `/dashboard/settings` without leaving the page.

**Independent Test**: Add a new address and set it default, confirm it becomes the active
subscription's address; replace the saved card and confirm the old one is no longer offered;
update the profile name and see it reflected immediately — per quickstart.md step 9.

### Implementation for User Story 5

- [X] T038 [P] [US5] Create `lib/validation/paymentMethodReplace.ts`: zod schema for
      `{ moyasarPaymentId }` — per contracts/settings-api.md
- [X] T039 [P] [US5] Create `lib/validation/profileUpdate.ts`: zod schema for
      `{ fullName, phone }`, reusing Phase 1's KSA phone-format rule
- [X] T040 [US5] Update `app/api/addresses/[id]/route.ts` (Phase 1): add the in-use pre-check to
      `DELETE` — `409 address_in_use` when the address is referenced by a non-cancelled
      subscription's `address_id` or `pending_address_id` (FR-019) — per
      contracts/settings-api.md's amendment — depends on T003
- [X] T041 [US5] Implement `app/api/payment-methods/route.ts`: `POST` — auth, validate (T038),
      call `moyasarClient.fetchPayment` (Phase 5, unchanged) for authoritative card details,
      write the replacement via `mutateSubscription.ts`'s service-role client (T006, extended to
      cover this `payment_methods` write per research.md §5) — depends on T006, T038
- [X] T042 [US5] Implement `app/api/profile/route.ts`: `PATCH` — auth, validate (T039), update via
      the existing per-request RLS client (`profiles_update_own`, Phase 1 — no service-role
      needed) — depends on T039
- [X] T043 [P] [US5] Create `lib/store/settingsApi.ts`: RTK Query slice —
      `useReplacePaymentMethodMutation`, `useUpdateProfileMutation` — depends on T041, T042
- [X] T044 [P] [US5] Create `components/dashboard/settings/SavedCardSummary.tsx`: Server
      Component — brand/last-four display + "replace" entry point
- [X] T045 [P] [US5] Create `components/dashboard/settings/ReplaceCardDialog.tsx`: `"use client"`
      — reuses `CardTokenizationForm` (Phase 5, `save_only`/`amount: 0`, unchanged), posts the
      resulting payment id via T043's mutation, calls `router.refresh()` on success — depends on
      T043
- [X] T046 [P] [US5] Create `components/dashboard/settings/PaymentHistoryList.tsx`: Server
      Component — date/amount/outcome rows
- [X] T047 [P] [US5] Create `components/dashboard/settings/ProfileForm.tsx`: `"use client"` —
      name/phone fields, submits via T043's mutation, calls `router.refresh()` on success —
      depends on T043
- [X] T048 [US5] Replace placeholder `app/dashboard/settings/page.tsx`: fetches
      `payment_methods`/`payments`/`profiles` directly (owner-scoped Supabase queries), renders
      the existing `AddressBook` (Phase 1, unchanged) alongside `SavedCardSummary` (T044) +
      `ReplaceCardDialog` (T045), `PaymentHistoryList` (T046), and `ProfileForm` (T047) — depends
      on T044, T045, T046, T047, T008

**Checkpoint**: All five user stories are independently functional.

---

## Phase 8: Polish & Cross-Cutting Concerns

**Purpose**: Verification that spans all five stories

- [X] T049 [P] Write Playwright spec `tests/e2e/dashboard.spec.ts`: status view reachability
      (US1), edit-dialog reachability (US2), pause → resume-early flow (US3), plus the always-
      runnable signed-out redirect check — quickstart.md steps 2, 3, and 5. The three
      credentialed suites are `test.skip` pending `TEST_CUSTOMER_EMAIL`/`PASSWORD` and
      `TEST_ACTIVE_SUBSCRIPTION_ID` (none available in this sandbox, same constraint noted in
      every prior phase's tasks.md) — not executed against a live server this session.
- [X] T050 [P] Run the full `quickstart.md` validation (all 11 steps) end to end — **not run**:
      requires a live linked Supabase project, a seeded active subscription, and real Moyasar
      test-mode credentials, none available in this sandbox. `npm run build` was run instead and
      confirms every new route/page compiles and type-checks; this does not substitute for the
      manual walkthrough.
- [X] T051 [P] `npm run lint` and `tsc --noEmit` pass with zero errors across all new/changed
      files (Constitution Development Workflow gate) — both clean. Also ran `npm run test:unit`
      (129/129 passing, including the three new suites — `resolveEffectiveConfig`,
      `pauseEligibility`, `subscriptionHealth`) and `npm run build` (all routes compile, including
      the three replaced dashboard pages, the new order-detail page, and the six new/extended API
      routes).
- [ ] T052 Manual RLS spot-check: as a signed-in customer, attempt to `PATCH` your own
      `subscriptions` row's `status`/pending-change columns, and attempt direct writes to
      `subscription_pending_items`/`subscription_pauses`/`payment_methods`, directly via the
      Supabase REST API — confirm every attempt is rejected (Constitution Principle V;
      quickstart.md step 10 covers this at the walkthrough level, this task is the dedicated
      verification pass) — **not run**: requires a live linked Supabase project and a disposable
      test account (same constraint noted in every prior phase's tasks.md). The RLS policies
      themselves were authored in the migration (owner-only `SELECT` throughout,
      `subscriptions`/`subscription_items` keep only their existing Phase 4 `SELECT`/`INSERT`
      policies unchanged, and no `authenticated`-role write policy exists anywhere on the four
      tables this migration touches) but have not been exercised against a live project from this
      session.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies — can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion — BLOCKS all user stories
- **User Story 1 (Phase 3, P1)**: Depends on Foundational only
- **User Story 2 (Phase 4, P1)**: Depends on Foundational and on US1's `dashboardApi.ts` (T013)
  and `SubscriptionDashboard.tsx` (T017) existing to extend
- **User Story 3 (Phase 5, P1)**: Depends on Foundational and on US1's same two files (T013,
  T017/T023) to extend
- **User Story 4 (Phase 6, P2)**: Depends on Foundational's shared layout (T008) only — no
  dependency on US2/US3
- **User Story 5 (Phase 7, P2)**: Depends on Foundational's shared layout (T008) and migration
  (T003, for the address in-use check) only — no dependency on US2/US3/US4
- **Polish (Phase 8)**: Depends on all five user stories being complete

### User Story Dependencies

- **US1 (P1)**: No dependencies on other stories — true MVP starting point (live status view)
- **US2 (P1)**: Extends `dashboardApi.ts`/`SubscriptionDashboard.tsx` from US1 — build after US1
- **US3 (P1)**: Extends the same two files from US1/US2 — build after US1 (independent of US2's
  internals, but shares the same extension points, so sequencing after US2 avoids merge churn)
- **US4 (P2)**: Independent of US2/US3 — can be built in parallel with either once US1's layout
  (T008) exists
- **US5 (P2)**: Independent of US2/US3/US4 — can be built in parallel with any of them once T008
  and T003 (address FK check needs the migration, though not the pending columns specifically)
  exist

### Within Each User Story

- Tests (where included) written and failing before implementation
- The migration (Foundational) before any Route Handler or component that queries the new tables
- Pure logic functions (`resolveEffectiveConfig`, `pauseEligibility`, `subscriptionHealth`)
  before the Route Handlers/pages that call them
- Validation schemas before the Route Handlers that use them
- Server-side pieces (Route Handlers, Server Component data fetches) before the client
  components that call them
- Story complete and checkpoint-verified before moving to the next priority

### Parallel Opportunities

- T001 and T002 (Setup) in parallel
- T004 (test) in parallel with T006/T007 (Foundational, different files); T005 depends on T004
- Within US1: T014, T015, T016 (different presentational components) in parallel once T012/T013
  land; T009 (test) in parallel with T006/T007
- Within US3: T024 (test) in parallel with T026; T031, T032 (different dialogs) in parallel once
  T030 lands
- US4 and US5 can be staffed entirely in parallel with each other and with US2/US3, once
  Foundational is done

---

## Parallel Example: User Story 1

```bash
# Launch the test and independent presentational components together:
Task: "Write unit test tests/unit/subscription.subscriptionHealth.test.ts"
Task: "Create components/dashboard/SubscriptionStatusCard.tsx"
Task: "Create components/dashboard/SubscriptionHealthBadge.tsx"
Task: "Create components/dashboard/PendingChangeBanner.tsx"
```

## Parallel Example: User Story 3

```bash
# Launch the test and the two independent dialogs together:
Task: "Write unit test tests/unit/subscription.pauseEligibility.test.ts"
Task: "Create components/dashboard/PauseDialog.tsx"
Task: "Create components/dashboard/CancelDialog.tsx"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational (CRITICAL — blocks all stories)
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: `/dashboard` shows correct, live-refreshable subscription status, health,
   and next-delivery info for a real active subscription
5. Demo: open `/dashboard` as a seeded active-subscription customer, show status/next
   delivery/health

### Incremental Delivery

1. Setup + Foundational → foundation ready
2. Add US1 → validate → live status view (MVP!)
3. Add US2 → validate → demo (edit the box, watch price/next-delivery update live)
4. Add US3 → validate → demo (the phase's full headline scenario: pause → resume early → status/
   next-delivery correct)
5. Add US4 → validate → demo (order history + detail)
6. Add US5 → validate → demo (address/card/profile management from settings)
7. Phase 8 polish → full quickstart.md pass

### Parallel Team Strategy

With multiple developers, after Foundational completes:
- Developer A: US1, then US2 (shares `dashboardApi.ts`/`SubscriptionDashboard.tsx`)
- Developer B: US3 once US1's T013/T017 land (same shared-file dependency)
- Developer C: US4 and US5 in parallel — both are independent of US2/US3 and only need T008/T003

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- `resolveEffectiveConfig.ts` and `mutateSubscription.ts` are Foundational because both US1 (read)
  and US2/US3 (write) depend on them; `subscriptionHealth.ts` and `pauseEligibility.ts` are scoped
  to US1/US3 respectively since only one story's Route Handler ever calls each
- US4 and US5 deliberately have no `/api/orders*`/`/api/payments/history` Route Handler tasks —
  per contracts/orders-api.md and contracts/settings-api.md, those reads happen directly in their
  Server Component pages (Constitution Principle I), consistent with
  `app/subscription/confirmed/[id]/page.tsx`'s existing pattern from Phase 5
- Commit after each task or logical group
- Stop at any checkpoint to validate a story independently
- Avoid: vague tasks, same-file conflicts, cross-story dependencies that break independence
