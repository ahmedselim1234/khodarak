# Contract: Settings-page APIs — payment methods, payment history, profile

Covers User Story 5. Address CRUD is **not** repeated here — `/dashboard/settings` reuses the
existing `GET/POST/PATCH/DELETE /api/addresses[/​[id]]` Route Handlers from Phase 1 (same
`AddressBook`/`AddressForm` components, same contracts already documented in
`specs/002-phase-1-auth-address/contracts/`), with **one amendment**: `DELETE
/api/addresses/[id]` gains a pre-check this phase adds — since Phase 1 predates subscriptions
existing at all, its original contract couldn't have anticipated an address being "in use." Before
deleting, the handler now checks `exists (select 1 from subscriptions where address_id = $id or
pending_address_id = $id) and status != 'cancelled'`; if true, it returns `409
{ "error": "address_in_use" }` instead of deleting (FR-019) — the address CRUD's owner-scoped RLS
`DELETE` policy from Phase 1 is otherwise unchanged, this is an app-layer guard added in front of
it, since "is this address load-bearing for an active subscription" isn't something RLS's row-level
model expresses on its own.

## `POST /api/payment-methods`

Replaces the caller's saved card (FR-020/FR-021). Requires an authenticated session.

**Request**:
```json
{ "moyasarPaymentId": "pay_xxx" }
```
`moyasarPaymentId` is the id from the `$0` `save_only` payment `CardTokenizationForm`'s
`on_completed` callback returns — never raw card fields (Constitution Principle V). Validated by
`lib/validation/paymentMethodReplace.ts`.

**Behavior**:
1. Call `moyasarClient.fetchPayment(moyasarPaymentId)` — the same function Phase 5's callback
   route already uses — to authoritatively read `source.company`, `source.number` (masked),
   `source.month`, `source.year`, and the reusable `source.token` (research.md §5). `502
   { "error": "provider_error" }` if the call itself fails.
2. `422 { "error": "token_not_reusable" }` if the fetched payment has no `source.token` (e.g. the
   client somehow posted a non-`save_only` payment id).
3. Via `mutateSubscription.ts`'s service-role client (payment_methods writes stay on that same
   trusted path, even though this isn't a `subscriptions` write — no owner-scoped
   `INSERT`/`UPDATE` policy exists on `payment_methods` per Phase 5's migration): set the caller's
   existing `is_default = true` row (if any) to `is_default = false, status = 'removed'`, then
   insert the new row (`brand`, `last_four`, `exp_month`, `exp_year`, `is_default = true`,
   `status = 'active'`).

**Response — success**:
```json
{ "id": "uuid", "brand": "visa", "lastFour": "4242", "expMonth": 12, "expYear": 2029 }
```

**Response — provider error**: `502 { "error": "provider_error" }`.

**Response — token not reusable**: `422 { "error": "token_not_reusable" }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": {...} }`.

**Response — unauthenticated**: `401 { "error": "unauthenticated" }`.

---

## Payment history read (`PaymentHistoryList`)

Read-only, no mutation — same reasoning as `contracts/orders-api.md`: `/dashboard/settings`
(Server Component) queries `payments` directly (`select id, created_at, amount_halalas, status,
failure_reason from payments where user_id = auth.uid() order by created_at desc`) using the
per-request RLS client and passes the rows to `PaymentHistoryList`. No `/api/payments/history`
Route Handler exists in this phase — the existing owner-scoped `payments_select_own` RLS policy
from Phase 5 is what actually authorizes the read (FR-022).

---

## `PATCH /api/profile`

**Request**:
```json
{ "fullName": "أحمد محمد", "phone": "+966501234567" }
```
Validated by `lib/validation/profileUpdate.ts` — reuses the same KSA phone-format rule Phase 1's
signup validation already established.

**Behavior**: `update profiles set full_name = ..., phone = ... where id = auth.uid()` via the
existing per-request RLS client — `profiles_update_own` (Phase 1) already permits this, and
`profiles_role_immutable`'s trigger means even a maliciously-crafted body containing `role` would
be silently ignored at the database level rather than needing app-layer stripping (FR-023).

**Response — success**: `200 { "fullName": "أحمد محمد", "phone": "+966501234567" }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": {...} }`.

**Response — unauthenticated**: `401 { "error": "unauthenticated" }`.

## Notes

- `/dashboard/settings` itself is a Server Component (`SavedCardSummary`, `PaymentHistoryList`,
  and the address list all render from data it fetches directly, same pattern as
  `orders-api.md`). `ReplaceCardDialog` and `ProfileForm` are the only `"use client"` pieces on
  this page; each calls `router.refresh()` after a successful `POST`/`PATCH` so the
  server-rendered summary above it re-fetches the new value, rather than each owning its own RTK
  Query cache slice for a value that only ever changes from that one dialog.
