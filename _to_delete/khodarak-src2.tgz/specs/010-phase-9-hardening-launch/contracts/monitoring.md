# Contract: Monitoring surfaces (errors, uptime, dunning rate)

Not new endpoints for the first two — both reuse existing infrastructure (research.md §4). The
third is a small, documented extension to an existing admin view.

## Errors (FR-010)

**Mechanism**: the production container's stdout/stderr (every existing structured log line —
`console.error`/`console.log` calls already following this project's own convention of including
`subscription id`, `order id`, `cycle number`, etc. where relevant) is captured by the hosting
platform's own log retention (Docker's own logging driver, viewable via `docker compose logs` on
the host, or forwarded to a minimal external log-drain service if the host's own retention is too
short to be useful).

**What the audit (User Story 1) verifies**: every Route Handler and background job
(`app/api/cron/renewals/route.ts`, `app/api/webhooks/moyasar/route.ts`) that catches and handles
an error still logs enough context to identify the affected route/request before returning its
own response — not merely swallowing the error silently.

## Uptime (FR-011, 5-minute SLA per the clarification session)

**Mechanism**: an external, free-tier uptime-checking service configured to poll
`GET /api/health` (Phase 0, unchanged) every 1–5 minutes, alerting the team (email/SMS/webhook,
whichever the chosen service offers) on a non-`200` response or a request timeout.

**Why `/api/health` is sufficient as the check target**: it already verifies the application
process is up *and* that its Supabase dependency is reachable (its own existing implementation) —
a single check that would catch both "the container crashed" and "the container is up but can't
actually serve real traffic," without needing a second, more elaborate check built for this phase.

## Dunning rate (FR-012)

**Mechanism**: `components/admin/counters/CountersOverview.tsx` (Phase 8) gains a fourth counter
— "الاشتراكات الموقوفة تلقائياً هذا الأسبوع" (subscriptions auto-suspended this week) — computed
via the query in `data-model.md`'s own `subscription_pauses` section, displayed identically to
Phase 8's existing three counters (same card style, same "computed fresh on every request, no
caching" rule Phase 8 already established for the other three).

**Why this satisfies "aggregate... not only inside each individual customer's own record"**: an
operator viewing one subscription's own detail page (Phase 8) already sees whether *that*
subscription was auto-suspended; this counter is what lets the same operator notice a *rising
trend* across every customer at a glance, which is the specific signal FR-012 names.

## Notes

- None of these three add a new database table, a new Route Handler, or a new customer-facing
  surface — consistent with `data-model.md`'s own framing that this phase adds no schema.
- The specific external uptime-checking *service* used is a configuration choice made at
  deployment time (an account with whichever free-tier provider the team picks), not something
  this contract or the application's own code needs to name — only that it polls `/api/health` on
  the documented interval and alerts on failure.
