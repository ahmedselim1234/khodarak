# Phase 1 Design: Data Model — Phase 2 — Catalog + Admin Product CRUD

Two new tables. `products` matches `plan.md` §2's target schema exactly; `cart_items` is new,
added per the feature spec's 2026-08-10 Clarifications (server-synced cart) — see
[research.md](./research.md) §1 for why it's a single table with no `carts` parent.

## `products`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `name_ar` | `text`, not null | Arabic product name |
| `category` | `text`, not null, check in `('vegetables', 'fruits')` | Backs the خضروات/فواكه tabs (FR-006) |
| `price` | `numeric(10,2)`, not null, check `> 0` | SAR; the pricing engine (Phase 3) reads this as the base unit price |
| `unit` | `text`, not null, check in `('kg', 'piece')` | كجم / حبة per `plan.md` §2 |
| `image_url` | `text`, not null | Public URL in the `product-images` Storage bucket; NOT NULL enforces FR-001's "photo required" rule at the data layer, not just in the form |
| `is_available` | `boolean`, not null, default `true` | FR-004 |
| `min_qty` | `integer`, not null, default `1`, check `>= 1` | FR-012 lower clamp bound |
| `max_qty` | `integer`, not null, check `>= min_qty` | FR-012 upper clamp bound |
| `sort_order` | `integer`, not null, default `0` | Default catalog ordering (research.md / spec Assumptions) |
| `created_at` | `timestamptz`, not null, default `now()` | |
| `updated_at` | `timestamptz`, not null, default `now()` | Bumped on every admin edit (trigger or app-level `set updated_at = now()`) |

**Validation rules** (enforced in `lib/validation/product.ts` with zod, mirrored by the `check`
constraints above so an invalid row can't reach the table even from a bug elsewhere):
- `price > 0`
- `min_qty >= 1` and `max_qty >= min_qty`
- `category` and `unit` are closed enums, not free text
- `image_url` must be non-empty and point into the `product-images` bucket (checked in the Route
  Handler, since a `check` constraint can't easily validate bucket membership)

**RLS**: public-read (`select` for everyone, including anonymous — the storefront must render for
signed-out visitors browsing `/browse`), admin-write (`insert`/`update`/`delete` gated on the
caller's `profiles.role = 'admin'`, same role-lookup pattern the existing
`profiles_role_immutable` migrations already established for `profiles`).

**Lifecycle**: no soft-delete — FR-003 says a removed product simply stops appearing in the
customer catalog; a hard `delete` is sufficient since `order_items`/`subscription_items` (later
phases) snapshot `product_name_snapshot`/`unit_price_snapshot` rather than holding a live FK
dependency back to `products` for historical display, per `plan.md` §2's "orders and order_items
store snapshots" rule.

## `cart_items`

| Column | Type | Notes |
|---|---|---|
| `id` | `uuid`, PK, default `gen_random_uuid()` | |
| `user_id` | `uuid`, not null, FK → `auth.users(id)` on delete cascade | Owner |
| `product_id` | `uuid`, not null, FK → `products(id)` on delete cascade | FR-012's "product deleted → removed from cart" falls out of the FK cascade for free |
| `quantity` | `integer`, not null, check `>= 1` | Row is deleted, not zeroed, when quantity would reach 0 (FR-012) |
| `created_at` | `timestamptz`, not null, default `now()` | |
| `updated_at` | `timestamptz`, not null, default `now()` | Bumped on every quantity change |

**Constraints**: `unique (user_id, product_id)` — one row per product per customer, upserted by
quantity changes (matches how `addresses`' default-invariant work used a database-level constraint
rather than trusting application code alone, per Constitution Principle VI's "database-level, not
just app-level" precedent from Phase 1).

**RLS**: owner-only — `select`/`insert`/`update`/`delete` all scoped to `user_id = auth.uid()`. No
admin access is needed this phase (admins don't manage customer carts).

**Lifecycle**: a row is created on first `PUT /api/cart/items/[productId]` with quantity ≥ 1,
updated on subsequent quantity changes, and deleted when quantity is clamped down to 0 or the
referenced product is deleted (FK cascade). Guest cart entries never touch this table — they exist
only as `cartSlice` state mirrored to `localStorage` until `POST /api/cart/merge` folds them in at
login (FR-015), after which the guest-side state is cleared.

## Client-side: guest cart (not a database table)

`lib/cart/cartSlice.ts` holds, per product id: `{ quantity, name, price, unit, imageUrl, maxQty }`
— a denormalized snapshot captured at add/update time (see research.md §4 for why this is
acceptable pre-pricing-engine). Hydrated from and synced to a single `localStorage` key by
`StoreProvider` on mount; cleared after a successful `/api/cart/merge` call at login.

## Storage: `product-images` bucket

Not a Postgres table, but part of this phase's data model. Public-read (product photos need to
render for signed-out visitors), write restricted to `admin`-role users via a Storage RLS policy
keyed off `auth.jwt()` → `profiles.role`, the same role source the `products` table's write policy
and the existing `/admin` middleware gate already use.

## Entity relationships

```
auth.users (Supabase-managed)
  └─< cart_items >─ products
                        △
                        │ image_url points into
                 product-images (storage bucket)
```

`cart_items` and `products` are the only two entities this phase adds; both existing entities from
Phase 1 (`profiles`, `addresses`, `cities`) are unchanged.
