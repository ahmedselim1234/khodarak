# Feature Specification: Phase 6 — Customer Dashboard

**Feature Branch**: `007-phase-6-customer-dashboard`

**Created**: 2026-08-11

**Status**: Draft

**Input**: User description: "read plan.md and create a specification for the Phase 6" — scoped from `plan.md` §4 "Phase 6 — Customer Dashboard": `/dashboard` per `design/dashboard.html` (side nav + bento layout: next delivery card, calendar view, subscription health, tips, support) — subscription status card, next delivery + next charge amount, edit items/quantities with re-pricing, change frequency, pause/resume/cancel with rule enforcement, edit cutoff window; `/dashboard/orders` per `design/my-orders.html` — order history + detail; `/dashboard/settings` per `design/settings.html` — address management, saved card display + update card, payment history, profile. Demo target: "pause a subscription, resume it, edit the box, and show the next delivery date and next charge recalculating correctly."

## Clarifications

### Session 2026-08-11

- Q: When a customer edits their box (items/quantities) or changes frequency from the dashboard, does the change apply starting with the very next delivery, or only from the delivery after next? → A: Applies to the next delivery, provided the edit is made before that delivery's edit cutoff window (the same `edit_cutoff_hours` rule from `plan.md` §3); if the cutoff has already passed for the upcoming delivery, the change is saved but only takes effect from the delivery after that.
- Q: When a customer cancels an active subscription, is any confirmation or reason capture required, and can a cancelled subscription be reactivated later, or must the customer build a new one? → A: Require a simple confirm step (no reason capture) before cancelling; a cancelled subscription cannot be reactivated — the customer would need to build a new subscription from `/subscription` if they want to resume service.
- Q: Does "subscription health" (shown on the dashboard bento layout) reflect a real computed signal, or is it a simple, deterministic status indicator for this phase? → A: A simple, deterministic indicator this phase — derived only from the subscription's own state already defined elsewhere in the plan (active/paused/cancelled, any consecutive failed-payment count once Phase 7 exists, upcoming edit-cutoff proximity) rather than any new scoring model; presented as a small set of plain states (e.g. good / needs attention) rather than a numeric score.
- Q: When a customer pauses or cancels their subscription during the edit-cutoff window, does that already-locked next delivery still go out and get charged, or does pause/cancel immediately stop it too? → A: Pause/cancel immediately overrides the lock — the locked next delivery is stopped too, no matter how close it is to the cutoff; unlike item/frequency/address edits, pause and cancel are not deferred to the delivery after next.
- Q: When the admin's "max pauses per year" limit is checked, does "per year" mean a rolling 365-day window or a fixed calendar year? → A: A rolling 365-day window counted back from today — a pause older than 365 days no longer counts against the limit, and eligibility restores gradually rather than resetting all at once on a fixed date.
- Q: When a customer's item/frequency/address edit is deferred past the locked next delivery, how does the system know what that locked delivery should still contain, given no order exists for it yet? → A: The subscription keeps its current items/frequency/address unchanged (used as-is for the locked next delivery); the customer's deferred edit is stored separately as a pending version that automatically replaces the current one once the locked delivery has passed — no proactive snapshot is taken at the moment the cutoff window opens.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - See subscription status and what's coming next (Priority: P1)

A customer with an active subscription opens `/dashboard` and immediately sees whether their subscription is active, paused, or cancelled, when their next delivery is scheduled, what's in it, and what they'll be charged for it.

**Why this priority**: This is the reason a customer returns to the dashboard at all — it's the first thing they see, it's read-only (no risk of accidental changes), and every other capability in this phase is reached from this screen. Without it, nothing else in the phase has a home.

**Independent Test**: Can be fully tested by logging in as a customer with an existing active subscription (created in Phase 4/5) and confirming the dashboard shows the correct status, next delivery date, next order contents, and next charge amount, sourced from that subscription's real data — delivers a complete, verifiable read-only view independent of any edit capability.

**Acceptance Scenarios**:

1. **Given** a customer with an active subscription, **When** they open `/dashboard`, **Then** they see a status card showing "active," the next delivery date, the items and quantities that will be in that delivery, and the amount that will be charged for it.
2. **Given** a customer with a paused subscription, **When** they open `/dashboard`, **Then** they see a status card showing "paused" along with the date it will resume, and no upcoming delivery is presented as scheduled.
3. **Given** a customer with a cancelled subscription, **When** they open `/dashboard`, **Then** they see a status card showing "cancelled" and are guided toward starting a new subscription rather than shown stale delivery information.
4. **Given** a customer who has never completed a subscription, **When** they open `/dashboard`, **Then** they see an empty/first-time state that directs them to `/subscription` rather than a broken or blank page.
5. **Given** a signed-in customer, **When** they attempt to view another customer's dashboard data by any means, **Then** they are denied and only ever see their own subscription, orders, and account information.

---

### User Story 2 - Edit the box and change frequency, with live re-pricing (Priority: P1)

A customer with an active subscription changes the items/quantities in their box or switches how often it arrives, sees the price update live using the same pricing rules used at signup, and saves a change that will actually be reflected in their next eligible delivery.

**Why this priority**: This is the dashboard's core ongoing value beyond viewing — a subscription customers can never adjust after signup is a worse product than one-off ordering. It's tied with User Story 1 for top priority because it's the phase's stated demo centerpiece ("edit the box... show the next delivery date and next charge amount recalculating correctly").

**Independent Test**: Can be fully tested by opening an active subscription's edit view, changing a quantity or swapping the frequency, observing the price breakdown update before saving, saving the change, and confirming the next delivery date/next charge now reflect it — delivers a complete, verifiable edit-and-reprice loop independent of pause/cancel/address changes.

**Acceptance Scenarios**:

1. **Given** a customer editing their active subscription's items, **When** they change a quantity or add/remove a product, **Then** the price breakdown (subtotal, discount, delivery fee, VAT, total) recalculates immediately using the same server-side pricing rules as subscription creation, before anything is saved.
2. **Given** a customer changes their delivery frequency, **When** the change is made, **Then** the price breakdown and the projected next delivery date both update to reflect the new frequency's rules and discount.
3. **Given** a customer attempts to save an edit that would violate an admin-configured rule (minimum order value, per-product min/max quantity, or maximum items per box), **When** they try to save, **Then** the save is blocked with a specific, actionable message identifying which rule was violated.
4. **Given** a customer opens the edit view for their box, **When** the current time is within the admin-configured edit cutoff window before their next scheduled delivery, **Then** they are told the next delivery is locked and any change they save will instead be held as a pending change that takes effect starting with the delivery after that, while the current locked delivery's contents and price stay exactly as they already were.
5. **Given** a customer successfully saves an eligible edit outside the cutoff window, **When** the save completes, **Then** the dashboard's status card immediately reflects the new items/frequency and the updated next charge amount.
6. **Given** a customer has a pending change stored because their earlier edit was deferred, **When** they view their subscription before the locked delivery has passed, **Then** they can see both what the current locked delivery will contain and what will change starting after it; if they save another edit before then, it replaces the pending change rather than stacking a second one.

---

### User Story 3 - Pause, resume, and cancel (Priority: P1)

A customer temporarily pauses their subscription until a chosen resume date, resumes it early if they change their mind, or cancels it outright — each action respecting the admin-configured pause limits and requiring the customer to confirm the consequence before it happens.

**Why this priority**: Pause/resume/cancel is explicitly named in the phase's own demo target and is the second half of the "edit the box, pause it, resume it" story — without it, a subscription is a one-way commitment, which is a common reason customers abandon a service entirely rather than adjusting it.

**Independent Test**: Can be fully tested by pausing an active subscription with a resume date, confirming its status and next-delivery presentation update accordingly, resuming it early, and confirming it returns to active with a recalculated next delivery — delivers a complete, verifiable lifecycle-control loop independent of item/frequency edits.

**Acceptance Scenarios**:

1. **Given** a customer with an active subscription, **When** they choose to pause and select a resume date, **Then** the subscription's status becomes "paused" immediately — including stopping the next delivery even if it was already inside the edit cutoff window — no delivery is generated while paused, and the chosen resume date is shown back to them.
2. **Given** a customer attempts to pause beyond the admin-configured maximum pause duration, or beyond the admin-configured maximum number of pauses allowed in a year, **When** they try, **Then** the pause is blocked with a specific message explaining which limit was hit.
3. **Given** a customer with a paused subscription, **When** they choose to resume before their originally chosen resume date, **Then** the subscription becomes "active" again immediately and a new next delivery date is calculated from the resume moment.
4. **Given** a paused subscription's chosen resume date arrives, **When** that date passes, **Then** the subscription automatically becomes "active" again without requiring the customer to take any action.
5. **Given** a customer chooses to cancel their subscription, **When** they confirm the cancellation in an explicit confirm step, **Then** the subscription's status becomes "cancelled" immediately — including stopping the next delivery even if it was already inside the edit cutoff window — no further deliveries are scheduled, and the customer is told that reactivating means starting a new subscription rather than resuming this one.
6. **Given** a customer starts the cancel flow but does not confirm it, **When** they dismiss or back out, **Then** the subscription remains completely unchanged.

---

### User Story 4 - View order history and order detail (Priority: P2)

A customer opens `/dashboard/orders` and sees every delivery ever generated from their subscription — past, in progress, and upcoming — and can open any one of them to see exactly what was in it and what it cost.

**Why this priority**: Valuable for trust and support ("did I actually get charged for this?") but not required to demonstrate the phase's core loop (status, editing, pause/resume/cancel), so it ranks below those.

**Independent Test**: Can be fully tested by opening `/dashboard/orders` for a customer with at least one existing order (from Phase 5's first-order generation) and confirming the list and its detail view show that order's real snapshotted items and price — delivers a complete, verifiable read view independent of any subscription-editing capability.

**Acceptance Scenarios**:

1. **Given** a customer with one or more past orders, **When** they open `/dashboard/orders`, **Then** they see a list showing each order's date, status, and total.
2. **Given** a customer opens one order's detail, **When** the detail loads, **Then** it shows the exact items, quantities, and price breakdown that were snapshotted for that specific order at the time it was generated — never a value recalculated from current prices.
3. **Given** a customer with no orders yet, **When** they open `/dashboard/orders`, **Then** they see a clear empty state rather than a broken or blank page.
4. **Given** a customer attempts to view an order that belongs to someone else, **When** they try, **Then** they are denied.

---

### User Story 5 - Manage addresses, saved card, and profile from settings (Priority: P2)

A customer opens `/dashboard/settings` and can manage their delivery addresses (add, edit, delete, set default), see their saved card and start replacing it, review their past payment attempts, and update their profile name and phone number.

**Why this priority**: Necessary self-service functionality that rounds out the dashboard, but it largely surfaces and re-uses capability already built in earlier phases (address CRUD from Phase 1, card tokenization from Phase 5) rather than introducing new subscription logic, so it ranks below the subscription-management stories.

**Independent Test**: Can be fully tested by adding a new address, setting it default, confirming it's offered as the subscription's delivery address, starting a card replacement and completing it, and updating the profile name — delivers a complete, verifiable account-management view independent of subscription editing.

**Acceptance Scenarios**:

1. **Given** a customer on `/dashboard/settings`, **When** they add, edit, delete, or set-default an address, **Then** the change is reflected immediately and, when it's their default, becomes the address offered for their active subscription.
2. **Given** a customer attempts to delete the address currently assigned to their active subscription, **When** they try, **Then** they are blocked with a message explaining they must choose a different delivery address for the subscription first, or told to pick a replacement default in the same step.
3. **Given** a customer on `/dashboard/settings`, **When** they view the payment section, **Then** they see their currently saved card's brand and last four digits (never the full number), and an action to replace it that reuses the existing tokenization flow.
4. **Given** a customer replaces their saved card successfully, **When** the replacement completes, **Then** the new card becomes the one used for the subscription's future charges and the old one is no longer offered.
5. **Given** a customer on `/dashboard/settings`, **When** they view payment history, **Then** they see every past payment attempt for their account (successful and failed) with date, amount, and outcome.
6. **Given** a customer updates their profile name or phone number, **When** they save, **Then** the update is reflected immediately across the dashboard (e.g. any place displaying their name).

---

### Edge Cases

- What happens when a customer tries to edit their box, change frequency, or change address while a delivery is already locked inside the edit cutoff window? The change is stored as a pending change rather than rejected outright or applied to the locked delivery — the subscription's current (in-effect) items/frequency/address are left untouched for that locked delivery, and the pending version automatically becomes current once that delivery has passed.
- What happens if a customer saves a second deferred edit while an earlier pending change is still waiting to take effect? The new pending change replaces the earlier one entirely — pending changes never stack or merge.
- What happens when a customer pauses or cancels while a delivery is already locked inside the edit cutoff window? Unlike item/frequency/address edits, pause and cancel are never deferred — both take effect immediately and stop even an already-locked next delivery, since their purpose is to prevent an imminent unwanted charge.
- What happens when a customer's next delivery date falls on an admin-configured blackout day after a frequency change or resume? The system recalculates to the next valid, non-blackout date rather than presenting an invalid date.
- What happens when a customer resumes a paused subscription and the resulting next delivery date would land inside what would otherwise be an edit cutoff window? The resume still succeeds; the next delivery date is calculated normally from the resume moment, since resuming is not itself a same-delivery edit.
- What happens when an admin changes a product's price or availability while a customer is mid-edit on their box (before saving)? The customer's next save re-validates and re-prices against current data, and if a chosen product has since become unavailable, the save is blocked with a message identifying that product rather than silently substituting or removing it.
- What happens when a customer tries to pause a subscription that is already paused, or cancel one that is already cancelled? The action is rejected with a message reflecting the subscription's actual current state.
- What happens when a customer has no saved address at all (shouldn't normally occur once Phase 1's address-required rule is enforced) and opens the dashboard? They're guided to add an address before any subscription-editing action that requires one.
- What happens when a customer tries to open `/dashboard`, `/dashboard/orders`, or `/dashboard/settings` while signed out? They're redirected to sign in, consistent with the existing route-protection rule from Phase 1.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST show a signed-in customer their own subscription's current status (active, paused, or cancelled) on `/dashboard`, and MUST NOT show any other customer's subscription, order, or account data under any circumstance.
- **FR-002**: System MUST show, for an active subscription, the next scheduled delivery date, the items and quantities that delivery will contain, and the amount that will be charged for it.
- **FR-003**: System MUST show, for a paused subscription, its resume date and MUST NOT present any delivery as currently scheduled while paused.
- **FR-004**: System MUST show, for a cancelled subscription, its cancelled state and direct the customer toward starting a new subscription rather than displaying stale active-subscription data.
- **FR-005**: System MUST show a first-time/empty state directing the customer to `/subscription` when they have never completed a subscription.
- **FR-006**: System MUST let a customer edit their active subscription's items and quantities, recalculating the full price breakdown through the same server-side pricing engine used at subscription creation on every change, before any save is committed.
- **FR-007**: System MUST let a customer change their active subscription's delivery frequency to any option currently enabled in admin settings, recalculating both price and next delivery date accordingly.
- **FR-008**: System MUST validate every subscription edit against the current admin-configured order rules (minimum order value, per-product minimum/maximum quantity, maximum items per box) before saving, and MUST block a save that violates any of them with a message identifying which rule was violated.
- **FR-009**: System MUST enforce the admin-configured edit cutoff window: an item/frequency/address edit made after that window has begun for the next scheduled delivery MUST NOT alter that upcoming (locked) delivery's contents, address, or price. Such an edit MUST instead be stored as a pending change that automatically replaces the subscription's current items/frequency/address once the locked delivery has passed, without requiring further customer action; a customer saving another edit before then MUST replace the existing pending change rather than accumulate multiple pending changes.
- **FR-010**: System MUST let a customer pause their active subscription with a chosen resume date, during which no delivery is generated — this MUST take effect immediately and MUST stop even a next delivery that is already inside the edit cutoff window, unlike item/frequency/address edits.
- **FR-011**: System MUST enforce the admin-configured maximum pause duration and maximum number of pauses per year — counted as a rolling 365-day window back from the current date, not a fixed calendar year — blocking a pause request that would exceed either with a message identifying which limit was hit.
- **FR-012**: System MUST let a customer resume a paused subscription at any time before its chosen resume date, recalculating the next delivery date from the moment of resume.
- **FR-013**: System MUST automatically transition a paused subscription back to active once its chosen resume date passes, without requiring customer action.
- **FR-014**: System MUST let a customer cancel their active or paused subscription only after an explicit confirmation step, after which no further deliveries are scheduled — this MUST take effect immediately and MUST stop even a next delivery that is already inside the edit cutoff window — and the subscription cannot be reactivated; starting service again requires creating a new subscription.
- **FR-015**: System MUST let a customer change the delivery address on their active subscription to any address from their own saved addresses, respecting the same edit cutoff rule (and pending-change deferral behavior per FR-009) as item/frequency edits.
- **FR-016**: System MUST show a customer a list of every order ever generated from their own subscription, each with its date, status, and total.
- **FR-017**: System MUST show a customer an order's exact snapshotted items, quantities, and price breakdown as they were recorded at that order's generation — never a value recalculated from current product prices or settings.
- **FR-018**: System MUST let a customer add, edit, delete, and set-default a delivery address from `/dashboard/settings`, reusing the same address rules established in Phase 1.
- **FR-019**: System MUST block deletion of an address currently assigned as a subscription's delivery address until the customer assigns a different address to that subscription.
- **FR-020**: System MUST show a customer their currently saved card's brand and last four digits only (never the full card number or security code) and MUST let them replace it using the existing card-tokenization flow.
- **FR-021**: System MUST use a customer's most recently saved card for all of that customer's future charges once a card replacement completes, and MUST stop offering the previously saved card.
- **FR-022**: System MUST show a customer a history of their own past payment attempts (successful and failed) with date, amount, and outcome.
- **FR-023**: System MUST let a customer update their own profile name and phone number, reflecting the change immediately everywhere it's displayed.
- **FR-024**: System MUST present a simple, deterministic subscription "health" indicator derived only from existing subscription state (current status, any consecutive failed-payment count, and proximity to the edit cutoff window) rather than introducing a new scoring or analytics model.
- **FR-025**: System MUST redirect a signed-out visitor attempting to reach `/dashboard`, `/dashboard/orders`, or `/dashboard/settings` to sign in, consistent with existing route protection.

### Key Entities

- **Subscription** *(existing, extended by this phase's actions)*: A customer's recurring box — status (active/paused/cancelled), current items and quantities, frequency, delivery address, next delivery date, resume date (when paused), and price breakdown. This phase adds customer-driven transitions between its states; a pending items/frequency/address change (and the delivery cycle it becomes effective from) that stays separate from the current, in-effect configuration until the locked next delivery has passed; and a timestamped history of past pauses (start date, resume date) so the rolling 365-day pause-limit count can be derived rather than relying on a resettable counter.
- **Order** *(existing, read-only in this phase)*: One generated delivery from a subscription, carrying its own snapshotted items, quantities, price breakdown, address, and status — never altered by later edits to the subscription or product catalog.
- **Address** *(existing, managed in this phase)*: A customer's saved delivery location, with a default flag; this phase adds full customer-facing CRUD and default-selection surfaced through settings.
- **Payment Method** *(existing, read/replace in this phase)*: A customer's saved card reference (brand, last four, expiry, status) as established in Phase 5; this phase surfaces it for display and initiates its replacement.
- **Payment** *(existing, read-only in this phase)*: A record of a past charge attempt (amount, outcome, date) as established in Phase 5; this phase surfaces it as a customer-facing history list.
- **Profile** *(existing, editable in this phase)*: A customer's name and phone number, editable from settings.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A customer can determine their subscription's current status, next delivery date, and next charge amount within seconds of opening `/dashboard`, without needing to contact support.
- **SC-002**: 100% of subscription edits (items, quantity, frequency) that are saved reflect the identical price breakdown the server's pricing engine would independently compute for the same inputs — no discrepancy between what's shown live and what's saved.
- **SC-003**: 100% of edits attempted within the admin-configured edit cutoff window for the next delivery are prevented from altering that delivery, and instead correctly apply from the delivery after it.
- **SC-004**: 100% of pause requests that would exceed the admin-configured pause-duration or pauses-per-year limits are blocked before taking effect.
- **SC-005**: A customer can pause, resume, and observe their subscription's next delivery date and charge amount update correctly, in a single dashboard session, without needing to reload or contact support.
- **SC-006**: 100% of order-detail views show the order's originally snapshotted items and price, unaffected by any later product price change or subscription edit.
- **SC-007**: A customer can complete an address change, a card replacement, or a profile update from settings without leaving `/dashboard/settings`.
- **SC-008**: 0% of dashboard, order, or settings data is ever visible to a customer other than its owner.

## Assumptions

- This phase covers only customer self-service management of a subscription that already exists in an active or paused state (created via Phases 4–5); building a brand-new subscription remains the job of `/subscription`, unchanged by this phase.
- The renewal/charge-generation engine (turning an upcoming delivery into an actual new order and charge on its scheduled date) is Phase 7's job; this phase only lets the customer view what the next delivery *will* contain and cost, and edit the subscription that drives it — it does not itself generate or charge for any order.
- "Consecutive failed-payment count" referenced by the health indicator (FR-024) is read from whatever payment-history data already exists at the time this phase ships; if Phase 7's dunning/retry tracking doesn't exist yet, the indicator simply treats that signal as zero rather than this phase inventing its own retry-tracking mechanism.
- Per the clarification above, deferred edits (an item/frequency/address change saved after the edit cutoff has begun) are stored as pending fields on the subscription itself (a pending items/frequency/address plus the cycle they become effective from) rather than a separate "scheduled change" entity or a proactively generated snapshot; the currently in-effect fields are left untouched until the locked delivery has passed, at which point the pending values are promoted to current and cleared. Something (this phase's own logic or a scheduled check) needs to perform that promotion once the locked delivery's date passes — the mechanism for detecting "has passed" is a planning-level detail, not constrained further here.
- Per the clarification above, pause and cancel are never deferred by the edit cutoff — both take effect immediately, including stopping an already-locked next delivery, which is a deliberate exception to the general edit-cutoff deferral behavior described above.
- Cancellation is permanent within this phase's scope per the clarification above; no "reactivate a cancelled subscription" capability is built here or implied elsewhere in `plan.md`.
- The bento-layout elements from `design/dashboard.html` that are purely presentational/informational (tips, support links, calendar view of the next delivery) are included as the phase's UI surface but introduce no new data model or business rule beyond what's already listed above.
- Admin-side management of subscriptions, orders, and payments (viewing/altering *other* customers' data) is explicitly out of scope — that's Phase 8's "Admin Operations" per `plan.md`.
