# Contract: `/api/admin/settings`

Route Handlers backing the admin settings screen (spec User Story 1). Every request MUST be an
authenticated `admin`-role session (enforced by `middleware.ts`'s existing `/admin` gate at the
route level for the *page*, and re-checked server-side in this handler since `/api/admin/settings`
is not itself under the `/admin` path prefix — same pattern as `/api/admin/products` from Phase 2).
Every request body is validated with the zod schema in `lib/validation/settings.ts` before
touching the database.

## `GET /api/admin/settings`

Returns the current (singleton) settings row.

**Request**: no body, no query params.

**Response — success**:
```
200 OK
Content-Type: application/json

{
  "settings": {
    "frequencies": {
      "weekly":   { "enabled": true, "discountPercent": 5,  "deliveriesPerMonth": 4 },
      "biweekly": { "enabled": true, "discountPercent": 8,  "deliveriesPerMonth": 2 },
      "monthly":  { "enabled": true, "discountPercent": 12, "deliveriesPerMonth": 1 }
    },
    "minOrderValue": 50,
    "maxItemsPerBox": 20,
    "editCutoffHours": 24,
    "firstDeliveryLeadDays": 2,
    "blackoutWeekdays": [5],
    "deliveryMode": "flat",
    "deliveryFlatFee": 10,
    "deliveryFreeThreshold": 150,
    "maxPauseDays": 30,
    "maxPausesPerYear": 4,
    "vatPercent": 15,
    "pricesIncludeVat": true,
    "roundingMode": "nearest_0.5",
    "updatedAt": "2026-08-10T12:00:00Z"
  }
}
```

**Response — unauthorized (not admin)**: `403 Forbidden`. **Unauthenticated**: `401 Unauthorized`.

---

## `PATCH /api/admin/settings`

Updates any subset of settings fields (FR-001 through FR-006).

**Request** (all fields optional; at least one MUST be present):
```json
{
  "frequencies": {
    "weekly": { "enabled": true, "discountPercent": 15, "deliveriesPerMonth": 4 }
  }
}
```

A partial `frequencies` update replaces only the named frequency key(s) within the JSON object —
omitted frequency keys keep their previously saved values, not a merge at the field level within a
single frequency (each frequency object is replaced as a whole when included).

Validation (FR-008): every numeric field checked against the same range the database's `check`
constraints enforce (see [data-model.md](../data-model.md)) — e.g. `discountPercent` `0`–`100`,
`vatPercent` `0`–`100`, all currency/day/hour counts `>= 0`, `deliveryMode` and `roundingMode`
restricted to their enum values, `blackoutWeekdays` entries `0`–`6`.

**Response — success**: `200 OK`, same shape as `GET`'s response, reflecting the merged, updated
row.

**Response — validation error**:
```
400 Bad Request

{ "error": "validation_failed", "fields": { "vatPercent": "must be between 0 and 100" } }
```

**Response — unauthorized (not admin)**: `403 Forbidden`. **Unauthenticated**: `401 Unauthorized`.

## Notes

- There is no `POST` or `DELETE` — the settings row is seeded once by migration and only ever
  edited in place (data-model.md Lifecycle).
- RLS (`insert`/`update`/`delete` gated on `profiles.role = 'admin'`) is the authorization boundary
  beneath this handler's own role check, matching the `products-admin-api.md` precedent from
  Phase 2 (Constitution Principle V).
