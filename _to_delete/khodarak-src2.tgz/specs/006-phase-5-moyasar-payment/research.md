# Phase 0 Research: Phase 5 — Moyasar Integration & First Payment

No `NEEDS CLARIFICATION` markers remain in the Technical Context — the feature spec's own
2026-08-10 Clarifications session already resolved the two decisions that would otherwise have
landed here (saved-card reuse, retry throttling). This document records the remaining
design-level decisions made while turning that spec into an implementable plan.

## 1. Why does financial-state writing require a service-role client, not RLS?

**Decision**: `subscriptions.status`/`started_at`, `payment_methods`, `payments`,
`orders`/`order_items` are never written by the customer's own RLS-scoped session — only by
`lib/payments/processPaymentOutcome.ts`, using a new service-role Supabase client
(`lib/supabase/serviceRole.ts`). No `authenticated`-role `INSERT`/`UPDATE` policy is granted on
any of these tables.

**Rationale**: This project already has a concrete precedent for why an owner-scoped RLS
`UPDATE` policy on a sensitive column is dangerous:
`supabase/migrations/20260810120300_profiles_role_immutable.sql` exists because
`profiles_update_own` (an ordinary "customers edit their own row" policy) let a signed-in customer
`PATCH` their own `role` straight to `'admin'` via the REST API — RLS restricts *rows*, not
*columns*, so "you can update your own profile" quietly also meant "you can update your own role."
The equivalent mistake here — "you can update your own subscription" implicitly meaning "you can
set your own subscription's status to `active` without ever paying" — would be a direct revenue
bypass, not just a role bug. Closing it with a second migration (an immutability trigger, as
`profiles` did) is possible but strictly worse than never opening it: a service-role client that
only ever runs from one trusted, server-only module is a narrower, harder-to-misuse boundary than
"any RLS policy plus a trigger to patch the part of it that shouldn't have existed." The webhook
path makes this doubly necessary regardless of preference — it has no user session at all, so an
RLS-scoped client isn't even available there; the callback path uses the same service-role path
for consistency, so the activation logic behaves identically no matter which route calls it.

**Alternatives considered**:
- An owner-scoped `UPDATE` policy on `subscriptions` restricted to non-`status` columns via a
  trigger (mirroring `profiles_role_immutable.sql` exactly) — rejected; it reopens the same shape
  of risk this research decision exists to avoid, for tables where the value at stake is money, not
  just a role flag, and it would still leave the webhook path needing a separate solution anyway.
- A Postgres function (`SECURITY DEFINER`) callable via `.rpc()` for just the activation
  transaction — reconsidered from Phase 4's research.md §3 (which rejected RPC transactions for a
  low-stakes, no-money-yet operation) but still rejected here: it would solve atomicity but not the
  RLS-write-boundary problem this decision is actually about, and the service-role client already
  gives the Route Handler a single Postgres statement's worth of atomicity per write without new
  infrastructure.

## 2. Why are both `payments.order_id` and `payments.subscription_id` nullable?

**Decision**: `payments` has both columns, both nullable. A payment attempt row is created with
`subscription_id` set and `order_id` null at charge-initiation time; `order_id` is filled in by
`processPaymentOutcome.ts` once the resulting order is generated on success.

**Rationale**: `plan.md` §2's original sketch shows `payments.order_id` without marking it
nullable, but `plan.md` §3b's own renewal description is explicit that "the order [is generated]
only on successful payment" — meaning at the moment any charge is *attempted*, first payment or
renewal alike, no order exists yet for it to reference. A payment attempt still needs to be
recorded before its outcome is known (so the callback/webhook has a row to find by
`moyasar_payment_id`), so the FK it can reliably point to at creation time is the subscription,
not an order that doesn't exist yet.

**Alternatives considered**:
- Defer creating the `payments` row until the outcome is known — rejected; it would leave nothing
  for the callback or webhook to look up by `moyasar_payment_id` if they arrive first (a real
  possibility — Moyasar's webhook can fire before the customer's browser finishes redirecting
  back), which is exactly the race this phase's idempotency requirements are designed around.
- Make `order_id` non-nullable and generate a placeholder/draft order before charging — rejected;
  it would mean a draft order exists for every failed/declined attempt too, contradicting FR-009's
  "order is generated upon activation" and creating cleanup work for every decline.

## 3. How is outcome processing made idempotent without a database transaction?

**Decision**: `processPaymentOutcome.ts` performs a single conditional update as its first write:
`UPDATE payments SET status = $1, ... WHERE id = $2 AND status NOT IN ('paid', 'failed') RETURNING
id`. If it returns no row, the payment was already terminally processed by an earlier call (the
callback, an earlier webhook delivery, or a concurrent one) and the function returns immediately
without touching `subscriptions`/`payment_methods`/`orders` at all. Only when the conditional
update *does* return a row does the function proceed to activation (or leave the failure recorded
and stop).

**Rationale**: Extends Phase 4's research.md §3 precedent (no Postgres RPC transaction
infrastructure in this project yet; sequential calls plus a targeted safety mechanism instead) with
the specific technique this phase's two-entry-point race requires. A plain `SELECT` then `UPDATE`
would have a race window between the two independent processes (the callback executing because the
customer's redirect completed at the same moment the webhook is processing the same event);
folding the "is this already done" check into the `WHERE` clause of the write itself closes that
window using Postgres's own row-level locking during the update, without needing an explicit
transaction block or advisory lock.

**Alternatives considered**:
- A unique constraint on `payments.moyasar_payment_id` plus catching the conflict — this still
  matters and is included (data-model.md), but it only prevents *creating a second row* for the
  same payment; it doesn't by itself prevent two processes from both successfully reading the one
  existing row as "not yet processed" and both proceeding to activate. The conditional update
  closes that specific gap the unique constraint alone doesn't.
- A Postgres advisory lock keyed on the payment id for the duration of processing — rejected as
  more moving parts than the conditional-update technique for the same guarantee, and less
  obviously correct to a future reader than a `WHERE status NOT IN (...)` clause sitting right next
  to the write it's guarding.

## 4. How is the incoming webhook's authenticity verified?

**Decision**: `lib/payments/verifyWebhookSignature.ts` compares a secret token Moyasar sends in a
request header against `serverEnv.MOYASAR_WEBHOOK_SECRET` (configured to match the secret token
set on the Moyasar dashboard's webhook configuration), using a constant-time string comparison. A
request that fails this check is rejected before its body is parsed or trusted in any way.

**Rationale**: Matches `plan.md` §3b's explicit instruction ("webhooks are the source of truth...
verify the signature") and the project's existing security posture of validating every external
boundary (Constitution Principle IV) — a webhook endpoint is the one Route Handler in this project
reachable by a party we don't control, so proving the request actually came from Moyasar has to
happen before anything else. Constant-time comparison avoids a timing side-channel on the secret
comparison itself, standard practice for any secret-token check.

**Alternatives considered**:
- Trusting the source IP address (Moyasar's published webhook IP ranges) — rejected as strictly
  weaker than a secret-token check and more operationally fragile (IP ranges change; the secret
  token doesn't need infrastructure-level allowlisting).
- Skipping verification and relying solely on the synchronous callback path — rejected outright;
  it would mean a customer who closes their browser during 3DS could never have their subscription
  activated even after successfully paying, directly contradicting FR-011 and the Edge Case this
  spec calls out for exactly that scenario.

## 5. How is the tokenization form integrated without card data touching our server?

**Decision**: `CardTokenizationForm.tsx` loads Moyasar's hosted tokenization script via
`next/script` (lazy, scoped to the payment step only) and mounts it against the publishable key
(`NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY`) with `save_only: true`. The script's own completion
callback yields a token id directly to the component — the component's only server interaction is
sending that resulting token id (never the card fields themselves) to `POST
/api/subscriptions/[id]/pay`.

**Rationale**: This is the literal mechanism `plan.md` §3b describes ("tokenization must be
initiated from the browser directly against the Moyasar API — you are not permitted to post card
details to your own server"). Loading the script via `next/script` rather than a global include
keeps it off every route that isn't the payment step, consistent with Constitution Principle III's
budget for third-party scripts.

**Alternatives considered**:
- A native HTML form posting directly to Moyasar with no JS — rejected; Moyasar's documented
  integration path is its JS-driven tokenization flow, and hand-rolling raw form posts to a
  payment API is more fragile to get right than using the vendor's own script.

## 6. Where is retry throttling enforced, since Moyasar doesn't throttle this for us?

**Decision**: `POST /api/subscriptions/[id]/pay` counts the subscription's own `payments` rows
with `status = 'failed'` created within a short trailing window (e.g. the last 15 minutes) before
initiating a new charge; `lib/payments/retryThrottle.ts` is the pure decision function given that
count. Over the threshold, the endpoint responds with a clear "too many attempts" error instead of
calling Moyasar at all.

**Rationale**: Moyasar's own fraud controls protect Moyasar and card networks from abuse across
their whole platform, but nothing about that protects *this application's own* `/pay` endpoint
from being hammered with different stolen card numbers against the same subscription — that guard
has to live in our own Route Handler, mirroring exactly how Phase 1 built its own login-throttling
rather than assuming Supabase Auth's rate limiting covered a codepath it doesn't touch (in that
case Supabase's limiter *did* cover it; here, Moyasar's fraud tooling is a different, opaque
system this application shouldn't assume behaves like a per-endpoint request limiter).

**Alternatives considered**:
- A global (cross-subscription) rate limit per customer or per IP — rejected as out of scope; the
  spec's Clarifications answer scoped this to "the same subscription," and a broader limiter is
  exactly the kind of general hardening `plan.md` reserves for Phase 9.
