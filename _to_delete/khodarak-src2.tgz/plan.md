# Khodarak (خضارك) — MVP Implementation Plan

Based on the uploaded project overview (5-slide deck). Scope, stack, and routes below follow that document, not the earlier Express/MongoDB roadmap.

---

## 0. Two things to settle first

### A) Confirmed stack

| Layer | Decision |
|---|---|
| Frontend + backend | Single Next.js (App Router) + TypeScript monolith, Route Handlers for the API |
| Styling | Tailwind CSS, RTL-first |
| Database + Auth | Supabase (Postgres + Auth + Storage) |
| Payment | **Moyasar** — card tokenization for recurring charges (Mada, Visa, Mastercard, Apple Pay) |
| Client data layer | Redux Toolkit + RTK Query against `/api/*` |
| Deployment | Docker |

Routes as committed on the slides: `/login`, `/browse`, `/subscription`, `/dashboard`, `/admin`.

**Route additions from the design mockups (§0.B):** the actual screens add a public marketing home page and a product-detail sub-route that weren't in the original list, and split `/dashboard` into sub-routes matching its side nav:

| Route | Source screen |
|---|---|
| `/` | `design/home.html` — public landing page |
| `/browse` | `design/products.html` |
| `/browse/[id]` | `design/product-details.html` |
| `/subscription` | `design/subscription-builder.html` + `design/complete-order.html` (final step) |
| `/dashboard` | `design/dashboard.html` |
| `/dashboard/orders` | `design/my-orders.html` |
| `/dashboard/settings` | `design/settings.html` (addresses + payment methods + profile) |
| `/admin` | no mockup provided — see Phase 8 note |

**Note the scope change from the overview deck:** the slides say Cash on Delivery and explicitly put an online payment gateway out of scope for the MVP. Moving to Moyasar adds real weight — tokenization, 3DS, webhooks, failed-payment retries, and card-expiry handling. It's the right call for a subscription product (COD subscriptions have brutal collection problems), but it is roughly one extra phase of work, and it makes the renewal engine substantially more complex because renewal now means *charging money*, not just generating an order. Plan for it rather than discovering it in Phase 6.

Your RTK Query preference still fits: use it as the client-side data layer against Next.js Route Handlers (`/api/*`), and keep Supabase server-side. Don't call Supabase directly from the browser for anything price-related — see §3.

### B) The UI designs

Resolved — the `design/` folder now contains 9 finished static HTML/Tailwind mockups (RTL, Arabic, fonts and colors already wired up via an inline `tailwind.config`). This plan is no longer design-agnostic; every customer-facing phase below is pinned to these screens.

| File | Maps to | Notes |
|---|---|---|
| `home.html` | `/` | Hero, trust badges, product carousel, subscription plan pricing cards (weekly/monthly/bi-weekly), testimonials, footer |
| `products.html` | `/browse` | Sidebar filters (category, price, availability), sort bar, product grid, pagination |
| `product-details.html` | `/browse/[id]` | Single product detail page |
| `subscription-builder.html` | `/subscription` (build step) | Multi-step wizard header + progress line, sticky order-summary sidebar, product grid for box customization |
| `complete-order.html` | `/subscription` (checkout step) | Address section, delivery time-slot picker, payment method radio (card vs other), promo code, totals — where Moyasar card entry slots in |
| `successfull-order.html` | post-payment confirmation | Shown after the §3b Moyasar 3DS callback verifies |
| `dashboard.html` | `/dashboard` | Side nav (لوحة التحكم / طلباتي / اشتراكاتي / العناوين / الإعدادات), bento layout: next delivery card, calendar view, subscription health %, tips, support |
| `my-orders.html` | `/dashboard/orders` | Order history list |
| `settings.html` | `/dashboard/settings` | Address management (home/work cards + add new), payment methods, profile form, referral card |

**Gap:** no admin-panel mockup exists. `/admin` (Phase 8) stays design-agnostic — it'll reuse the same design tokens/components below, but layout is undetermined until a mockup is provided.

**Open reconciliation:** `products.html` shows a generic filter sidebar (category/price/availability), while the function inventory (§1) specifies two tabs خضروات/فواكه. Decide whether tabs sit above the existing filter sidebar or replace the category filter — flagged again in Phase 2.

#### Design system (source: `tailwind.config` block repeated across the mockups, e.g. `design/home.html` lines 36–124)

- **Colors** — Material-3-style token names, light palette only (mockups reference `dark:` classes but define no dark values, so dark mode is unfinished in the source and out of scope until it is): `primary #00450d`, `secondary #944a00`, plus the full `surface`/`surface-container*`/`on-*`/`error`/`tertiary` family.
- **Border radius** — `organic: 20px` is the signature card/button radius, alongside standard `lg`/`xl`/`full`.
- **Spacing scale** — named tokens `stack-sm/md/lg`, `gutter`, `margin-mobile/desktop`, `container-max`.
- **Typography** — Plus Jakarta Sans (400/600/700/800) + Material Symbols Outlined icons; custom font-size scale `display-lg`, `headline-md`, `body-lg/md`, `label-sm`.
- **Signature effects** — `organic-shadow` (soft green-tinted shadow), `glass-effect` (backdrop-blur), RTL-first (`dir="rtl"`, `flex-row-reverse` throughout), hover/active micro-interactions (`scale-95`/`scale-105`).

This is the literal source for `tailwind.config.ts` `theme.extend` in Phase 0 — port it verbatim rather than re-deriving a palette.

---

## 1. Full Function Inventory

Everything the MVP must do, grouped by module. This is the checklist the phases below deliver against.

### Auth & Account
- Sign up (email + password), log in, log out, session persistence
- Password reset
- Role resolution: `customer` vs `admin`
- Route protection (middleware): `/subscription`, `/dashboard` → customer; `/admin` → admin only
- Profile: name, phone (KSA format)

### Address
- Create / edit / delete delivery address
- Set default address
- City selection (from admin-managed city/zone list)
- At least one address required before subscription checkout

### Catalog (Customer)
- Browse products in two tabs: خضروات / فواكه
- Product grid card: image, name, price, unit (كجم / حبة)
- Quantity stepper (+/−) directly on card
- Persistent cart bar: item count + total, links to subscription builder
- Out-of-stock / unavailable state on card
- Cart state persists across page reloads (and merges on login)

### Subscription Builder — the core
- Carry selected items + quantities from browse
- Select frequency: weekly / bi-weekly / monthly (only those enabled in admin settings)
- Select first delivery date (respecting admin lead-time and blackout rules)
- **Live price breakdown**, recalculated on every change: items subtotal → frequency discount → delivery fee → VAT → total per delivery + estimated monthly cost
- Validation against admin rules: min order value, min/max qty per product, max items per box
- Select delivery address
- Card entry via Moyasar (tokenized) + explicit recurring-charge consent checkbox
- Confirm → first payment → create subscription + generate first order

### Pricing Engine (server-side, single source of truth)
- Calculate item subtotal from current product prices
- Apply frequency-based discount/multiplier from admin settings
- Apply delivery fee rule (flat / free-above-threshold / per-city)
- Apply VAT rate from settings
- Apply rounding rule
- Return a structured, auditable breakdown (not just a number)
- Snapshot prices onto each generated order so historical orders never change retroactively

### Subscription Management (`/dashboard`)
- View status: active / paused / cancelled
- View next delivery date + next order contents + next charge amount
- Edit items and quantities → triggers live re-price before saving
- Change frequency → recalculates next delivery date and price
- Pause (with resume date), Resume, Cancel
- Enforce edit cutoff window (e.g. no edits within X hours of next delivery — X from admin settings)
- Change delivery address
- Order history list + order detail

### Payments (Moyasar)
- Card tokenization at signup — card fields submitted **from the browser directly to Moyasar**, never through your server
- First charge with 3DS, redirect to callback, server-side verification of payment status before activating the subscription
- Save token reference: token id, brand, last four, expiry month/year (never PAN or CVC)
- Recurring charge on renewal using the saved token (3DS off for active tokens, so it can run unattended)
- Webhook endpoint: `paid`, `failed`, `refunded`, `captured` → update order + subscription state
- Webhook signature verification + replay protection
- Failed-payment handling (dunning): retry schedule, notify customer, suspend subscription after N consecutive failures
- Card expiry detection before renewal → prompt customer to update card
- Update/replace saved card from the dashboard
- Payment history view (customer) + payments list (admin)
- Refund from admin (manual, via Moyasar dashboard or API)

### Renewal Engine
- Scheduled job: find subscriptions whose next delivery date is due
- Re-price the box against current settings/prices, snapshot the breakdown
- **Charge the saved token**, then generate the order only on successful payment
- Advance `next_delivery_date` by frequency
- Skip paused/cancelled subscriptions; auto-resume when resume date passes
- Idempotency guard — never double-charge or double-generate for the same cycle
- Handle edge cases: product deleted or unavailable at renewal, price changed since signup, expired card, declined card

### Admin Panel (`/admin`)
- Product CRUD: name, category, price, unit, image, availability, min/max qty
- **Settings screen — the rules that drive pricing:** see §3
- Subscriptions list: filter by status, view detail, manually pause/cancel
- Orders list: filter by status/date, update order status (pending → out for delivery → delivered → cancelled)
- Cities/delivery zones management
- Basic counters: active subscriptions, orders today, revenue this month

---

## 2. Data Model (Supabase / Postgres)

```
profiles          id (fk auth.users), full_name, phone, role, created_at
addresses         id, user_id, label, city_id, district, street, details, is_default
cities            id, name_ar, is_active, delivery_fee_override
products          id, name_ar, category ('vegetables'|'fruits'), price, unit ('kg'|'piece'),
                  image_url, is_available, min_qty, max_qty, sort_order
settings          id (singleton row), json/columns — see §3
subscriptions     id, user_id, address_id, frequency, status ('active'|'paused'|'cancelled'),
                  next_delivery_date, paused_until, started_at, cancelled_at,
                  price_breakdown (jsonb snapshot at last save)
subscription_items  id, subscription_id, product_id, quantity
orders            id, subscription_id, user_id, address_snapshot (jsonb),
                  status, scheduled_date, delivered_at, price_breakdown (jsonb), created_at
order_items       id, order_id, product_id, product_name_snapshot, unit_price_snapshot, quantity
payment_methods   id, user_id, moyasar_token_id, brand, last_four, exp_month, exp_year,
                  is_default, status ('active'|'expired'|'removed'), created_at
payments          id, order_id, user_id, moyasar_payment_id, amount_halalas, status,
                  failure_reason, attempt_number, raw_response (jsonb), created_at
webhook_events    id, moyasar_event_id (unique), type, payload (jsonb), processed_at
```

Key rule: **`orders` and `order_items` store snapshots.** If admin changes a product price tomorrow, yesterday's orders must not change.

RLS policies: customers read/write only their own rows; `settings` and `products` are admin-write, public-read.

---

## 3. The Admin Settings → Pricing Rules Model

This is the piece you specifically asked about, so it's worth designing explicitly rather than discovering it mid-build.

**Settings the admin controls:**

```
frequencies:
  weekly:     { enabled, discount_percent, deliveries_per_month }
  biweekly:   { enabled, discount_percent, deliveries_per_month }
  monthly:    { enabled, discount_percent, deliveries_per_month }

order_rules:
  min_order_value
  max_items_per_box
  edit_cutoff_hours          # no edits within N hours of delivery
  first_delivery_lead_days   # earliest selectable first delivery
  blackout_weekdays          # e.g. no Friday deliveries

delivery:
  mode: 'flat' | 'free_above_threshold' | 'per_city'
  flat_fee
  free_threshold
  (per-city fees live on the cities table)

pause_rules:
  max_pause_days
  max_pauses_per_year

tax:
  vat_percent                # 15 in KSA
  prices_include_vat: bool   # important — changes the whole formula

rounding:
  mode: 'none' | 'nearest_0.5' | 'nearest_1'
```

**Calculation order (server-side function, one place only):**

```
1. itemsSubtotal   = Σ (product.price × quantity)
2. frequencyDiscount = itemsSubtotal × frequencies[f].discount_percent
3. afterDiscount   = itemsSubtotal − frequencyDiscount
4. deliveryFee     = resolve from delivery mode + city + afterDiscount
5. taxableBase     = afterDiscount + deliveryFee
6. vat             = prices_include_vat ? extracted : taxableBase × vat_percent
7. totalPerDelivery = round(taxableBase + vat)
8. estimatedMonthly = totalPerDelivery × frequencies[f].deliveries_per_month
```

**Three non-negotiables:**

1. **One implementation, server-side.** Put it in `lib/pricing/calculate.ts`, call it from Route Handlers. The browser may render a preview using the same pure function, but the value that gets saved always comes from the server. Otherwise a user can edit the client state and subscribe at their own price.
2. **Return the breakdown, not the total.** The UI needs to show each line (subtotal, discount, delivery, VAT) — and you'll need it for invoices later.
3. **Unit tests before the UI.** This function is the one piece where a bug silently costs real money. Test it in isolation with a table of cases (min order not met, free-delivery threshold exactly hit, VAT inclusive vs exclusive, rounding boundaries).

**Open decision for you:** does the customer see the price **per delivery** or **per billing cycle**? Recommendation: show per-delivery as the headline number with "≈ X ر.س شهرياً" underneath — Saudi grocery users compare against a single basket, so per-delivery reads cheaper and more honest at the same time.

---

---

## 3b. Moyasar Integration Design

**Flow at signup:**

1. Customer fills card details in a Moyasar-hosted form / JS component on the client. <cite index="9-1">Tokenization must be initiated from the browser directly against the Moyasar API — you are not permitted to post card details to your own server</cite>, and the form sets `save_only` to true to produce a reusable checkout token.
2. Your server takes the returned token and creates the first payment with 3DS enabled.
3. Customer completes 3DS, gets redirected to your callback URL.
4. **Your server verifies the payment status by calling Moyasar** — never trust the callback query params alone.
5. On success: save the token to `payment_methods`, activate the subscription, generate the first order.

**Flow at renewal (unattended):**

```
payment = moyasar.payments.create({
  amount: totalHalalas,          // 1000 = 10.00 SAR
  currency: 'SAR',
  description: `Khodarak — subscription ${sub.id} cycle ${n}`,
  source: { type: 'token', token: pm.moyasar_token_id },
  metadata: { subscription_id, cycle_number, order_id }
})
```

<cite index="11-1">For an active (already-verified) token, 3DS defaults to false, which is what makes unattended recurring charges possible</cite>. The `metadata` field is searchable via the payments list API, so put your own IDs there — it's what saves you during reconciliation.

**Five things that will bite you if you skip them:**

1. **Amounts are in halalas, not riyals.** `amount: 1000` is 10.00 SAR. Wrap this in one conversion helper and never do the multiplication inline — this is the classic 100× production bug.
2. **Idempotency.** Before charging, check whether a `payments` row already exists for that `order_id` in a non-failed state. A retried cron job that charges twice is the worst possible failure mode for a subscription business.
3. **Webhooks are the source of truth, not the API response.** A payment can settle or fail asynchronously. Store every event in `webhook_events` keyed by the Moyasar event id, ignore duplicates, and verify the signature.
4. **Dunning is a feature, not an edge case.** Cards decline constantly (insufficient funds, expired, bank blocks). Decide the retry schedule up front — e.g. retry at +1 day, +3 days, +5 days, then suspend and email. Without this you silently lose paying customers.
5. **Card expiry.** Check `exp_month`/`exp_year` against the next delivery date and prompt the customer *before* the charge fails.

**Test mode:** use `pk_test_` / `sk_test_` keys throughout development. Webhooks need a public URL — use a tunnel (ngrok/cloudflared) locally.

---

## 4. Phased Plan

Each phase ends in something demoable — usable directly as an episode.

### Phase 0 — Foundation
Next.js App Router + TypeScript + Tailwind, port the design system from `design/*.html` into `tailwind.config.ts` (colors, `organic` radius, spacing tokens, Plus Jakarta Sans + Material Symbols, RTL `dir="rtl"` base layout), Supabase project + client/server helpers, env config, folder structure. Run and develop locally (`npm run dev`) — no Docker yet; containerization is deliberately deferred to the last phase (Phase 9) so it never blocks or slows down local iteration.
**Demo:** empty but styled RTL shell — matching the mockups' look and feel — with all routes reachable (including `/` and `/browse/[id]`).

### Phase 1 — Auth & Address
Supabase Auth signup/login/logout/reset, `profiles` table + role, middleware route protection, address CRUD with default selection, city list.
**Demo:** create an account, log in, add a delivery address, get redirected correctly by role.

### Phase 2 — Catalog + Admin Product CRUD
`products` table, admin product CRUD with image upload (Supabase Storage), `/browse` per `design/products.html` (filter sidebar, sort bar, product grid, pagination) and `/browse/[id]` per `design/product-details.html`, stepper, persistent cart bar, cart state (Redux Toolkit) with reload persistence. **Resolve the tabs-vs-filter-sidebar question from §0.B first** — decide whether خضروات/فواكه becomes a tab strip above the sidebar or the sidebar's category filter, before building the grid.
**Demo:** admin adds a product → it appears instantly on the customer browse page; customer adds quantities and sees the cart bar update.

### Phase 3 — Admin Settings & the Pricing Engine
`settings` table + admin settings UI, `calculate.ts` pure function, unit test suite, `/api/pricing/preview` route handler.
**Demo:** change the weekly discount in admin from 5% to 15%, refresh the customer side, watch the price drop. This is the strongest single demo in the whole series — show the admin screen and the customer screen side by side.

### Phase 4 — Subscription Builder (no payment yet)
`/subscription` build step per `design/subscription-builder.html` (wizard progress header, sticky order-summary sidebar, box-customization product grid): carried-over cart, frequency selector (only enabled options), first delivery date picker respecting lead time and blackout days, live price breakdown, rule validation. Checkout step per `design/complete-order.html`: address selection, delivery time-slot picker, promo code, totals, confirm → create subscription in `pending_payment` state.
**Demo:** build a box end to end and watch the total change live as items and frequency change.

### Phase 5 — Moyasar Integration & First Payment
Moyasar test account + keys, client-side tokenization form slotted into the payment-method section of `design/complete-order.html`, first payment with 3DS, callback verification, `payment_methods` / `payments` tables, webhook endpoint with signature verification and event deduplication, subscription activation on confirmed payment landing on `design/successfull-order.html`, recurring-consent UI.
**Demo:** subscribe with a Moyasar test card, complete 3DS, land back on the success screen, and show the payment appearing in the Moyasar dashboard. Strong episode — this is the single most-requested topic from Arabic-speaking freelancers building for Saudi clients.

### Phase 6 — Customer Dashboard
`/dashboard` per `design/dashboard.html` (side nav + bento layout: next delivery card, calendar view, subscription health, tips, support): subscription status card, next delivery + next charge amount, edit items/quantities with re-pricing, change frequency, pause/resume/cancel with rule enforcement, edit cutoff window. `/dashboard/orders` per `design/my-orders.html`: order history + detail. `/dashboard/settings` per `design/settings.html`: address management, saved card display + update card, payment history, profile.
**Demo:** pause a subscription, resume it, edit the box, and show the next delivery date and next charge recalculating correctly.

### Phase 7 — Renewal Engine & Dunning
Scheduled job (pg_cron or a protected API route hit by an external scheduler), re-price → charge saved token → generate order on success, date advancement, idempotency guard, paused/cancelled handling, unavailable-product handling, failed-payment retry schedule, suspend-after-N-failures, card expiry pre-check.
**Demo:** back-date a subscription, trigger the job, watch a real test charge go through and a fresh order appear. Then force a decline with a failing test card and show the retry/suspend path. Showing the *failure* path on camera is what makes this episode credible.

### Phase 8 — Admin Operations
Subscriptions list + detail + manual pause/cancel, orders list with status transitions, payments list, cities/zones management, basic counters dashboard. **No mockup exists for `/admin`** — build using the same design-system tokens (colors, `organic` radius, typography from §0.B) and standard admin-panel conventions (data tables, filters, detail drawers) until a screen is provided; revisit layout if one arrives before this phase starts.
**Demo:** process an order from pending to delivered as an operator, and see it reflect on the customer's side.

### Phase 9 — Hardening, Docker & Launch (final phase)
RLS policy audit, server-side validation pass on every mutation, webhook endpoint hardening, error/loading/empty states, Arabic copy review, Lighthouse/mobile pass — all done and verified running locally first. **Docker is the last thing built in this phase**, once everything above is already working outside a container: Dockerfile + compose, CI, deploy, monitoring, switch to live Moyasar keys, soft-launch checklist.
**Demo:** the live URL, on a phone, in Arabic, with a real card.

---

## 5. Ordering Note

Phase 3 before Phase 4 is deliberate. Building the subscription UI first and bolting pricing rules on afterward is the most common way this kind of project ends up with pricing logic scattered across five components. Settings and the calculation function first, UI second.

**Docker is deliberately last.** Every phase from 0 through 8 is built and demoed running locally via `npm run dev` against the real Supabase/Moyasar test services — no Docker involved, and no `docker` commands are run during development. Containerization only happens inside Phase 9, after the app already works outside a container, to avoid debugging application logic and container config at the same time.

---

## 6. What I Need From You Next

1. **Per-delivery vs per-cycle pricing display** (§3 open decision).
2. **Frequency semantics for "monthly"** — one delivery per month, or a month's worth of deliveries billed monthly? This directly changes both the renewal engine and the charge amount.
3. **Billing timing** — charge per delivery (each renewal = one charge) or charge per cycle upfront (one charge covers 4 weekly deliveries)? Per-delivery is simpler and lower-risk for the MVP; per-cycle improves cash flow but complicates refunds when someone cancels mid-cycle.
4. **Is the existing project already scaffolded?** You mentioned keeping the existing structure and functionality in mind — if there's a repo already, send me the folder tree and I'll fit the plan to it rather than assuming a greenfield start.
5. **Admin panel mockup** (§0.B gap) — no design exists for `/admin` yet; send one if/when available, otherwise Phase 8 proceeds with the shared design tokens and generic admin-UI conventions.
6. **Tabs vs. filter sidebar on `/browse`** (§0.B open reconciliation) — how خضروات/فواكه should coexist with the category/price/availability filters shown in `design/products.html`.