import Link from "next/link";
import Image from "next/image";
import { ArrowLeft, Leaf, ShieldCheck, Sprout, Truck } from "lucide-react";
import { Container } from "@/components/ui/Container";
import type { MappedProduct } from "@/lib/products/mapProductRow";

const proofPoints = [
  { Icon: Truck, label: "توصيل مجاني للطلبات فوق ١٥٠ ر.س" },
  { Icon: ShieldCheck, label: "جودة مضمونة أو نعيد لك المبلغ" },
  { Icon: Leaf, label: "من مزارع محلية، تُقطف كل صباح" },
];

const stats = [
  { value: "+٢٤٠٠", label: "صندوق يُوصَّل شهرياً" },
  { value: "٤.٩/٥", label: "متوسط تقييم المشتركين" },
  { value: "١٢ ساعة", label: "من الحقل إلى بابك" },
];

// The right-hand collage uses real catalog photos when the catalog has any —
// a home page whose "products" are stock illustrations is the fastest way to
// look like a template. With an empty catalog it degrades to the plain
// gradient wash rather than rendering broken image frames.
export function Hero({ showcase = [] }: { showcase?: MappedProduct[] }) {
  const tiles = showcase.slice(0, 4);

  return (
    <section className="relative overflow-hidden border-b border-outline-variant bg-surface-container-low">
      <div
        className="pointer-events-none absolute -top-32 -start-24 size-[420px] rounded-full bg-primary-container/60 blur-3xl"
        aria-hidden="true"
      />
      <div
        className="pointer-events-none absolute -bottom-40 -end-20 size-[360px] rounded-full bg-secondary-container/50 blur-3xl"
        aria-hidden="true"
      />

      <Container>
        <div className="relative grid grid-cols-1 items-center gap-stack-xl py-stack-2xl lg:grid-cols-2 lg:py-stack-3xl">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full bg-primary-container px-3 py-1.5 text-caption font-semibold text-on-primary-container">
              <Leaf className="size-3.5" aria-hidden="true" />
              أهلاً بك في خضارك
            </span>

            <h1 className="mt-stack-md text-display-lg-mobile text-on-background md:text-display-lg">
              طازج من المزرعة
              <br />
              إلى باب بيتك
            </h1>

            <p className="mt-stack-md max-w-lg text-body-lg text-on-surface-variant">
              اشترك في صندوق خضروات وفواكه طازجة، أسبوعياً أو شهرياً. أنت تختار
              المحتويات والموعد، ونحن نتكفّل بالباقي.
            </p>

            <div className="mt-stack-lg flex flex-wrap items-center gap-stack-sm">
              <Link
                href="/subscription"
                prefetch
                className="inline-flex h-[52px] items-center gap-2 rounded-organic bg-primary px-7 text-body-md font-semibold text-on-primary shadow-sm transition-[background-color,color,box-shadow] duration-fast ease-out-quart hover:bg-primary-container hover:text-on-primary-container hover:shadow-md"
              >
                ابدأ اشتراكك الآن
                <ArrowLeft className="size-4" aria-hidden="true" />
              </Link>
              <Link
                href="/browse"
                prefetch
                className="inline-flex h-[52px] items-center rounded-organic border border-outline-variant bg-surface px-7 text-body-md font-semibold text-on-surface transition-colors duration-fast hover:border-primary hover:text-primary"
              >
                تصفّح المنتجات
              </Link>
            </div>

            <ul className="mt-stack-lg flex flex-col gap-2.5">
              {proofPoints.map(({ Icon, label }) => (
                <li
                  key={label}
                  className="flex items-center gap-2.5 text-small text-on-surface-variant"
                >
                  <Icon className="size-4 shrink-0 text-primary" aria-hidden="true" />
                  {label}
                </li>
              ))}
            </ul>

            <dl className="mt-stack-xl grid max-w-lg grid-cols-3 gap-stack-sm border-t border-outline-variant pt-stack-md">
              {stats.map((stat) => (
                <div key={stat.label}>
                  <dt className="sr-only">{stat.label}</dt>
                  <dd>
                    <span className="block text-h2 text-primary">{stat.value}</span>
                    <span className="mt-0.5 block text-caption text-on-surface-variant">
                      {stat.label}
                    </span>
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative hidden lg:block" aria-hidden="true">
            {tiles.length > 0 ? (
              <div className="grid grid-cols-2 gap-stack-sm">
                {tiles.map((product, index) => (
                  <div
                    key={product.id}
                    className={`relative overflow-hidden rounded-organic bg-surface shadow-lg ${
                      index % 2 === 0 ? "translate-y-6" : ""
                    } ${index === 0 ? "aspect-[4/5]" : "aspect-square"}`}
                  >
                    <Image
                      src={product.imageUrl}
                      alt=""
                      fill
                      sizes="(max-width: 1024px) 0px, 260px"
                      // Only the first tile is likely inside the LCP element;
                      // eagerly loading all four would compete with it.
                      priority={index === 0}
                      className="object-cover"
                    />
                    <span className="absolute bottom-2 start-2 rounded-full bg-surface/90 px-2.5 py-1 text-caption font-semibold text-on-surface">
                      {product.nameAr}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex aspect-square items-center justify-center rounded-organic bg-gradient-to-br from-primary-container to-secondary-container">
                <Sprout className="size-24 text-on-primary-container/70" />
              </div>
            )}
          </div>
        </div>
      </Container>
    </section>
  );
}
