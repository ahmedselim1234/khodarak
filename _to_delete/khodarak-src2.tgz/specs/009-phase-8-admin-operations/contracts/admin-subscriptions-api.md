# Contract: `/admin/subscriptions` list + detail, pause/cancel APIs

## `/admin/subscriptions` list (Server Component read)

Same pattern as `admin-orders-api.md`'s list: `app/admin/subscriptions/page.tsx` +
`lib/admin/queryAdminSubscriptions.ts`, requires `requireAdmin()`.

**`searchParams`**: `status?` (`pending_payment|active|paused|cancelled`), `search?` (customer
name/email/phone), `page?`.

**Renders**: each row's customer, frequency, next delivery date, status.

---

## `/admin/subscriptions/[id]` detail (Server Component read)

**Query**: the subscription plus its `subscription_items`, current `payment_methods`, that
customer's `payments` history for it, and — if `renewal_attempt_count > 0` or `status = 'paused'`
with no `paused_until` (Phase 7's own auto-suspend signature) — its Phase 7 dunning state.
`404`/`notFound()` if the subscription doesn't exist (owner-agnostic — admins can view any).

**Renders**: items/quantities, frequency, next delivery date, current price breakdown, delivery
address, payment history, dunning state if present (FR-006) — plus entry points into
`AdminPauseDialog`/`AdminCancelDialog`, shown/hidden per the subscription's current status
(mirroring how Phase 6's own `SubscriptionStatusCard` conditionally shows its actions).

---

## `POST /api/admin/subscriptions/[id]/pause`

**Request**:
```json
{ "reason": "Customer requested a temporary hold while travelling", "resumeDate": "2026-09-01" }
```
`resumeDate` is optional (omitted or `null` → indefinite pause, per the clarification session).
Validated by `lib/validation/adminSubscriptionAction.ts` — `reason` required, non-empty.

**Behavior**:
1. `requireAdmin()` — `401`/`403` otherwise.
2. `404` if the subscription doesn't exist. `409 { "error": "already_paused" }` /
   `409 { "error": "already_cancelled" }` if not currently `active` (FR-009, mirrors Phase 6's own
   customer-facing rule).
3. Calls `lib/subscription/mutateSubscription.ts`'s existing `pauseSubscription()`, extended with
   `adminId`/`reason` parameters — the exact same immediate-override-of-any-lock behavior Phase
   6/7 already give a pause (spec.md's own edge case), writing `initiated_by_admin_id`/`reason`
   onto the inserted `subscription_pauses` row (data-model.md). No `resumeDate` → `paused_until`
   stays `null` (indefinite, distinct from a customer's own always-dated pause).

**Response — success**: `200 { "status": "paused", "pausedUntil": "2026-09-01" }` (or `null`).

**Response — already paused/cancelled**: `409 { "error": "already_paused" | "already_cancelled" }`.

**Response — validation error (missing reason)**: `400 { "error": "validation_failed", "fields": { "reason": "..." } }`.

---

## `POST /api/admin/subscriptions/[id]/cancel`

**Request**:
```json
{ "reason": "Confirmed fraudulent signup — see support ticket #4821" }
```
Validated the same way — `reason` required.

**Behavior**:
1. `requireAdmin()`. `404` if not found. `409 { "error": "already_cancelled" }` if already
   cancelled (FR-009).
2. Calls the existing `cancelSubscription()`, extended with `adminId`/`reason` — writes
   `cancelled_by_admin_id`/`cancel_reason` (data-model.md), permanent/terminal exactly as the
   customer-facing path already is (FR-008).

**Response — success**: `200 { "status": "cancelled" }`.

**Response — already cancelled**: `409 { "error": "already_cancelled" }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": { "reason": "..." } }`.

---

Both endpoints additionally return `401`/`403` per `requireAdmin()`, and neither is reachable from
a customer's own session (FR-016) — the admin-only reason/attribution is never included in any
response a customer-facing route (Phase 6) reads.
