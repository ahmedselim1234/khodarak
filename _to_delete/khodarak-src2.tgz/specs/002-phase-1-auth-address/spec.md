# Feature Specification: Phase 1 — Auth & Address

**Feature Branch**: `002-phase-1-auth-address`

**Created**: 2026-08-10

**Status**: Draft

**Input**: User description: "read plan.md and create specification for the Phase 1" — scoped from `plan.md` §4 "Phase 1 — Auth & Address": Supabase Auth signup/login/logout/reset, `profiles` table + role, middleware route protection, address CRUD with default selection, city list. Demo target: "create an account, log in, add a delivery address, get redirected correctly by role."

## Clarifications

### Session 2026-08-10

- Q: Is the district on an address a free-text field the customer types, or must it be chosen from a predefined list scoped to the selected city? → A: Free text — customer types the district/neighborhood name themselves, same as street details; no admin-managed district list this phase.
- Q: Should the system cap how many delivery addresses a single customer can save? → A: No cap — customers can save an unlimited number of addresses this phase.
- Q: Should repeated failed login attempts on an account be throttled (temporary lockout/slowdown) to resist password-guessing attacks? → A: Yes, standard throttling — after a small number of consecutive failed attempts, further attempts for that account/IP are temporarily blocked or slowed.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Create an account and sign in (Priority: P1)

A new visitor creates an account with an email and password, and can subsequently log out and log back in, staying signed in across page reloads until they explicitly log out.

**Why this priority**: Every other feature in the product — browsing with a saved cart, subscribing, viewing the dashboard — requires a known, signed-in user. Without this, nothing else is reachable.

**Independent Test**: Can be fully tested by signing up with a new email/password, confirming a profile is created, logging out, and logging back in with the same credentials — delivers a working account a user can return to.

**Acceptance Scenarios**:

1. **Given** a visitor with no account, **When** they submit a valid email and password on the signup form, **Then** an account and matching profile record are created and they are signed in.
2. **Given** a visitor submits an email already registered, **When** they try to sign up again, **Then** they see a clear error and no duplicate account is created.
3. **Given** a signed-in user, **When** they choose to log out, **Then** their session ends and protected pages are no longer accessible until they sign in again.
4. **Given** a returning user with valid credentials, **When** they submit the login form, **Then** they are signed in and their session persists across a page reload without re-entering credentials.
5. **Given** a returning user, **When** they submit an incorrect password, **Then** they see a clear error and remain signed out.

---

### User Story 2 - Recover a forgotten password (Priority: P2)

A user who forgot their password requests a reset, receives a reset link, and sets a new password they can then log in with.

**Why this priority**: Locked-out users otherwise have no path back into a subscription they're already paying for — this directly protects retention, but the product is still usable end-to-end without it during initial testing, so it ranks below core signup/login.

**Independent Test**: Can be fully tested by requesting a reset for a known account, completing the reset flow with a new password, and logging in with the new password — delivers self-service account recovery.

**Acceptance Scenarios**:

1. **Given** a user who forgot their password, **When** they request a reset for a registered email, **Then** they receive a way to set a new password without contacting support.
2. **Given** a user completes the reset flow with a new password, **When** they subsequently log in with the new password, **Then** they are signed in, and the old password no longer works.
3. **Given** someone requests a reset for an email that is not registered, **When** the request is submitted, **Then** the system responds without revealing whether that email has an account.

---

### User Story 3 - Land in the right place based on role (Priority: P1)

Signed-in customers can reach customer-facing areas (subscription builder, dashboard) but are kept out of the admin panel; admins can reach the admin panel; signed-out visitors are sent to log in when they try to reach any protected area.

**Why this priority**: This is the access-control backbone the rest of the roadmap (subscriptions, payments, admin operations) depends on. Getting it wrong either locks customers out of their own account or exposes admin tooling to anyone — both are launch blockers, so it ships alongside core auth.

**Independent Test**: Can be fully tested by attempting to reach `/dashboard`, `/subscription`, and `/admin` as: a signed-out visitor, a signed-in customer, and a signed-in admin, and confirming each gets the correct outcome — delivers verifiable route protection independent of any other feature.

**Acceptance Scenarios**:

1. **Given** a signed-out visitor, **When** they navigate directly to `/subscription`, `/dashboard`, or `/admin`, **Then** they are redirected to log in, and land on their intended page after signing in.
2. **Given** a signed-in customer, **When** they navigate to `/subscription` or `/dashboard`, **Then** they reach the page normally.
3. **Given** a signed-in customer, **When** they navigate to `/admin`, **Then** they are denied and redirected away from the admin area.
4. **Given** a signed-in admin, **When** they navigate to `/admin`, **Then** they reach the admin area normally.

---

### User Story 4 - Manage delivery addresses (Priority: P2)

A signed-in customer adds one or more delivery addresses, edits or removes them, and marks one as their default so it's used automatically wherever an address is needed later (subscription checkout).

**Why this priority**: An address is a hard prerequisite for the subscription checkout built in a later phase, but the browsing and account-creation flows work without it, so it's important but not the very first thing a user needs.

**Independent Test**: Can be fully tested by adding an address, editing its details, adding a second address and marking it default, then deleting the first — delivers a working address book independent of the subscription flow that will later consume it.

**Acceptance Scenarios**:

1. **Given** a signed-in customer with no saved addresses, **When** they add a new address with a label, city, district, and street details, **Then** it is saved to their account and automatically becomes their default.
2. **Given** a customer with one saved address, **When** they add a second address and mark it as default, **Then** the second address becomes the default and the first is no longer marked default.
3. **Given** a customer with two saved addresses, **When** they edit one address's details, **Then** the changes are saved and reflected immediately.
4. **Given** a customer with two saved addresses, **When** they delete the non-default one, **Then** it is removed and the remaining address stays the default.
5. **Given** a customer with only one saved address, **When** they delete it, **Then** it is removed and they have no default address until they add another.
6. **Given** a customer adding or editing an address, **When** they choose a city, **Then** only cities the admin has marked active are offered.

---

### Edge Cases

- What happens when a user tries to sign up with a malformed email or a password that doesn't meet minimum strength requirements? System rejects with a specific, actionable error before creating any account.
- What happens when a signed-in user's session expires (token lifetime elapses) while they're on a protected page? They are treated as signed-out on their next action and redirected to log in.
- What happens when a customer enters a phone number that isn't a valid Saudi mobile format? The profile form rejects it with a specific error rather than silently accepting it.
- What happens when a reset-password link is reused after already being used once, or has expired? The system rejects it and prompts the user to request a new one.
- What happens if the city a customer's saved address references is later deactivated by an admin? The address remains stored and usable by the customer, but that city no longer appears as a choice for new/edited addresses.
- What happens when a customer tries to delete their only address while it's also referenced as required for an in-progress subscription checkout (later phase)? Deletion of an address is always allowed from the address book itself in this phase; enforcing "at least one address before checkout" is the responsibility of the subscription checkout flow being specified separately.
- What happens when an admin account (not yet buildable via self-serve signup) needs to be created? Out of scope for this phase's UI — see Assumptions.
- What happens when a user exceeds the allowed number of consecutive failed login attempts? Further attempts are temporarily blocked/slowed and the user sees a clear message rather than a generic "wrong password" error, until the throttling window passes.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: System MUST allow a visitor to create an account using an email address and password.
- **FR-002**: System MUST prevent creating a second account with an email address already registered, and surface a clear error.
- **FR-003**: System MUST allow a registered user to log in with their email and password, and to log out, ending their session.
- **FR-003a**: System MUST temporarily throttle or block further login attempts against an account/source after a small number of consecutive failed attempts, to resist password-guessing.
- **FR-004**: System MUST keep a signed-in user's session persisted across page reloads until they log out or the session expires.
- **FR-005**: System MUST allow a user who forgot their password to request a reset and set a new password, without requiring support intervention.
- **FR-006**: System MUST NOT reveal whether a given email address has a registered account when handling a password-reset request.
- **FR-007**: System MUST create a profile record for every account, capturing full name and phone number, and resolve each account to exactly one role: `customer` or `admin`.
- **FR-008**: System MUST default every self-service signup to the `customer` role; assigning the `admin` role is not exposed through the signup flow.
- **FR-009**: System MUST validate the phone number entered on a profile against Saudi mobile number format and reject invalid values with a specific error.
- **FR-010**: System MUST protect `/subscription` and `/dashboard` (and their sub-routes) so only signed-in users with the `customer` or `admin` role can reach them; signed-out visitors are redirected to log in and returned to the page they requested after signing in.
- **FR-011**: System MUST protect `/admin` (and its sub-routes) so only signed-in users with the `admin` role can reach them; signed-in customers attempting to reach it are redirected away, and signed-out visitors are redirected to log in.
- **FR-012**: System MUST allow a signed-in customer to create a delivery address with, at minimum, a label, city (selected from active cities), a free-text district/neighborhood name, and street-level details.
- **FR-013**: System MUST allow a signed-in customer to edit and delete their own delivery addresses, and MUST NOT allow a customer to view, edit, or delete another user's address.
- **FR-013a**: System MUST NOT impose a maximum number of saved addresses per customer.
- **FR-014**: System MUST allow a customer to designate exactly one of their saved addresses as the default at any time; setting a new default automatically un-defaults the previous one.
- **FR-015**: System MUST automatically mark a customer's first saved address as their default.
- **FR-016**: System MUST offer only admin-marked-active cities as choices when a customer creates or edits an address.
- **FR-017**: System MUST preserve an existing address's stored city reference even if that city is later deactivated by an admin, without allowing it to be selected again for new or edited addresses.

### Key Entities

- **Account / Profile**: A registered user's identity and account-level attributes — full name, phone number, and role (`customer` or `admin`). One profile per authenticated account.
- **Address**: A customer's saved delivery location — label (e.g. "Home", "Work"), city (from the active city list), a free-text district/neighborhood name, street-level details, and whether it is the customer's current default. Belongs to exactly one customer; a customer may have many.
- **City**: An admin-managed delivery location a customer can select for an address, with an active/inactive state controlling whether it's offered for new selections.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A new user can complete the signup form and receive clear next-step feedback (a confirmation-email prompt) in under 2 minutes.
- **SC-002**: 100% of attempts to reach a role-restricted route with the wrong role (or signed out) are redirected instead of showing the protected content.
- **SC-003**: A signed-in customer can add their first delivery address and see it saved as their default in under 90 seconds.
- **SC-004**: A user who requests a password reset can regain access to their account without any manual/support intervention.
- **SC-005**: 100% of saved addresses correctly reflect exactly one default per customer at all times (never zero when at least one address exists, never more than one).
- **SC-006**: Returning users remain signed in across a normal browsing session (multiple page loads) without needing to re-authenticate.

## Assumptions

- Email confirmation IS required before first login (confirmed during implementation — the live Supabase project has "Confirm email" enabled, and the decision was to keep it that way rather than loosen it for MVP speed). A new signup shows a "check your email to confirm" state instead of an immediate session; SC-001's "under 2 minutes" applies to the signup submission itself, not the time until the user clicks the emailed link.
- Admin accounts are provisioned out-of-band (directly in the database/Supabase dashboard) rather than through a self-service UI — there is no product surface in this phase for promoting a user to `admin`.
- "Saudi mobile format" means a KSA mobile number recognizable in either local (`05XXXXXXXX`) or international (`+9665XXXXXXXX`) form; the exact accepted pattern is a presentation-layer validation detail, not a scope decision.
- The city list itself (adding/editing/deactivating cities) is managed by the admin panel delivered in a later phase (per `plan.md` Phase 8); this phase only needs to read the active city list to populate address selection, and assumes at least one active city exists for testing.
- "At least one address required before subscription checkout" (noted in `plan.md`'s Address module) is enforced by the subscription checkout flow, not by this phase — this phase only guarantees addresses can be created, edited, deleted, and defaulted correctly.
- Password strength/format rules follow Supabase Auth's standard defaults rather than a custom policy, since none was specified.
