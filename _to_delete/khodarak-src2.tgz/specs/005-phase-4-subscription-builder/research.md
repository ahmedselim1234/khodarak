# Phase 0 Research: Phase 4 — Subscription Builder (no payment yet)

No `NEEDS CLARIFICATION` markers remain in the Technical Context — the feature spec's own
2026-08-10 Clarifications session already resolved the three decisions that would otherwise have
landed here (post-confirm landing, promo code scope, checkout back-navigation). This document
records the remaining design-level decisions made while turning that spec into an implementable
plan.

## 1. Is the "box" a separate draft state, or literally the cart?

**Decision**: The box *is* the customer's `cart_items` rows. The build step reuses
`lib/store/cartApi.ts` and `components/cart/QuantityStepper.tsx` from Phase 2 unmodified.

**Rationale**: FR-001 requires the builder to pre-load the current cart as the starting box, FR-002
requires every add/remove/quantity-change to behave exactly like the existing stepper (same
clamping, same immediate feedback), and FR-012 requires the cart to be cleared once a subscription
is created *from it*. Read together, these describe the cart as the box's actual storage, not a
separate state that merely starts out copied from the cart. Treating them as the same rows also
means the persistent `CartBar` (Phase 2) and the builder's own order summary never disagree with
each other — there is exactly one place item selections live.

**Alternatives considered**:
- A separate "draft subscription" table/state, initialized from the cart and only written back on
  confirm — rejected; it would require its own CRUD surface duplicating `cart_items`'s, and create
  a real risk of the cart and the draft silently diverging (e.g., a customer edits their cart from
  `/browse` in another tab while the builder is open).
- Keeping the cart untouched and having the builder hold its own in-memory copy — rejected for the
  same divergence risk, and it would mean losing builder progress on a refresh, which nothing in
  the spec asks for and would be a worse experience than the cart's existing persistence.

## 2. What are the delivery time slots, and where do they live?

**Decision**: A fixed, hardcoded set of three slots — `morning` (٨ص–١٢م), `afternoon` (١٢م–٤م),
`evening` (٤م–٩م) — defined once in `lib/subscription/timeSlots.ts` and imported by both the
picker component and the Route Handler's validation.

**Rationale**: Per the spec's own Assumptions, `plan.md`'s settings model never defines time slots
as an admin-configurable concept, so inventing admin UI for them would be scope creep unsupported
by anything else in the project. A single shared source of truth (one file, both sides import it)
avoids the client and server ever disagreeing about which slot values are valid — the same reason
`lib/pricing/mapSettingsRow.ts`'s types are shared between the Route Handler and the UI in Phase 3.

**Alternatives considered**:
- Storing time slots in the `settings` table (a new `jsonb` or array column) — rejected; it would
  resurrect a settings-schema question the spec explicitly scoped out this phase, for a value that
  has no admin-facing configuration screen to edit it from anyway.
- Deriving slots from the mockup's literal date-bundled options ("tomorrow morning", "day after") —
  rejected; the spec's Assumptions already separate date selection (build step, lead-time/blackout
  aware) from time-window selection (checkout step) to avoid the mockup's redundant date-picking,
  so slots are pure time windows, not date+time bundles.

## 3. How is "create subscription + items, then clear the cart" made safe without a DB transaction?

**Decision**: Sequential Supabase calls from the Route Handler — insert `subscriptions`, then
insert `subscription_items`, then delete the customer's `cart_items` — with a compensating delete
of the just-created `subscriptions` row if the `subscription_items` insert fails. The cart is only
deleted after both inserts succeed.

**Rationale**: This project has no existing precedent for Postgres RPC/stored-procedure
transactions — Phase 1's default-address invariant, the closest prior case of "multiple writes
that must stay consistent," used two sequential `UPDATE` calls backstopped by a database-level
unique index (the index is what actually prevents an inconsistent end state, not transaction
wrapping). Following that same shape here — plain sequential calls, with the one compensating
action ordered to prevent the specific bad state that matters (`subscriptions` row with no
sibling `subscription_items` reachable) — keeps this phase consistent with the codebase's existing
patterns and constitutional posture (RLS enforces the real security boundary; Route Handler logic
handles process consistency) rather than introducing a new class of infrastructure (Postgres
functions callable via `.rpc()`) for one phase.

**Alternatives considered**:
- A Postgres `SECURITY DEFINER` function performing all three operations in one transaction —
  rejected for this phase; it's the textbook "right" answer for atomicity, but this project has
  intentionally kept all business logic in TypeScript Route Handlers so far (per `plan.md`'s own
  stack decisions), and a `pending_payment` subscription created without its items is a detectable,
  low-stakes failure mode (no money has moved) rather than a silent-corruption risk — worth
  revisiting if/when Phase 5 or 6 needs true multi-table atomicity for something money-adjacent.
- Deleting cart items first, then creating the subscription — rejected; a failure partway through
  would leave the customer with an empty cart and no subscription, which is strictly worse for them
  than a `pending_payment` subscription that's merely missing (recoverable, detectable) items.

## 4. What city does the live preview use before an address is chosen?

**Decision**: The build step's live price preview uses the customer's default address's city if
they have one; if they have none yet, it falls back to the first active city purely for preview
purposes. The price is always recomputed against the *actually selected* address's city once the
customer reaches or revisits checkout (FR-017a), which is the value that ends up in the
confirmed snapshot.

**Rationale**: The wizard's step order (per `design/subscription-builder.html`) puts item/frequency
selection before address selection, but `calculate.ts` needs a city to resolve delivery fees
(`plan.md` §3). Most customers already have a default address from Phase 1 by the time they reach
the builder, so this default is accurate for them most of the time; for the rest, the preview is
still correct for every line except delivery fee until they pick a real address, which the
UI treats as expected (the breakdown recalculates the moment a real address is selected — nothing
about this is silently wrong or stale, per FR-005's "never a client-computed or stale price").

**Alternatives considered**:
- Hiding the delivery fee line entirely until an address is chosen — rejected as unnecessary
  UI complexity for a gap that resolves itself within the same session for the vast majority of
  customers (those with a default address already).
- Forcing address selection before item/frequency selection (reordering the wizard) — rejected;
  it would contradict the design mockup's own step order and `plan.md`'s explicit ordering
  ("carried-over cart... frequency selector... delivery date... checkout step: address selection"),
  for a benefit (always-accurate delivery fee from step one) that doesn't outweigh matching the
  established design.
