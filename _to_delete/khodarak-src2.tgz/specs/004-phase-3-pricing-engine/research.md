# Phase 0 Research: Phase 3 — Admin Settings & the Pricing Engine

No `NEEDS CLARIFICATION` markers remain in the Technical Context — the feature spec's own
2026-08-10 Clarifications session already resolved the two decisions that would otherwise have
landed here (preview access, preview route placement). This document records the remaining
design-level decisions made while turning that spec into an implementable plan.

## 1. How is the `settings` singleton shaped and enforced?

**Decision**: One table, one row, enforced with `id integer primary key default 1 check (id = 1)`.
Per-frequency rules (`weekly`/`biweekly`/`monthly`) live in a single `frequencies jsonb` column;
everything else (order rules, delivery, pause rules, tax, rounding) is scalar columns with `check`
constraints.

**Rationale**: FR-007 requires exactly one active configuration, not a history of versions or
per-tenant rows. A `check (id = 1)` primary key makes a second row a constraint violation rather
than an application-level convention that a bug could silently violate — the same "database-level,
not just app-level" precedent Phase 1 used for the one-default-address-per-customer invariant.
Frequencies are a natural `jsonb` fit because they're a small, uniform, three-key map that's always
read/written as a whole (`plan.md` §3 itself calls the shape "json/columns" without mandating one
or the other) — everything else is an independent scalar value with its own sane-range rule
(FR-008), which a `check` constraint expresses directly instead of hiding inside a blob.

**Alternatives considered**:
- Fully `jsonb` (one column holding the whole settings shape) — rejected; it would bury FR-008's
  range validation entirely in application code with no database-level backstop, unlike every
  other table this project has added so far.
- Fully normalized (a `frequencies` table with one row per frequency) — rejected as unnecessary
  indirection for exactly three, fixed, never-added-to keys; a join buys nothing here that a
  `jsonb` map with a documented shape doesn't already give.
- A settings-history table (append-only, "current" = latest row) — rejected as speculative; no
  requirement in this phase or `plan.md` calls for an audit trail of settings changes, and it can
  be added later without reshaping the current-settings read path.

## 2. Where does `/pricing-preview` live, and does `middleware.ts` need to change?

**Decision**: A new top-level route, `/pricing-preview`, outside the `/subscription` prefix
entirely. `middleware.ts`'s existing matcher (`/subscription/:path*`) is untouched.

**Rationale**: The spec's Clarifications session settled that the preview must be public and must
not touch `/subscription`'s protection. Since `middleware.ts`'s `matchesPrefix` check is a literal
`pathname.startsWith('/subscription/')` test, *any* route nested under `/subscription` — including
something like `/subscription/preview` — would still be swept into the customer-gated matcher and
require either an explicit carve-out (more moving parts, more surface for a future regression to
accidentally re-protect or under-protect part of the path) or a middleware change. A sibling
top-level route sidesteps the question entirely: zero lines of `middleware.ts` change for this
phase, and Phase 4 later builds the real, protected checkout at `/subscription` exactly as Phase 1
already set up.

**Alternatives considered**:
- `/subscription/preview` with a middleware exception — rejected (this was the clarification
  option's own example path, but implementing it literally would require carving an exception into
  `matchesPrefix`, which is more change and more risk than a plain sibling route for the same
  outcome).
- Embedding the preview as a widget on `/browse` — rejected in the Clarifications session in favor
  of a dedicated page; a dedicated route is also easier to link directly from the admin settings
  screen for the demo ("go check the preview") and to retire cleanly once Phase 4 ships.

## 3. Does the preview ever compute a price client-side?

**Decision**: No. `PreviewForm` calls `POST /api/pricing/preview` on every selection change
(debounced); `calculate.ts` is never imported into client code.

**Rationale**: Constitution Principle II explicitly permits a client-side preview using "the same
pure function" as an optimization, but that clause assumes the function is safe to ship to the
browser. Here it isn't just about safety — the formula only exists once, server-side; duplicating
it client-side (even as a "preview-only" copy) would immediately violate `plan.md` §3's first
non-negotiable ("one implementation, server-side") and create exactly the drift risk that rule
exists to prevent. Calling the Route Handler on every change costs a small amount of latency for a
form with a handful of fields; that's a fully acceptable trade for guaranteeing the preview can
never show a number the real engine wouldn't produce.

**Alternatives considered**:
- Ship `calculate.ts` to the client bundle and call it directly for instant feedback — rejected
  per the reasoning above; also would require settings and product-price data to be sent to the
  browser as plain values the client could tamper with before the *next* real calculation, which
  Constitution Principle V's "server-side authority" spirit argues against even for a non-charging
  preview.

## 4. How is rounding implemented without floating-point surprises?

**Decision**: All currency arithmetic inside `calculate.ts` is done in regular floating-point SAR
values (not halalas — that halalas/integer-cents convention is specific to the Moyasar payment
integration in `plan.md` §3b, which this phase doesn't touch), but every rounding-mode application
happens through one small helper that rounds to a fixed number of decimal places using
`Math.round` on a pre-scaled value (e.g. `Math.round(value * 2) / 2` for "nearest 0.5") rather than
comparing floats directly — and the boundary cases in `tests/unit/pricing.calculate.test.ts` are
picked specifically to land exactly on a rounding threshold (e.g. a pre-rounding total of exactly
12.25 under "nearest 0.5") to catch any drift.

**Rationale**: The spec explicitly calls out rounding-boundary correctness (FR-015, Edge Cases,
SC-004) as a required, hand-verifiable test case — this is a case where "it usually rounds right"
isn't good enough, since the whole point of a rounding mode is that its boundary behavior is
deterministic. Scaling-then-rounding-then-unscaling is the standard technique for avoiding the
classic `0.1 + 0.2` class of float bugs at exactly the boundaries the tests target.

**Alternatives considered**:
- A decimal/bignum library (e.g. `decimal.js`) — rejected as unnecessary weight for this phase;
  SAR prices in this catalog are two-decimal values and the scale-round-unscale technique is
  sufficient at that precision, matching the precision Postgres's own `numeric(10,2)` columns
  (`products.price`) already commit to.
