# Quickstart: Validating Phase 2 — Catalog + Admin Product CRUD

Validates the four user stories in [spec.md](./spec.md) end to end. Run after implementation, on
top of a working Phase 1 checkout (auth, roles, and addresses already functional).

## Prerequisites

- Phase 1's quickstart already passing (an admin test account exists — `profiles.role = 'admin'`
  — and at least one customer account)
- Migrations applied: `products`, `product_images_bucket`, `cart_items`
  (see [data-model.md](./data-model.md))
- `npm run dev` running

## 1. Admin creates a product with a photo (User Story 1, FR-001–005, SC-001)

```
# signed in as the admin test account: visit /admin/products/new
# fill name, category (خضروات), price, unit, min/max qty; upload a product photo; save
```

**Expected**: redirected back to `/admin/products` with the new row listed; attempting to submit
without a photo is rejected before the request is sent (FR-001's "MUST NOT allow saving ... without
a photo"); uploading an oversized or wrong-format file shows a specific error and the rest of the
form's fields remain filled in (FR-005).

## 2. New product appears on `/browse` (SC-001 — this phase's headline demo)

```
# in a second tab (or signed out): visit /browse, switch to the خضروات tab
```

**Expected**: the product created in step 1 appears in the grid with no manual refresh step beyond
a normal page load. Edit its price and availability from `/admin/products/[id]/edit` and reload
`/browse` — both changes are reflected immediately (FR-002).

## 3. Browse, filter, sort, paginate (User Story 2, FR-006–010, SC-002/006)

```
# on /browse: switch between خضروات and فواكه tabs
# set a price range and toggle "available only" in the sidebar
# change the sort order
# page to a second page if enough products exist
```

**Expected**: the grid always matches the active tab/filter/sort/page combination (check the URL's
`searchParams` per [contracts/catalog-browse.md](./contracts/catalog-browse.md)); switching tabs
preserves the active price/availability filters; a filter combination with zero matches shows the
empty state instead of a blank grid; an unavailable product is visibly flagged and its stepper
can't be increased (FR-018).

## 4. Adjust quantities and watch the cart bar (User Story 3, FR-011–014, SC-003)

```
# as a signed-out (guest) visitor: increase a product's quantity via its grid-card stepper
# reload the page
```

**Expected**: the persistent cart bar's count/total update immediately on each stepper click, with
no page reload; after reloading, the same selections and totals are still shown (guest cart
persisted via `localStorage`, FR-014). Try pushing a quantity above the product's `maxQty` or below
`minQty` (other than to 0) — the stepper clamps rather than accepting the value (FR-012).

## 5. Guest cart merges at login (FR-015, SC-004)

```
# still signed out, with items in the cart bar from step 4: log in with a customer account that
# already has a different product in its (server-side) cart
```

**Expected**: `POST /api/cart/merge` fires once after login (check the network tab); the resulting
cart contains both the guest's and the account's pre-existing items; for any product present in
both, the higher of the two quantities wins, capped at that product's `maxQty`
(see [contracts/cart-api.md](./contracts/cart-api.md)); `GET /api/cart` on next load reflects the
merged state, not either side alone.

## 6. View a product detail page (User Story 4, FR-016/017)

```
# from /browse, select a product → confirm its detail page renders with gallery/photo, price, unit
# adjust its quantity via the detail-page stepper → confirm the cart bar updates the same way
# navigate directly to /browse/<a deleted or nonexistent id>
```

**Expected**: the detail page's stepper and cart-bar update behave identically to the grid card's;
a nonexistent/deleted product id renders a clear "not found" state, not a broken page.

## 7. Confirm admin-only write access (Constitution Principle V)

```
# signed in as a customer (not admin): attempt POST/PATCH/DELETE against
# /api/admin/products directly (e.g. via browser devtools or curl with the customer's session cookie)
```

**Expected**: every request is rejected (`401`/`403`) — RLS on `products` and the `/admin`
middleware gate both block it; `/browse` itself remains reachable signed-out (it is not behind the
`/admin` or `/dashboard` route-protection matrix from Phase 1).

## 8. Run the unit and e2e suites (Constitution Principle VI)

```
npm run test:unit
npx playwright test tests/e2e/catalog-cart.spec.ts
```

**Expected**: `clampQuantity` and `mergeCartQuantities` boundary cases pass (at-min, at-max,
one-below, one-above, guest-only, account-only, both-present); the Playwright spec walks the full
admin-creates → browse-and-filter → stepper-updates-cart-bar → reload-persists →
guest-merges-at-login path from steps 1–5 above without manual intervention.
