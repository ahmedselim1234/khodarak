# Quickstart: Validating Phase 9 — Hardening, Docker & Launch

Validates the seven user stories in [spec.md](./spec.md) end to end. This is the project's final
phase — running this quickstart to completion, with `LAUNCH_CHECKLIST.md` fully resolved, **is**
the launch decision (User Story 7).

## Prerequisites

- Every prior phase's own quickstart already passing against `npm run dev`
- A GitHub repository with Actions enabled (for CI, User Story 3)
- A single Docker host provisioned and reachable (research.md §2) — SSH access, Docker installed,
  logged in to the chosen container registry
- A free-tier external uptime-checking account (User Story 4/contracts/monitoring.md)
- Real, live Moyasar production credentials, obtained but **not yet placed anywhere** until the
  User Story 5 step below

## 1. Run the security/correctness audit (User Story 1, FR-001–004, SC-001)

```
# systematically review every RLS policy across every migration in supabase/migrations/
# against each phase's own data-model.md; attempt every customer-session write this project
# has ever forbidden, directly via the Supabase REST API; review every Route Handler's body
# parsing for a validation step; replay a captured Moyasar webhook payload twice
```

**Expected**: every finding is recorded in `AUDIT_FINDINGS.md` with a severity; every `Blocking`
finding is fixed and its row updated to `Resolution: Fixed`; a redelivered webhook event is
confirmed to still be a no-op (Phase 5's own deduplication, re-verified rather than assumed).

## 2. Verify the container is a faithful package of the app (User Story 2, FR-005/006)

```
docker compose build
docker compose up
# in another terminal, exercise: browse a product, build a subscription, pay with a Moyasar
# test card, open /dashboard, open /admin
```

**Expected**: the build succeeds without modifying application code (confirm the
`NEXT_PUBLIC_MOYASAR_PUBLISHABLE_KEY` placeholder fix from research.md §5 is in place — the build
would otherwise fail at this exact step); every flow behaves identically to the same flow run via
`npm run dev`.

## 3. Confirm the CI pipeline blocks a bad change and ships a good one (User Story 3, FR-007/008)

```
# push a branch with a deliberate type error
# confirm the PR shows a failing check and no deploy job runs
# fix it, push again, merge to main
```

**Expected**: the broken branch's check fails and blocks merge; the fixed, merged change results
in a new image tag in the registry and `scripts/deploy.sh` running successfully against the
production host (contracts/ci-workflow.md, contracts/deploy-and-rollback.md).

## 4. Exercise rollback for real (User Story 3 Acceptance Scenario 4, FR-009, SC-003a)

```
# after step 3's deploy, run scripts/rollback.sh <the-previous-tag> on the production host
```

**Expected**: the production host observably returns to running the previous version (confirm via
its own version/build marker, or simply that the just-deployed change's effect is no longer
present) — per the clarification session, this MUST actually be run, not left as an unexecuted
procedure.

## 5. Confirm monitoring actually notices problems (User Story 4, FR-010–012, SC-004)

```
# deliberately stop the production container and time how long until the uptime alert fires
# trigger a deliberate server error (e.g., a malformed request to an existing endpoint) and
# confirm it's visible in the container's logs with enough context to identify the route
# open /admin and confirm the new "auto-suspended this week" counter renders (even at 0)
```

**Expected**: the uptime alert fires within 5 minutes (the clarified SLA) of the container
stopping; the deliberate error is visible in the logs with identifiable context; the counter
renders correctly on `/admin`.

## 6. Cut over to live Moyasar credentials and prove it with one real transaction (User Story 5, FR-013/014, SC-005)

```
# replace pk_test_/sk_test_/the test webhook secret in the production environment's own secret
# configuration with the real live values — nowhere else
# with a real card, complete one real, minimal-amount subscription payment against the live
# production URL
```

**Expected**: the transaction succeeds; it appears in the application's own `payments` table
(via `/admin/payments`, Phase 8) and in the live Moyasar dashboard, with matching amounts; a
search of the production environment's configuration confirms no `pk_test_`/`sk_test_`/test
webhook secret value remains present anywhere reachable by the live application.

## 7. Verify UX consistency and performance across the whole app (User Story 6, FR-015–017, SC-006/007)

```
npx lhci autorun
# separately, walk every screen from Phases 0-8 while forcing a network failure, a slow
# response, and a genuinely empty data set; review every Arabic string encountered along the way
```

**Expected**: Lighthouse CI's own report shows every one of the four named pages (home, browse,
subscription builder, dashboard) meeting the constitution's budget (LCP < 2.5s, INP < 200ms,
CLS < 0.1) on mobile emulation; every screen shows a real error/loading/empty state; every
Arabic string reviewed is correct, consistent, and renders correctly RTL — any issue found is
fixed and, if non-trivial, also logged in `AUDIT_FINDINGS.md`.

## 8. Complete the launch checklist (User Story 7, FR-018, SC-008 — the phase's own demo target)

```
# fill in LAUNCH_CHECKLIST.md: one row per FR-001 through FR-017, each with concrete evidence
# from steps 1-7 above
```

**Expected**: every row is either `Verified` with a concrete evidence reference, or
`Deferred (non-blocking)` with a reason — no row is left blank. Once complete: open the live
production URL on a real mobile phone, in Arabic, and complete a real transaction — the phase's
own stated demo target, now provably true rather than assumed.
