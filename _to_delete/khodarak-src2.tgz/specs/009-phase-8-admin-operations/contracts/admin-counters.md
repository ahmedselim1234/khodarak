# Contract: `/admin` counters landing view

Not a network endpoint — `app/admin/page.tsx` (replacing the Phase 0 placeholder) renders
`CountersOverview.tsx`, a Server Component computing three aggregates fresh on every request
(research.md §5), requires `requireAdmin()`.

## Queries

1. **Active subscriptions**: `select count(*) from subscriptions where status = 'active'`.
2. **Orders today**: `select count(*) from orders where scheduled_date = current_date`.
3. **Revenue this month**: `select sum(amount_halalas) from payments where status = 'paid' and
   created_at >= date_trunc('month', current_date) and created_at <
   date_trunc('month', current_date) + interval '1 month'`, converted to SAR by dividing by 100
   (the existing halalas display convention) — `0` when no rows match, never `null`.

All three rely on the new `subscriptions_select_admin`/`orders_select_admin`/
`payments_select_admin` RLS policies (data-model.md) via the caller's own RLS-scoped client.

## Renders

Three labeled figures: "الاشتراكات النشطة" (active subscriptions count), "طلبات اليوم" (today's
order count), "الإيرادات هذا الشهر" (this month's revenue, formatted as SAR) — per FR-015,
SC-005.

## Notes

- No caching, no scheduled recomputation (research.md §5) — satisfies SC-005's "never more than
  one page-load stale" directly by computing fresh every time.
- A partially-completed Phase 7 renewal-job run mid-execution simply means some of today's
  renewals aren't reflected yet in the counters at that exact moment — not an error state
  (spec.md's own edge case).
