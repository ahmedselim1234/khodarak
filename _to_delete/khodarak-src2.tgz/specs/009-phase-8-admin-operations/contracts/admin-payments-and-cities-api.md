# Contract: `/admin/payments` list, `/admin/cities` list + create/edit

## `/admin/payments` list (Server Component read)

Same pattern again: `app/admin/payments/page.tsx` + `lib/admin/queryAdminPayments.ts`, requires
`requireAdmin()`. Read-only — no row actions (spec.md Assumptions).

**`searchParams`**: `status?` (`initiated|paid|failed`), `dateFrom?`/`dateTo?` (ISO dates,
`created_at` range), `search?` (customer name/email/phone), `page?`.

**Renders**: each row's customer, amount (halalas → SAR via the existing display convention),
outcome, failure reason (when `failed`), `attempt_number`, and `kind` (`initial` vs `renewal` —
Phase 7's own column) labeled in Arabic as "دفعة أولى" / "تجديد".

---

## `/admin/cities` (Server Component read + inline create/edit)

**List query**: all `cities` rows, ordered by `name_ar`. No pagination (this project's own city
count is small — Phase 1 seeds a single row; unlike orders/subscriptions/payments, nothing in
this phase's scope suggests city count will ever need it).

**Renders**: name, active flag, delivery fee override, an edit entry point opening `CityForm` in
edit mode, and an "add city" entry point opening the same form in create mode (mirroring
`components/address/AddressForm.tsx`'s own create-vs-edit-in-one-component shape).

---

## `POST /api/admin/cities`

**Request**:
```json
{ "nameAr": "جدة", "isActive": true, "deliveryFeeOverride": 15 }
```
Validated by `lib/validation/city.ts` — `nameAr` required; `deliveryFeeOverride` optional,
non-negative when present.

**Behavior**: `requireAdmin()`, then insert via the caller's own RLS-scoped client
(`cities_insert_admin` policy, data-model.md) — never service-role.

**Response — success**: `201 { "city": { "id": "uuid", "nameAr": "جدة", "isActive": true, "deliveryFeeOverride": 15 } }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": {...} }`.

---

## `PATCH /api/admin/cities/[id]`

**Request** (any subset):
```json
{ "isActive": false }
```

**Behavior**: `requireAdmin()`, then update via `cities_update_admin`. Deactivating (`isActive:
false`) takes effect immediately for the customer-facing address form's city options (FR-014) —
`AddressForm`'s own existing city query already filters `is_active = true` (Phase 1, unchanged),
so no separate propagation step is needed. Never alters or invalidates any existing address that
already references this city (FR-014, Phase 1's own established rule).

**Response — success**: `200 { "city": { "id": "uuid", "nameAr": "جدة", "isActive": false, "deliveryFeeOverride": 15 } }`.

**Response — not found**: `404 { "error": "not_found" }`.

**Response — validation error**: `400 { "error": "validation_failed", "fields": {...} }`.

## Notes

- No `DELETE` endpoint for cities — deactivation is the only removal path (data-model.md, FR-013/014).
- Both endpoints return `401`/`403` per `requireAdmin()` and are unreachable from a customer's own
  session (FR-016).
